// Procedural Web Audio API Synthesizer for Weapon Mechanical & Energy Activation Sounds

class WeaponSoundEngine {
  private ctx: AudioContext | null = null;
  public enabled: boolean = true;

  private getContext(): AudioContext | null {
    if (!this.enabled) return null;
    if (!this.ctx && typeof window !== 'undefined') {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
    return this.ctx;
  }

  public playWeaponActivation(weaponId: string, speed: number = 1) {
    const ctx = this.getContext();
    if (!ctx) return;

    const now = ctx.currentTime;
    const invSpeed = 1 / Math.max(0.25, speed);

    switch (weaponId) {
      case 'golden-tycoon': {
        // 1. Metallic Hammer Click
        this.playClick(ctx, now, 1400, 0.04);
        // 2. Coin Spin High Golden Chime
        this.playTone(ctx, now + 0.08 * invSpeed, 1760, 2637, 0.38 * invSpeed, 'triangle', 0.16);
        this.playTone(ctx, now + 0.14 * invSpeed, 2637, 3520, 0.45 * invSpeed, 'sine', 0.14);
        // 3. Hydraulic Recoil Thump
        this.playTone(ctx, now + 0.18 * invSpeed, 180, 52, 0.32 * invSpeed, 'sine', 0.28);
        break;
      }

      case 'laser-buster': {
        // 4-cell sequential rising sci-fi charge + dorsal fin vent
        [0, 0.07, 0.14, 0.21].forEach((offset, idx) => {
          const baseFreq = 420 + idx * 240;
          this.playTone(
            ctx,
            now + offset * invSpeed,
            baseFreq,
            baseFreq + 320,
            0.14 * invSpeed,
            'sawtooth',
            0.1
          );
        });
        // Plasma chamber resonance
        this.playTone(ctx, now + 0.25 * invSpeed, 980, 220, 0.42 * invSpeed, 'triangle', 0.22);
        break;
      }

      case 'cyber-carbine': {
        // Dual tactical bolt cycle clacks + neon core hum
        this.playClick(ctx, now + 0.02 * invSpeed, 950, 0.06);
        this.playTone(ctx, now + 0.05 * invSpeed, 320, 880, 0.18 * invSpeed, 'sawtooth', 0.14);
        this.playClick(ctx, now + 0.24 * invSpeed, 1120, 0.06);
        this.playTone(ctx, now + 0.27 * invSpeed, 440, 1240, 0.25 * invSpeed, 'triangle', 0.16);
        break;
      }

      case 'banana-blaster': {
        // Bio-plasma peel servo open + golden core harmonic wobble
        this.playTone(ctx, now, 280, 760, 0.28 * invSpeed, 'sine', 0.18);
        this.playTone(ctx, now + 0.15 * invSpeed, 760, 1180, 0.35 * invSpeed, 'triangle', 0.16);
        this.playTone(ctx, now + 0.32 * invSpeed, 580, 240, 0.25 * invSpeed, 'sine', 0.15);
        break;
      }

      case 'storm-caller': {
        // High-voltage Tesla coil zap + electric arc crackle
        this.playNoiseBurst(ctx, now + 0.04 * invSpeed, 0.45 * invSpeed, 0.18);
        this.playTone(ctx, now, 520, 1960, 0.22 * invSpeed, 'sawtooth', 0.14);
        this.playTone(ctx, now + 0.18 * invSpeed, 1480, 310, 0.38 * invSpeed, 'sawtooth', 0.16);
        break;
      }

      case 'super-soaker': {
        // Hydraulic pump whoosh + pressurized aqua bubble chime
        this.playNoiseBurst(ctx, now, 0.22 * invSpeed, 0.15);
        this.playTone(ctx, now + 0.05 * invSpeed, 380, 980, 0.26 * invSpeed, 'sine', 0.18);
        this.playTone(ctx, now + 0.22 * invSpeed, 640, 1420, 0.28 * invSpeed, 'triangle', 0.15);
        break;
      }

      case 'firework-launcher': {
        // Fuse sizzle + whistling rocket spin + festive sparkle pop
        this.playNoiseBurst(ctx, now, 0.32 * invSpeed, 0.16);
        this.playTone(ctx, now + 0.04 * invSpeed, 520, 1850, 0.35 * invSpeed, 'sine', 0.15);
        this.playTone(ctx, now + 0.28 * invSpeed, 240, 65, 0.32 * invSpeed, 'triangle', 0.24);
        break;
      }

      case 'bio-plasma': {
        // Radioactive green Tesla hum + glass coil resonance
        this.playTone(ctx, now, 180, 920, 0.25 * invSpeed, 'sawtooth', 0.15);
        this.playNoiseBurst(ctx, now + 0.08 * invSpeed, 0.35 * invSpeed, 0.14);
        this.playTone(ctx, now + 0.2 * invSpeed, 920, 340, 0.35 * invSpeed, 'sine', 0.18);
        break;
      }

      case 'card-gun': {
        // Crisp royal card riffle shuffle + magical casino chime
        [0, 0.06, 0.12, 0.18].forEach((offset, idx) => {
          this.playClick(ctx, now + offset * invSpeed, 1200 + idx * 280, 0.045);
        });
        this.playTone(ctx, now + 0.2 * invSpeed, 1318, 2637, 0.38 * invSpeed, 'triangle', 0.15);
        break;
      }

      case 'minigun': {
        // High-speed rotary motor spin-up + 6-barrel rapid mechanical clatter
        this.playTone(ctx, now, 140, 460, 0.48 * invSpeed, 'sawtooth', 0.18);
        [0.05, 0.12, 0.19, 0.26, 0.33, 0.4].forEach((offset) => {
          this.playClick(ctx, now + offset * invSpeed, 780, 0.04);
        });
        break;
      }
    }
  }

  private playTone(
    ctx: AudioContext,
    startTime: number,
    startFreq: number,
    endFreq: number,
    duration: number,
    type: OscillatorType,
    volume: number
  ) {
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(startFreq, startTime);
    osc.frequency.exponentialRampToValueAtTime(Math.max(20, endFreq), startTime + duration);

    gain.gain.setValueAtTime(0.001, startTime);
    gain.gain.linearRampToValueAtTime(volume, startTime + duration * 0.15);
    gain.gain.exponentialRampToValueAtTime(0.001, startTime + duration);

    osc.connect(gain);
    gain.connect(ctx.destination);

    osc.start(startTime);
    osc.stop(startTime + duration + 0.02);
  }

  private playClick(ctx: AudioContext, startTime: number, freq: number, duration: number) {
    this.playTone(ctx, startTime, freq, freq * 0.35, duration, 'square', 0.15);
  }

  private playNoiseBurst(ctx: AudioContext, startTime: number, duration: number, volume: number) {
    const bufferSize = Math.floor(ctx.sampleRate * duration);
    const buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) {
      data[i] = (Math.random() * 2 - 1) * Math.exp(-i / (bufferSize * 0.45));
    }

    const noise = ctx.createBufferSource();
    noise.buffer = buffer;

    const filter = ctx.createBiquadFilter();
    filter.type = 'bandpass';
    filter.frequency.setValueAtTime(2400, startTime);
    filter.Q.setValueAtTime(2.5, startTime);

    const gain = ctx.createGain();
    gain.gain.setValueAtTime(volume, startTime);
    gain.gain.exponentialRampToValueAtTime(0.001, startTime + duration);

    noise.connect(filter);
    filter.connect(gain);
    gain.connect(ctx.destination);

    noise.start(startTime);
  }
}

export const soundEngine = new WeaponSoundEngine();
