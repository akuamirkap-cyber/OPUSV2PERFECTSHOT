export type WeaponId =
  | 'golden-tycoon'
  | 'laser-buster'
  | 'cyber-carbine'
  | 'banana-blaster'
  | 'storm-caller'
  | 'super-soaker'
  | 'firework-launcher'
  | 'bio-plasma'
  | 'card-gun'
  | 'minigun';

export interface WeaponSpec {
  id: WeaponId;
  batch: 1 | 2;
  number: string;
  serialCode: string;
  name: string;
  mythicTitle: string;
  indonesianTitle: string;
  rarity: string;
  mythicRarity: string;
  stars: number;
  rarityBadgeStyle: {
    bg: string;
    border: string;
    text: string;
  };
  primaryColor: string;
  secondaryColor: string;
  glowColor: string;
  cardBg: string;
  description: string;
  stats: {
    power: number;
    resonance: number;
    craftsmanship: number;
  };
  mechanicalActions: string[];
  svgFeatures: string[];
}

export const WEAPONS_DATA: WeaponSpec[] = [
  // ==================== BATCH 2: 5 SENJATA BARU (NEW!) ====================
  {
    id: 'super-soaker',
    batch: 2,
    number: '06',
    serialCode: 'LTD-006 // AQUA-TYPHOON',
    name: 'SUPER SOAKER',
    mythicTitle: 'HYDRO PRESSURIZED EDITION',
    indonesianTitle: 'Pistol Air Bertekanan Tinggi Tangki Biru & Pompa Oranye',
    rarity: 'AQUA',
    mythicRarity: 'MYTHIC HYDRO',
    stars: 5,
    rarityBadgeStyle: {
      bg: 'rgba(3, 105, 161, 0.85)',
      border: '#F97316',
      text: '#FDE047',
    },
    primaryColor: '#22C55E',
    secondaryColor: '#00B4D8',
    glowColor: 'rgba(34, 197, 94, 0.62)',
    cardBg:
      'radial-gradient(circle at 50% 45%, rgba(0, 180, 216, 0.52) 0%, rgba(37, 99, 235, 0.38) 48%, #071026 88%)',
    description:
      'Blaster air bertekanan tinggi dengan tangki air biru transparan berlogo tetesan air (💧), bodi hijau limau segar berstrip kuning-oranye, manometer pengukur tekanan di belakang, serta pompa bawah berulir oranye.',
    stats: {
      power: 96,
      resonance: 99,
      craftsmanship: 100,
    },
    mechanicalActions: [
      'Gagang pompa oranye berulir di bawah laras bergerak memompa maju-mundur secara hidrolik',
      'Jarum merah pada manometer tekanan (Pressure Gauge) berputar cepat ke zona merah maksimum',
      'Air biru di dalam tangki atas berguncang bergelombang dengan gelembung udara naik',
      'Nosel oranye depan memancarkan mahkota cipratan air & tetesan air melayang (Tanpa Peluru!)',
    ],
    svgFeatures: [
      'Tangki Air Transparan + Logo 💧',
      'Manometer Jarum Tekanan Aktif',
      'Pompa Bawah Oranye Berulir',
      'Efek Cipratan & Gelembung Air',
    ],
  },
  {
    id: 'firework-launcher',
    batch: 2,
    number: '07',
    serialCode: 'LTD-007 // STAR-FESTIVAL',
    name: 'FIREWORK LAUNCHER',
    mythicTitle: 'GRAND CARNIVAL EDITION',
    indonesianTitle: 'Peluncur Kembang Api Bundel 4 Roket Bintang & Sumbu Api',
    rarity: 'FESTIVAL',
    mythicRarity: 'MYTHIC PYRO',
    stars: 5,
    rarityBadgeStyle: {
      bg: 'rgba(88, 28, 135, 0.88)',
      border: '#F59E0B',
      text: '#FDE047',
    },
    primaryColor: '#EF4444',
    secondaryColor: '#F59E0B',
    glowColor: 'rgba(245, 158, 11, 0.65)',
    cardBg:
      'radial-gradient(circle at 50% 46%, rgba(239, 68, 68, 0.44) 0%, rgba(88, 28, 135, 0.42) 50%, #090618 88%)',
    description:
      'Peluncur bundel meriam kembang api bermotif biru-merah berbintang emas (★) yang diikat 2 cincin kuningan emas tebal, dilengkapi sumbu api menyala di belakang, knalpot api belakang, dual grip, dan 4 hulu ledak kerucut roket.',
    stats: {
      power: 100,
      resonance: 98,
      craftsmanship: 100,
    },
    mechanicalActions: [
      'Sumbu tali kepang di bagian atas-belakang menyala memercikkan api bintang keemasan',
      'Knalpot pendorong belakang menyemburkan lidah api berlapis kuning-oranye yang berkobar',
      '4 kerucut roket merah-biru di ujung tabung bergetar & memompa siap luncur di soketnya',
      'Bunga api kembang api & konfeti warna-warni berpendar di sekeliling moncong (Tanpa Peluru Keluar!)',
    ],
    svgFeatures: [
      'Bundel Tabung Bintang Emas ★',
      '4 Kerucut Hulu Ledak Roket',
      'Sumbu Api & Knalpot Belakang',
      'Banner Ungu-Emas Bersayap',
    ],
  },
  {
    id: 'bio-plasma',
    batch: 2,
    number: '08',
    serialCode: 'LTD-008 // EMERALD-TESLA',
    name: 'BIO-PLASMA GUN',
    mythicTitle: 'GAMMA OVERCHARGE EDITION',
    indonesianTitle: 'Pistol Tabung Kaca Plasma Hijau Neon & Petir Gamma',
    rarity: 'GAMMA',
    mythicRarity: 'MYTHIC GAMMA',
    stars: 5,
    rarityBadgeStyle: {
      bg: 'rgba(6, 78, 59, 0.88)',
      border: '#10B981',
      text: '#A7F3D0',
    },
    primaryColor: '#10B981',
    secondaryColor: '#6EE7B7',
    glowColor: 'rgba(16, 185, 129, 0.68)',
    cardBg:
      'radial-gradient(circle at 50% 46%, rgba(16, 185, 129, 0.45) 0%, rgba(126, 34, 206, 0.38) 50%, #080716 88%)',
    description:
      'Blaster sci-fi berbahan baja gunmetal gelap dengan tabung kaca silinder transparan berisi cairan plasma hijau zamrud dan sambaran petir putih-hijau di dalamnya, kabel konduit atas, serta gagang berurat neon hijau.',
    stats: {
      power: 99,
      resonance: 100,
      craftsmanship: 99,
    },
    mechanicalActions: [
      'Petir plasma putih-hijau di dalam tabung kaca silinder menyambar dan bergelombang hebat',
      'Urat energi hijau di dalam gagang pistol & indikator kapsul samping berkedip terang',
      'Kabel konduit lengkung di atas bodi belakang menyalurkan pulsa tegangan tinggi ke tabung',
      'Moncong silinder depan memancarkan lensa pusaran cahaya zamrud (Tanpa Peluru Keluar!)',
    ],
    svgFeatures: [
      'Tabung Kaca Plasma Transparan',
      'Petir Internal Hijau Zamrud',
      'Gagang Gunmetal Urat Neon',
      'Kabel Konduit & Sirip Pendingin',
    ],
  },
  {
    id: 'card-gun',
    batch: 2,
    number: '09',
    serialCode: 'LTD-009 // ROYAL-FLUSH',
    name: 'CARD GUN',
    mythicTitle: 'ROYAL CASINO DEALER EDITION',
    indonesianTitle: 'Pistol Kasino Merah-Emas 4 Simbol Kartu (♥ ♠ ♦ ♣)',
    rarity: 'ROYAL FLUSH',
    mythicRarity: 'MYTHIC DEALER',
    stars: 5,
    rarityBadgeStyle: {
      bg: 'rgba(127, 29, 29, 0.88)',
      border: '#FBBF24',
      text: '#FEF08A',
    },
    primaryColor: '#EF4444',
    secondaryColor: '#38BDF8',
    glowColor: 'rgba(239, 68, 68, 0.62)',
    cardBg:
      'radial-gradient(circle at 50% 46%, rgba(225, 29, 72, 0.44) 0%, rgba(88, 28, 135, 0.42) 50%, #080618 88%)',
    description:
      'Pistol kasino mewah berlapis merah-putih dan lis emas kerajaan. Memiliki kipas 4 kartu remi bercahaya sian di slot atas, jendela samping berisi 4 kartu Royal (♥ ♠ ♦ ♣), gagang berhias berlian emas, dan kartu melayang di moncong.',
    stats: {
      power: 97,
      resonance: 99,
      craftsmanship: 100,
    },
    mechanicalActions: [
      'Kipas 4 kartu remi di slot atas mengocok dan mengembang dengan pendaran neon biru sian',
      '4 kartu simbol (♥ Hati, ♠ Sekop, ♦ Wajik, ♣ Keriting) di bodi samping menyala berurutan',
      'Permata wajik emas pada gagang merah dan indikator sian berkilau serentak',
      'Kartu As Hati, As Sekop, & Wajik berputar melayang di pusaran energi sian moncong (Tanpa Peluru!)',
    ],
    svgFeatures: [
      'Kipas Kartu Slot Atas Bercahaya',
      '4 Kartu Royal (♥ ♠ ♦ ♣) di Laras',
      'Gagang Merah Berlian Emas ♦',
      'Pusaran Kartu As di Moncong',
    ],
  },
  {
    id: 'minigun',
    batch: 2,
    number: '10',
    serialCode: 'LTD-010 // VULCAN-TITAN',
    name: 'MINIGUN',
    mythicTitle: 'HEAVY GATLING OVERLORD',
    indonesianTitle: 'Meriam Putar 6-Laras Baja Hitam & Drum Magasin Berat',
    rarity: 'EPIC',
    mythicRarity: 'MYTHIC TITAN',
    stars: 5,
    rarityBadgeStyle: {
      bg: 'rgba(126, 34, 206, 0.88)',
      border: '#C084FC',
      text: '#F3E8FF',
    },
    primaryColor: '#F59E0B',
    secondaryColor: '#94A3B8',
    glowColor: 'rgba(245, 158, 11, 0.62)',
    cardBg:
      'radial-gradient(circle at 50% 46%, rgba(245, 158, 11, 0.38) 0%, rgba(88, 28, 135, 0.42) 50%, #090914 88%)',
    description:
      'Meriam putar Gatling kelas berat berbahan baja titanium gelap dengan 6 laras putar yang ujungnya berpijar kuning-emas panas, gagang belakang bergaya gergaji mesin, pegangan jinjing atas, dan tabung drum amunisi besar di bawah.',
    stats: {
      power: 100,
      resonance: 97,
      craftsmanship: 100,
    },
    mechanicalActions: [
      'Kluster 6-laras Gatling berputar cepat secara mekanis dengan efek rotasi laras paralel',
      'Ke-6 cincin ujung moncong laras berpijar kuning-oranye membara karena gesekan rotasi tinggi',
      'Tabung drum amunisi bawah dan motor penggerak tengah bergetar dengan torsi mesin berat',
      'Cincin korona panas keemasan berputar di ujung ke-6 laras (Tanpa Mengeluarkan Peluru!)',
    ],
    svgFeatures: [
      'Kluster 6-Laras Gatling Putar',
      '6 Moncong Pijar Emas Membara',
      'Tabung Drum Magasin Berpaku',
      'Gagang Belakang & Handle Atas',
    ],
  },

  // ==================== BATCH 1: 5 SENJATA KLASIK PERTAMA ====================
  {
    id: 'golden-tycoon',
    batch: 1,
    number: '01',
    serialCode: 'LTD-001 // 24K-IMPERIAL',
    name: 'GOLDEN TYCOON',
    mythicTitle: 'SOVEREIGN EMPEROR EDITION',
    indonesianTitle: 'Pistol Bangsawan Emas 24K & Berlian Rubi ($)',
    rarity: 'ROYAL GOLD',
    mythicRarity: 'MYTHIC SOVEREIGN',
    stars: 5,
    rarityBadgeStyle: {
      bg: 'rgba(180, 83, 9, 0.45)',
      border: '#FBBF24',
      text: '#FEF08A',
    },
    primaryColor: '#F59E0B',
    secondaryColor: '#9F1239',
    glowColor: 'rgba(245, 158, 11, 0.65)',
    cardBg:
      'radial-gradient(circle at 52% 46%, rgba(245, 158, 11, 0.46) 0%, rgba(136, 19, 55, 0.34) 45%, #070913 88%)',
    description:
      'Mahakarya pistol flintlock bangsawan berlapis emas 24K & beludru merah marun kerajaan. Dilengkapi ukiran sulur barok rumit, medali koin Dolar ($) 3D berputar, silinder bawah 5 cincin berulir, serta 3 berlian rubi merah menyala.',
    stats: {
      power: 98,
      resonance: 96,
      craftsmanship: 100,
    },
    mechanicalActions: [
      'Pelatuk belakang (Flintlock Gold Hammer) mengokang -42° & memantik percikan emas di ruang bakar',
      'Koin Medali Emas ($) 3D berputar 360° memancarkan gelombang cincin kejayaan kerajaan',
      '3 Berlian Rubi Merah menyala kaskade berurutan dengan bias cahaya kristal silang',
      'Silinder bawah berulir (Ribbed Under-Lug) memompa mundur & moncong memancarkan Mahkota Emas (Tanpa Peluru!)',
    ],
    svgFeatures: [
      'Ukiran Barok Emas 24K Berlapis',
      'Koin $ 3D + Kilau Logam Bergerak',
      '3 Permata Rubi Facet Berlian',
      'Halo Mandala Emas Kerajaan',
    ],
  },
  {
    id: 'laser-buster',
    batch: 1,
    number: '02',
    serialCode: 'LTD-002 // CRIMSON-CORE',
    name: 'LASER BUSTER',
    mythicTitle: 'OMEGA HYPERNOVA EDITION',
    indonesianTitle: 'Blaster Fusi Torpedo Perak & 4 Kapsul Plasma Merah',
    rarity: 'LEGEND',
    mythicRarity: 'MYTHIC LEGEND',
    stars: 5,
    rarityBadgeStyle: {
      bg: 'rgba(30, 41, 59, 0.9)',
      border: '#F59E0B',
      text: '#FBBF24',
    },
    primaryColor: '#EF4444',
    secondaryColor: '#E2E8F0',
    glowColor: 'rgba(239, 68, 68, 0.68)',
    cardBg:
      'radial-gradient(circle at 48% 48%, rgba(225, 29, 72, 0.48) 0%, rgba(88, 28, 135, 0.34) 48%, #070A18 88%)',
    description:
      'Blaster fusi aerodinamis berbalut krom putih-perak mengilap dengan 4 jendela kapsul plasma merah berfilamen energi, sirip punggung artikulasi, gagang berinti merah, serta sayap perisai crimson-magenta.',
    stats: {
      power: 99,
      resonance: 97,
      craftsmanship: 98,
    },
    mechanicalActions: [
      '4 Kapsul Plasma Merah menyala kaskade berurutan (1 → 2 → 3 → 4) dengan filamen fusi internal',
      'Sirip Punggung (Dorsal Fin) terangkat otomatis mengeluarkan uap panas plasma merah',
      'Inti merah vertikal pada gagang mengalirkan pulsa foton menuju ruang reaktor utama',
      'Hentakan recoil presisi disertai Bintang Fusi Crimson & Cincin Korona di ujung moncong (Tanpa Peluru!)',
    ],
    svgFeatures: [
      '4 Kapsul Reaktor Berfilamen',
      'Bodi Torpedo Krom + Sheen Sweep',
      'Sirip Punggung Ventilasi Aktif',
      'Sayap Perisai Crimson & Koin Emas',
    ],
  },
  {
    id: 'cyber-carbine',
    batch: 1,
    number: '03',
    serialCode: 'LTD-003 // NEON-VALKYRIE',
    name: 'CYBER PULSE SMG',
    mythicTitle: 'PHANTOM OVERCLOCK EDITION',
    indonesianTitle: 'Karabin Taktis Obsidian & Sirkuit Neon Biru Sian',
    rarity: 'PHANTOM',
    mythicRarity: 'MYTHIC PHANTOM',
    stars: 5,
    rarityBadgeStyle: {
      bg: 'rgba(15, 23, 42, 0.9)',
      border: '#38BDF8',
      text: '#7DD3FC',
    },
    primaryColor: '#00F0FF',
    secondaryColor: '#334155',
    glowColor: 'rgba(0, 240, 255, 0.62)',
    cardBg:
      'radial-gradient(circle at 52% 46%, rgba(56, 189, 248, 0.4) 0%, rgba(109, 40, 217, 0.36) 48%, #080917 88%)',
    description:
      'Senapan serbu taktis berbahan matte-titanium hitam dengan popor rangka neon sian, optik reflex holografik berbidik aktif, jendela bolt-carrier plasma, magasin lengkung 2 strip neon, dan pedestal cincin ungu-sian.',
    stats: {
      power: 96,
      resonance: 100,
      craftsmanship: 99,
    },
    mechanicalActions: [
      'Bolt-Carrier Plasma Sian di tengah bodi bergerak maju-mundur cepat dengan kilatan ruang bakar',
      'Lensa Optik Holografik atas memproyeksikan cincin radar bidik sian yang berputar',
      'Aliran arus data mengalir deras dari 2 strip neon magasin ke sirkuit L-shape di handguard',
      'Modul silinder bawah laras memompa & celah kompensator moncong memancarkan Sayap Ion Sian (Tanpa Peluru!)',
    ],
    svgFeatures: [
      'Popor Rangka Konduit Plasma',
      'Optik Reflex Reticle Aktif',
      'Magasin 2 Strip Neon + Indikator',
      'Pedestal Hologram Ungu-Sian',
    ],
  },
  {
    id: 'banana-blaster',
    batch: 1,
    number: '04',
    serialCode: 'LTD-004 // SOLAR-POTASSIUM',
    name: 'BANANA BLASTER',
    mythicTitle: 'CELESTIAL GOLDEN HARVEST',
    indonesianTitle: 'Blaster Bio-Plasma Pisang Emas & Eksoskeleton Krom',
    rarity: 'EPIC',
    mythicRarity: 'MYTHIC CELESTIAL',
    stars: 5,
    rarityBadgeStyle: {
      bg: 'rgba(30, 27, 75, 0.9)',
      border: '#EC4899',
      text: '#F9A8D4',
    },
    primaryColor: '#FACC15',
    secondaryColor: '#CBD5E1',
    glowColor: 'rgba(250, 204, 21, 0.65)',
    cardBg:
      'radial-gradient(circle at 50% 48%, rgba(234, 179, 8, 0.46) 0%, rgba(30, 58, 138, 0.36) 50%, #070D1E 88%)',
    description:
      'Senjata bio-mekanik langka berbentuk pisang emas melengkung dengan tangkai kayu bertekstur, kerah eksoskeleton krom perak berinti oval surya, kelopak kulit pisang artikulasi atas-bawah, dan nosel teleskopik.',
    stats: {
      power: 97,
      resonance: 98,
      craftsmanship: 100,
    },
    mechanicalActions: [
      'Kelopak Kulit Pisang Emas atas & bawah membuka melebar (±11°) melepaskan pendaran bio-surya',
      'Tabung Plasma Emas tengah & inti oval pada kerah krom berdenyut dengan gelombang energi berlapis',
      'Nosel Mekanik Perak berulir di ujung depan memendek & memanjang secara hidrolik',
      'Kelopak daun emas & bintang 4-sudut berpendar mengelilingi mahkota moncong (Tanpa Peluru!)',
    ],
    svgFeatures: [
      'Kelopak Pisang Emas Artikulasi',
      'Kerah Krom Perak + Inti Oval Surya',
      'Tabung Bio-Plasma Gelombang',
      'Partikel Daun Emas & Bintang',
    ],
  },
  {
    id: 'storm-caller',
    batch: 1,
    number: '05',
    serialCode: 'LTD-005 // THUNDER-VALKYRIE',
    name: 'STORM CALLER',
    mythicTitle: 'TEMPEST ARCHANGEL EDITION',
    indonesianTitle: 'Blaster Petir Kristal Es & Kumparan Kapasitor Tesla',
    rarity: 'STORM',
    mythicRarity: 'MYTHIC TEMPEST',
    stars: 5,
    rarityBadgeStyle: {
      bg: 'rgba(8, 47, 73, 0.92)',
      border: '#38BDF8',
      text: '#E0F2FE',
    },
    primaryColor: '#38BDF8',
    secondaryColor: '#1E293B',
    glowColor: 'rgba(56, 189, 248, 0.72)',
    cardBg:
      'radial-gradient(circle at 52% 46%, rgba(56, 189, 248, 0.48) 0%, rgba(88, 28, 135, 0.4) 50%, #070817 88%)',
    description:
      'Blaster badai petir berdesain sayap kristal es geometris tajam dengan laras obsidian heksagonal berlogo petir (⚡), emblem belah ketupat petir tengah, gagang berinti kilat, dan moncong kumparan Tesla.',
    stats: {
      power: 100,
      resonance: 100,
      craftsmanship: 99,
    },
    mechanicalActions: [
      'Sayap Kristal Es atas & bawah merentang keluar (±12°) dengan getaran resonansi tegangan tinggi',
      'Emblem Berlian Petir [⚡] tengah & simbol petir di laras menyala putih-sian menyilaukan',
      'Jaringan Busur Petir SVG (Tesla Lightning Arcs) menyambar mengelilingi sayap, gagang, & bodi',
      'Kumparan kapasitor Tesla di moncong memancarkan Bola Plasma Petir & Cincin Badai (Tanpa Peluru!)',
    ],
    svgFeatures: [
      'Sayap Kristal Es Multi-Facet',
      'Emblem Belah Ketupat Petir [⚡]',
      'Jaringan Busur Petir SVG Aktif',
      'Kumparan Tesla & Pedestal Badai',
    ],
  },
];
