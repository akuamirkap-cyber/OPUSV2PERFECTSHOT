import { useState, useRef, useCallback } from 'react';
import { WEAPONS_DATA, WeaponSpec } from './data/weaponsData';
import { CollageShowcaseGrid } from './components/CollageShowcaseGrid';
import { StudioStageView } from './components/StudioStageView';
import { soundEngine } from './utils/soundEffects';
import {
  LayoutGrid,
  Focus,
  Zap,
  Play,
  Pause,
  Volume2,
  VolumeX,
  CheckCircle,
  Crown,
} from 'lucide-react';

export function App() {
  // Default to showing all 10 weapons together (with the 5 NEW weapons right at the top!)
  const [viewMode, setViewMode] = useState<'collage' | 'studio'>('collage');
  const [selectedWeapon, setSelectedWeapon] = useState<WeaponSpec>(WEAPONS_DATA[0]);

  // Mythic Collector Aura & Holo-Sheen enabled by default for maximum visual splendor
  const [isMythic, setIsMythic] = useState<boolean>(true);

  // Active state per weapon (supports all 10 weapons!)
  const [activeWeapons, setActiveWeapons] = useState<Record<string, boolean>>({
    'super-soaker': false,
    'firework-launcher': false,
    'bio-plasma': false,
    'card-gun': false,
    'minigun': false,
    'golden-tycoon': false,
    'laser-buster': false,
    'cyber-carbine': false,
    'banana-blaster': false,
    'storm-caller': false,
  });

  const [speed, setSpeed] = useState<number>(1);
  const [soundEnabled, setSoundEnabled] = useState<boolean>(true);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const burstTimeoutsRef = useRef<Record<string, number>>({});

  const showToast = useCallback((msg: string) => {
    setToastMessage(msg);
    window.setTimeout(() => {
      setToastMessage((prev) => (prev === msg ? null : prev));
    }, 3000);
  }, []);

  const toggleSound = () => {
    const next = !soundEnabled;
    setSoundEnabled(next);
    soundEngine.enabled = next;
  };

  // Trigger a single mechanical activation cycle (~1.35s) for a weapon
  const triggerWeaponBurst = useCallback(
    (weaponId: string) => {
      soundEngine.playWeaponActivation(weaponId, speed);

      if (burstTimeoutsRef.current[weaponId]) {
        window.clearTimeout(burstTimeoutsRef.current[weaponId]);
      }

      setActiveWeapons((prev) => ({ ...prev, [weaponId]: true }));

      const durationMs = Math.round(1350 / speed);
      burstTimeoutsRef.current[weaponId] = window.setTimeout(() => {
        setActiveWeapons((prev) => ({ ...prev, [weaponId]: false }));
      }, durationMs);
    },
    [speed]
  );

  // Toggle continuous loop animation for a single weapon
  const toggleWeaponLoop = useCallback(
    (weaponId: string) => {
      if (burstTimeoutsRef.current[weaponId]) {
        window.clearTimeout(burstTimeoutsRef.current[weaponId]);
      }
      setActiveWeapons((prev) => {
        const nextState = !prev[weaponId];
        if (nextState) {
          soundEngine.playWeaponActivation(weaponId, speed);
        }
        return { ...prev, [weaponId]: nextState };
      });
    },
    [speed]
  );

  // Trigger ALL 10 weapons simultaneously!
  const allAreActive = WEAPONS_DATA.every((w) => activeWeapons[w.id]);

  const toggleAllWeaponsLoop = () => {
    const targetState = !allAreActive;
    Object.values(burstTimeoutsRef.current).forEach((t) => window.clearTimeout(t));
    if (targetState) {
      soundEngine.playWeaponActivation(selectedWeapon.id, speed);
    }
    const nextMap: Record<string, boolean> = {};
    WEAPONS_DATA.forEach((w) => {
      nextMap[w.id] = targetState;
    });
    setActiveWeapons(nextMap);
  };

  const triggerAllBurst = () => {
    WEAPONS_DATA.forEach((w, idx) => {
      window.setTimeout(() => {
        triggerWeaponBurst(w.id);
      }, idx * 90);
    });
  };

  // Download standalone .SVG file
  const handleDownloadSvg = (weapon: WeaponSpec, svgEl: SVGSVGElement | null) => {
    if (!svgEl) return;
    const serializer = new XMLSerializer();
    let source = serializer.serializeToString(svgEl);
    if (!source.match(/^<svg[^>]+xmlns="http\:\/\/www\.w3\.org\/2000\/svg"/)) {
      source = source.replace(/^<svg/, '<svg xmlns="http://www.w3.org/2000/svg"');
    }
    const svgBlob = new Blob([source], { type: 'image/svg+xml;charset=utf-8' });
    const svgUrl = URL.createObjectURL(svgBlob);
    const downloadLink = document.createElement('a');
    downloadLink.href = svgUrl;
    downloadLink.download = `${weapon.id}-mythic-2d.svg`;
    document.body.appendChild(downloadLink);
    downloadLink.click();
    document.body.removeChild(downloadLink);
    URL.revokeObjectURL(svgUrl);
    showToast(`File ${weapon.id}-mythic-2d.svg berhasil diunduh!`);
  };

  // Copy standalone SVG code to clipboard
  const handleCopySvgCode = (weapon: WeaponSpec, svgEl: SVGSVGElement | null): boolean => {
    if (!svgEl) return false;
    const serializer = new XMLSerializer();
    const source = serializer.serializeToString(svgEl);
    navigator.clipboard.writeText(source);
    showToast(`Kode SVG 2D "${weapon.name}" berhasil disalin ke Clipboard!`);
    return true;
  };

  const handleOpenInStudio = (weapon: WeaponSpec) => {
    setSelectedWeapon(weapon);
    setViewMode('studio');
    triggerWeaponBurst(weapon.id);
  };

  return (
    <div className="min-h-screen bg-[#05070E] text-slate-100 flex flex-col justify-between relative selection:bg-amber-400 selection:text-slate-950">
      {/* Subtle Ambient Top Spotlight */}
      <div
        className="pointer-events-none fixed top-0 left-1/2 -translate-x-1/2 w-[960px] h-[340px] rounded-full blur-[140px] opacity-30 z-0 transition-all duration-700"
        style={{ background: selectedWeapon.primaryColor }}
      />

      {/* ==================== TOP STUDIO HEADER BAR ==================== */}
      <header className="sticky top-0 z-40 bg-slate-950/88 backdrop-blur-xl border-b border-amber-500/20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3.5 flex flex-wrap items-center justify-between gap-4">
          {/* Brand Title */}
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-gradient-to-br from-amber-300 via-rose-500 to-sky-400 p-[2px] shadow-[0_0_25px_rgba(245,158,11,0.4)]">
              <div className="w-full h-full bg-slate-950 rounded-[14px] flex items-center justify-center">
                <Crown className="w-5 h-5 text-amber-300 fill-amber-300/30" />
              </div>
            </div>
            <div>
              <div className="flex flex-wrap items-center gap-2">
                <h1 className="font-display font-extrabold text-base sm:text-lg tracking-wider uppercase bg-gradient-to-r from-amber-200 via-yellow-300 to-sky-300 bg-clip-text text-transparent">
                  10 SENJATA SVG 2D • MYTHIC COLLECTOR STUDIO
                </h1>
                <span className="hidden sm:inline-block px-2.5 py-0.5 text-[10px] font-mono-code font-bold uppercase rounded-full bg-emerald-500/15 text-emerald-300 border border-emerald-400/40">
                  ★ +5 Senjata Baru • Tanpa Peluru
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Koleksi 10 Vektor 2D Presisi Tinggi (Set #1 & Set #2) • Klik Senjata untuk Animasi Mekanik Saat Digunakan
              </p>
            </div>
          </div>

          {/* Right Controls: View Mode Switcher, Mythic Toggle, Trigger All 10, & Audio */}
          <div className="flex flex-wrap items-center gap-2">
            {/* View Mode Toggle Pills */}
            <div className="bg-slate-900 p-1 rounded-xl border border-slate-800 flex items-center">
              <button
                onClick={() => setViewMode('collage')}
                className={`px-3 py-1.5 rounded-lg font-display font-bold text-xs uppercase tracking-wider flex items-center gap-1.5 transition cursor-pointer ${
                  viewMode === 'collage'
                    ? 'bg-amber-400 text-slate-950 shadow'
                    : 'text-slate-300 hover:text-white'
                }`}
              >
                <LayoutGrid className="w-3.5 h-3.5" />
                <span>Galeri 10 Senjata</span>
              </button>
              <button
                onClick={() => setViewMode('studio')}
                className={`px-3 py-1.5 rounded-lg font-display font-bold text-xs uppercase tracking-wider flex items-center gap-1.5 transition cursor-pointer ${
                  viewMode === 'studio'
                    ? 'bg-amber-400 text-slate-950 shadow'
                    : 'text-slate-300 hover:text-white'
                }`}
              >
                <Focus className="w-3.5 h-3.5" />
                <span>Studio Detail & Kode</span>
              </button>
            </div>

            {/* Mythic Awakened Aura Toggle */}
            <button
              onClick={() => setIsMythic((m) => !m)}
              className={`px-3 py-2 rounded-xl font-display font-bold text-xs uppercase tracking-wider flex items-center gap-1.5 border transition cursor-pointer ${
                isMythic
                  ? 'bg-amber-500/20 border-amber-400 text-amber-200 shadow-[0_0_20px_rgba(245,158,11,0.3)]'
                  : 'bg-slate-900 border-slate-700 text-slate-400 hover:text-white'
              }`}
              title="Aktifkan/Matikan Aura Langka Mythic & Kilau Logam Bergerak"
            >
              <Crown className="w-3.5 h-3.5 text-amber-300 fill-amber-300" />
              <span className="hidden xl:inline">Aura Mythic</span>
            </button>

            {/* Activate All 10 Weapons Buttons */}
            <button
              onClick={triggerAllBurst}
              className="px-3.5 py-2 rounded-xl bg-gradient-to-r from-amber-300 via-orange-400 to-rose-500 hover:brightness-110 text-slate-950 font-display font-extrabold text-xs uppercase tracking-wider flex items-center gap-1.5 shadow-lg transition active:scale-95 cursor-pointer"
            >
              <Zap className="w-3.5 h-3.5 fill-current" />
              <span>Gunakan Semua (10x)</span>
            </button>

            <button
              onClick={toggleAllWeaponsLoop}
              className={`px-3.5 py-2 rounded-xl font-display font-bold text-xs uppercase tracking-wider flex items-center gap-1.5 border transition cursor-pointer ${
                allAreActive
                  ? 'bg-emerald-500/25 border-emerald-400 text-emerald-200 shadow-[0_0_20px_rgba(16,185,129,0.3)]'
                  : 'bg-slate-900 hover:bg-slate-800 border-slate-700 text-slate-200'
              }`}
            >
              {allAreActive ? (
                <>
                  <Pause className="w-3.5 h-3.5 fill-current" />
                  <span className="hidden md:inline">Stop Semua</span>
                </>
              ) : (
                <>
                  <Play className="w-3.5 h-3.5 fill-current" />
                  <span className="hidden md:inline">Loop Semua 10</span>
                </>
              )}
            </button>

            {/* Sound Toggle */}
            <button
              onClick={toggleSound}
              title={soundEnabled ? 'Matikan Suara Mekanik' : 'Nyalakan Suara Mekanik'}
              className={`p-2 rounded-xl border transition cursor-pointer ${
                soundEnabled
                  ? 'bg-slate-900 border-slate-700 text-amber-300 hover:bg-slate-800'
                  : 'bg-slate-950 border-slate-800 text-slate-500 hover:text-slate-300'
              }`}
            >
              {soundEnabled ? (
                <Volume2 className="w-4 h-4" />
              ) : (
                <VolumeX className="w-4 h-4" />
              )}
            </button>
          </div>
        </div>
      </header>

      {/* ==================== MAIN CONTENT AREA ==================== */}
      <main className="relative z-10 flex-1 pt-6">
        {viewMode === 'collage' ? (
          <CollageShowcaseGrid
            activeWeapons={activeWeapons}
            onToggleWeapon={toggleWeaponLoop}
            onTriggerBurst={triggerWeaponBurst}
            onSelectForStudio={handleOpenInStudio}
            onDownloadSvg={handleDownloadSvg}
            speed={speed}
            isMythic={isMythic}
          />
        ) : (
          <StudioStageView
            selectedWeapon={selectedWeapon}
            onSelectWeapon={(w) => {
              setSelectedWeapon(w);
              triggerWeaponBurst(w.id);
            }}
            isActive={!!activeWeapons[selectedWeapon.id]}
            onToggleLoop={() => toggleWeaponLoop(selectedWeapon.id)}
            onTriggerBurst={() => triggerWeaponBurst(selectedWeapon.id)}
            speed={speed}
            onChangeSpeed={setSpeed}
            isMythic={isMythic}
            onToggleMythic={() => setIsMythic((m) => !m)}
            onDownloadSvg={handleDownloadSvg}
            onCopySvgCode={handleCopySvgCode}
          />
        )}
      </main>

      {/* ==================== TOAST NOTIFICATION ==================== */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 bg-slate-900/95 border border-amber-400/60 text-amber-200 px-4 py-3 rounded-2xl shadow-2xl flex items-center gap-2.5 animate-bounce">
          <CheckCircle className="w-4 h-4 text-amber-400 shrink-0" />
          <span className="text-xs font-medium">{toastMessage}</span>
        </div>
      )}
    </div>
  );
}

export default App;
