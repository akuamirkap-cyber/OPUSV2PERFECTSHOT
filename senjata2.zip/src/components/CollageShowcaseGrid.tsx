import React, { useState } from 'react';
import { WEAPONS_DATA, WeaponSpec } from '../data/weaponsData';
import { WeaponRenderer } from './weapons/WeaponRenderer';
import {
  Play,
  Pause,
  Maximize2,
  Download,
  Sparkles,
  Flame,
  Zap,
  ShieldCheck,
  Star,
  Crown,
  Droplets,
  Layers,
} from 'lucide-react';

interface CollageShowcaseGridProps {
  activeWeapons: Record<string, boolean>;
  onToggleWeapon: (id: string) => void;
  onTriggerBurst: (id: string) => void;
  onSelectForStudio: (weapon: WeaponSpec) => void;
  onDownloadSvg: (weapon: WeaponSpec, svgElement: SVGSVGElement | null) => void;
  speed: number;
  isMythic: boolean;
}

export const CollageShowcaseGrid: React.FC<CollageShowcaseGridProps> = ({
  activeWeapons,
  onToggleWeapon,
  onTriggerBurst,
  onSelectForStudio,
  onDownloadSvg,
  speed,
  isMythic,
}) => {
  const [filterBatch, setFilterBatch] = useState<'all' | 2 | 1>('all');
  const svgRefs = React.useRef<Record<string, SVGSVGElement | null>>({});

  const filteredWeapons = WEAPONS_DATA.filter((w) =>
    filterBatch === 'all' ? true : w.batch === filterBatch
  );

  return (
    <div className="w-full max-w-7xl mx-auto px-4 sm:px-6 pb-12">
      {/* ==================== COLLECTION FILTER BAR ==================== */}
      <div className="mb-6 flex flex-wrap items-center justify-between gap-4 bg-slate-900/75 border border-slate-800/90 rounded-2xl p-3 backdrop-blur-md">
        <div className="flex items-center gap-2.5 pl-1">
          <Layers className="w-4 h-4 text-amber-400" />
          <span className="text-xs font-display font-bold uppercase tracking-wider text-slate-200">
            KOLEKSI ARMORY VEKTOR 2D:
          </span>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={() => setFilterBatch('all')}
            className={`px-3.5 py-1.5 rounded-xl font-display font-bold text-xs uppercase tracking-wider transition cursor-pointer flex items-center gap-1.5 ${
              filterBatch === 'all'
                ? 'bg-amber-400 text-slate-950 shadow-md'
                : 'bg-slate-950/80 text-slate-300 hover:bg-slate-800 border border-slate-800'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>Semua 10 Senjata Lengkap</span>
          </button>

          <button
            onClick={() => setFilterBatch(2)}
            className={`px-3.5 py-1.5 rounded-xl font-display font-bold text-xs uppercase tracking-wider transition cursor-pointer flex items-center gap-1.5 ${
              filterBatch === 2
                ? 'bg-gradient-to-r from-emerald-400 to-sky-400 text-slate-950 shadow-md'
                : 'bg-slate-950/80 text-emerald-300 hover:bg-slate-800 border border-emerald-500/30'
            }`}
          >
            <Zap className="w-3.5 h-3.5" />
            <span>★ 5 Senjata Baru (Set #2)</span>
          </button>

          <button
            onClick={() => setFilterBatch(1)}
            className={`px-3.5 py-1.5 rounded-xl font-display font-bold text-xs uppercase tracking-wider transition cursor-pointer flex items-center gap-1.5 ${
              filterBatch === 1
                ? 'bg-sky-400 text-slate-950 shadow-md'
                : 'bg-slate-950/80 text-slate-300 hover:bg-slate-800 border border-slate-800'
            }`}
          >
            <Crown className="w-3.5 h-3.5" />
            <span>5 Senjata Pertama (Set #1)</span>
          </button>
        </div>
      </div>

      {/* ==================== WEAPON SHOWCASE GRID ==================== */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-6 gap-6">
        {filteredWeapons.map((weapon, idx) => {
          const isActive = !!activeWeapons[weapon.id];
          // Pattern: In groups of 5, first 2 take 3 cols each (half width), next 3 take 2 cols each (third width)
          const posInGroup = idx % 5;
          const colSpanClass = posInGroup < 2 ? 'lg:col-span-3' : 'lg:col-span-2';

          return (
            <div
              key={weapon.id}
              className={`${colSpanClass} group relative rounded-3xl overflow-hidden border-2 transition-all duration-300 flex flex-col justify-between hover:-translate-y-1`}
              style={{
                background: weapon.cardBg,
                borderColor: isActive
                  ? weapon.primaryColor
                  : isMythic
                  ? `${weapon.primaryColor}66`
                  : 'rgba(148, 163, 184, 0.22)',
                boxShadow: isActive
                  ? `0 0 46px -4px ${weapon.glowColor}, inset 0 0 28px ${weapon.glowColor}`
                  : isMythic
                  ? `0 20px 50px -12px rgba(0, 0, 0, 0.85), 0 0 25px -8px ${weapon.glowColor}`
                  : '0 16px 40px -12px rgba(0, 0, 0, 0.7)',
              }}
            >
              {/* Sunburst Conic Rays Overlay like Game Poster */}
              <div className="absolute inset-0 sunburst-rays pointer-events-none opacity-85" />

              {/* Holographic Collector Foil Shimmer Sweep */}
              {isMythic && (
                <div className="absolute inset-0 holo-foil-sweep pointer-events-none z-10" />
              )}

              {/* Ornate Game Corner Frame Lines */}
              <div
                className="absolute inset-2.5 rounded-2xl pointer-events-none border opacity-45"
                style={{ borderColor: weapon.primaryColor }}
              />
              {/* Corner Accent Brackets */}
              <div
                className="absolute top-2.5 left-2.5 w-5 h-5 border-t-2 border-l-2 rounded-tl-lg pointer-events-none"
                style={{ borderColor: weapon.primaryColor }}
              />
              <div
                className="absolute top-2.5 right-2.5 w-5 h-5 border-t-2 border-r-2 rounded-tr-lg pointer-events-none"
                style={{ borderColor: weapon.primaryColor }}
              />
              <div
                className="absolute bottom-2.5 left-2.5 w-5 h-5 border-b-2 border-l-2 rounded-bl-lg pointer-events-none"
                style={{ borderColor: weapon.primaryColor }}
              />
              <div
                className="absolute bottom-2.5 right-2.5 w-5 h-5 border-b-2 border-r-2 rounded-br-lg pointer-events-none"
                style={{ borderColor: weapon.primaryColor }}
              />

              {/* Card Top Header: Authentic Rarity Badge, 5-Stars & Controls */}
              <div className="relative z-20 flex items-center justify-between px-4 pt-4">
                <div className="flex flex-col gap-1">
                  <div className="flex items-center gap-2 flex-wrap">
                    {/* Authentic Trapezoid Game Rarity Badge */}
                    <div
                      className="px-3.5 py-1 rounded-md border text-xs font-display font-bold tracking-wider uppercase flex items-center gap-1.5 shadow-lg"
                      style={{
                        backgroundColor: weapon.rarityBadgeStyle.bg,
                        borderColor: weapon.rarityBadgeStyle.border,
                        color: weapon.rarityBadgeStyle.text,
                        clipPath: 'polygon(6% 0%, 100% 0%, 94% 100%, 0% 100%)',
                      }}
                    >
                      {weapon.id === 'laser-buster' || weapon.id === 'firework-launcher' ? (
                        <Flame className="w-3.5 h-3.5 text-amber-400 fill-amber-400" />
                      ) : weapon.id === 'storm-caller' || weapon.id === 'bio-plasma' ? (
                        <Zap className="w-3.5 h-3.5 text-emerald-300 fill-emerald-300" />
                      ) : weapon.id === 'super-soaker' ? (
                        <Droplets className="w-3.5 h-3.5 text-sky-300 fill-sky-300" />
                      ) : (
                        <Crown className="w-3.5 h-3.5 text-yellow-300 fill-yellow-300" />
                      )}
                      <span>{isMythic ? weapon.mythicRarity : weapon.rarity}</span>
                    </div>

                    {/* NEW Badge for Batch 2 */}
                    {weapon.batch === 2 && (
                      <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 border border-emerald-400 text-[10px] font-display font-extrabold text-emerald-300 uppercase tracking-wider">
                        BARU #{weapon.number}
                      </span>
                    )}

                    {/* 5 Golden Collector Stars */}
                    <div className="flex items-center gap-0.5 bg-slate-950/75 px-2 py-1 rounded-full border border-amber-400/30">
                      {Array.from({ length: weapon.stars }).map((_, sIdx) => (
                        <Star
                          key={sIdx}
                          className="w-2.5 h-2.5 text-amber-400 fill-amber-400"
                        />
                      ))}
                    </div>
                  </div>

                  {/* Serial Code */}
                  <span className="text-[10px] font-mono-code text-slate-300/80 tracking-wider pl-1">
                    {weapon.serialCode}
                  </span>
                </div>

                {/* Quick Action Icons */}
                <div className="flex items-center gap-1.5">
                  <button
                    onClick={() =>
                      onDownloadSvg(weapon, svgRefs.current[weapon.id] || null)
                    }
                    title="Download File .SVG Murni"
                    className="p-2 rounded-xl bg-slate-950/85 hover:bg-slate-800 text-slate-200 hover:text-white border border-slate-700/80 transition cursor-pointer shadow"
                  >
                    <Download className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => onSelectForStudio(weapon)}
                    title="Buka di Studio Inspeksi Mythic"
                    className="p-2 rounded-xl bg-slate-950/85 hover:bg-slate-800 text-slate-200 hover:text-white border border-slate-700/80 transition cursor-pointer shadow"
                  >
                    <Maximize2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              {/* Interactive SVG Canvas Area (Click directly to Trigger Animation!) */}
              <div
                onClick={() => onTriggerBurst(weapon.id)}
                className="relative z-20 w-full h-64 sm:h-72 flex items-center justify-center px-3 cursor-pointer"
                title="Klik senjata untuk mengaktifkan animasi mekanik & energi langka (Tanpa Peluru!)"
              >
                <div className="w-full h-full flex items-center justify-center transition-transform duration-300 group-hover:scale-[1.03]">
                  <WeaponRenderer
                    weaponId={weapon.id}
                    isActive={isActive}
                    speed={speed}
                    showBackdrop={true}
                    isMythic={isMythic}
                    svgRef={{
                      get current() {
                        return svgRefs.current[weapon.id] || null;
                      },
                      set current(el: SVGSVGElement | null) {
                        svgRefs.current[weapon.id] = el;
                      },
                    }}
                  />
                </div>

                {/* Status Pill when Animating */}
                {isActive && (
                  <div
                    className="absolute top-1 right-4 px-3 py-0.5 rounded-full text-[10px] font-mono-code font-bold uppercase tracking-wider flex items-center gap-1.5 animate-pulse border shadow-lg"
                    style={{
                      backgroundColor: 'rgba(5, 7, 14, 0.92)',
                      borderColor: weapon.primaryColor,
                      color: weapon.primaryColor,
                    }}
                  >
                    <span
                      className="w-2 h-2 rounded-full"
                      style={{ backgroundColor: weapon.primaryColor }}
                    />
                    OVERDRIVE AKTIF • TANPA PELURU
                  </div>
                )}
              </div>

              {/* Authentic Poster Nameplate & Interactive Controls Footer */}
              <div className="relative z-20 px-4 pb-4 pt-2 flex flex-col gap-3 bg-gradient-to-t from-slate-950 via-slate-950/85 to-transparent">
                {/* Poster Title Styling matching Reference Cards */}
                <div className="text-center">
                  <div className="text-[10px] font-mono-code uppercase tracking-[0.2em] text-amber-300/90 mb-1">
                    ★ {weapon.mythicTitle} ★
                  </div>

                  {/* Special Winged Royal Purple-Gold Crest Banner for FIREWORK LAUNCHER & CARD GUN */}
                  {weapon.id === 'firework-launcher' || weapon.id === 'card-gun' ? (
                    <div className="relative inline-flex items-center justify-center my-1">
                      {/* Left & Right Cyan-Gold Mini Wings */}
                      <span className="hidden sm:block w-4 h-3 -mr-1 bg-gradient-to-l from-sky-400 to-amber-300 rounded-l-full transform -skew-y-12 border border-amber-400" />
                      <div className="relative px-6 py-1.5 rounded-2xl bg-gradient-to-b from-[#3B1D7A] via-[#24104F] to-[#140830] border-2 border-amber-400 shadow-[0_0_24px_rgba(245,158,11,0.45)]">
                        {/* Top Center Diamond Crest Gem */}
                        <span className="absolute -top-2 left-1/2 -translate-x-1/2 w-3.5 h-3.5 rotate-45 bg-gradient-to-br from-purple-300 to-purple-600 border-2 border-amber-300 shadow" />
                        <h3 className="font-display font-extrabold text-base sm:text-lg tracking-wider text-amber-300 uppercase drop-shadow-[0_2px_4px_rgba(0,0,0,0.9)]">
                          {weapon.name}
                        </h3>
                      </div>
                      <span className="hidden sm:block w-4 h-3 -ml-1 bg-gradient-to-r from-sky-400 to-amber-300 rounded-r-full transform skew-y-12 border border-amber-400" />
                    </div>
                  ) : weapon.id === 'minigun' ? (
                    <div className="inline-flex items-center gap-2.5 px-5 py-1.5 rounded-2xl bg-slate-950/95 border-2 border-amber-600/70 shadow-lg">
                      <h3 className="font-display font-extrabold text-base sm:text-lg tracking-wider text-amber-400 uppercase">
                        MINIGUN
                      </h3>
                      <span className="px-2.5 py-0.5 rounded-lg bg-purple-600 text-white font-display font-bold text-xs uppercase flex items-center gap-1">
                        <Zap className="w-3 h-3 fill-current" /> EPIC
                      </span>
                    </div>
                  ) : weapon.id === 'super-soaker' ? (
                    <div className="inline-block px-6 py-1 rounded-xl bg-slate-950/95 border-2 border-orange-500 shadow-[0_0_18px_rgba(249,115,22,0.45)]">
                      <h3 className="font-display font-extrabold text-lg sm:text-xl tracking-wider text-amber-400 uppercase">
                        {weapon.name}
                      </h3>
                    </div>
                  ) : weapon.id === 'storm-caller' ? (
                    <div className="inline-block px-6 py-1 rounded-full bg-slate-950/95 border-2 border-sky-400 shadow-[0_0_20px_rgba(56,189,248,0.55)]">
                      <h3 className="font-display font-extrabold text-base sm:text-lg tracking-widest text-sky-100 uppercase">
                        {weapon.name}
                      </h3>
                    </div>
                  ) : (
                    <h3
                      className="font-display font-extrabold text-xl sm:text-2xl tracking-wider uppercase drop-shadow-[0_2px_12px_rgba(0,0,0,0.95)]"
                      style={{
                        color:
                          weapon.id === 'laser-buster'
                            ? '#FCA5A5'
                            : weapon.id === 'banana-blaster' || weapon.id === 'golden-tycoon'
                            ? '#FEF08A'
                            : weapon.id === 'bio-plasma'
                            ? '#6EE7B7'
                            : '#7DD3FC',
                      }}
                    >
                      {weapon.name}
                    </h3>
                  )}

                  <p className="text-xs text-slate-300/95 mt-1 font-medium">
                    {weapon.indonesianTitle}
                  </p>
                </div>

                {/* Collector Rarity Stat Bars */}
                <div className="grid grid-cols-3 gap-2 px-2 py-1.5 rounded-xl bg-slate-900/75 border border-slate-800/80">
                  <div>
                    <div className="flex justify-between text-[10px] font-mono-code text-slate-400">
                      <span>POWER</span>
                      <span className="text-white font-bold">{weapon.stats.power}</span>
                    </div>
                    <div className="w-full h-1 bg-slate-800 rounded-full overflow-hidden mt-0.5">
                      <div
                        className="h-full rounded-full"
                        style={{
                          width: `${weapon.stats.power}%`,
                          backgroundColor: weapon.primaryColor,
                        }}
                      />
                    </div>
                  </div>
                  <div>
                    <div className="flex justify-between text-[10px] font-mono-code text-slate-400">
                      <span>AURA</span>
                      <span className="text-white font-bold">{weapon.stats.resonance}</span>
                    </div>
                    <div className="w-full h-1 bg-slate-800 rounded-full overflow-hidden mt-0.5">
                      <div
                        className="h-full rounded-full"
                        style={{
                          width: `${weapon.stats.resonance}%`,
                          backgroundColor: weapon.primaryColor,
                        }}
                      />
                    </div>
                  </div>
                  <div>
                    <div className="flex justify-between text-[10px] font-mono-code text-slate-400">
                      <span>DETAIL</span>
                      <span className="text-amber-300 font-bold">
                        {weapon.stats.craftsmanship}%
                      </span>
                    </div>
                    <div className="w-full h-1 bg-slate-800 rounded-full overflow-hidden mt-0.5">
                      <div
                        className="h-full rounded-full bg-amber-400"
                        style={{ width: `${weapon.stats.craftsmanship}%` }}
                      />
                    </div>
                  </div>
                </div>

                {/* Mechanical Action Summary Badges */}
                <div className="flex flex-wrap items-center justify-center gap-1.5">
                  {weapon.svgFeatures.map((feat, i) => (
                    <span
                      key={i}
                      className="text-[10px] px-2 py-0.5 rounded-md bg-slate-900/95 text-slate-200 border border-slate-700/70 font-medium"
                    >
                      {feat}
                    </span>
                  ))}
                </div>

                {/* Action Buttons Row */}
                <div className="grid grid-cols-2 gap-2 pt-1">
                  <button
                    onClick={() => onTriggerBurst(weapon.id)}
                    className="py-2.5 px-3 rounded-xl font-display font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-1.5 transition-all cursor-pointer shadow-lg hover:brightness-110 active:scale-95"
                    style={{
                      background: `linear-gradient(135deg, ${weapon.primaryColor}, ${weapon.secondaryColor})`,
                      color:
                        weapon.id === 'banana-blaster' ||
                        weapon.id === 'golden-tycoon' ||
                        weapon.id === 'minigun' ||
                        weapon.id === 'bio-plasma'
                          ? '#0F172A'
                          : '#FFFFFF',
                    }}
                  >
                    <Zap className="w-3.5 h-3.5 fill-current" />
                    <span>Gunakan Senjata</span>
                  </button>

                  <button
                    onClick={() => onToggleWeapon(weapon.id)}
                    className={`py-2.5 px-3 rounded-xl font-display font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-1.5 border transition-all cursor-pointer ${
                      isActive
                        ? 'bg-emerald-500/25 border-emerald-400 text-emerald-200 shadow-[0_0_15px_rgba(16,185,129,0.3)]'
                        : 'bg-slate-900/95 hover:bg-slate-800 border-slate-700 text-slate-200'
                    }`}
                  >
                    {isActive ? (
                      <>
                        <Pause className="w-3.5 h-3.5 fill-current" />
                        <span>Stop Animasi</span>
                      </>
                    ) : (
                      <>
                        <Play className="w-3.5 h-3.5 fill-current" />
                        <span>Animasi Loop</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Guarantee Banner: Zero Projectiles / Pure Mechanical & Energy SVG */}
      <div className="mt-7 rounded-2xl bg-gradient-to-r from-slate-900/90 via-slate-900/95 to-slate-900/90 border border-amber-500/30 p-4 sm:p-5 flex flex-col sm:flex-row items-center justify-between gap-4 shadow-xl">
        <div className="flex items-center gap-3.5">
          <div className="w-11 h-11 rounded-xl bg-amber-500/15 border border-amber-400/50 flex items-center justify-center text-amber-300 shrink-0 shadow-inner">
            <ShieldCheck className="w-6 h-6" />
          </div>
          <div>
            <h4 className="text-sm font-display font-bold uppercase tracking-wide text-amber-200">
              Koleksi Lengkap 10 Senjata Mythic ★ 100% Vektor SVG 2D Berlapis & Animasi Mekanik Tanpa Peluru
            </h4>
            <p className="text-xs text-slate-300 mt-0.5">
              Seluruh 10 senjata (5 Senjata Baru: Super Soaker, Firework Launcher, Bio-Plasma Gun, Card Gun, Minigun + 5 Senjata Pertama) dirancang dengan presisi vektor SVG 2D dan animasi mekanik internal tanpa menembakkan peluru keluar.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
