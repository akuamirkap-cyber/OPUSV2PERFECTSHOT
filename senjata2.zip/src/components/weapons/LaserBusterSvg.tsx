import React from 'react';

interface WeaponSvgProps {
  isActive: boolean;
  speed?: number;
  showBackdrop?: boolean;
  isMythic?: boolean;
  svgRef?: React.RefObject<SVGSVGElement | null>;
}

export const LaserBusterSvg: React.FC<WeaponSvgProps> = ({
  isActive,
  speed = 1,
  showBackdrop = true,
  isMythic = true,
  svgRef,
}) => {
  const dur = (base: number) => `${(base / speed).toFixed(2)}s`;

  return (
    <svg
      ref={svgRef}
      viewBox="0 0 800 500"
      className="w-full h-full select-none overflow-visible"
      xmlns="http://www.w3.org/2000/svg"
    >
      <defs>
        {/* Crimson Radial Starburst Background */}
        <radialGradient id="lb-bg-glow" cx="46%" cy="50%" r="48%">
          <stop offset="0%" stopColor="#F43F5E" stopOpacity="0.62" />
          <stop offset="38%" stopColor="#BE123C" stopOpacity="0.34" />
          <stop offset="72%" stopColor="#311042" stopOpacity="0.14" />
          <stop offset="100%" stopColor="#090D1A" stopOpacity="0" />
        </radialGradient>

        {/* Sleek White-Silver Hull Gradient */}
        <linearGradient id="lb-hull-silver" x1="0%" y1="0%" x2="0%" y2="100%">
          <stop offset="0%" stopColor="#FFFFFF" />
          <stop offset="20%" stopColor="#F8FAFC" />
          <stop offset="48%" stopColor="#CBD5E1" />
          <stop offset="76%" stopColor="#64748B" />
          <stop offset="92%" stopColor="#334155" />
          <stop offset="100%" stopColor="#475569" />
        </linearGradient>

        {/* Lower Metallic Chassis Gradient */}
        <linearGradient id="lb-dark-metal" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#64748B" />
          <stop offset="40%" stopColor="#334155" />
          <stop offset="85%" stopColor="#1E293B" />
          <stop offset="100%" stopColor="#0F172A" />
        </linearGradient>

        {/* Glowing Crimson Energy Cell Gradient */}
        <linearGradient id="lb-red-cell" x1="0%" y1="0%" x2="0%" y2="100%">
          <stop offset="0%" stopColor="#FFE4E6" />
          <stop offset="22%" stopColor="#FF1E2E" />
          <stop offset="68%" stopColor="#DC2626" />
          <stop offset="100%" stopColor="#7F1D1D" />
        </linearGradient>

        {/* Swept Crimson Under-Wing Gradient */}
        <linearGradient id="lb-crimson-wing" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#4C0519" stopOpacity="0.88" />
          <stop offset="65%" stopColor="#9F1239" stopOpacity="0.92" />
          <stop offset="100%" stopColor="#F43F5E" stopOpacity="0.98" />
        </linearGradient>

        {/* Chrome Hull Sheen Sweep */}
        <linearGradient id="lb-sheen-grad" x1="0%" y1="0%" x2="100%" y2="0%">
          <stop offset="0%" stopColor="#FFFFFF" stopOpacity="0" />
          <stop offset="45%" stopColor="#FFE4E6" stopOpacity="0.55" />
          <stop offset="50%" stopColor="#FFFFFF" stopOpacity="0.9" />
          <stop offset="55%" stopColor="#FFE4E6" stopOpacity="0.55" />
          <stop offset="100%" stopColor="#FFFFFF" stopOpacity="0" />
        </linearGradient>

        <clipPath id="lb-torpedo-clip">
          <path d="M154,202 C205,178 310,170 435,174 C512,176 568,188 602,202 L602,230 C568,244 510,256 435,258 C310,262 205,258 154,248 Z" />
        </clipPath>

        {/* Red Neon Glow Filters */}
        <filter id="lb-red-glow" x="-45%" y="-45%" width="190%" height="190%">
          <feGaussianBlur stdDeviation="7" result="blur" />
          <feComposite in="SourceGraphic" in2="blur" operator="over" />
        </filter>

        <filter id="lb-overcharge-glow" x="-70%" y="-70%" width="240%" height="240%">
          <feGaussianBlur stdDeviation="14" result="blur1" />
          <feGaussianBlur stdDeviation="5" result="blur2" />
          <feMerge>
            <feMergeNode in="blur1" />
            <feMergeNode in="blur2" />
            <feMergeNode in="SourceGraphic" />
          </feMerge>
        </filter>
      </defs>

      {/* ==================== AMBIENT BACKDROP, MYTHIC RING & RAYS ==================== */}
      {showBackdrop && (
        <g>
          <ellipse cx="380" cy="250" rx="345" ry="215" fill="url(#lb-bg-glow)" />

          {/* Mythic Legend Rotating Fusion Ring */}
          {isMythic && (
            <g opacity={isActive ? '0.55' : '0.28'} transform="translate(360, 240)">
              <g style={{ animation: `rotateSlowCCW 22s linear infinite` }}>
                <circle
                  cx="0"
                  cy="0"
                  r="172"
                  fill="none"
                  stroke="#FB7185"
                  strokeWidth="1.6"
                  strokeDasharray="18 10 4 10"
                />
                <circle
                  cx="0"
                  cy="0"
                  r="148"
                  fill="none"
                  stroke="#F43F5E"
                  strokeWidth="1"
                  strokeDasharray="6 14"
                />
              </g>
            </g>
          )}

          {/* Dynamic Starburst Rays behind weapon matching Reference */}
          <g opacity="0.28" stroke="#FB7185" strokeLinecap="round">
            <line x1="360" y1="245" x2="150" y2="90" strokeWidth="3.5" />
            <line x1="360" y1="245" x2="265" y2="65" strokeWidth="2.5" />
            <line x1="360" y1="245" x2="430" y2="70" strokeWidth="4" />
            <line x1="360" y1="245" x2="585" y2="95" strokeWidth="3" />
            <line x1="360" y1="245" x2="135" y2="340" strokeWidth="3" />
            <line x1="360" y1="245" x2="545" y2="375" strokeWidth="2.5" />
          </g>

          {/* Authentic Floating Golden Coins & Stars on Right Edge (Matching Reference Crop!) */}
          <g>
            <g
              style={{
                animation: `sparkleTwinkle ${dur(2.4)} ease-in-out infinite`,
                transformOrigin: '718px 232px',
              }}
            >
              <ellipse
                cx="718"
                cy="232"
                rx="13"
                ry="9"
                fill="#FACC15"
                stroke="#B45309"
                strokeWidth="2"
              />
              <ellipse cx="718" cy="231" rx="8" ry="5" fill="#FEF08A" />
            </g>
            <path
              d="M735,288 L739,298 L750,300 L741,307 L743,318 L735,312 L726,318 L728,307 L720,300 L731,298 Z"
              fill="#FDE047"
              stroke="#CA8A04"
              strokeWidth="1.5"
              style={{
                animation: `sparkleTwinkle ${dur(1.9)} ease-in-out infinite`,
                transformOrigin: '735px 304px',
              }}
            />
          </g>
        </g>
      )}

      {/* ==================== MAIN WEAPON GROUP (FLOATS & RECOILS) ==================== */}
      <g
        style={{
          animation: isActive
            ? `laserBusterRecoil ${dur(0.62)} cubic-bezier(0.22, 1, 0.36, 1) infinite`
            : `floatIdle 3.6s ease-in-out infinite`,
          transformOrigin: '360px 260px',
        }}
      >
        {/* Angled Pose matching Reference (-15 degrees upward-right) */}
        <g transform="translate(375, 250) rotate(-15) translate(-375, -250)">
          {/* 1. SWEPT CRIMSON-MAGENTA ENERGY SHIELD WING (Behind Grip) */}
          <g>
            <path
              d="M148,240 C175,306 245,356 312,375 L416,288 L454,235 Z"
              fill="url(#lb-crimson-wing)"
              stroke="#FB7185"
              strokeWidth="2.5"
              opacity="0.92"
            />
            {/* Inner Tech Grid Lines on Crimson Wing */}
            <path
              d="M188,268 C218,308 265,338 310,352 L392,282"
              fill="none"
              stroke="#FFE4E6"
              strokeWidth="1.2"
              opacity="0.35"
            />
            {/* Glowing Pink-Red Edge Bars on the Lower Wing */}
            <line
              x1="348"
              y1="344"
              x2="375"
              y2="322"
              stroke="#FFFFFF"
              strokeWidth="5.5"
              strokeLinecap="round"
              filter="url(#lb-red-glow)"
            />
            <line
              x1="386"
              y1="312"
              x2="405"
              y2="296"
              stroke="#FFFFFF"
              strokeWidth="4.5"
              strokeLinecap="round"
              filter="url(#lb-red-glow)"
            />
          </g>

          {/* 2. ARTICULATED TOP DORSAL FIN (Lifts & vents heat when activated) */}
          <g
            style={{
              animation: isActive
                ? `laserFinVent ${dur(0.62)} ease-in-out infinite`
                : 'none',
              transformOrigin: '375px 180px',
            }}
          >
            {/* Red Internal Heat Glow & Vent Plume revealed when fin lifts */}
            {isActive && (
              <g filter="url(#lb-overcharge-glow)">
                <ellipse cx="362" cy="180" rx="44" ry="10" fill="#FF1E2E" />
                <ellipse cx="362" cy="180" rx="28" ry="5" fill="#FFFFFF" />
              </g>
            )}
            <path
              d="M306,184 L334,148 L406,155 L430,182 Z"
              fill="url(#lb-hull-silver)"
              stroke="#1E293B"
              strokeWidth="3.2"
              strokeLinejoin="round"
            />
            {/* Fin Inner Bevel & Seam Line */}
            <path
              d="M322,178 L340,156 L398,161 L414,178 Z"
              fill="#E2E8F0"
              stroke="#64748B"
              strokeWidth="1.6"
            />
            <line
              x1="336"
              y1="153"
              x2="402"
              y2="159"
              stroke="#FFFFFF"
              strokeWidth="3"
              strokeLinecap="round"
            />
          </g>

          {/* 3. LOWER METALLIC RECEIVER & PISTOL GRIP WITH RED CORE STRIPE */}
          <g>
            {/* Under-Hull Receiver Housing */}
            <path
              d="M210,250 L242,277 L432,268 L478,236 Z"
              fill="url(#lb-dark-metal)"
              stroke="#0F172A"
              strokeWidth="3.2"
            />
            {/* Panel Seam & Rivet Dots */}
            <path
              d="M248,266 L396,260 L422,242"
              fill="none"
              stroke="#94A3B8"
              strokeWidth="2"
              opacity="0.78"
            />
            <circle cx="388" cy="252" r="3" fill="#1E293B" stroke="#CBD5E1" strokeWidth="1.2" />
            <circle cx="400" cy="251" r="3" fill="#1E293B" stroke="#CBD5E1" strokeWidth="1.2" />

            {/* Angled Futuristic Pistol Grip */}
            <path
              d="M276,268 L294,376 L364,364 L352,264 Z"
              fill="url(#lb-dark-metal)"
              stroke="#0F172A"
              strokeWidth="3.4"
              strokeLinejoin="round"
            />
            {/* Left & Right Grip Metallic Side Bolsters */}
            <path
              d="M282,272 L298,368 L316,365 L302,270 Z"
              fill="#64748B"
              opacity="0.5"
            />

            {/* CENTRAL VERTICAL GLOWING RED STRIPE ON GRIP */}
            <path
              d="M312,268 L326,364 L344,361 L330,267 Z"
              fill="url(#lb-red-cell)"
              stroke="#4C0519"
              strokeWidth="2"
              filter={isActive ? 'url(#lb-overcharge-glow)' : 'url(#lb-red-glow)'}
            />
            {/* Bright Inner Energy Conduit Line inside Grip Stripe */}
            <line
              x1="321"
              y1="274"
              x2="335"
              y2="356"
              stroke="#FFE4E6"
              strokeWidth="2.5"
              strokeDasharray="6 4"
              opacity={isActive ? 1 : 0.6}
            />
            {/* Horizontal Dark Rib Segments across Grip */}
            {[292, 316, 340].map((yPos, idx) => (
              <line
                key={idx}
                x1={284 + idx * 4}
                y1={yPos}
                x2={354 + idx * 3}
                y2={yPos - 5}
                stroke="#0F172A"
                strokeWidth="3.8"
              />
            ))}

            {/* Flared Silver-White Grip Pommel Baseplate */}
            <path
              d="M284,372 L374,356 L368,380 L294,394 Z"
              fill="url(#lb-hull-silver)"
              stroke="#0F172A"
              strokeWidth="3.2"
              strokeLinejoin="round"
            />
            <line
              x1="292"
              y1="377"
              x2="366"
              y2="364"
              stroke="#FFFFFF"
              strokeWidth="3"
              strokeLinecap="round"
            />
          </g>

          {/* 4. SLEEK AERODYNAMIC WHITE-SILVER TORPEDO FUSELAGE */}
          <g>
            {/* Glowing Red Rear Tail Cap */}
            <path
              d="M156,204 C130,208 130,244 156,248 Z"
              fill="url(#lb-red-cell)"
              stroke="#4C0519"
              strokeWidth="2.8"
              filter={isActive ? 'url(#lb-overcharge-glow)' : 'url(#lb-red-glow)'}
            />
            <ellipse cx="144" cy="220" rx="5.5" ry="7.5" fill="#FFFFFF" opacity="0.9" />

            {/* Main White-Silver Streamlined Torpedo Body */}
            <path
              d="M154,202 C205,178 310,170 435,174 C512,176 568,188 602,202 L602,230 C568,244 510,256 435,258 C310,262 205,258 154,248 Z"
              fill="url(#lb-hull-silver)"
              stroke="#1E293B"
              strokeWidth="3.5"
              strokeLinejoin="round"
            />

            {/* Upper Glossy White Specular Highlight Strip */}
            <path
              d="M170,202 C230,183 335,177 450,180 C512,182 558,191 588,202"
              fill="none"
              stroke="#FFFFFF"
              strokeWidth="5.5"
              strokeLinecap="round"
              opacity="0.95"
            />

            {/* Lower Blue-Grey Cel-Shaded Belly Shadow */}
            <path
              d="M158,238 C220,250 325,254 440,250 C512,248 564,238 598,225 L598,230 C562,244 508,255 435,257 C310,261 206,256 156,247 Z"
              fill="#475569"
              opacity="0.8"
            />

            {/* Mechanical Panel Seams & Micro Rivets on Fuselage */}
            <path
              d="M180,196 L180,251 M548,187 L548,244"
              stroke="#64748B"
              strokeWidth="2.2"
              opacity="0.7"
            />

            {/* Animated Chrome Sheen Sweep across Torpedo Body */}
            {isMythic && (
              <g clipPath="url(#lb-torpedo-clip)" pointerEvents="none">
                <rect
                  x="160"
                  y="160"
                  width="90"
                  height="120"
                  fill="url(#lb-sheen-grad)"
                  transform="skewX(-25)"
                  style={{
                    animation: `svgMetalSheen ${dur(4.0)} ease-in-out infinite`,
                  }}
                />
              </g>
            )}
          </g>

          {/* 5. FOUR ICONIC GLOWING RED ENERGY WINDOWS ([1] [2] [3] [4]) */}
          {[
            { x: 188, y: 204, w: 60, h: 32, rx: 11, delay: '0s' },
            { x: 262, y: 199, w: 72, h: 36, rx: 12, delay: '0.08s' },
            { x: 348, y: 196, w: 82, h: 39, rx: 13, delay: '0.16s' },
            { x: 444, y: 197, w: 92, h: 36, rx: 13, delay: '0.24s' },
          ].map((cell, idx) => (
            <g
              key={idx}
              style={{
                animation: isActive
                  ? `laserCellOvercharge ${dur(0.5)} ease-in-out infinite`
                  : 'none',
                animationDelay: cell.delay,
                transformOrigin: `${cell.x + cell.w / 2}px ${cell.y + cell.h / 2}px`,
              }}
            >
              {/* Dark Beveled Metallic Socket */}
              <rect
                x={cell.x - 3}
                y={cell.y - 3}
                width={cell.w + 6}
                height={cell.h + 6}
                rx={cell.rx + 2}
                fill="#1E293B"
                stroke="#94A3B8"
                strokeWidth="1.6"
              />
              {/* Glowing Crimson Energy Capsule */}
              <rect
                x={cell.x}
                y={cell.y}
                width={cell.w}
                height={cell.h}
                rx={cell.rx}
                fill="url(#lb-red-cell)"
                filter={isActive ? 'url(#lb-overcharge-glow)' : 'url(#lb-red-glow)'}
              />
              {/* Bright Inner Plasma Core */}
              <rect
                x={cell.x + 6}
                y={cell.y + 6}
                width={cell.w - 12}
                height={cell.h - 12}
                rx={cell.rx - 4}
                fill="#FF4D5E"
                opacity={isActive ? 0.98 : 0.62}
              />
              {/* Internal Plasma Filament Wave */}
              <path
                d={`M${cell.x + 10},${cell.y + cell.h * 0.58} Q${cell.x + cell.w * 0.5},${cell.y + cell.h * 0.35} ${cell.x + cell.w - 10},${cell.y + cell.h * 0.58}`}
                fill="none"
                stroke="#FFE4E6"
                strokeWidth="2"
                strokeLinecap="round"
                opacity={isActive ? 0.95 : 0.5}
              />
              {/* Top-Left Glossy White-Pink Specular Pill Highlight */}
              <rect
                x={cell.x + 7}
                y={cell.y + 5}
                width={cell.w * 0.6}
                height={6.5}
                rx={3.2}
                fill="#FFFFFF"
                opacity="0.94"
              />
            </g>
          ))}

          {/* 6. MUZZLE NOSE EMITTER RING */}
          <g>
            {/* Metallic Nose Collar */}
            <path
              d="M598,200 L613,204 L613,228 L598,232 Z"
              fill="#475569"
              stroke="#0F172A"
              strokeWidth="2.6"
            />
            {/* Glowing Crimson Emitter Lip */}
            <ellipse
              cx="615"
              cy="216"
              rx="6.5"
              ry="12.5"
              fill="#FF1E2E"
              stroke="#FFE4E6"
              strokeWidth="2.2"
              filter="url(#lb-red-glow)"
            />
          </g>

          {/* ==================== STATIONARY MUZZLE OVERCHARGE CORONA (NO PROJECTILES!) ==================== */}
          {isActive && (
            <g
              style={{
                animation: `muzzleCrownPulse ${dur(0.62)} ease-out infinite`,
                transformOrigin: '616px 216px',
              }}
            >
              {/* Contained Crimson-Pink Plasma Halo anchored at Nose Tip */}
              <circle
                cx="616"
                cy="216"
                r="36"
                fill="#F43F5E"
                opacity="0.44"
                filter="url(#lb-overcharge-glow)"
              />
              <circle
                cx="616"
                cy="216"
                r="25"
                fill="none"
                stroke="#FFE4E6"
                strokeWidth="3.5"
                strokeDasharray="8 6"
                filter="url(#lb-overcharge-glow)"
              />
              {/* Stationary Multi-Point Crimson Star Flare at Nozzle Lip */}
              <path
                d="M616,162 L623,205 L666,216 L623,227 L616,270 L609,227 L566,216 L609,205 Z"
                fill="#FFFFFF"
                stroke="#FF1E2E"
                strokeWidth="1.8"
                filter="url(#lb-overcharge-glow)"
              />
              <path
                d="M585,185 L612,210 L647,185 L622,216 L647,247 L612,222 L585,247 L610,216 Z"
                fill="#FDA4AF"
                opacity="0.9"
              />
            </g>
          )}
        </g>
      </g>
    </svg>
  );
};
