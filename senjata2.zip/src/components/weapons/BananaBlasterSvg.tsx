import React from 'react';

interface WeaponSvgProps {
  isActive: boolean;
  speed?: number;
  showBackdrop?: boolean;
  isMythic?: boolean;
  svgRef?: React.RefObject<SVGSVGElement | null>;
}

export const BananaBlasterSvg: React.FC<WeaponSvgProps> = ({
  isActive,
  speed = 1,
  showBackdrop = true,
  isMythic = true,
  svgRef,
}) => {
  const dur = (base: number) => `${(base / speed).toFixed(2)}s`;

  return (
    <svg
      ref={svgRef}
      viewBox="0 0 800 500"
      className="w-full h-full select-none overflow-visible"
      xmlns="http://www.w3.org/2000/svg"
    >
      <defs>
        {/* Warm Golden Radial Glow */}
        <radialGradient id="bb-bg-glow" cx="48%" cy="48%" r="48%">
          <stop offset="0%" stopColor="#FACC15" stopOpacity="0.58" />
          <stop offset="40%" stopColor="#CA8A04" stopOpacity="0.3" />
          <stop offset="75%" stopColor="#1E3A8A" stopOpacity="0.14" />
          <stop offset="100%" stopColor="#090D1A" stopOpacity="0" />
        </radialGradient>

        {/* Rich Golden Banana Body Gradient */}
        <linearGradient id="bb-banana-gold" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#FEF9C3" />
          <stop offset="25%" stopColor="#FDE047" />
          <stop offset="58%" stopColor="#EAB308" />
          <stop offset="85%" stopColor="#CA8A04" />
          <stop offset="100%" stopColor="#854D0E" />
        </linearGradient>

        {/* Banana Belly Shadow Gradient */}
        <linearGradient id="bb-banana-shadow" x1="0%" y1="0%" x2="0%" y2="100%">
          <stop offset="0%" stopColor="#EAB308" />
          <stop offset="60%" stopColor="#B45309" />
          <stop offset="100%" stopColor="#713F12" />
        </linearGradient>

        {/* Woody Brown Stem Tip Gradient */}
        <linearGradient id="bb-wood-stem" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#A16207" />
          <stop offset="45%" stopColor="#713F12" />
          <stop offset="100%" stopColor="#3B1A04" />
        </linearGradient>

        {/* Sculpted Silver-Chrome Exo-Frame Gradient */}
        <linearGradient id="bb-chrome-silver" x1="0%" y1="0%" x2="0%" y2="100%">
          <stop offset="0%" stopColor="#FFFFFF" />
          <stop offset="22%" stopColor="#F1F5F9" />
          <stop offset="55%" stopColor="#94A3B8" />
          <stop offset="85%" stopColor="#475569" />
          <stop offset="100%" stopColor="#1E293B" />
        </linearGradient>

        {/* Incandescent Solar-Gold Plasma Core Gradient */}
        <linearGradient id="bb-plasma-core" x1="0%" y1="0%" x2="0%" y2="100%">
          <stop offset="0%" stopColor="#F59E0B" />
          <stop offset="25%" stopColor="#FEF08A" />
          <stop offset="50%" stopColor="#FFFFFF" />
          <stop offset="75%" stopColor="#FEF08A" />
          <stop offset="100%" stopColor="#D97706" />
        </linearGradient>

        {/* Golden Sheen Sweep */}
        <linearGradient id="bb-sheen-grad" x1="0%" y1="0%" x2="100%" y2="0%">
          <stop offset="0%" stopColor="#FFFFFF" stopOpacity="0" />
          <stop offset="45%" stopColor="#FEF9C3" stopOpacity="0.55" />
          <stop offset="50%" stopColor="#FFFFFF" stopOpacity="0.9" />
          <stop offset="55%" stopColor="#FEF9C3" stopOpacity="0.55" />
          <stop offset="100%" stopColor="#FFFFFF" stopOpacity="0" />
        </linearGradient>

        <clipPath id="bb-grip-clip">
          <path d="M174,376 C192,292 238,228 318,186 L354,258 C286,286 244,336 212,404 Z" />
        </clipPath>

        {/* Golden Glow Filters */}
        <filter id="bb-gold-glow" x="-45%" y="-45%" width="190%" height="190%">
          <feGaussianBlur stdDeviation="7" result="blur" />
          <feComposite in="SourceGraphic" in2="blur" operator="over" />
        </filter>

        <filter id="bb-solar-overcharge" x="-70%" y="-70%" width="240%" height="240%">
          <feGaussianBlur stdDeviation="14" result="blur1" />
          <feGaussianBlur stdDeviation="4" result="blur2" />
          <feMerge>
            <feMergeNode in="blur1" />
            <feMergeNode in="blur2" />
            <feMergeNode in="SourceGraphic" />
          </feMerge>
        </filter>
      </defs>

      {/* ==================== AMBIENT BACKDROP, MYTHIC SOLAR HALO & SPARKLES ==================== */}
      {showBackdrop && (
        <g>
          <ellipse cx="390" cy="250" rx="345" ry="210" fill="url(#bb-bg-glow)" />

          {/* Mythic Celestial Rotating Solar Ring */}
          {isMythic && (
            <g opacity={isActive ? '0.52' : '0.26'} transform="translate(380, 235)">
              <g style={{ animation: `rotateSlowCW 25s linear infinite` }}>
                <circle
                  cx="0"
                  cy="0"
                  r="170"
                  fill="none"
                  stroke="#FDE047"
                  strokeWidth="1.6"
                  strokeDasharray="16 10 4 10"
                />
                <circle
                  cx="0"
                  cy="0"
                  r="146"
                  fill="none"
                  stroke="#F59E0B"
                  strokeWidth="1.1"
                  strokeDasharray="5 12"
                />
              </g>
            </g>
          )}

          {/* Floating 4-Point Star Sparkles matching Reference */}
          {[
            { x: 185, y: 245, s: 13, d: '0s' },
            { x: 350, y: 118, s: 11, d: '0.4s' },
            { x: 332, y: 318, s: 9.5, d: '0.7s' },
            { x: 472, y: 302, s: 14, d: '0.2s' },
            { x: 255, y: 162, s: 8, d: '0.9s' },
            { x: 485, y: 102, s: 9, d: '0.5s' },
          ].map((st, i) => (
            <path
              key={i}
              d={`M${st.x},${st.y - st.s} L${st.x + st.s * 0.28},${st.y - st.s * 0.28} L${st.x + st.s},${st.y} L${st.x + st.s * 0.28},${st.y + st.s * 0.28} L${st.x},${st.y + st.s} L${st.x - st.s * 0.28},${st.y + st.s * 0.28} L${st.x - st.s},${st.y} L${st.x - st.s * 0.28},${st.y - st.s * 0.28} Z`}
              fill="#FFFFFF"
              stroke="#FACC15"
              strokeWidth="0.8"
              filter="url(#bb-gold-glow)"
              style={{
                animation: `sparkleTwinkle ${dur(2.0)} ease-in-out infinite`,
                animationDelay: st.d,
                transformOrigin: `${st.x}px ${st.y}px`,
              }}
            />
          ))}

          {/* Floating Golden Leaf/Peel Motes near Front matching Reference */}
          <g opacity="0.92">
            <path
              d="M552,124 C566,110 584,108 580,127 C573,142 556,140 552,124 Z"
              fill="url(#bb-banana-gold)"
              stroke="#78350F"
              strokeWidth="1.8"
            />
            <path
              d="M558,248 C580,246 594,258 582,269 C567,275 554,262 558,248 Z"
              fill="url(#bb-banana-gold)"
              stroke="#78350F"
              strokeWidth="1.8"
            />
            <path
              d="M612,218 C625,216 634,224 625,231 C616,235 608,226 612,218 Z"
              fill="#FDE047"
              stroke="#B45309"
              strokeWidth="1.2"
            />
          </g>
        </g>
      )}

      {/* ==================== MAIN WEAPON GROUP (FLOATS & RECOILS) ==================== */}
      <g
        style={{
          animation: isActive
            ? `bananaRecoil ${dur(0.64)} cubic-bezier(0.22, 1, 0.36, 1) infinite`
            : `floatIdle 3.5s ease-in-out infinite`,
          transformOrigin: '340px 260px',
        }}
      >
        {/* 1. CENTRAL INCANDESCENT GOLDEN BIO-PLASMA TUBE (Between the Peels) */}
        <g>
          {/* Outer Solar Glow */}
          <path
            d="M342,206 C395,188 452,180 514,182 L518,220 C458,226 398,236 346,246 Z"
            fill="url(#bb-plasma-core)"
            filter={isActive ? 'url(#bb-solar-overcharge)' : 'url(#bb-gold-glow)'}
          />
          {/* Undulating Golden Energy Wave Ribbons inside Plasma Core */}
          <path
            d="M352,224 Q388,200 424,214 T500,196"
            fill="none"
            stroke="#FFFFFF"
            strokeWidth={isActive ? '6.5' : '4'}
            strokeLinecap="round"
            filter="url(#bb-gold-glow)"
          />
          <path
            d="M358,232 Q398,226 435,202 T504,208"
            fill="none"
            stroke="#FEF08A"
            strokeWidth="3"
            strokeLinecap="round"
          />
        </g>

        {/* 2. STEPPED SILVER-CHROME MECHANICAL NOZZLE (Pumps telescopically on activation) */}
        <g
          style={{
            animation: isActive
              ? `bananaNozzlePump ${dur(0.64)} ease-in-out infinite`
              : 'none',
            transformOrigin: '520px 198px',
          }}
        >
          {/* Rear Nozzle Cylinder Segment */}
          <path
            d="M484,167 L528,161 L536,221 L492,229 Z"
            fill="url(#bb-chrome-silver)"
            stroke="#1E293B"
            strokeWidth="3.2"
            strokeLinejoin="round"
          />
          {/* Mid Stepped Ribbed Ring */}
          <path
            d="M524,165 L553,161 L559,213 L530,218 Z"
            fill="url(#bb-chrome-silver)"
            stroke="#1E293B"
            strokeWidth="3"
            strokeLinejoin="round"
          />
          {/* Mechanical Vent Slots on Silver Nozzle */}
          <line
            x1="502"
            y1="171"
            x2="508"
            y2="219"
            stroke="#334155"
            strokeWidth="3.2"
          />
          <line
            x1="516"
            y1="169"
            x2="522"
            y2="217"
            stroke="#334155"
            strokeWidth="3.2"
          />
          {/* Front Rounded Golden Emitter Tip */}
          <path
            d="M553,167 C576,165 584,175 586,186 C588,197 579,207 557,209 Z"
            fill="url(#bb-banana-gold)"
            stroke="#78350F"
            strokeWidth="3"
          />
          <ellipse
            cx="569"
            cy="179"
            rx="7.5"
            ry="4.2"
            fill="#FFFFFF"
            opacity="0.92"
          />
        </g>

        {/* 3. ARTICULATED UPPER GOLDEN BANANA PEEL SHROUD (Hinges open upward when used) */}
        <g
          style={{
            animation: isActive
              ? `bananaPeelTopOpen ${dur(0.64)} ease-in-out infinite`
              : 'none',
            transformOrigin: '355px 185px',
          }}
        >
          {/* Upper Banana Peel Blade */}
          <path
            d="M342,186 C386,140 462,120 546,127 C512,158 446,184 358,208 Z"
            fill="url(#bb-banana-gold)"
            stroke="#3B1A04"
            strokeWidth="3.4"
            strokeLinejoin="round"
          />
          {/* Inner Peel Rim Shadow */}
          <path
            d="M356,202 C438,180 502,156 540,129 C504,164 442,188 358,208 Z"
            fill="#B45309"
            opacity="0.78"
          />
          {/* Glossy Lemon-White Highlight Curve along Top Edge */}
          <path
            d="M358,177 C398,142 464,127 530,131"
            fill="none"
            stroke="#FFFFFF"
            strokeWidth="5"
            strokeLinecap="round"
            opacity="0.92"
          />
        </g>

        {/* 4. ARTICULATED LOWER GOLDEN BANANA PEEL SHROUD (Hinges open downward when used) */}
        <g
          style={{
            animation: isActive
              ? `bananaPeelBottomOpen ${dur(0.64)} ease-in-out infinite`
              : 'none',
            transformOrigin: '350px 252px',
          }}
        >
          {/* Lower Banana Peel Blade */}
          <path
            d="M332,248 C406,236 482,226 554,215 C518,249 444,273 338,275 Z"
            fill="url(#bb-banana-gold)"
            stroke="#3B1A04"
            strokeWidth="3.4"
            strokeLinejoin="round"
          />
          {/* Lower Belly Amber Shadow */}
          <path
            d="M338,264 C434,264 504,244 548,218 C514,250 442,273 338,275 Z"
            fill="url(#bb-banana-shadow)"
          />
          {/* Upper Inner Edge Highlight */}
          <path
            d="M346,250 C414,240 480,230 540,219"
            fill="none"
            stroke="#FEF9C3"
            strokeWidth="3.5"
            strokeLinecap="round"
          />
        </g>

        {/* 5. CURVED GOLDEN BANANA GRIP & WOODY BROWN STEM BASE */}
        <g>
          {/* Main Curved Banana Stalk Grip */}
          <path
            d="M174,376 C192,292 238,228 318,186 L354,258 C286,286 244,336 212,404 Z"
            fill="url(#bb-banana-gold)"
            stroke="#3B1A04"
            strokeWidth="3.5"
            strokeLinejoin="round"
          />

          {/* Lower Facet Warm Amber Shading */}
          <path
            d="M192,388 C222,318 268,266 338,234 L354,258 C286,286 244,336 212,404 Z"
            fill="url(#bb-banana-shadow)"
            opacity="0.85"
          />

          {/* Longitudinal Banana Ridge Line & Specular Shine */}
          <path
            d="M192,384 C218,314 264,262 336,232"
            fill="none"
            stroke="#78350F"
            strokeWidth="2.8"
            strokeLinecap="round"
          />
          <path
            d="M188,376 C214,306 258,254 328,224"
            fill="none"
            stroke="#FFFFFF"
            strokeWidth="5"
            strokeLinecap="round"
            opacity="0.9"
          />
          <path
            d="M182,362 C202,294 244,238 312,198"
            fill="none"
            stroke="#FEF08A"
            strokeWidth="3.2"
            strokeLinecap="round"
            opacity="0.78"
          />

          {/* Animated Golden Sheen Sweep across Banana Grip */}
          {isMythic && (
            <g clipPath="url(#bb-grip-clip)" pointerEvents="none">
              <rect
                x="150"
                y="180"
                width="80"
                height="240"
                fill="url(#bb-sheen-grad)"
                transform="skewX(-22)"
                style={{
                  animation: `svgMetalSheen ${dur(4.3)} ease-in-out infinite`,
                }}
              />
            </g>
          )}

          {/* Woody Dark-Brown Banana Stem Tip at Bottom-Left Base */}
          <path
            d="M174,372 L192,368 L216,396 L204,414 C186,418 166,404 166,388 Z"
            fill="url(#bb-wood-stem)"
            stroke="#271202"
            strokeWidth="3.4"
            strokeLinejoin="round"
          />
          <path
            d="M176,382 L192,386 L198,408"
            fill="none"
            stroke="#CA8A04"
            strokeWidth="2.4"
            strokeLinecap="round"
          />
        </g>

        {/* 6. SCULPTED SILVER-CHROME EXO-FRAME COLLAR & GLOWING OVAL CORE */}
        <g>
          {/* Upper Arched Silver Dorsal Handle Loop */}
          <path
            d="M276,212 C292,166 338,144 394,151 L379,168 C338,163 304,180 292,214 Z"
            fill="url(#bb-chrome-silver)"
            stroke="#1E293B"
            strokeWidth="3.2"
            strokeLinejoin="round"
          />

          {/* Main Sculpted Silver Collar Housing wrapping the Banana Waist */}
          <path
            d="M272,210 C282,192 318,178 358,180 C373,182 383,196 377,216 C371,238 379,258 362,273 C338,279 298,273 282,254 C272,242 268,224 272,210 Z"
            fill="url(#bb-chrome-silver)"
            stroke="#1E293B"
            strokeWidth="3.4"
            strokeLinejoin="round"
          />

          {/* Silver Collar Bevel Highlight */}
          <path
            d="M280,214 C290,198 320,188 354,190"
            fill="none"
            stroke="#FFFFFF"
            strokeWidth="4"
            strokeLinecap="round"
          />

          {/* GLOWING GOLDEN-AMBER OVAL ENERGY CORE INSIDE SILVER COLLAR */}
          <g transform="translate(324, 228) rotate(-18)">
            {/* Recessed Dark Metallic Bezel */}
            <ellipse
              cx="0"
              cy="0"
              rx="32"
              ry="21"
              fill="#334155"
              stroke="#0F172A"
              strokeWidth="2.2"
            />
            {/* Glowing Amber-Gold Core */}
            <ellipse
              cx="0"
              cy="0"
              rx="27"
              ry="16"
              fill="#F59E0B"
              filter={isActive ? 'url(#bb-solar-overcharge)' : 'url(#bb-gold-glow)'}
            />
            {/* Bright Solar-Yellow & White Center */}
            <ellipse
              cx="0"
              cy="0"
              rx="21"
              ry="10.5"
              fill="#FEF08A"
            />
            <ellipse
              cx="-4"
              cy="-2"
              rx="13"
              ry="5.5"
              fill="#FFFFFF"
              opacity="0.95"
            />
          </g>
        </g>

        {/* ==================== STATIONARY SOLAR-BANANA MUZZLE CROWN (NO PROJECTILES!) ==================== */}
        {isActive && (
          <g
            style={{
              animation: `muzzleCrownPulse ${dur(0.64)} ease-out infinite`,
              transformOrigin: '586px 186px',
            }}
          >
            {/* Contained Solar Gold Halo at Emitter Tip */}
            <circle
              cx="586"
              cy="186"
              r="38"
              fill="#FACC15"
              opacity="0.46"
              filter="url(#bb-solar-overcharge)"
            />
            {/* Stationary 8-Point Golden Starburst anchored to Muzzle Tip */}
            <path
              d="M586,130 L594,173 L636,186 L594,199 L586,242 L578,199 L536,186 L578,173 Z"
              fill="#FFFFFF"
              stroke="#F59E0B"
              strokeWidth="1.8"
              filter="url(#bb-solar-overcharge)"
            />
            {/* Stationary Golden Peel Petals flaring around Nozzle */}
            <path
              d="M598,150 C616,136 632,140 622,158 C612,170 600,164 598,150 Z"
              fill="#FEF08A"
              filter="url(#bb-gold-glow)"
            />
            <path
              d="M600,218 C618,230 634,224 622,208 C612,198 600,204 600,218 Z"
              fill="#FEF08A"
              filter="url(#bb-gold-glow)"
            />
          </g>
        )}
      </g>
    </svg>
  );
};
