import React from 'react';

interface WeaponSvgProps {
  isActive: boolean;
  speed?: number;
  showBackdrop?: boolean;
  isMythic?: boolean;
  svgRef?: React.RefObject<SVGSVGElement | null>;
}

export const SuperSoakerSvg: React.FC<WeaponSvgProps> = ({
  isActive,
  speed = 1,
  showBackdrop = true,
  isMythic = true,
  svgRef,
}) => {
  const dur = (base: number) => `${(base / speed).toFixed(2)}s`;

  return (
    <svg
      ref={svgRef}
      viewBox="0 0 800 500"
      className="w-full h-full select-none overflow-visible"
      xmlns="http://www.w3.org/2000/svg"
    >
      <defs>
        {/* Background Aqua-Blue Splash Glow */}
        <radialGradient id="ss-bg-glow" cx="50%" cy="46%" r="48%">
          <stop offset="0%" stopColor="#00F0FF" stopOpacity="0.64" />
          <stop offset="38%" stopColor="#0284C7" stopOpacity="0.42" />
          <stop offset="75%" stopColor="#1E1B4B" stopOpacity="0.16" />
          <stop offset="100%" stopColor="#090D1A" stopOpacity="0" />
        </radialGradient>

        {/* Translucent Pressurized Aqua Water Tank Gradient */}
        <linearGradient id="ss-water-tank" x1="0%" y1="0%" x2="0%" y2="100%">
          <stop offset="0%" stopColor="#F0F9FF" />
          <stop offset="16%" stopColor="#7DD3FC" />
          <stop offset="48%" stopColor="#0284C7" />
          <stop offset="82%" stopColor="#0369A1" />
          <stop offset="100%" stopColor="#082F49" />
        </linearGradient>

        {/* Deep Sloshing Water Fill Inside Tank */}
        <linearGradient id="ss-liquid-fill" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#00F0FF" stopOpacity="0.9" />
          <stop offset="50%" stopColor="#0284C7" stopOpacity="0.95" />
          <stop offset="100%" stopColor="#1D4ED8" stopOpacity="0.98" />
        </linearGradient>

        {/* Vibrant Lime-Green Body Gradient */}
        <linearGradient id="ss-lime-body" x1="0%" y1="0%" x2="0%" y2="100%">
          <stop offset="0%" stopColor="#DCFCE7" />
          <stop offset="15%" stopColor="#4ADE80" />
          <stop offset="52%" stopColor="#22C55E" />
          <stop offset="82%" stopColor="#15803D" />
          <stop offset="100%" stopColor="#052E16" />
        </linearGradient>

        {/* Sunny Orange-Gold Pump & Cap Gradient */}
        <linearGradient id="ss-orange-pump" x1="0%" y1="0%" x2="0%" y2="100%">
          <stop offset="0%" stopColor="#FEF9C3" />
          <stop offset="20%" stopColor="#FACC15" />
          <stop offset="55%" stopColor="#F97316" />
          <stop offset="85%" stopColor="#C2410C" />
          <stop offset="100%" stopColor="#7C2D12" />
        </linearGradient>

        {/* Glossy Bubble Gradient */}
        <radialGradient id="ss-bubble" cx="35%" cy="30%" r="65%">
          <stop offset="0%" stopColor="#FFFFFF" stopOpacity="0.98" />
          <stop offset="35%" stopColor="#7DD3FC" stopOpacity="0.72" />
          <stop offset="75%" stopColor="#0284C7" stopOpacity="0.52" />
          <stop offset="100%" stopColor="#E0F2FE" stopOpacity="0.9" />
        </radialGradient>

        {/* Animated Hydro Sheen Sweep */}
        <linearGradient id="ss-sheen-grad" x1="0%" y1="0%" x2="100%" y2="0%">
          <stop offset="0%" stopColor="#FFFFFF" stopOpacity="0" />
          <stop offset="45%" stopColor="#E0F2FE" stopOpacity="0.6" />
          <stop offset="50%" stopColor="#FFFFFF" stopOpacity="0.95" />
          <stop offset="55%" stopColor="#E0F2FE" stopOpacity="0.6" />
          <stop offset="100%" stopColor="#FFFFFF" stopOpacity="0" />
        </linearGradient>

        <clipPath id="ss-tank-clip">
          <rect x="214" y="112" width="222" height="86" rx="42" />
        </clipPath>

        <clipPath id="ss-body-clip">
          <path d="M204,196 L432,196 L456,174 L568,174 L576,184 L576,238 L398,248 L204,254 Z" />
        </clipPath>

        {/* Glow Filters */}
        <filter id="ss-aqua-glow" x="-45%" y="-45%" width="190%" height="190%">
          <feGaussianBlur stdDeviation="7" result="blur" />
          <feComposite in="SourceGraphic" in2="blur" operator="over" />
        </filter>

        <filter id="ss-hydro-overcharge" x="-70%" y="-70%" width="240%" height="240%">
          <feGaussianBlur stdDeviation="13" result="blur1" />
          <feGaussianBlur stdDeviation="4" result="blur2" />
          <feMerge>
            <feMergeNode in="blur1" />
            <feMergeNode in="blur2" />
            <feMergeNode in="SourceGraphic" />
          </feMerge>
        </filter>
      </defs>

      {/* ==================== AMBIENT BACKDROP, WATER RIBBONS & BUBBLES ==================== */}
      {showBackdrop && (
        <g>
          <ellipse cx="400" cy="245" rx="350" ry="215" fill="url(#ss-bg-glow)" />

          {/* Mythic Hydro Rotating Vortex Ring */}
          {isMythic && (
            <g opacity={isActive ? '0.62' : '0.32'} transform="translate(395, 235)">
              <g style={{ animation: `rotateSlowCW 20s linear infinite` }}>
                <circle
                  cx="0"
                  cy="0"
                  r="174"
                  fill="none"
                  stroke="#00F0FF"
                  strokeWidth="1.8"
                  strokeDasharray="22 10 6 10"
                />
                <circle
                  cx="0"
                  cy="0"
                  r="150"
                  fill="none"
                  stroke="#4ADE80"
                  strokeWidth="1.3"
                  strokeDasharray="8 14"
                />
                {[0, 60, 120, 180, 240, 300].map((deg) => (
                  <path
                    key={deg}
                    d="M0,-182 C4,-172 4,-166 0,-162 C-4,-166 -4,-172 0,-182 Z"
                    fill="#7DD3FC"
                    transform={`rotate(${deg})`}
                  />
                ))}
              </g>
            </g>
          )}

          {/* Dynamic Curved Water Splash Ribbons in Background matching Reference */}
          <g opacity="0.55" fill="none" stroke="#38BDF8" strokeLinecap="round">
            <path
              d="M162,282 C125,220 152,138 232,102"
              strokeWidth="8.5"
              filter="url(#ss-aqua-glow)"
            />
            <path d="M178,328 C118,285 112,192 164,142" strokeWidth="4.5" stroke="#E0F2FE" />
            <path d="M448,315 C515,345 568,376 588,408" strokeWidth="5.5" />
          </g>

          {/* Large Glossy Water Teardrop & Floating Bubbles matching Reference */}
          <path
            d="M475,318 C516,332 550,348 558,366 C564,380 548,394 532,388 C512,378 492,346 475,318 Z"
            fill="url(#ss-bubble)"
            stroke="#BAE6FD"
            strokeWidth="1.8"
          />
          <ellipse cx="536" cy="368" rx="9" ry="4" fill="#FFFFFF" opacity="0.85" transform="rotate(24 536 368)" />

          {[
            { cx: 190, cy: 205, r: 10.5, d: '0s' },
            { cx: 235, cy: 108, r: 8.5, d: '0.4s' },
            { cx: 618, cy: 235, r: 17, d: '0.2s' },
            { cx: 585, cy: 392, r: 11.5, d: '0.7s' },
            { cx: 505, cy: 396, r: 7.5, d: '0.5s' },
            { cx: 345, cy: 88, r: 6.5, d: '0.3s' },
          ].map((b, i) => (
            <g
              key={i}
              style={{
                animation: `sparkleTwinkle ${dur(2.2)} ease-in-out infinite`,
                animationDelay: b.d,
                transformOrigin: `${b.cx}px ${b.cy}px`,
              }}
            >
              <circle
                cx={b.cx}
                cy={b.cy}
                r={b.r}
                fill="url(#ss-bubble)"
                stroke="#E0F2FE"
                strokeWidth="1.4"
              />
              <circle
                cx={b.cx - b.r * 0.32}
                cy={b.cy - b.r * 0.32}
                r={b.r * 0.28}
                fill="#FFFFFF"
              />
            </g>
          ))}
        </g>
      )}

      {/* ==================== MAIN WEAPON GROUP (FLOATS & RECOILS) ==================== */}
      <g
        style={{
          animation: isActive
            ? `soakerRecoil ${dur(0.56)} ease-in-out infinite`
            : `floatIdle 3.6s ease-in-out infinite`,
          transformOrigin: '380px 255px',
        }}
      >
        {/* Angled Pose matching Reference (-26 degrees upward-right) */}
        <g transform="translate(390, 250) rotate(-26) translate(-390, -250)">
          {/* Drop Shadow */}
          <ellipse
            cx="385"
            cy="265"
            rx="210"
            ry="55"
            fill="#020617"
            opacity="0.45"
            filter="blur(14px)"
          />

          {/* 1. TOP TRANSLUCENT AQUA-BLUE WATER TANK & DROPLET LOGO */}
          <g>
            {/* Rear Yellow-Orange Ribbed Tank Cap */}
            <rect
              x="192"
              y="130"
              width="30"
              height="50"
              rx="10"
              fill="url(#ss-orange-pump)"
              stroke="#7C2D12"
              strokeWidth="3.2"
            />
            <line x1="201" y1="136" x2="201" y2="174" stroke="#FEF9C3" strokeWidth="2.8" />
            <line x1="209" y1="136" x2="209" y2="174" stroke="#C2410C" strokeWidth="2.8" />

            {/* Main Cylindrical Translucent Blue Water Tank */}
            <rect
              x="214"
              y="112"
              width="222"
              height="86"
              rx="42"
              fill="url(#ss-water-tank)"
              stroke="#082F49"
              strokeWidth="3.6"
            />

            {/* Sloshing Water Wave, Secondary Ripple & Rising Bubbles Inside Tank */}
            <g clipPath="url(#ss-tank-clip)">
              <g
                style={{
                  animation: isActive
                    ? `soakerWaterSlosh ${dur(0.52)} ease-in-out infinite`
                    : `soakerWaterSlosh 3.0s ease-in-out infinite`,
                  transformOrigin: '325px 158px',
                }}
              >
                {/* Back Wave */}
                <path
                  d="M190,148 Q260,162 325,146 T455,154 L455,210 L190,210 Z"
                  fill="#0369A1"
                  opacity="0.7"
                />
                {/* Main Front Aqua Wave */}
                <path
                  d="M190,152 Q255,136 320,154 T450,146 L450,210 L190,210 Z"
                  fill="url(#ss-liquid-fill)"
                />
                <path
                  d="M190,152 Q255,136 320,154 T450,146"
                  fill="none"
                  stroke="#E0F2FE"
                  strokeWidth="3.5"
                />
                {/* Internal Tank Bubbles */}
                <circle cx="262" cy="176" r="5.5" fill="#E0F2FE" opacity="0.75" />
                <circle cx="280" cy="162" r="4" fill="#FFFFFF" opacity="0.85" />
                <circle cx="372" cy="174" r="6.5" fill="#E0F2FE" opacity="0.75" />
                <circle cx="392" cy="158" r="4.5" fill="#FFFFFF" opacity="0.85" />
              </g>

              {/* Tank Internal Moulded Seam Rings & Measurement Ticks */}
              <ellipse
                cx="248"
                cy="155"
                rx="13"
                ry="43"
                fill="none"
                stroke="#BAE6FD"
                strokeWidth="2.2"
                opacity="0.5"
              />
              <ellipse
                cx="398"
                cy="155"
                rx="15"
                ry="43"
                fill="none"
                stroke="#BAE6FD"
                strokeWidth="2.6"
                opacity="0.6"
              />
              {/* Hydro Level Scale Lines */}
              {[136, 148, 160, 172].map((ty, i) => (
                <line
                  key={i}
                  x1="274"
                  y1={ty}
                  x2={i % 2 === 0 ? '286' : '281'}
                  y2={ty}
                  stroke="#E0F2FE"
                  strokeWidth="2"
                  opacity="0.65"
                />
              ))}

              {/* Animated Sheen Sweep across Glass Tank */}
              {isMythic && (
                <rect
                  x="195"
                  y="105"
                  width="75"
                  height="100"
                  fill="url(#ss-sheen-grad)"
                  transform="skewX(-24)"
                  style={{
                    animation: `svgMetalSheen ${dur(4.0)} ease-in-out infinite`,
                  }}
                />
              )}
            </g>

            {/* Glossy White Specular Highlight Strip along Top of Tank */}
            <path
              d="M242,124 L402,124"
              stroke="#FFFFFF"
              strokeWidth="7.5"
              strokeLinecap="round"
              opacity="0.88"
            />

            {/* WHITE CIRCULAR WATER DROPLET BADGE IN CENTER OF TANK */}
            <g transform="translate(325, 156)">
              <circle
                cx="0"
                cy="0"
                r="24"
                fill="#E0F2FE"
                stroke="#0369A1"
                strokeWidth="2.8"
              />
              <circle
                cx="0"
                cy="0"
                r="20"
                fill="#FFFFFF"
              />
              {/* 3 Blue Water Droplets Icon inside Badge */}
              <path
                d="M-3,-12 C-3,-12 5.5,-1 5.5,4.5 C5.5,9 1.8,12.5 -3,12.5 C-7.8,12.5 -11.5,9 -11.5,4.5 C-11.5,-1 -3,-12 -3,-12 Z"
                fill="#0284C7"
              />
              <path
                d="M9,-6 C9,-6 13.5,0 13.5,3.5 C13.5,6 11.5,8 9,8 C6.5,8 4.5,6 4.5,3.5 C4.5,0 9,-6 9,-6 Z"
                fill="#00B4D8"
              />
              <circle cx="-5" cy="5.5" r="2.5" fill="#E0F2FE" />
            </g>
          </g>

          {/* 2. RIBBED BRIGHT ORANGE UNDER-BARREL PUMP HANDLE (Slides on activation!) */}
          <g
            style={{
              animation: isActive
                ? `soakerPumpSlide ${dur(0.56)} ease-in-out infinite`
                : 'none',
            }}
          >
            {/* Chrome & Green Pump Guide Rod */}
            <rect
              x="392"
              y="246"
              width="124"
              height="15"
              rx="5"
              fill="#15803D"
              stroke="#052E16"
              strokeWidth="2.6"
            />
            <line x1="396" y1="251" x2="510" y2="251" stroke="#86EFAC" strokeWidth="2" />

            {/* Cylindrical Ribbed Orange Pump Grip */}
            <rect
              x="412"
              y="241"
              width="118"
              height="44"
              rx="17"
              fill="url(#ss-orange-pump)"
              stroke="#7C2D12"
              strokeWidth="3.4"
            />
            {/* 6 Ribbed Grooves on Orange Pump */}
            {[430, 446, 462, 478, 494, 510].map((px, idx) => (
              <g key={idx}>
                <line
                  x1={px}
                  y1="244"
                  x2={px}
                  y2="282"
                  stroke="#9A3412"
                  strokeWidth="4"
                />
                <line
                  x1={px + 3}
                  y1="246"
                  x2={px + 3}
                  y2="280"
                  stroke="#FDE047"
                  strokeWidth="1.5"
                  opacity="0.7"
                />
              </g>
            ))}
            {/* Specular Highlight on Orange Pump */}
            <line
              x1="424"
              y1="250"
              x2="518"
              y2="250"
              stroke="#FFFFFF"
              strokeWidth="4.5"
              strokeLinecap="round"
              opacity="0.88"
            />
          </g>

          {/* 3. LIME-GREEN PISTOL GRIP & ORANGE TRIGGER */}
          <g>
            {/* Orange Trigger Blade */}
            <path
              d="M312,254 L335,254 L339,289 L314,283 Z"
              fill="url(#ss-orange-pump)"
              stroke="#7C2D12"
              strokeWidth="2.6"
              strokeLinejoin="round"
            />
            {/* Lime-Green Trigger Guard */}
            <path
              d="M304,252 L358,252 L348,308 L296,308 Z"
              fill="none"
              stroke="url(#ss-lime-body)"
              strokeWidth="12.5"
              strokeLinejoin="round"
            />
            <path
              d="M304,252 L358,252 L348,308 L296,308 Z"
              fill="none"
              stroke="#052E16"
              strokeWidth="2.6"
              strokeLinejoin="round"
            />

            {/* Ribbed Lime-Green Pistol Grip */}
            <path
              d="M252,250 L312,250 L296,386 L232,386 Z"
              fill="url(#ss-lime-body)"
              stroke="#052E16"
              strokeWidth="3.5"
              strokeLinejoin="round"
            />
            {/* Horizontal Grip Ridges */}
            {[276, 296, 316, 336, 356].map((gy, idx) => (
              <line
                key={idx}
                x1={258 - idx * 2}
                y1={gy}
                x2={296 - idx * 2}
                y2={gy}
                stroke="#14532D"
                strokeWidth="4.2"
                strokeLinecap="round"
              />
            ))}
            {/* Grip Specular Edge */}
            <line
              x1="258"
              y1="260"
              x2="242"
              y2="374"
              stroke="#DCFCE7"
              strokeWidth="4.5"
              strokeLinecap="round"
              opacity="0.82"
            />
            {/* Bottom Grip Flared Cap */}
            <rect
              x="228"
              y="376"
              width="72"
              height="14"
              rx="6"
              fill="url(#ss-lime-body)"
              stroke="#052E16"
              strokeWidth="2.8"
            />
          </g>

          {/* 4. MAIN LIME-GREEN RECEIVER, YELLOW-ORANGE STRIPE & NOZZLE */}
          <g>
            {/* Rear Green End Knob */}
            <rect
              x="180"
              y="206"
              width="28"
              height="36"
              rx="10"
              fill="url(#ss-lime-body)"
              stroke="#052E16"
              strokeWidth="3.2"
            />

            {/* Main Streamlined Lime-Green Chassis */}
            <path
              d="M204,196 L432,196 L456,174 L568,174 L576,184 L576,238 L398,248 L204,254 Z"
              fill="url(#ss-lime-body)"
              stroke="#052E16"
              strokeWidth="3.6"
              strokeLinejoin="round"
            />

            {/* Top Specular Highlight on Green Body */}
            <path
              d="M460,182 L564,182"
              stroke="#FFFFFF"
              strokeWidth="5.5"
              strokeLinecap="round"
              opacity="0.92"
            />

            {/* Vibrant Yellow-Orange Horizontal Accent Stripe along Receiver */}
            <polygon
              points="296,214 558,200 558,219 296,233"
              fill="url(#ss-orange-pump)"
              stroke="#9A3412"
              strokeWidth="2.2"
              strokeLinejoin="round"
            />
            <line
              x1="304"
              y1="219"
              x2="550"
              y2="205"
              stroke="#FFFFFF"
              strokeWidth="2.8"
              strokeLinecap="round"
            />

            {/* Animated Sheen Sweep across Lime-Green Body */}
            {isMythic && (
              <g clipPath="url(#ss-body-clip)" pointerEvents="none">
                <rect
                  x="200"
                  y="165"
                  width="85"
                  height="100"
                  fill="url(#ss-sheen-grad)"
                  transform="skewX(-24)"
                  style={{
                    animation: `svgMetalSheen ${dur(4.2)} ease-in-out infinite`,
                  }}
                />
              </g>
            )}

            {/* Front Cylindrical Orange-Yellow Muzzle Nozzle */}
            <rect
              x="574"
              y="181"
              width="36"
              height="50"
              rx="10"
              fill="url(#ss-orange-pump)"
              stroke="#7C2D12"
              strokeWidth="3.4"
            />
            <ellipse
              cx="610"
              cy="206"
              rx="7.5"
              ry="21"
              fill="#FACC15"
              stroke="#7C2D12"
              strokeWidth="2.6"
            />
            <ellipse
              cx="610"
              cy="206"
              rx="4.2"
              ry="12"
              fill="#00F0FF"
              filter="url(#ss-aqua-glow)"
            />
          </g>

          {/* 5. WHITE CIRCULAR PRESSURE GAUGE DIAL WITH SPINNING RED NEEDLE */}
          <g transform="translate(248, 224)">
            {/* Outer Metallic Gauge Rim */}
            <circle
              cx="0"
              cy="0"
              r="25"
              fill="#F1F5F9"
              stroke="#0F172A"
              strokeWidth="3.2"
            />
            {/* White Gauge Face */}
            <circle cx="0" cy="0" r="20" fill="#FFFFFF" stroke="#94A3B8" strokeWidth="1.6" />
            {/* Colored Pressure Arc (Green -> Orange -> Red Danger Zone) */}
            <path
              d="M-14,6 A15,15 0 1,1 14,6"
              fill="none"
              stroke="#EF4444"
              strokeWidth="4"
              strokeDasharray="16 7"
            />
            {/* Animated Spinning Red Pressure Needle */}
            <g
              style={{
                animation: isActive
                  ? `soakerNeedleSpin ${dur(0.42)} ease-in-out infinite`
                  : 'none',
              }}
            >
              <line
                x1="0"
                y1="4"
                x2="-12"
                y2="-11"
                stroke="#DC2626"
                strokeWidth="3.2"
                strokeLinecap="round"
              />
              <circle cx="0" cy="0" r="4.5" fill="#0F172A" />
            </g>
            {/* Glass Dome Glint */}
            <path
              d="M-12,-10 A14,14 0 0,1 10,-12"
              fill="none"
              stroke="#BAE6FD"
              strokeWidth="2.5"
              strokeLinecap="round"
            />
          </g>

          {/* ==================== STATIONARY AQUA SPLASH CROWN AT NOZZLE (NO PROJECTILES!) ==================== */}
          {isActive && (
            <g
              style={{
                animation: `muzzleCrownPulse ${dur(0.54)} ease-out infinite`,
                transformOrigin: '614px 206px',
              }}
            >
              {/* Contained Aqua Water Burst Crown anchored to Nozzle Tip */}
              <path
                d="M612,206 C634,156 664,148 652,180 C680,170 690,196 656,206 C690,216 680,242 652,232 C664,264 634,256 612,206 Z"
                fill="#00F0FF"
                opacity="0.9"
                filter="url(#ss-hydro-overcharge)"
              />
              <path
                d="M612,206 L658,174 L636,200 L672,206 L636,212 L658,238 Z"
                fill="#FFFFFF"
              />
              <circle cx="652" cy="158" r="6.5" fill="#FFFFFF" />
              <circle cx="658" cy="252" r="5.5" fill="#FFFFFF" />
            </g>
          )}
        </g>
      </g>
    </svg>
  );
};
