import React from 'react';

interface WeaponSvgProps {
  isActive: boolean;
  speed?: number;
  showBackdrop?: boolean;
  isMythic?: boolean;
  svgRef?: React.RefObject<SVGSVGElement | null>;
}

export const CyberCarbineSvg: React.FC<WeaponSvgProps> = ({
  isActive,
  speed = 1,
  showBackdrop = true,
  isMythic = true,
  svgRef,
}) => {
  const dur = (base: number) => `${(base / speed).toFixed(2)}s`;

  return (
    <svg
      ref={svgRef}
      viewBox="0 0 800 500"
      className="w-full h-full select-none overflow-visible"
      xmlns="http://www.w3.org/2000/svg"
    >
      <defs>
        {/* Background Radial Glow */}
        <radialGradient id="cc-bg-glow" cx="50%" cy="46%" r="48%">
          <stop offset="0%" stopColor="#00F0FF" stopOpacity="0.48" />
          <stop offset="45%" stopColor="#7C3AED" stopOpacity="0.34" />
          <stop offset="80%" stopColor="#1E1B4B" stopOpacity="0.14" />
          <stop offset="100%" stopColor="#090D1A" stopOpacity="0" />
        </radialGradient>

        {/* Matte Dark Titanium Body Gradient */}
        <linearGradient id="cc-dark-armor" x1="0%" y1="0%" x2="0%" y2="100%">
          <stop offset="0%" stopColor="#64748B" />
          <stop offset="15%" stopColor="#334155" />
          <stop offset="55%" stopColor="#1E293B" />
          <stop offset="88%" stopColor="#0F172A" />
          <stop offset="100%" stopColor="#020617" />
        </linearGradient>

        {/* Gunmetal Steel Bevel Gradient */}
        <linearGradient id="cc-steel-bevel" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#94A3B8" />
          <stop offset="35%" stopColor="#475569" />
          <stop offset="75%" stopColor="#1E293B" />
          <stop offset="100%" stopColor="#0F172A" />
        </linearGradient>

        {/* Glowing Cyan Neon Gradient */}
        <linearGradient id="cc-cyan-neon" x1="0%" y1="0%" x2="100%" y2="0%">
          <stop offset="0%" stopColor="#38BDF8" />
          <stop offset="50%" stopColor="#FFFFFF" />
          <stop offset="100%" stopColor="#00F0FF" />
        </linearGradient>

        {/* Cyber Titanium Sheen Sweep */}
        <linearGradient id="cc-sheen-grad" x1="0%" y1="0%" x2="100%" y2="0%">
          <stop offset="0%" stopColor="#00F0FF" stopOpacity="0" />
          <stop offset="45%" stopColor="#7DD3FC" stopOpacity="0.4" />
          <stop offset="50%" stopColor="#FFFFFF" stopOpacity="0.75" />
          <stop offset="55%" stopColor="#7DD3FC" stopOpacity="0.4" />
          <stop offset="100%" stopColor="#00F0FF" stopOpacity="0" />
        </linearGradient>

        <clipPath id="cc-receiver-clip">
          <path d="M238,196 L256,182 L512,182 L520,194 L520,244 L424,250 L414,266 L252,266 L238,248 Z" />
        </clipPath>

        {/* Cyan Glow Filters */}
        <filter id="cc-cyan-glow" x="-45%" y="-45%" width="190%" height="190%">
          <feGaussianBlur stdDeviation="6" result="blur" />
          <feComposite in="SourceGraphic" in2="blur" operator="over" />
        </filter>

        <filter id="cc-intense-cyan" x="-70%" y="-70%" width="240%" height="240%">
          <feGaussianBlur stdDeviation="13" result="blur1" />
          <feGaussianBlur stdDeviation="4" result="blur2" />
          <feMerge>
            <feMergeNode in="blur1" />
            <feMergeNode in="blur2" />
            <feMergeNode in="SourceGraphic" />
          </feMerge>
        </filter>
      </defs>

      {/* ==================== AMBIENT BACKDROP, MYTHIC HUD RING & HOLOGRAPHIC PEDESTAL ==================== */}
      {showBackdrop && (
        <g>
          <ellipse cx="400" cy="235" rx="345" ry="210" fill="url(#cc-bg-glow)" />

          {/* Mythic Phantom Rotating Cybernetic Target Halo */}
          {isMythic && (
            <g opacity={isActive ? '0.52' : '0.26'} transform="translate(390, 225)">
              <g style={{ animation: `rotateSlowCW 24s linear infinite` }}>
                <circle
                  cx="0"
                  cy="0"
                  r="175"
                  fill="none"
                  stroke="#00F0FF"
                  strokeWidth="1.5"
                  strokeDasharray="24 12 4 12"
                />
                <circle
                  cx="0"
                  cy="0"
                  r="152"
                  fill="none"
                  stroke="#A855F7"
                  strokeWidth="1.2"
                  strokeDasharray="8 16"
                />
              </g>
            </g>
          )}

          {/* Floating Cyan Diamond Particles matching Reference */}
          {[
            { x: 175, y: 170, s: 6.5, d: '0s' },
            { x: 225, y: 118, s: 5.5, d: '0.5s' },
            { x: 295, y: 318, s: 6, d: '0.3s' },
            { x: 565, y: 295, s: 5.5, d: '0.8s' },
            { x: 485, y: 108, s: 5, d: '0.2s' },
            { x: 645, y: 220, s: 4.5, d: '0.6s' },
          ].map((dia, i) => (
            <polygon
              key={i}
              points={`${dia.x},${dia.y - dia.s} ${dia.x + dia.s},${dia.y} ${dia.x},${dia.y + dia.s} ${dia.x - dia.s},${dia.y}`}
              fill="#E0F2FE"
              stroke="#00F0FF"
              strokeWidth="0.8"
              filter="url(#cc-cyan-glow)"
              style={{
                animation: `sparkleTwinkle ${dur(2.2)} ease-in-out infinite`,
                animationDelay: dia.d,
                transformOrigin: `${dia.x}px ${dia.y}px`,
              }}
            />
          ))}

          {/* Glowing Purple-Violet & Cyan Holographic Pedestal Rings at Bottom */}
          <g
            style={{
              animation: `pedestalPulse ${dur(2.6)} ease-in-out infinite`,
              transformOrigin: '410px 432px',
            }}
          >
            <ellipse
              cx="410"
              cy="432"
              rx="210"
              ry="23"
              fill="none"
              stroke="#A855F7"
              strokeWidth="4.5"
              opacity="0.78"
              filter="url(#cc-cyan-glow)"
            />
            <ellipse
              cx="410"
              cy="432"
              rx="168"
              ry="15.5"
              fill="none"
              stroke="#F3E8FF"
              strokeWidth="2.8"
              opacity="0.92"
            />
            <ellipse
              cx="410"
              cy="432"
              rx="242"
              ry="29"
              fill="none"
              stroke="#00F0FF"
              strokeWidth="1.6"
              opacity="0.45"
            />
          </g>
        </g>
      )}

      {/* ==================== MAIN WEAPON GROUP (FLOATS & RECOILS) ==================== */}
      <g
        style={{
          animation: isActive
            ? `cyberCarbineRecoil ${dur(0.58)} cubic-bezier(0.22, 1, 0.36, 1) infinite`
            : `floatIdle 3.7s ease-in-out infinite`,
          transformOrigin: '380px 250px',
        }}
      >
        {/* Angled Tactical Pose (-22 deg upward-right matching Reference) */}
        <g transform="translate(385, 245) rotate(-22) translate(-385, -245)">
          {/* 1. SKELETAL FOLDING BUTTSTOCK (Left/Rear) */}
          <g>
            {/* Upper Stock Bar */}
            <path
              d="M118,210 L248,210 L248,232 L126,232 Z"
              fill="url(#cc-dark-armor)"
              stroke="#020617"
              strokeWidth="3.2"
            />
            {/* Glowing Cyan Neon Channel inside Upper Stock Bar */}
            <rect
              x="130"
              y="217"
              width="106"
              height="6.5"
              rx="3.2"
              fill="url(#cc-cyan-neon)"
              filter={isActive ? 'url(#cc-intense-cyan)' : 'url(#cc-cyan-glow)'}
            />

            {/* Lower Diagonal Stock Strut */}
            <path
              d="M126,298 L244,242 L248,256 L132,316 Z"
              fill="url(#cc-steel-bevel)"
              stroke="#020617"
              strokeWidth="3.2"
            />

            {/* Vertical Buttpad on Left */}
            <path
              d="M108,204 L132,204 L136,324 L112,324 C106,324 104,204 108,204 Z"
              fill="url(#cc-dark-armor)"
              stroke="#020617"
              strokeWidth="3.4"
            />
            {/* Glowing Cyan Strip on Buttpad */}
            <rect
              x="118"
              y="224"
              width="6.5"
              height="84"
              rx="3.2"
              fill="url(#cc-cyan-neon)"
              filter="url(#cc-cyan-glow)"
            />
          </g>

          {/* 2. PISTOL GRIP & TRIGGER ASSEMBLY */}
          <g>
            {/* Trigger Guard */}
            <path
              d="M306,266 L306,296 L354,296 L358,266 Z"
              fill="none"
              stroke="#1E293B"
              strokeWidth="6.5"
              strokeLinejoin="round"
            />
            {/* Trigger Blade */}
            <path
              d="M326,268 C324,280 318,286 328,290"
              fill="none"
              stroke="#00F0FF"
              strokeWidth="4"
              strokeLinecap="round"
            />

            {/* Angled Tactical Pistol Grip */}
            <path
              d="M266,264 L244,368 L302,374 L316,266 Z"
              fill="url(#cc-dark-armor)"
              stroke="#020617"
              strokeWidth="3.4"
              strokeLinejoin="round"
            />
            {/* Grip Panel Texture & Bevel Highlight */}
            <path
              d="M276,274 L258,358 L288,361 L302,274 Z"
              fill="#334155"
              opacity="0.6"
            />
            <line
              x1="252"
              y1="364"
              x2="298"
              y2="369"
              stroke="#94A3B8"
              strokeWidth="3"
              strokeLinecap="round"
            />
          </g>

          {/* 3. CURVED HEAVY MAGAZINE WITH TWO CYAN NEON STRIPS */}
          <g>
            {/* Curved Magazine Body */}
            <path
              d="M352,262 C356,308 368,352 386,390 L448,378 C428,342 416,300 412,260 Z"
              fill="url(#cc-dark-armor)"
              stroke="#020617"
              strokeWidth="3.4"
              strokeLinejoin="round"
            />
            {/* Magazine Vertical Ribs */}
            <path
              d="M372,268 C376,308 386,345 402,380"
              fill="none"
              stroke="#475569"
              strokeWidth="3"
            />
            <path
              d="M392,268 C396,308 406,345 422,376"
              fill="none"
              stroke="#0F172A"
              strokeWidth="3.5"
            />

            {/* TWO ICONIC PARALLEL GLOWING CYAN NEON STRIPS ON LOWER MAGAZINE */}
            <line
              x1="374"
              y1="352"
              x2="432"
              y2="341"
              stroke="#00F0FF"
              strokeWidth="5.5"
              strokeLinecap="round"
              filter={isActive ? 'url(#cc-intense-cyan)' : 'url(#cc-cyan-glow)'}
            />
            <line
              x1="374"
              y1="352"
              x2="432"
              y2="341"
              stroke="#FFFFFF"
              strokeWidth="2.2"
              strokeLinecap="round"
            />

            <line
              x1="382"
              y1="372"
              x2="440"
              y2="361"
              stroke="#00F0FF"
              strokeWidth="5.5"
              strokeLinecap="round"
              filter={isActive ? 'url(#cc-intense-cyan)' : 'url(#cc-cyan-glow)'}
            />
            <line
              x1="382"
              y1="372"
              x2="440"
              y2="361"
              stroke="#FFFFFF"
              strokeWidth="2.2"
              strokeLinecap="round"
            />
          </g>

          {/* 4. UNDER-BARREL RIBBED CYLINDRICAL TACTICAL POD */}
          <g
            style={{
              animation: isActive
                ? `cyberUnderPodPulse ${dur(0.58)} ease-in-out infinite`
                : 'none',
            }}
          >
            {/* Mount Bracket */}
            <rect
              x="442"
              y="246"
              width="52"
              height="14"
              fill="#1E293B"
              stroke="#020617"
              strokeWidth="2"
            />
            {/* Cylindrical Ribbed Pod Body */}
            <rect
              x="430"
              y="256"
              width="86"
              height="28"
              rx="9"
              fill="url(#cc-steel-bevel)"
              stroke="#020617"
              strokeWidth="3"
            />
            {/* Vertical Dark & Cyan Rib Rings */}
            {[446, 462, 478, 494].map((xPos, idx) => (
              <g key={idx}>
                <rect
                  x={xPos}
                  y="255"
                  width="7.5"
                  height="30"
                  rx="2.2"
                  fill="#0F172A"
                />
                <line
                  x1={xPos + 3.7}
                  y1="259"
                  x2={xPos + 3.7}
                  y2="281"
                  stroke="#00F0FF"
                  strokeWidth="1.8"
                  opacity={isActive ? 1 : 0.72}
                />
              </g>
            ))}
          </g>

          {/* 5. HEAVY FLUTED BARREL & SLOTTED CYAN COMPENSATOR MUZZLE */}
          <g>
            {/* Main Barrel Tube */}
            <rect
              x="512"
              y="196"
              width="78"
              height="28"
              rx="5"
              fill="url(#cc-steel-bevel)"
              stroke="#020617"
              strokeWidth="3.2"
            />
            {/* Top Barrel Specular Highlight */}
            <line
              x1="516"
              y1="202"
              x2="584"
              y2="202"
              stroke="#E2E8F0"
              strokeWidth="2.8"
            />
            {/* Glowing Cyan Compensator Vent Ports on Barrel */}
            <rect
              x="534"
              y="206"
              width="14"
              height="7.5"
              rx="3.2"
              fill="#00F0FF"
              filter="url(#cc-cyan-glow)"
            />
            <rect
              x="556"
              y="206"
              width="10"
              height="7.5"
              rx="3.2"
              fill="#00F0FF"
              filter="url(#cc-cyan-glow)"
            />
            {/* Muzzle Ring Cap */}
            <ellipse
              cx="590"
              cy="210"
              rx="6.5"
              ry="14.5"
              fill="#334155"
              stroke="#020617"
              strokeWidth="2.6"
            />
            <ellipse
              cx="591"
              cy="210"
              rx="3.5"
              ry="9"
              fill="#00F0FF"
              filter="url(#cc-cyan-glow)"
            />
          </g>

          {/* 6. MAIN FACETED ARMORED RECEIVER & HANDGUARD */}
          <g>
            {/* Main Receiver Chassis */}
            <path
              d="M238,196 L256,182 L512,182 L520,194 L520,244 L424,250 L414,266 L252,266 L238,248 Z"
              fill="url(#cc-dark-armor)"
              stroke="#020617"
              strokeWidth="3.5"
              strokeLinejoin="round"
            />

            {/* Upper Silver-Blue Beveled Shoulder Plate */}
            <path
              d="M254,186 L508,186 L514,196 L246,196 Z"
              fill="#64748B"
              opacity="0.75"
            />
            <line
              x1="258"
              y1="190"
              x2="504"
              y2="190"
              stroke="#FFFFFF"
              strokeWidth="2.2"
              opacity="0.85"
            />

            {/* Handguard Forward Bevel Panel */}
            <path
              d="M398,196 L514,196 L514,240 L398,242 Z"
              fill="url(#cc-steel-bevel)"
              stroke="#0F172A"
              strokeWidth="2.4"
            />

            {/* ICONIC GLOWING L-SHAPED CYAN NEON CIRCUIT ON HANDGUARD */}
            <path
              d="M412,232 L424,212 L496,212"
              fill="none"
              stroke="#00F0FF"
              strokeWidth="5"
              strokeLinecap="round"
              strokeLinejoin="round"
              filter={isActive ? 'url(#cc-intense-cyan)' : 'url(#cc-cyan-glow)'}
            />
            <path
              d="M412,232 L424,212 L496,212"
              fill="none"
              stroke="#FFFFFF"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
            />

            {/* RECIPROCATING GLOWING CYAN PLASMA BOLT CARRIER WINDOW */}
            <g>
              {/* Recessed Dark Chamber Slot */}
              <rect
                x="302"
                y="208"
                width="74"
                height="24"
                rx="7"
                fill="#020617"
                stroke="#475569"
                strokeWidth="2.2"
              />
              {/* Moving Glowing Cyan Bolt Core */}
              <g
                style={{
                  animation: isActive
                    ? `cyberBoltCycle ${dur(0.58)} ease-in-out infinite`
                    : 'none',
                }}
              >
                <rect
                  x="308"
                  y="212"
                  width="62"
                  height="16"
                  rx="5"
                  fill="url(#cc-cyan-neon)"
                  filter={isActive ? 'url(#cc-intense-cyan)' : 'url(#cc-cyan-glow)'}
                />
                <rect
                  x="316"
                  y="216"
                  width="44"
                  height="6"
                  rx="3"
                  fill="#FFFFFF"
                />
              </g>
            </g>

            {/* Lower Receiver Cyan Micro-Indicators (• • —) */}
            <g filter="url(#cc-cyan-glow)">
              <rect x="284" y="250" width="6.5" height="4.5" rx="2" fill="#00F0FF" />
              <rect x="294" y="250" width="6.5" height="4.5" rx="2" fill="#00F0FF" />
              <rect x="304" y="250" width="14" height="4.5" rx="2" fill="#00F0FF" />
              <rect x="342" y="248" width="12" height="5" rx="2" fill="#00F0FF" />
            </g>

            {/* Animated Titanium Sheen Sweep across Receiver */}
            {isMythic && (
              <g clipPath="url(#cc-receiver-clip)" pointerEvents="none">
                <rect
                  x="210"
                  y="170"
                  width="85"
                  height="110"
                  fill="url(#cc-sheen-grad)"
                  transform="skewX(-25)"
                  style={{
                    animation: `svgMetalSheen ${dur(4.4)} ease-in-out infinite`,
                  }}
                />
              </g>
            )}
          </g>

          {/* 7. TOP TACTICAL HOLOGRAPHIC REFLEX OPTIC & FRONT IRON SIGHT */}
          <g>
            {/* Rear Iron Bumper */}
            <path
              d="M266,182 L274,168 L286,168 L290,182 Z"
              fill="#334155"
              stroke="#020617"
              strokeWidth="2.5"
            />

            {/* Reflex Optic Housing */}
            <path
              d="M306,182 L316,144 L362,144 L372,182 Z"
              fill="url(#cc-dark-armor)"
              stroke="#020617"
              strokeWidth="3.2"
              strokeLinejoin="round"
            />
            <path
              d="M318,148 L358,148"
              stroke="#CBD5E1"
              strokeWidth="2.5"
              strokeLinecap="round"
            />
            {/* Glowing Cyan Holographic Optic Lens */}
            <circle
              cx="342"
              cy="163"
              r="11.5"
              fill="#020617"
              stroke="#475569"
              strokeWidth="2"
            />
            <circle
              cx="342"
              cy="163"
              r="8.5"
              fill="#00F0FF"
              filter={isActive ? 'url(#cc-intense-cyan)' : 'url(#cc-cyan-glow)'}
            />
            {/* Active Target Crosshair inside Lens */}
            <circle
              cx="342"
              cy="163"
              r="5"
              fill="none"
              stroke="#FFFFFF"
              strokeWidth="1.2"
              strokeDasharray="3 2"
            />
            <circle cx="340" cy="161" r="2.8" fill="#FFFFFF" />

            {/* Front Sight Post with Glowing Dot */}
            <path
              d="M492,182 L498,154 L518,154 L522,182 Z"
              fill="url(#cc-dark-armor)"
              stroke="#020617"
              strokeWidth="3"
              strokeLinejoin="round"
            />
            <circle
              cx="508"
              cy="166"
              r="4.8"
              fill="#A3E635"
              stroke="#020617"
              strokeWidth="1.5"
              filter="url(#cc-cyan-glow)"
            />
          </g>

          {/* ==================== STATIONARY CYAN PLASMA MUZZLE CROWN (NO PROJECTILES!) ==================== */}
          {isActive && (
            <g
              style={{
                animation: `muzzleCrownPulse ${dur(0.58)} ease-out infinite`,
                transformOrigin: '594px 210px',
              }}
            >
              {/* Contained V-Crown Plasma Flash anchored directly at Muzzle Brake */}
              <polygon
                points="590,210 644,162 622,199 664,210 622,221 644,258"
                fill="#00F0FF"
                opacity="0.9"
                filter="url(#cc-intense-cyan)"
              />
              <polygon
                points="592,210 630,176 614,203 648,210 614,217 630,244"
                fill="#FFFFFF"
              />
              {/* Stationary Ion Ring at Compensator */}
              <ellipse
                cx="596"
                cy="210"
                rx="11"
                ry="30"
                fill="none"
                stroke="#E0F2FE"
                strokeWidth="3.2"
                filter="url(#cc-intense-cyan)"
              />
            </g>
          )}
        </g>
      </g>
    </svg>
  );
};
