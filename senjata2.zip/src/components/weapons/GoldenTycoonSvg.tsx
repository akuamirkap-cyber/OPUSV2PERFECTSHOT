import React from 'react';

interface WeaponSvgProps {
  isActive: boolean;
  speed?: number;
  showBackdrop?: boolean;
  isMythic?: boolean;
  svgRef?: React.RefObject<SVGSVGElement | null>;
}

export const GoldenTycoonSvg: React.FC<WeaponSvgProps> = ({
  isActive,
  speed = 1,
  showBackdrop = true,
  isMythic = true,
  svgRef,
}) => {
  const dur = (base: number) => `${(base / speed).toFixed(2)}s`;

  return (
    <svg
      ref={svgRef}
      viewBox="0 0 800 500"
      className="w-full h-full select-none overflow-visible"
      xmlns="http://www.w3.org/2000/svg"
    >
      <defs>
        {/* Background Glow Gradients */}
        <radialGradient id="gt-bg-glow" cx="50%" cy="48%" r="48%">
          <stop offset="0%" stopColor="#F59E0B" stopOpacity="0.62" />
          <stop offset="35%" stopColor="#D97706" stopOpacity="0.32" />
          <stop offset="68%" stopColor="#881337" stopOpacity="0.16" />
          <stop offset="100%" stopColor="#090D1A" stopOpacity="0" />
        </radialGradient>

        {/* Cylindrical 3D 24K Gold Barrel Gradient */}
        <linearGradient id="gt-gold-cylinder" x1="0%" y1="0%" x2="0%" y2="100%">
          <stop offset="0%" stopColor="#78350F" />
          <stop offset="12%" stopColor="#FDE047" />
          <stop offset="26%" stopColor="#FEF9C3" />
          <stop offset="42%" stopColor="#F59E0B" />
          <stop offset="68%" stopColor="#B45309" />
          <stop offset="86%" stopColor="#78350F" />
          <stop offset="100%" stopColor="#3B1302" />
        </linearGradient>

        {/* Beveled Gold Frame Gradient */}
        <linearGradient id="gt-gold-bevel" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#FEF9C3" />
          <stop offset="22%" stopColor="#FACC15" />
          <stop offset="52%" stopColor="#D97706" />
          <stop offset="82%" stopColor="#92400E" />
          <stop offset="100%" stopColor="#FEF08A" />
        </linearGradient>

        {/* Bright Gold Coin Face */}
        <radialGradient id="gt-coin-face" cx="35%" cy="30%" r="70%">
          <stop offset="0%" stopColor="#FFFFFF" />
          <stop offset="22%" stopColor="#FEF08A" />
          <stop offset="55%" stopColor="#EAB308" />
          <stop offset="85%" stopColor="#A16207" />
          <stop offset="100%" stopColor="#713F12" />
        </radialGradient>

        {/* Royal Crimson / Burgundy Body Gradient */}
        <linearGradient id="gt-crimson-body" x1="0%" y1="0%" x2="0%" y2="100%">
          <stop offset="0%" stopColor="#BE123C" />
          <stop offset="20%" stopColor="#E11D48" />
          <stop offset="55%" stopColor="#881337" />
          <stop offset="85%" stopColor="#4C0519" />
          <stop offset="100%" stopColor="#26020C" />
        </linearGradient>

        {/* Deep Ruby Gem Gradient */}
        <linearGradient id="gt-ruby-gem" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#FFE4E6" />
          <stop offset="25%" stopColor="#FB7185" />
          <stop offset="58%" stopColor="#E11D48" />
          <stop offset="85%" stopColor="#9F1239" />
          <stop offset="100%" stopColor="#4C0519" />
        </linearGradient>

        {/* Metallic Shimmer Sweep Gradient */}
        <linearGradient id="gt-sheen-grad" x1="0%" y1="0%" x2="100%" y2="0%">
          <stop offset="0%" stopColor="#FFFFFF" stopOpacity="0" />
          <stop offset="45%" stopColor="#FEF9C3" stopOpacity="0.65" />
          <stop offset="50%" stopColor="#FFFFFF" stopOpacity="0.95" />
          <stop offset="55%" stopColor="#FEF9C3" stopOpacity="0.65" />
          <stop offset="100%" stopColor="#FFFFFF" stopOpacity="0" />
        </linearGradient>

        <clipPath id="gt-barrel-clip">
          <rect x="222" y="120" width="440" height="128" rx="24" />
        </clipPath>

        {/* Glow Filters */}
        <filter id="gt-glow" x="-40%" y="-40%" width="180%" height="180%">
          <feGaussianBlur stdDeviation="7" result="blur" />
          <feComposite in="SourceGraphic" in2="blur" operator="over" />
        </filter>

        <filter id="gt-intense-glow" x="-60%" y="-60%" width="220%" height="220%">
          <feGaussianBlur stdDeviation="12" result="blur1" />
          <feGaussianBlur stdDeviation="4" result="blur2" />
          <feMerge>
            <feMergeNode in="blur1" />
            <feMergeNode in="blur2" />
            <feMergeNode in="SourceGraphic" />
          </feMerge>
        </filter>
      </defs>

      {/* ==================== AMBIENT BACKDROP, MYTHIC HALO & SPARKLES ==================== */}
      {showBackdrop && (
        <g>
          <ellipse cx="410" cy="240" rx="345" ry="210" fill="url(#gt-bg-glow)" />

          {/* Mythic Sovereign Rotating Mandala Halo behind weapon */}
          {isMythic && (
            <g opacity={isActive ? '0.52' : '0.26'} transform="translate(390, 215)">
              <g
                style={{
                  animation: `rotateSlowCW 26s linear infinite`,
                }}
              >
                <circle
                  cx="0"
                  cy="0"
                  r="168"
                  fill="none"
                  stroke="#FACC15"
                  strokeWidth="1.5"
                  strokeDasharray="12 8 4 8"
                />
                <circle
                  cx="0"
                  cy="0"
                  r="146"
                  fill="none"
                  stroke="#F59E0B"
                  strokeWidth="1"
                  strokeDasharray="4 10"
                />
                {/* 8 Compass Points on Mythic Ring */}
                {[0, 45, 90, 135, 180, 225, 270, 315].map((deg) => (
                  <polygon
                    key={deg}
                    points="0,-176 4,-164 0,-156 -4,-164"
                    fill="#FEF08A"
                    transform={`rotate(${deg})`}
                  />
                ))}
              </g>
            </g>
          )}

          {/* Horizontal atmospheric royal light streaks */}
          <rect x="110" y="155" width="580" height="2" fill="#FDE047" opacity="0.16" rx="1" />
          <rect x="150" y="295" width="520" height="1.5" fill="#F59E0B" opacity="0.14" rx="1" />

          {/* Floating Golden Bokeh, 4-Point Stars & Mini Dollar Sigils */}
          {[
            { cx: 205, cy: 110, r: 4.5, d: '0s', star: true },
            { cx: 315, cy: 88, r: 5.5, d: '0.4s', star: false },
            { cx: 435, cy: 98, r: 4.5, d: '0.8s', star: true },
            { cx: 540, cy: 112, r: 3.5, d: '0.2s', star: false },
            { cx: 635, cy: 138, r: 5, d: '0.6s', star: true },
            { cx: 495, cy: 298, r: 4.5, d: '0.3s', star: false },
            { cx: 365, cy: 335, r: 4, d: '0.9s', star: true },
            { cx: 265, cy: 365, r: 4.5, d: '0.5s', star: false },
            { cx: 140, cy: 275, r: 4, d: '0.7s', star: true },
          ].map((p, idx) =>
            p.star ? (
              <path
                key={idx}
                d={`M${p.cx},${p.cy - p.r * 2.4} L${p.cx + p.r * 0.6},${p.cy - p.r * 0.6} L${p.cx + p.r * 2.4},${p.cy} L${p.cx + p.r * 0.6},${p.cy + p.r * 0.6} L${p.cx},${p.cy + p.r * 2.4} L${p.cx - p.r * 0.6},${p.cy + p.r * 0.6} L${p.cx - p.r * 2.4},${p.cy} L${p.cx - p.r * 0.6},${p.cy - p.r * 0.6} Z`}
                fill="#FEF9C3"
                filter="url(#gt-glow)"
                style={{
                  animation: `sparkleTwinkle ${dur(2.1)} ease-in-out infinite`,
                  animationDelay: p.d,
                  transformOrigin: `${p.cx}px ${p.cy}px`,
                }}
              />
            ) : (
              <circle
                key={idx}
                cx={p.cx}
                cy={p.cy}
                r={p.r}
                fill="#FEF08A"
                filter="url(#gt-glow)"
                style={{
                  animation: `sparkleTwinkle ${dur(2.2)} ease-in-out infinite`,
                  animationDelay: p.d,
                  transformOrigin: `${p.cx}px ${p.cy}px`,
                }}
              />
            )
          )}
        </g>
      )}

      {/* ==================== MAIN WEAPON GROUP (FLOATS & RECOILS) ==================== */}
      <g
        style={{
          animation: isActive
            ? `tycoonRecoil ${dur(0.68)} cubic-bezier(0.22, 1, 0.36, 1) infinite`
            : `floatIdle 3.8s ease-in-out infinite`,
          transformOrigin: '280px 260px',
        }}
      >
        {/* Drop Shadow behind weapon */}
        <g opacity="0.52" transform="translate(0, 14)">
          <path
            d="M150,398 L236,398 L266,300 L425,292 L430,240 L600,240 L650,210 L650,175 L600,145 L385,145 L370,122 L225,122 L195,220 Z"
            fill="#02040A"
            filter="blur(12px)"
          />
        </g>

        {/* 1. REAR FLINTLOCK GOLD HAMMER (Cocks back & strikes on activation) */}
        <g
          style={{
            animation: isActive ? `tycoonHammerStrike ${dur(0.68)} ease-in-out infinite` : 'none',
            transformOrigin: '234px 175px',
          }}
        >
          {/* Ornate Hammer Arm */}
          <path
            d="M238,184 C218,176 210,156 186,146 C202,132 226,142 236,162 Z"
            fill="url(#gt-gold-bevel)"
            stroke="#3B1302"
            strokeWidth="2.8"
          />
          {/* Inner Engraved Curl on Hammer */}
          <path
            d="M226,170 C216,162 208,152 196,147"
            fill="none"
            stroke="#FEF9C3"
            strokeWidth="2"
            strokeLinecap="round"
          />
          {/* Hammer Spur Finial Ball */}
          <circle cx="190" cy="146" r="6.5" fill="#FEF9C3" stroke="#78350F" strokeWidth="2.2" />
          <circle cx="232" cy="172" r="9" fill="url(#gt-gold-cylinder)" stroke="#3B1302" strokeWidth="2.2" />
          <circle cx="232" cy="172" r="4" fill="#FEF08A" />
        </g>

        {/* Ignition Flint Spark when Hammer Strikes */}
        {isActive && (
          <g filter="url(#gt-intense-glow)">
            <circle cx="222" cy="148" r="10" fill="#FEF08A" opacity="0.85" />
            <path
              d="M222,130 L225,144 L238,148 L225,152 L222,166 L219,152 L206,148 L219,144 Z"
              fill="#FFFFFF"
            />
          </g>
        )}

        {/* 2. TRIGGER & ORNATE GOLD TRIGGER GUARD */}
        <g>
          {/* Trigger Finger Blade (Animated pull) */}
          <g
            style={{
              animation: isActive ? `tycoonTriggerPull ${dur(0.68)} ease-in-out infinite` : 'none',
              transformOrigin: '275px 252px',
            }}
          >
            <path
              d="M272,248 C272,266 260,280 278,287 C286,278 284,262 283,248 Z"
              fill="url(#gt-gold-bevel)"
              stroke="#3B1302"
              strokeWidth="2.4"
            />
          </g>

          {/* Ornate Gold Trigger Guard */}
          <path
            d="M238,248 C238,294 262,308 296,306 C324,304 335,285 335,248 L318,248 C318,274 308,288 288,289 C266,290 254,276 254,248 Z"
            fill="url(#gt-gold-cylinder)"
            stroke="#3B1302"
            strokeWidth="3"
          />
          {/* Inner highlight of trigger guard */}
          <path
            d="M248,254 C250,282 266,296 292,296 C312,296 324,282 326,254"
            fill="none"
            stroke="#FEF9C3"
            strokeWidth="2"
            opacity="0.8"
          />
        </g>

        {/* 3. RIBBED UNDER-BARREL CYLINDER LUG (Pumps on activation) */}
        <g
          style={{
            animation: isActive ? `tycoonUnderLugPump ${dur(0.68)} ease-in-out infinite` : 'none',
          }}
        >
          {/* Main Under-cylinder Base */}
          <rect
            x="324"
            y="240"
            width="108"
            height="48"
            rx="12"
            fill="url(#gt-gold-cylinder)"
            stroke="#3B1302"
            strokeWidth="3"
          />
          {/* 5 Vertical Ribbed Gold Rings with Bevel Glints */}
          {[336, 352, 368, 384, 400].map((rxPos, i) => (
            <g key={i}>
              <rect
                x={rxPos}
                y="237"
                width="11.5"
                height="54"
                rx="4.5"
                fill="url(#gt-gold-cylinder)"
                stroke="#3B1302"
                strokeWidth="2.2"
              />
              <line
                x1={rxPos + 4}
                y1="242"
                x2={rxPos + 4}
                y2="286"
                stroke="#FEF9C3"
                strokeWidth="2"
                opacity="0.78"
              />
            </g>
          ))}
          {/* Domed Front End Cap with Horizontal Pin */}
          <path
            d="M416,236 L429,236 C440,236 446,248 446,264 C446,280 440,292 429,292 L416,292 Z"
            fill="url(#gt-gold-cylinder)"
            stroke="#3B1302"
            strokeWidth="2.8"
          />
          <rect
            x="437"
            y="259"
            width="15"
            height="10"
            rx="4"
            fill="url(#gt-gold-bevel)"
            stroke="#3B1302"
            strokeWidth="2.2"
          />
        </g>

        {/* 4. CURVED ROYAL CRIMSON & GOLD FILIGREE GRIP */}
        <g>
          {/* Gold Outer Grip Frame & Backstrap */}
          <path
            d="M232,208 C200,226 170,286 148,378 L235,378 C243,326 259,286 287,250 L232,208 Z"
            fill="url(#gt-gold-bevel)"
            stroke="#3B1302"
            strokeWidth="3.4"
          />

          {/* Inner Royal Crimson Velvet Grip Panel */}
          <path
            d="M234,222 C208,240 182,292 161,372 L224,372 C232,324 246,286 272,250 Z"
            fill="url(#gt-crimson-body)"
            stroke="#78350F"
            strokeWidth="2.4"
          />

          {/* Intricate Baroque Gold Filigree Scrollwork & Leaves Inside Grip */}
          <g fill="none" stroke="url(#gt-gold-bevel)" strokeLinecap="round">
            <path
              d="M244,246 C222,256 205,284 218,304 C228,318 204,338 182,360"
              strokeWidth="3.5"
            />
            <path
              d="M226,264 C211,260 202,274 211,283 C218,289 227,281 223,272"
              strokeWidth="2.6"
            />
            <path
              d="M206,305 C190,311 182,328 195,339 C205,346 216,334 208,325"
              strokeWidth="2.6"
            />
            <path
              d="M192,344 C178,348 171,359 180,367"
              strokeWidth="2.4"
            />
            <path
              d="M248,266 C236,282 232,298 239,314"
              strokeWidth="2.4"
            />
            {/* Filigree Gold Dots */}
            <circle cx="215" cy="275" r="2.2" fill="#FEF08A" />
            <circle cx="201" cy="330" r="2.2" fill="#FEF08A" />
            <circle cx="184" cy="358" r="2" fill="#FEF08A" />
          </g>

          {/* Grip Specular Highlight Curve */}
          <path
            d="M228,230 C205,252 184,298 168,364"
            fill="none"
            stroke="#FFE4E6"
            strokeWidth="2.5"
            opacity="0.45"
            strokeLinecap="round"
          />

          {/* Heavy Gold Bottom Pommel Baseplate with Crown Bevel */}
          <rect
            x="140"
            y="370"
            width="102"
            height="24"
            rx="10"
            fill="url(#gt-gold-cylinder)"
            stroke="#3B1302"
            strokeWidth="3.2"
          />
          <line
            x1="152"
            y1="377"
            x2="230"
            y2="377"
            stroke="#FFFFFF"
            strokeWidth="3"
            strokeLinecap="round"
            opacity="0.85"
          />
        </g>

        {/* 5. MAIN ORNATE GOLD BARREL WITH BAROQUE SCROLLWORK & 3 RUBY DIAMONDS */}
        <g>
          {/* Main Barrel Cylinder */}
          <rect
            x="375"
            y="148"
            width="225"
            height="72"
            fill="url(#gt-gold-cylinder)"
            stroke="#3B1302"
            strokeWidth="3.4"
          />

          {/* Upper and Lower Raised Gold Trim Rails */}
          <rect
            x="375"
            y="143"
            width="225"
            height="10"
            rx="3.5"
            fill="url(#gt-gold-bevel)"
            stroke="#3B1302"
            strokeWidth="2.2"
          />
          <rect
            x="375"
            y="215"
            width="225"
            height="10"
            rx="3.5"
            fill="url(#gt-gold-bevel)"
            stroke="#3B1302"
            strokeWidth="2.2"
          />

          {/* Top Specular Shine Strip along Barrel */}
          <line
            x1="384"
            y1="162"
            x2="592"
            y2="162"
            stroke="#FFFFFF"
            strokeWidth="4.5"
            strokeLinecap="round"
            opacity="0.82"
          />

          {/* Ornate Baroque Scrollwork Engravings between the 3 Ruby Gems */}
          <g fill="none" stroke="#78350F" strokeWidth="2.5" strokeLinecap="round" opacity="0.88">
            <path d="M385,172 C395,158 409,158 415,172 C421,185 405,200 392,197 C383,195 383,184 392,182" />
            <path d="M432,171 C443,157 456,157 461,171" />
            <path d="M432,197 C443,211 456,211 461,197" />
            <path d="M482,169 C494,156 510,156 518,169" />
            <path d="M482,199 C494,212 510,212 518,199" />
            <path d="M542,172 C554,158 572,160 579,174 C585,187 572,203 558,200 C548,198 548,186 556,184" />
            <path d="M576,168 C587,164 595,175 591,186 C587,198 578,203 570,196" />
          </g>

          {/* Gold Highlight Overlay on Scrollwork */}
          <g fill="none" stroke="#FEF9C3" strokeWidth="1.5" strokeLinecap="round" opacity="0.8">
            <path d="M386,170 C396,156 409,156 415,170" />
            <path d="M433,169 C444,155 456,155 461,169" />
            <path d="M483,167 C495,154 511,154 519,167" />
            <path d="M543,170 C555,156 573,158 579,172" />
          </g>

          {/* 3 CRIMSON RUBY DIAMOND GEMS SET INTO THE BARREL */}
          {[
            { cx: 422, delay: '0s' },
            { cx: 472, delay: '0.1s' },
            { cx: 528, delay: '0.2s' },
          ].map((gem, idx) => (
            <g
              key={idx}
              style={{
                animation: isActive
                  ? `rubyGemCascade ${dur(0.68)} ease-in-out infinite`
                  : 'none',
                animationDelay: gem.delay,
                transformOrigin: `${gem.cx}px 184px`,
              }}
            >
              {/* Gold Diamond Bezel Setting */}
              <polygon
                points={`${gem.cx},164 ${gem.cx + 17},184 ${gem.cx},204 ${gem.cx - 17},184`}
                fill="url(#gt-gold-bevel)"
                stroke="#3B1302"
                strokeWidth="2.4"
              />
              {/* Ruby Diamond Body */}
              <polygon
                points={`${gem.cx},169 ${gem.cx + 13},184 ${gem.cx},199 ${gem.cx - 13},184`}
                fill="url(#gt-ruby-gem)"
                stroke="#4C0519"
                strokeWidth="1.5"
              />
              {/* Inner Crown Table Facet */}
              <polygon
                points={`${gem.cx},174 ${gem.cx + 7},184 ${gem.cx},194 ${gem.cx - 7},184`}
                fill="#FB7185"
                opacity="0.65"
              />
              {/* Top-Left Specular Glint */}
              <polygon
                points={`${gem.cx - 1},171 ${gem.cx + 5},180 ${gem.cx - 1},183 ${gem.cx - 7},179`}
                fill="#FFFFFF"
                opacity="0.92"
              />
              {/* Mythic Cross Glint when Active */}
              {isActive && (
                <path
                  d={`M${gem.cx},160 L${gem.cx},208 M${gem.cx - 20},184 L${gem.cx + 20},184`}
                  stroke="#FFE4E6"
                  strokeWidth="2"
                  filter="url(#gt-glow)"
                />
              )}
            </g>
          ))}

          {/* FLARED VERTICAL GOLD MUZZLE COLLAR & BULBOUS ENGRAVED TIP */}
          <g>
            {/* Flared Vertical Collar Ring */}
            <path
              d="M594,130 C607,130 620,144 620,184 C620,224 607,238 594,238 L586,223 L586,145 Z"
              fill="url(#gt-gold-cylinder)"
              stroke="#3B1302"
              strokeWidth="3.4"
            />
            <path
              d="M598,137 C607,144 612,162 612,184 C612,206 607,224 598,231"
              fill="none"
              stroke="#FFFFFF"
              strokeWidth="3"
              opacity="0.85"
            />

            {/* Bulbous Rounded Golden Muzzle Tip */}
            <path
              d="M617,152 C646,152 664,165 664,184 C664,203 646,216 617,216 Z"
              fill="url(#gt-gold-cylinder)"
              stroke="#3B1302"
              strokeWidth="3.4"
            />
            {/* Engraved Spiral Swirl on Bulbous Tip */}
            <path
              d="M626,174 C639,167 652,176 648,187 C644,196 630,193 632,183"
              fill="none"
              stroke="#78350F"
              strokeWidth="2.4"
              strokeLinecap="round"
            />
            {/* Specular Glint on Bulbous Tip */}
            <ellipse
              cx="639"
              cy="167"
              rx="12"
              ry="5"
              fill="#FFFFFF"
              opacity="0.88"
            />
          </g>
        </g>

        {/* 6. CENTRAL ROYAL CRIMSON RECEIVER BOX & 3D DOLLAR ($) MEDALLION */}
        <g>
          {/* Outer Crimson & Gold Rounded Receiver Box */}
          <rect
            x="222"
            y="120"
            width="164"
            height="128"
            rx="26"
            fill="url(#gt-crimson-body)"
            stroke="#3B1302"
            strokeWidth="3.6"
          />
          {/* Top Crimson Specular Rim */}
          <path
            d="M246,126 L362,126"
            stroke="#FDA4AF"
            strokeWidth="3.5"
            strokeLinecap="round"
            opacity="0.68"
          />

          {/* Thick Beveled Gold Inner Frame */}
          <rect
            x="234"
            y="132"
            width="140"
            height="104"
            rx="18"
            fill="url(#gt-gold-bevel)"
            stroke="#3B1302"
            strokeWidth="3"
          />

          {/* Recessed Burgundy & Engraved Gold Chamber Plate */}
          <rect
            x="244"
            y="142"
            width="120"
            height="84"
            rx="12"
            fill="url(#gt-crimson-body)"
            stroke="#78350F"
            strokeWidth="2.2"
          />

          {/* Left-side Gold Engraved Panel inside Receiver */}
          <path
            d="M246,144 L282,144 L282,224 L246,224 C245,224 245,144 246,144 Z"
            fill="url(#gt-gold-cylinder)"
            opacity="0.94"
          />
          {/* Scrollwork on Left Gold Panel */}
          <g fill="none" stroke="#78350F" strokeWidth="2.2" strokeLinecap="round">
            <path d="M254,155 C265,151 271,162 262,168 C254,174 252,184 262,190 C271,196 265,209 254,205" />
            <circle cx="260" cy="180" r="2.8" fill="#78350F" />
          </g>

          {/* Right-side Crimson Panel Filigree Accents */}
          <g fill="none" stroke="url(#gt-gold-bevel)" strokeWidth="2.2" opacity="0.85">
            <path d="M338,153 C351,153 357,164 348,174" />
            <path d="M338,215 C351,215 357,204 348,194" />
          </g>

          {/* CENTRAL GLEAMING 3D GOLD DOLLAR ($) COIN MEDALLION */}
          <g
            style={{
              animation: isActive
                ? `tycoonCoinSpin ${dur(0.68)} cubic-bezier(0.34, 1.56, 0.64, 1) infinite`
                : 'none',
              transformOrigin: '308px 184px',
            }}
          >
            {/* Coin Drop Shadow */}
            <circle cx="310" cy="187" r="39" fill="#1F0108" opacity="0.72" />

            {/* Outer Gold Coin Rim */}
            <circle
              cx="308"
              cy="184"
              r="38"
              fill="url(#gt-gold-bevel)"
              stroke="#3B1302"
              strokeWidth="3"
            />

            {/* Recessed Coin Face */}
            <circle
              cx="308"
              cy="184"
              r="31"
              fill="url(#gt-coin-face)"
              stroke="#92400E"
              strokeWidth="2.2"
            />

            {/* Dashed Milled Coin Edge Ring */}
            <circle
              cx="308"
              cy="184"
              r="27"
              fill="none"
              stroke="#78350F"
              strokeWidth="1.6"
              strokeDasharray="3 3"
              opacity="0.65"
            />

            {/* Embossed Dollar Sign ($) Shadow */}
            <text
              x="310"
              y="198"
              textAnchor="middle"
              fill="#78350F"
              fontSize="41"
              fontWeight="900"
              fontFamily="Chakra Petch, sans-serif"
            >
              $
            </text>
            {/* Embossed Dollar Sign ($) Gold Main */}
            <text
              x="308"
              y="196"
              textAnchor="middle"
              fill="#FEF9C3"
              stroke="#92400E"
              strokeWidth="1.3"
              fontSize="41"
              fontWeight="900"
              fontFamily="Chakra Petch, sans-serif"
            >
              $
            </text>

            {/* Diagonal Metallic Sheen across Coin */}
            <path
              d="M284,164 L298,154 L330,204 L316,214 Z"
              fill="#FFFFFF"
              opacity="0.4"
            />
          </g>
        </g>

        {/* ANIMATED METALLIC GOLD SHEEN SWEEP ACROSS RECEIVER & BARREL */}
        {isMythic && (
          <g clipPath="url(#gt-barrel-clip)" pointerEvents="none">
            <rect
              x="180"
              y="110"
              width="95"
              height="160"
              fill="url(#gt-sheen-grad)"
              transform="skewX(-25)"
              style={{
                animation: `svgMetalSheen ${dur(4.2)} ease-in-out infinite`,
              }}
            />
          </g>
        )}

        {/* ==================== STATIONARY ACTIVATION ENERGY CROWN (NO PROJECTILES!) ==================== */}
        {isActive && (
          <g
            style={{
              animation: `muzzleCrownPulse ${dur(0.68)} ease-out infinite`,
              transformOrigin: '664px 184px',
            }}
          >
            {/* Contained Royal Gold & Ruby Aura Ring anchored at the Muzzle Tip */}
            <circle
              cx="664"
              cy="184"
              r="38"
              fill="none"
              stroke="#FEF08A"
              strokeWidth="4.5"
              filter="url(#gt-intense-glow)"
            />
            <circle
              cx="664"
              cy="184"
              r="26"
              fill="none"
              stroke="#FB7185"
              strokeWidth="2.5"
              strokeDasharray="6 4"
            />
            <circle
              cx="664"
              cy="184"
              r="22"
              fill="#F59E0B"
              opacity="0.52"
              filter="url(#gt-intense-glow)"
            />
            {/* Stationary 8-Pointed Golden Royal Starburst at Muzzle Crown */}
            <path
              d="M664,128 L672,171 L714,184 L672,197 L664,240 L656,197 L614,184 L656,171 Z"
              fill="#FFFFFF"
              stroke="#F59E0B"
              strokeWidth="1.8"
              filter="url(#gt-intense-glow)"
            />
            {/* Stationary Ruby & Gold Diamond Sparkles around Muzzle Collar */}
            <polygon
              points="686,144 693,151 686,158 679,151"
              fill="#FB7185"
              filter="url(#gt-glow)"
            />
            <polygon
              points="688,212 695,219 688,226 681,219"
              fill="#FDE047"
              filter="url(#gt-glow)"
            />
          </g>
        )}
      </g>
    </svg>
  );
};
