import React from 'react';

interface WeaponSvgProps {
  isActive: boolean;
  speed?: number;
  showBackdrop?: boolean;
  isMythic?: boolean;
  svgRef?: React.RefObject<SVGSVGElement | null>;
}

export const StormCallerSvg: React.FC<WeaponSvgProps> = ({
  isActive,
  speed = 1,
  showBackdrop = true,
  isMythic = true,
  svgRef,
}) => {
  const dur = (base: number) => `${(base / speed).toFixed(2)}s`;

  return (
    <svg
      ref={svgRef}
      viewBox="0 0 800 500"
      className="w-full h-full select-none overflow-visible"
      xmlns="http://www.w3.org/2000/svg"
    >
      <defs>
        {/* Storm Blue-Purple Radial Glow */}
        <radialGradient id="sc-bg-glow" cx="50%" cy="46%" r="48%">
          <stop offset="0%" stopColor="#38BDF8" stopOpacity="0.62" />
          <stop offset="40%" stopColor="#2563EB" stopOpacity="0.35" />
          <stop offset="72%" stopColor="#581C87" stopOpacity="0.22" />
          <stop offset="100%" stopColor="#090D1A" stopOpacity="0" />
        </radialGradient>

        {/* Dark Obsidian Barrel & Chassis Gradient */}
        <linearGradient id="sc-obsidian-body" x1="0%" y1="0%" x2="0%" y2="100%">
          <stop offset="0%" stopColor="#475569" />
          <stop offset="22%" stopColor="#1E293B" />
          <stop offset="65%" stopColor="#0F172A" />
          <stop offset="100%" stopColor="#020617" />
        </linearGradient>

        {/* Crystalline Ice-Blue Wing Gradient (Light Facet) */}
        <linearGradient id="sc-crystal-light" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#FFFFFF" />
          <stop offset="35%" stopColor="#E0F2FE" />
          <stop offset="75%" stopColor="#7DD3FC" />
          <stop offset="100%" stopColor="#0284C7" />
        </linearGradient>

        {/* Crystalline Ice-Blue Wing Gradient (Mid/Deep Facet) */}
        <linearGradient id="sc-crystal-mid" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#E0F2FE" />
          <stop offset="45%" stopColor="#38BDF8" />
          <stop offset="85%" stopColor="#0284C7" />
          <stop offset="100%" stopColor="#0369A1" />
        </linearGradient>

        {/* Glowing Cyan Tesla Coil Gradient */}
        <linearGradient id="sc-tesla-coil" x1="0%" y1="0%" x2="0%" y2="100%">
          <stop offset="0%" stopColor="#FFFFFF" />
          <stop offset="30%" stopColor="#7DD3FC" />
          <stop offset="70%" stopColor="#0284C7" />
          <stop offset="100%" stopColor="#0C4A6E" />
        </linearGradient>

        {/* Ice Crystal Sheen Sweep */}
        <linearGradient id="sc-sheen-grad" x1="0%" y1="0%" x2="100%" y2="0%">
          <stop offset="0%" stopColor="#38BDF8" stopOpacity="0" />
          <stop offset="45%" stopColor="#E0F2FE" stopOpacity="0.55" />
          <stop offset="50%" stopColor="#FFFFFF" stopOpacity="0.95" />
          <stop offset="55%" stopColor="#E0F2FE" stopOpacity="0.55" />
          <stop offset="100%" stopColor="#38BDF8" stopOpacity="0" />
        </linearGradient>

        <clipPath id="sc-barrel-clip">
          <polygon points="316,192 522,184 532,256 322,262" />
        </clipPath>

        {/* Electric Glow Filters */}
        <filter id="sc-electric-glow" x="-45%" y="-45%" width="190%" height="190%">
          <feGaussianBlur stdDeviation="6" result="blur" />
          <feComposite in="SourceGraphic" in2="blur" operator="over" />
        </filter>

        <filter id="sc-thunder-overcharge" x="-70%" y="-70%" width="240%" height="240%">
          <feGaussianBlur stdDeviation="13" result="blur1" />
          <feGaussianBlur stdDeviation="4" result="blur2" />
          <feMerge>
            <feMergeNode in="blur1" />
            <feMergeNode in="blur2" />
            <feMergeNode in="SourceGraphic" />
          </feMerge>
        </filter>
      </defs>

      {/* ==================== AMBIENT BACKDROP, MYTHIC STORM RING & PEDESTAL ==================== */}
      {showBackdrop && (
        <g>
          <ellipse cx="405" cy="235" rx="345" ry="215" fill="url(#sc-bg-glow)" />

          {/* Mythic Tempest Rotating Storm Ring */}
          {isMythic && (
            <g opacity={isActive ? '0.58' : '0.3'} transform="translate(395, 225)">
              <g style={{ animation: `rotateSlowCCW 20s linear infinite` }}>
                <circle
                  cx="0"
                  cy="0"
                  r="175"
                  fill="none"
                  stroke="#7DD3FC"
                  strokeWidth="1.6"
                  strokeDasharray="20 8 4 8"
                />
                <circle
                  cx="0"
                  cy="0"
                  r="152"
                  fill="none"
                  stroke="#38BDF8"
                  strokeWidth="1.2"
                  strokeDasharray="6 14"
                />
              </g>
            </g>
          )}

          {/* Glowing Purple-Cyan Pedestal Rings at Bottom */}
          <g
            style={{
              animation: `pedestalPulse ${dur(2.4)} ease-in-out infinite`,
              transformOrigin: '405px 435px',
            }}
          >
            <ellipse
              cx="405"
              cy="435"
              rx="215"
              ry="23"
              fill="none"
              stroke="#A855F7"
              strokeWidth="4"
              opacity="0.72"
              filter="url(#sc-electric-glow)"
            />
            <ellipse
              cx="405"
              cy="435"
              rx="165"
              ry="15"
              fill="none"
              stroke="#38BDF8"
              strokeWidth="3"
              opacity="0.92"
              filter="url(#sc-electric-glow)"
            />
          </g>
        </g>
      )}

      {/* ==================== MAIN WEAPON GROUP (FLOATS & RECOILS) ==================== */}
      <g
        style={{
          animation: isActive
            ? `stormCallerRecoil ${dur(0.56)} cubic-bezier(0.22, 1, 0.36, 1) infinite`
            : `floatIdle 3.4s ease-in-out infinite`,
          transformOrigin: '380px 260px',
        }}
      >
        {/* Steep Diagonal Pose matching Reference (-34 degrees upward-right) */}
        <g transform="translate(395, 250) rotate(-34) translate(-395, -250)">
          {/* 1. UPPER-LEFT SWEPT CRYSTALLINE ICE-BLUE WINGS (Flares outward on activation) */}
          <g
            style={{
              animation: isActive
                ? `stormWingTopFlare ${dur(0.56)} ease-in-out infinite`
                : 'none',
              transformOrigin: '370px 195px',
            }}
          >
            {/* Forward Upper Crystal Fin */}
            <polygon
              points="318,192 266,142 380,153 424,190"
              fill="url(#sc-crystal-mid)"
              stroke="#082F49"
              strokeWidth="3"
              strokeLinejoin="round"
            />
            <polygon
              points="266,142 342,150 318,192"
              fill="url(#sc-crystal-light)"
            />

            {/* Main Large Swept Rear Ice Crystal Wing */}
            <polygon
              points="178,187 294,156 346,192 246,240 204,229"
              fill="url(#sc-crystal-light)"
              stroke="#082F49"
              strokeWidth="3.2"
              strokeLinejoin="round"
            />
            {/* Crystal Facet Splits */}
            <polygon
              points="204,229 294,156 346,192 246,240"
              fill="url(#sc-crystal-mid)"
              opacity="0.78"
            />
            <line
              x1="180"
              y1="188"
              x2="344"
              y2="192"
              stroke="#FFFFFF"
              strokeWidth="3"
            />
          </g>

          {/* 2. LOWER-RIGHT JAGGED CRYSTALLINE FINS (Flares downward on activation) */}
          <g
            style={{
              animation: isActive
                ? `stormWingBottomFlare ${dur(0.56)} ease-in-out infinite`
                : 'none',
              transformOrigin: '375px 265px',
            }}
          >
            {/* Forward Under-Barrel Dark & Cyan Spike */}
            <polygon
              points="375,260 450,258 416,298 368,283"
              fill="#0F172A"
              stroke="#020617"
              strokeWidth="3.2"
              strokeLinejoin="round"
            />
            <polygon
              points="384,264 438,262 414,290"
              fill="url(#sc-crystal-light)"
            />

            {/* Rear Grip Guard Crystal Wing */}
            <polygon
              points="312,276 378,268 352,336 286,344"
              fill="url(#sc-crystal-mid)"
              stroke="#082F49"
              strokeWidth="3"
              strokeLinejoin="round"
            />
            <polygon
              points="318,282 368,274 346,328"
              fill="url(#sc-crystal-light)"
            />
          </g>

          {/* 3. ANGLED GEOMETRIC GRIP WITH GLOWING LIGHTNING CORE */}
          <g>
            {/* Outer Faceted Grip Frame */}
            <polygon
              points="276,248 346,252 292,398 225,388 217,358"
              fill="url(#sc-obsidian-body)"
              stroke="#020617"
              strokeWidth="3.5"
              strokeLinejoin="round"
            />
            {/* Ice-Cyan Grip Rim Trim */}
            <polyline
              points="227,386 290,396 342,256"
              fill="none"
              stroke="#38BDF8"
              strokeWidth="3.2"
              strokeLinejoin="round"
            />
            <polyline
              points="274,252 219,358 227,386"
              fill="none"
              stroke="#BAE6FD"
              strokeWidth="2.8"
              strokeLinejoin="round"
            />

            {/* Glowing Blue-White Electric Core Panel Inside Grip */}
            <polygon
              points="276,274 322,278 284,380 235,372 231,352"
              fill="url(#sc-crystal-mid)"
              filter={isActive ? 'url(#sc-thunder-overcharge)' : 'url(#sc-electric-glow)'}
            />
            {/* Inner White-Cyan Lightning Shard inside Grip */}
            <polygon
              points="286,294 259,335 278,337 253,370 299,326 278,324"
              fill="#FFFFFF"
              filter="url(#sc-electric-glow)"
            />
          </g>

          {/* 4. HEAVY FACETED DARK-OBSIDIAN MAIN BARREL WITH LIGHTNING INLAY */}
          <g>
            {/* Main Hexagonal Dark Barrel Body */}
            <polygon
              points="316,192 522,184 532,256 322,262"
              fill="url(#sc-obsidian-body)"
              stroke="#020617"
              strokeWidth="3.6"
              strokeLinejoin="round"
            />

            {/* Upper Beveled Slate-Blue Facet Plane */}
            <polygon
              points="320,195 520,187 524,212 324,218"
              fill="#334155"
              opacity="0.82"
            />
            {/* Crisp Specular Ridge Line along Barrel */}
            <line
              x1="326"
              y1="218"
              x2="522"
              y2="212"
              stroke="#BAE6FD"
              strokeWidth="2.4"
              opacity="0.85"
            />

            {/* ICONIC GLOWING LIGHTNING BOLT EMBLEM (⚡) ON BARREL SIDE */}
            <g
              filter={isActive ? 'url(#sc-thunder-overcharge)' : 'url(#sc-electric-glow)'}
            >
              <polygon
                points="470,197 406,224 434,226 390,249 464,220 436,218"
                fill="url(#sc-crystal-light)"
              />
              <polygon
                points="460,202 415,222 436,224 402,243 454,220 434,218"
                fill="#FFFFFF"
              />
            </g>

            {/* Animated Crystal Sheen Sweep across Barrel */}
            {isMythic && (
              <g clipPath="url(#sc-barrel-clip)" pointerEvents="none">
                <rect
                  x="290"
                  y="170"
                  width="85"
                  height="110"
                  fill="url(#sc-sheen-grad)"
                  transform="skewX(-25)"
                  style={{
                    animation: `svgMetalSheen ${dur(3.9)} ease-in-out infinite`,
                  }}
                />
              </g>
            )}
          </g>

          {/* 5. FRONT CYLINDRICAL TESLA COIL CAPACITOR NOZZLE */}
          <g>
            {/* First Stepped Cyan Ring */}
            <rect
              x="516"
              y="179"
              width="25"
              height="82"
              rx="8.5"
              fill="url(#sc-tesla-coil)"
              stroke="#082F49"
              strokeWidth="3.2"
            />
            {/* Second Stepped Bright Ice-Cyan Ring */}
            <rect
              x="536"
              y="185"
              width="25"
              height="70"
              rx="9.5"
              fill="url(#sc-crystal-light)"
              stroke="#082F49"
              strokeWidth="3.2"
              filter="url(#sc-electric-glow)"
            />
            {/* Glowing Front Emitter Face & Spherical High-Voltage Core */}
            <ellipse
              cx="561"
              cy="220"
              rx="10.5"
              ry="31"
              fill="#E0F2FE"
              stroke="#0284C7"
              strokeWidth="2.6"
              filter={isActive ? 'url(#sc-thunder-overcharge)' : 'url(#sc-electric-glow)'}
            />
            <circle
              cx="567"
              cy="220"
              r={isActive ? '20' : '13'}
              fill="#FFFFFF"
              filter="url(#sc-thunder-overcharge)"
            />
          </g>

          {/* 6. CENTRAL TILTED SQUARE / RHOMBUS LIGHTNING EMBLEM NODE */}
          <g>
            {/* Outer Ice-Cyan Beveled Square Frame */}
            <polygon
              points="296,204 358,204 348,266 286,266"
              fill="url(#sc-crystal-light)"
              stroke="#020617"
              strokeWidth="3.4"
              strokeLinejoin="round"
            />
            {/* Inner Dark Obsidian Recessed Square */}
            <polygon
              points="306,214 346,214 338,256 298,256"
              fill="#0F172A"
              stroke="#0284C7"
              strokeWidth="2.2"
              strokeLinejoin="round"
            />
            {/* Glowing White-Cyan Lightning Bolt Icon inside Badge */}
            <polygon
              points="333,217 309,236 322,236 311,253 337,232 324,232"
              fill="#FFFFFF"
              filter={isActive ? 'url(#sc-thunder-overcharge)' : 'url(#sc-electric-glow)'}
            />
          </g>

          {/* ==================== CRACKLING SVG LIGHTNING ARCS AROUND CHASSIS (NO PROJECTILES!) ==================== */}
          <g
            style={{
              animation: `lightningJitter ${dur(isActive ? 0.16 : 0.6)} steps(2, end) infinite`,
              transformOrigin: '420px 220px',
            }}
          >
            {/* Upper Barrel-to-Nozzle Electric Arc */}
            <polyline
              points="240,152 285,126 318,144 375,116 415,152 480,134 535,168 567,205"
              fill="none"
              stroke="#38BDF8"
              strokeWidth={isActive ? '5.5' : '2.8'}
              strokeLinecap="round"
              strokeLinejoin="round"
              filter="url(#sc-thunder-overcharge)"
            />
            <polyline
              points="240,152 285,126 318,144 375,116 415,152 480,134 535,168 567,205"
              fill="none"
              stroke="#FFFFFF"
              strokeWidth={isActive ? '2.8' : '1.4'}
              strokeLinecap="round"
              strokeLinejoin="round"
            />

            {/* Lower Grip-to-Wing Electric Arc */}
            <polyline
              points="210,335 184,286 232,265 196,225 256,215"
              fill="none"
              stroke="#38BDF8"
              strokeWidth={isActive ? '5' : '2.4'}
              strokeLinecap="round"
              strokeLinejoin="round"
              filter="url(#sc-thunder-overcharge)"
            />
            <polyline
              points="210,335 184,286 232,265 196,225 256,215"
              fill="none"
              stroke="#FFFFFF"
              strokeWidth={isActive ? '2.2' : '1.1'}
            />

            {/* Under-Barrel to Tesla Muzzle Arc */}
            <polyline
              points="365,335 425,318 446,282 512,296 548,256 568,226"
              fill="none"
              stroke="#38BDF8"
              strokeWidth={isActive ? '5.5' : '2.8'}
              strokeLinecap="round"
              strokeLinejoin="round"
              filter="url(#sc-thunder-overcharge)"
            />
            <polyline
              points="365,335 425,318 446,282 512,296 548,256 568,226"
              fill="none"
              stroke="#FFFFFF"
              strokeWidth={isActive ? '2.4' : '1.3'}
            />

            {/* Extra High-Voltage Cage Arcs when ACTIVATED (Strictly anchored around nozzle & fins - NO bullet!) */}
            {isActive && (
              <g>
                {/* Stationary Tesla Crown Arc Loop around Muzzle */}
                <polyline
                  points="544,172 586,148 612,185 596,218 618,250 584,280 542,258"
                  fill="none"
                  stroke="#FFFFFF"
                  strokeWidth="3.8"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  filter="url(#sc-thunder-overcharge)"
                />
                {/* Cross-Body Surge Arc */}
                <polyline
                  points="295,235 362,194 428,240 495,190 564,220"
                  fill="none"
                  stroke="#E0F2FE"
                  strokeWidth="3.4"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  filter="url(#sc-thunder-overcharge)"
                />
                {/* Contained Plasma Sphere Flare at Tesla Muzzle */}
                <circle
                  cx="568"
                  cy="220"
                  r="36"
                  fill="#38BDF8"
                  opacity="0.52"
                  filter="url(#sc-thunder-overcharge)"
                />
              </g>
            )}
          </g>
        </g>
      </g>
    </svg>
  );
};
