import React from 'react';

interface WeaponSvgProps {
  isActive: boolean;
  speed?: number;
  showBackdrop?: boolean;
  isMythic?: boolean;
  svgRef?: React.RefObject<SVGSVGElement | null>;
}

export const CardGunSvg: React.FC<WeaponSvgProps> = ({
  isActive,
  speed = 1,
  showBackdrop = true,
  isMythic = true,
  svgRef,
}) => {
  const dur = (base: number) => `${(base / speed).toFixed(2)}s`;

  return (
    <svg
      ref={svgRef}
      viewBox="0 0 800 500"
      className="w-full h-full select-none overflow-visible"
      xmlns="http://www.w3.org/2000/svg"
    >
      <defs>
        {/* Background Royal Casino Purple & Red Glow */}
        <radialGradient id="cg-bg-glow" cx="48%" cy="48%" r="48%">
          <stop offset="0%" stopColor="#EF4444" stopOpacity="0.58" />
          <stop offset="42%" stopColor="#7E22CE" stopOpacity="0.42" />
          <stop offset="78%" stopColor="#1E1B4B" stopOpacity="0.16" />
          <stop offset="100%" stopColor="#090D1A" stopOpacity="0" />
        </radialGradient>

        {/* Royal Casino Crimson Armor Gradient */}
        <linearGradient id="cg-crimson" x1="0%" y1="0%" x2="0%" y2="100%">
          <stop offset="0%" stopColor="#FECACA" />
          <stop offset="16%" stopColor="#EF4444" />
          <stop offset="56%" stopColor="#B91C1C" />
          <stop offset="88%" stopColor="#7F1D1D" />
          <stop offset="100%" stopColor="#450A0A" />
        </linearGradient>

        {/* Pearl White & Silver Chassis Gradient */}
        <linearGradient id="cg-pearl-silver" x1="0%" y1="0%" x2="0%" y2="100%">
          <stop offset="0%" stopColor="#FFFFFF" />
          <stop offset="28%" stopColor="#F8FAFC" />
          <stop offset="68%" stopColor="#CBD5E1" />
          <stop offset="100%" stopColor="#64748B" />
        </linearGradient>

        {/* 24K Casino Gold Trim Gradient */}
        <linearGradient id="cg-gold-trim" x1="0%" y1="0%" x2="0%" y2="100%">
          <stop offset="0%" stopColor="#FEF9C3" />
          <stop offset="26%" stopColor="#FACC15" />
          <stop offset="64%" stopColor="#D97706" />
          <stop offset="100%" stopColor="#78350F" />
        </linearGradient>

        {/* Casino Sheen Sweep */}
        <linearGradient id="cg-sheen-grad" x1="0%" y1="0%" x2="100%" y2="0%">
          <stop offset="0%" stopColor="#FFFFFF" stopOpacity="0" />
          <stop offset="45%" stopColor="#FEF08A" stopOpacity="0.55" />
          <stop offset="50%" stopColor="#FFFFFF" stopOpacity="0.95" />
          <stop offset="55%" stopColor="#FEF08A" stopOpacity="0.55" />
          <stop offset="100%" stopColor="#FFFFFF" stopOpacity="0" />
        </linearGradient>

        <clipPath id="cg-receiver-clip">
          <path d="M104,192 L124,174 L468,174 L478,184 L478,302 L262,302 L248,274 L112,274 L96,252 Z" />
        </clipPath>

        {/* Glow Filters */}
        <filter id="cg-cyan-glow" x="-45%" y="-45%" width="190%" height="190%">
          <feGaussianBlur stdDeviation="6" result="blur" />
          <feComposite in="SourceGraphic" in2="blur" operator="over" />
        </filter>

        <filter id="cg-gold-glow" x="-50%" y="-50%" width="200%" height="200%">
          <feGaussianBlur stdDeviation="9" result="blur" />
          <feComposite in="SourceGraphic" in2="blur" operator="over" />
        </filter>
      </defs>

      {/* ==================== AMBIENT BACKDROP & PEDESTAL ==================== */}
      {showBackdrop && (
        <g>
          <ellipse cx="400" cy="245" rx="350" ry="215" fill="url(#cg-bg-glow)" />

          {/* Mythic Dealer Rotating Suit Ring */}
          {isMythic && (
            <g opacity={isActive ? '0.58' : '0.3'} transform="translate(380, 235)">
              <g style={{ animation: `rotateSlowCW 22s linear infinite` }}>
                <circle
                  cx="0"
                  cy="0"
                  r="175"
                  fill="none"
                  stroke="#FACC15"
                  strokeWidth="1.8"
                  strokeDasharray="16 10 4 10"
                />
                <circle
                  cx="0"
                  cy="0"
                  r="152"
                  fill="none"
                  stroke="#38BDF8"
                  strokeWidth="1.3"
                  strokeDasharray="6 14"
                />
              </g>
            </g>
          )}

          {/* Dark Purple Pedestal Oval below Gun */}
          <ellipse
            cx="335"
            cy="420"
            rx="150"
            ry="18"
            fill="#090414"
            stroke="#6B21A8"
            strokeWidth="2.2"
            opacity="0.82"
          />

          {/* Floating Casino Gold Sparkles */}
          {[
            { x: 145, y: 125, r: 3.5 },
            { x: 315, y: 105, r: 4 },
            { x: 465, y: 118, r: 3.5 },
            { x: 255, y: 365, r: 4 },
            { x: 485, y: 355, r: 3.5 },
          ].map((sp, i) => (
            <circle
              key={i}
              cx={sp.x}
              cy={sp.y}
              r={sp.r}
              fill="#FEF08A"
              filter="url(#cg-gold-glow)"
              style={{
                animation: `sparkleTwinkle ${dur(2.0)} ease-in-out infinite`,
                animationDelay: `${i * 0.25}s`,
                transformOrigin: `${sp.x}px ${sp.y}px`,
              }}
            />
          ))}
        </g>
      )}

      {/* ==================== MAIN WEAPON GROUP (FLOATS & RECOILS) ==================== */}
      <g
        style={{
          animation: isActive
            ? `cardGunRecoil ${dur(0.56)} cubic-bezier(0.22, 1, 0.36, 1) infinite`
            : `floatIdle 3.6s ease-in-out infinite`,
          transformOrigin: '320px 260px',
        }}
      >
        {/* 1. TOP FAN OF 4 GLOWING PLAYING CARDS STICKING OUT OF UPPER SLOT */}
        <g
          style={{
            animation: isActive
              ? `topCardFanShuffle ${dur(0.48)} ease-in-out infinite`
              : 'none',
            transformOrigin: '218px 180px',
          }}
        >
          {/* Outer Cyan Magical Aura behind Top Cards */}
          <ellipse
            cx="218"
            cy="132"
            rx="66"
            ry="46"
            fill="#38BDF8"
            opacity="0.45"
            filter="url(#cg-cyan-glow)"
          />

          {/* Card 1 (Leftmost Tilted) */}
          <g transform="translate(182, 152) rotate(-23)">
            <rect
              x="-20"
              y="-48"
              width="42"
              height="60"
              rx="5"
              fill="#FFFFFF"
              stroke="#38BDF8"
              strokeWidth="2.6"
              filter="url(#cg-cyan-glow)"
            />
            <rect x="-15" y="-43" width="32" height="50" rx="3" fill="url(#cg-crimson)" />
          </g>

          {/* Card 2 (Mid-Left Tilted) */}
          <g transform="translate(197, 146) rotate(-12)">
            <rect
              x="-20"
              y="-48"
              width="42"
              height="60"
              rx="5"
              fill="#FFFFFF"
              stroke="#38BDF8"
              strokeWidth="2.6"
              filter="url(#cg-cyan-glow)"
            />
            <rect x="-15" y="-43" width="32" height="50" rx="3" fill="url(#cg-crimson)" />
          </g>

          {/* Card 3 (Mid-Right Tilted) */}
          <g transform="translate(214, 144) rotate(-1)">
            <rect
              x="-20"
              y="-48"
              width="42"
              height="60"
              rx="5"
              fill="#FFFFFF"
              stroke="#38BDF8"
              strokeWidth="2.6"
              filter="url(#cg-cyan-glow)"
            />
            <rect x="-15" y="-43" width="32" height="50" rx="3" fill="url(#cg-crimson)" />
          </g>

          {/* Card 4 (Front-Rightmost - Ornate Gold & Red Diamond Back) */}
          <g transform="translate(232, 148) rotate(10)">
            <rect
              x="-22"
              y="-50"
              width="46"
              height="64"
              rx="5.5"
              fill="#FFFFFF"
              stroke="#7DD3FC"
              strokeWidth="2.8"
              filter="url(#cg-cyan-glow)"
            />
            <rect
              x="-18"
              y="-46"
              width="38"
              height="56"
              rx="3"
              fill="url(#cg-crimson)"
              stroke="#FACC15"
              strokeWidth="1.8"
            />
            {/* Glowing Golden Diamond on Card Back */}
            <polygon
              points="1,-36 14,-18 1,0 -12,-18"
              fill="#FEF08A"
              stroke="#D97706"
              strokeWidth="1.6"
            />
            <polygon points="1,-29 8.5,-18 1,-7 -6.5,-18" fill="#FFFFFF" />
          </g>
        </g>

        {/* 2. CURVED RED, WHITE & GOLD LUXURY PISTOL GRIP */}
        <g>
          {/* Silver-White Trigger Guard & Gold Trigger */}
          <path
            d="M174,274 L244,274 L236,322 L168,322 Z"
            fill="none"
            stroke="url(#cg-pearl-silver)"
            strokeWidth="12.5"
            strokeLinejoin="round"
          />
          <path
            d="M174,274 L244,274 L236,322 L168,322 Z"
            fill="none"
            stroke="#1E293B"
            strokeWidth="2.6"
            strokeLinejoin="round"
          />
          {/* Gold Trigger Blade */}
          <path
            d="M196,278 C192,294 188,304 202,310 C208,302 208,290 206,278 Z"
            fill="url(#cg-gold-trim)"
            stroke="#451A03"
            strokeWidth="2.4"
          />

          {/* Pearl-Silver Inner Grip Chassis */}
          <path
            d="M118,266 L194,266 C182,318 164,358 148,408 L86,386 C102,344 118,306 118,266 Z"
            fill="url(#cg-pearl-silver)"
            stroke="#1E293B"
            strokeWidth="3.5"
            strokeLinejoin="round"
          />

          {/* Ornate Red & Gold Framed Grip Panel */}
          <path
            d="M126,280 L168,292 C154,328 142,356 132,390 L96,376 C108,342 122,310 126,280 Z"
            fill="url(#cg-crimson)"
            stroke="url(#cg-gold-trim)"
            strokeWidth="4.2"
            strokeLinejoin="round"
          />

          {/* Golden Diamond (♦) Gem Inlays inside Grip */}
          <polygon
            points="146,301 154,312 146,323 138,312"
            fill="#FEF9C3"
            stroke="#92400E"
            strokeWidth="1.4"
          />
          <polygon
            points="126,341 137,356 126,371 115,356"
            fill="#FEF9C3"
            stroke="#92400E"
            strokeWidth="1.6"
          />

          {/* Red Bottom Pommel Cap */}
          <path
            d="M82,380 L150,404 L144,418 L76,394 Z"
            fill="url(#cg-crimson)"
            stroke="#450A0A"
            strokeWidth="3.2"
            strokeLinejoin="round"
          />
        </g>

        {/* 3. MAIN CASINO RED, PEARL-WHITE & GOLD BARREL RECEIVER */}
        <g>
          {/* Rear Red Receiver Block */}
          <path
            d="M104,192 L124,174 L468,174 L478,184 L478,302 L262,302 L248,274 L112,274 L96,252 Z"
            fill="url(#cg-crimson)"
            stroke="#1E293B"
            strokeWidth="3.6"
            strokeLinejoin="round"
          />
          {/* Top Red Specular Highlight */}
          <line
            x1="130"
            y1="181"
            x2="462"
            y2="181"
            stroke="#FFE4E6"
            strokeWidth="4.5"
            strokeLinecap="round"
            opacity="0.88"
          />

          {/* Rear Sight Bump & Front Golden Sight Fin */}
          <path
            d="M100,192 L114,168 L128,174 Z"
            fill="url(#cg-crimson)"
            stroke="#1E293B"
            strokeWidth="3"
          />
          <path
            d="M428,174 L464,157 L468,174 Z"
            fill="url(#cg-gold-trim)"
            stroke="#451A03"
            strokeWidth="3"
            strokeLinejoin="round"
          />

          {/* 3 Diagonal Black Vent Slots on Rear-Left Red Receiver */}
          {[126, 144, 162].map((vx, idx) => (
            <polygon
              key={idx}
              points={`${vx},204 ${vx + 10},204 ${vx - 4},236 ${vx - 14},236`}
              fill="#0F172A"
              stroke="#FCA5A5"
              strokeWidth="1.2"
            />
          ))}

          {/* Pearl-White Central & Lower Receiver Plate with Gold Accent Blocks */}
          <path
            d="M188,200 L456,200 L456,296 L432,296 L422,276 L312,276 L298,298 L256,298 L244,274 L172,274 L172,244 L268,244 L268,200 Z"
            fill="url(#cg-pearl-silver)"
            stroke="#1E293B"
            strokeWidth="3.2"
            strokeLinejoin="round"
          />

          {/* Gold Trim Blocks on White Plate */}
          <rect
            x="256"
            y="274"
            width="42"
            height="24"
            rx="3.5"
            fill="url(#cg-gold-trim)"
            stroke="#451A03"
            strokeWidth="2.4"
          />
          <rect
            x="432"
            y="274"
            width="24"
            height="22"
            rx="3.5"
            fill="url(#cg-gold-trim)"
            stroke="#451A03"
            strokeWidth="2.4"
          />

          {/* Lower Red Scalloped Under-Barrel Guard with 4 Gold Studs */}
          <path
            d="M300,298 L314,276 L422,276 L432,298 Z"
            fill="url(#cg-crimson)"
            stroke="#450A0A"
            strokeWidth="3"
          />
          {[326, 354, 382, 410].map((gx, i) => (
            <circle
              key={i}
              cx={gx}
              cy="288"
              r="3.8"
              fill="#FEF9C3"
              stroke="#78350F"
              strokeWidth="1.4"
            />
          ))}

          {/* Glowing Cyan Horizontal Pill Indicator in Gold Frame */}
          <rect
            x="196"
            y="212"
            width="64"
            height="22"
            rx="9"
            fill="url(#cg-gold-trim)"
            stroke="#451A03"
            strokeWidth="2.4"
          />
          <rect
            x="202"
            y="217"
            width="52"
            height="12"
            rx="6"
            fill="#38BDF8"
            filter="url(#cg-cyan-glow)"
          />
          <rect x="208" y="220" width="36" height="5" rx="2.5" fill="#FFFFFF" />

          {/* 4. FOUR OVERLAPPING SUIT CARDS (♥ ♠ ♦ ♣) IN SIDE SHOWCASE WINDOW */}
          <g>
            {/* Card 1: HEART (♥) */}
            <g
              transform="translate(302, 238) rotate(-10)"
              style={{
                animation: isActive ? `rubyGemCascade ${dur(0.56)} ease-in-out infinite` : 'none',
              }}
            >
              <rect
                x="-18"
                y="-26"
                width="36"
                height="52"
                rx="4.5"
                fill="url(#cg-crimson)"
                stroke="#FACC15"
                strokeWidth="2.4"
              />
              {/* Gold Heart Symbol */}
              <path
                d="M0,10 C-12,0 -14,-10 -7,-14 C-2,-16 0,-11 0,-9 C0,-11 2,-16 7,-14 C14,-10 12,0 0,10 Z"
                fill="#FEF9C3"
              />
            </g>

            {/* Card 2: SPADE (♠) */}
            <g
              transform="translate(338, 236) rotate(-3)"
              style={{
                animation: isActive ? `rubyGemCascade ${dur(0.56)} ease-in-out infinite` : 'none',
                animationDelay: '0.1s',
              }}
            >
              <rect
                x="-18"
                y="-26"
                width="36"
                height="52"
                rx="4.5"
                fill="#FFFFFF"
                stroke="#94A3B8"
                strokeWidth="2.4"
              />
              {/* Dark Spade Symbol */}
              <path
                d="M0,-14 C-12,-2 -13,6 -6,9 C-2,10 0,7 0,7 L-4,15 L4,15 L0,7 C0,7 2,10 6,9 C13,6 12,-2 0,-14 Z"
                fill="#0F172A"
              />
            </g>

            {/* Card 3: DIAMOND (♦) */}
            <g
              transform="translate(374, 236) rotate(4)"
              style={{
                animation: isActive ? `rubyGemCascade ${dur(0.56)} ease-in-out infinite` : 'none',
                animationDelay: '0.2s',
              }}
            >
              <rect
                x="-18"
                y="-26"
                width="36"
                height="52"
                rx="4.5"
                fill="url(#cg-crimson)"
                stroke="#FACC15"
                strokeWidth="2.4"
              />
              {/* Gold Diamond Symbol */}
              <polygon points="0,-14 11,0 0,14 -11,0" fill="#FEF9C3" />
            </g>

            {/* Card 4: CLUB (♣) */}
            <g
              transform="translate(410, 238) rotate(10)"
              style={{
                animation: isActive ? `rubyGemCascade ${dur(0.56)} ease-in-out infinite` : 'none',
                animationDelay: '0.3s',
              }}
            >
              <rect
                x="-18"
                y="-26"
                width="36"
                height="52"
                rx="4.5"
                fill="url(#cg-crimson)"
                stroke="#FACC15"
                strokeWidth="2.4"
              />
              {/* Gold Club Symbol */}
              <circle cx="0" cy="-7" r="6" fill="#FEF9C3" />
              <circle cx="-6" cy="2" r="6" fill="#FEF9C3" />
              <circle cx="6" cy="2" r="6" fill="#FEF9C3" />
              <polygon points="0,3 -4,14 4,14" fill="#FEF9C3" />
            </g>
          </g>

          {/* Animated Casino Gold Sheen Sweep across Receiver */}
          {isMythic && (
            <g clipPath="url(#cg-receiver-clip)" pointerEvents="none">
              <rect
                x="110"
                y="165"
                width="85"
                height="150"
                fill="url(#cg-sheen-grad)"
                transform="skewX(-24)"
                style={{
                  animation: `svgMetalSheen ${dur(4.0)} ease-in-out infinite`,
                }}
              />
            </g>
          )}

          {/* 5. FRONT GOLDEN MUZZLE PLATE & CYAN ENERGY APERTURE */}
          <g>
            <rect
              x="474"
              y="188"
              width="19"
              height="108"
              rx="5.5"
              fill="url(#cg-gold-trim)"
              stroke="#451A03"
              strokeWidth="3.2"
            />
            <rect
              x="489"
              y="202"
              width="9"
              height="80"
              rx="4.5"
              fill="#38BDF8"
              filter="url(#cg-cyan-glow)"
            />
          </g>
        </g>

        {/* 6. HOVERING ROYAL FLUSH CARDS IN STATIONARY MUZZLE ENERGY VORTEX (NO PROJECTILES!) */}
        <g>
          {/* Contained Cyan Energy Field Lattice at Muzzle */}
          <rect
            x="496"
            y="198"
            width={isActive ? '164' : '128'}
            height="88"
            rx="12"
            fill="#38BDF8"
            opacity={isActive ? '0.32' : '0.18'}
            filter="url(#cg-cyan-glow)"
          />
          <polyline
            points="496,214 532,208 556,228 594,216 626,232"
            fill="none"
            stroke="#BAE6FD"
            strokeWidth="2.2"
            opacity="0.82"
          />
          <polyline
            points="496,266 538,274 568,252 608,268"
            fill="none"
            stroke="#BAE6FD"
            strokeWidth="2.2"
            opacity="0.82"
          />

          {/* Hovering Top Card: ACE OF HEARTS (♥) */}
          <g
            transform="translate(546, 152) rotate(-22)"
            style={{
              animation: `floatingCardSpin ${dur(isActive ? 0.52 : 2.5)} ease-in-out infinite`,
              transformOrigin: '546px 152px',
            }}
          >
            <rect
              x="-24"
              y="-34"
              width="48"
              height="68"
              rx="5.5"
              fill="#FFFFFF"
              stroke="#F43F5E"
              strokeWidth="2.6"
            />
            <path
              d="M0,10 C-11,1 -13,-8 -6,-12 C-2,-14 0,-9 0,-7 C0,-9 2,-14 6,-12 C13,-8 11,1 0,10 Z"
              fill="#E11D48"
            />
            <circle cx="-15" cy="-23" r="3" fill="#E11D48" />
            <circle cx="15" cy="23" r="3" fill="#E11D48" />
          </g>

          {/* Hovering Middle Wireframe Hologram Card */}
          <g transform="translate(572, 242) rotate(18)">
            <rect
              x="-18"
              y="-26"
              width="36"
              height="52"
              rx="4.5"
              fill="rgba(244, 63, 94, 0.24)"
              stroke="#FFE4E6"
              strokeWidth="2.2"
              filter="url(#cg-cyan-glow)"
            />
          </g>

          {/* Hovering Bottom Card: ACE OF DIAMONDS (♦) */}
          <g
            transform="translate(542, 316) rotate(-38)"
            style={{
              animation: `floatingCardSpin ${dur(isActive ? 0.56 : 2.8)} ease-in-out infinite`,
              animationDelay: '0.2s',
              transformOrigin: '542px 316px',
            }}
          >
            <rect
              x="-22"
              y="-32"
              width="44"
              height="64"
              rx="5.5"
              fill="#FFFFFF"
              stroke="#F43F5E"
              strokeWidth="2.6"
            />
            <polygon points="0,-12 9.5,0 0,12 -9.5,0" fill="#E11D48" />
            <circle cx="-14" cy="-21" r="2.5" fill="#E11D48" />
            <circle cx="14" cy="21" r="2.5" fill="#E11D48" />
          </g>

          {/* Hovering Front Card: ACE OF SPADES (♠) with Golden Aura Burst */}
          <g
            transform="translate(632, 236) rotate(28)"
            style={{
              animation: `floatingCardSpin ${dur(isActive ? 0.48 : 2.3)} ease-in-out infinite`,
              animationDelay: '0.1s',
              transformOrigin: '632px 236px',
            }}
          >
            {/* Golden Starburst behind Ace of Spades */}
            <circle
              cx="12"
              cy="4"
              r={isActive ? '48' : '30'}
              fill="#F59E0B"
              opacity="0.62"
              filter="url(#cg-gold-glow)"
            />
            <rect
              x="-24"
              y="-35"
              width="48"
              height="70"
              rx="5.5"
              fill="#FFFFFF"
              stroke="#FACC15"
              strokeWidth="3"
            />
            <path
              d="M0,-13 C-11,-2 -12,5 -5,8 C-2,9 0,6 0,6 L-4,14 L4,14 L0,6 C0,6 2,9 5,8 C12,5 11,-2 0,-13 Z"
              fill="#0F172A"
            />
            <circle cx="-15" cy="-24" r="2.5" fill="#0F172A" />
            <circle cx="15" cy="24" r="2.5" fill="#0F172A" />
          </g>
        </g>
      </g>
    </svg>
  );
};
