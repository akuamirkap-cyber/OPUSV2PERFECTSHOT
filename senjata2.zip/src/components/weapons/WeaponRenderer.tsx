import React from 'react';
import { GoldenTycoonSvg } from './GoldenTycoonSvg';
import { LaserBusterSvg } from './LaserBusterSvg';
import { CyberCarbineSvg } from './CyberCarbineSvg';
import { BananaBlasterSvg } from './BananaBlasterSvg';
import { StormCallerSvg } from './StormCallerSvg';
import { SuperSoakerSvg } from './SuperSoakerSvg';
import { FireworkLauncherSvg } from './FireworkLauncherSvg';
import { BioPlasmaGunSvg } from './BioPlasmaGunSvg';
import { CardGunSvg } from './CardGunSvg';
import { MinigunSvg } from './MinigunSvg';

interface WeaponRendererProps {
  weaponId: string;
  isActive: boolean;
  speed?: number;
  showBackdrop?: boolean;
  isMythic?: boolean;
  svgRef?: React.RefObject<SVGSVGElement | null>;
}

export const WeaponRenderer: React.FC<WeaponRendererProps> = ({
  weaponId,
  isActive,
  speed = 1,
  showBackdrop = true,
  isMythic = true,
  svgRef,
}) => {
  switch (weaponId) {
    case 'super-soaker':
      return (
        <SuperSoakerSvg
          isActive={isActive}
          speed={speed}
          showBackdrop={showBackdrop}
          isMythic={isMythic}
          svgRef={svgRef}
        />
      );
    case 'firework-launcher':
      return (
        <FireworkLauncherSvg
          isActive={isActive}
          speed={speed}
          showBackdrop={showBackdrop}
          isMythic={isMythic}
          svgRef={svgRef}
        />
      );
    case 'bio-plasma':
      return (
        <BioPlasmaGunSvg
          isActive={isActive}
          speed={speed}
          showBackdrop={showBackdrop}
          isMythic={isMythic}
          svgRef={svgRef}
        />
      );
    case 'card-gun':
      return (
        <CardGunSvg
          isActive={isActive}
          speed={speed}
          showBackdrop={showBackdrop}
          isMythic={isMythic}
          svgRef={svgRef}
        />
      );
    case 'minigun':
      return (
        <MinigunSvg
          isActive={isActive}
          speed={speed}
          showBackdrop={showBackdrop}
          isMythic={isMythic}
          svgRef={svgRef}
        />
      );
    case 'golden-tycoon':
      return (
        <GoldenTycoonSvg
          isActive={isActive}
          speed={speed}
          showBackdrop={showBackdrop}
          isMythic={isMythic}
          svgRef={svgRef}
        />
      );
    case 'laser-buster':
      return (
        <LaserBusterSvg
          isActive={isActive}
          speed={speed}
          showBackdrop={showBackdrop}
          isMythic={isMythic}
          svgRef={svgRef}
        />
      );
    case 'cyber-carbine':
      return (
        <CyberCarbineSvg
          isActive={isActive}
          speed={speed}
          showBackdrop={showBackdrop}
          isMythic={isMythic}
          svgRef={svgRef}
        />
      );
    case 'banana-blaster':
      return (
        <BananaBlasterSvg
          isActive={isActive}
          speed={speed}
          showBackdrop={showBackdrop}
          isMythic={isMythic}
          svgRef={svgRef}
        />
      );
    case 'storm-caller':
      return (
        <StormCallerSvg
          isActive={isActive}
          speed={speed}
          showBackdrop={showBackdrop}
          isMythic={isMythic}
          svgRef={svgRef}
        />
      );
    default:
      return null;
  }
};
