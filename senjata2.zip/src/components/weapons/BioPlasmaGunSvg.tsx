import React from 'react';

interface WeaponSvgProps {
  isActive: boolean;
  speed?: number;
  showBackdrop?: boolean;
  isMythic?: boolean;
  svgRef?: React.RefObject<SVGSVGElement | null>;
}

export const BioPlasmaGunSvg: React.FC<WeaponSvgProps> = ({
  isActive,
  speed = 1,
  showBackdrop = true,
  isMythic = true,
  svgRef,
}) => {
  const dur = (base: number) => `${(base / speed).toFixed(2)}s`;

  return (
    <svg
      ref={svgRef}
      viewBox="0 0 800 500"
      className="w-full h-full select-none overflow-visible"
      xmlns="http://www.w3.org/2000/svg"
    >
      <defs>
        {/* Background Purple & Emerald Gamma Glow */}
        <radialGradient id="bp-bg-glow" cx="50%" cy="46%" r="48%">
          <stop offset="0%" stopColor="#10B981" stopOpacity="0.6" />
          <stop offset="42%" stopColor="#9333EA" stopOpacity="0.42" />
          <stop offset="78%" stopColor="#1E1B4B" stopOpacity="0.16" />
          <stop offset="100%" stopColor="#090D1A" stopOpacity="0" />
        </radialGradient>

        {/* Dark Gunmetal Steel Gradient */}
        <linearGradient id="bp-gunmetal" x1="0%" y1="0%" x2="0%" y2="100%">
          <stop offset="0%" stopColor="#94A3B8" />
          <stop offset="18%" stopColor="#475569" />
          <stop offset="55%" stopColor="#1E293B" />
          <stop offset="88%" stopColor="#0F172A" />
          <stop offset="100%" stopColor="#020617" />
        </linearGradient>

        {/* Translucent Emerald Glass Cylinder Gradient */}
        <linearGradient id="bp-emerald-glass" x1="0%" y1="0%" x2="0%" y2="100%">
          <stop offset="0%" stopColor="#D1FAE5" stopOpacity="0.95" />
          <stop offset="20%" stopColor="#10B981" stopOpacity="0.9" />
          <stop offset="55%" stopColor="#059669" stopOpacity="0.95" />
          <stop offset="85%" stopColor="#047857" stopOpacity="0.98" />
          <stop offset="100%" stopColor="#022C22" stopOpacity="1" />
        </linearGradient>

        {/* Emerald Glass Sheen Sweep */}
        <linearGradient id="bp-sheen-grad" x1="0%" y1="0%" x2="100%" y2="0%">
          <stop offset="0%" stopColor="#34D399" stopOpacity="0" />
          <stop offset="45%" stopColor="#D1FAE5" stopOpacity="0.55" />
          <stop offset="50%" stopColor="#FFFFFF" stopOpacity="0.95" />
          <stop offset="55%" stopColor="#D1FAE5" stopOpacity="0.55" />
          <stop offset="100%" stopColor="#34D399" stopOpacity="0" />
        </linearGradient>

        <clipPath id="bp-glass-clip">
          <rect x="316" y="188" width="184" height="94" rx="18" />
        </clipPath>

        {/* Glow Filters */}
        <filter id="bp-green-glow" x="-45%" y="-45%" width="190%" height="190%">
          <feGaussianBlur stdDeviation="7" result="blur" />
          <feComposite in="SourceGraphic" in2="blur" operator="over" />
        </filter>

        <filter id="bp-gamma-overcharge" x="-70%" y="-70%" width="240%" height="240%">
          <feGaussianBlur stdDeviation="14" result="blur1" />
          <feGaussianBlur stdDeviation="4" result="blur2" />
          <feMerge>
            <feMergeNode in="blur1" />
            <feMergeNode in="blur2" />
            <feMergeNode in="SourceGraphic" />
          </feMerge>
        </filter>
      </defs>

      {/* ==================== AMBIENT BACKDROP & GAMMA RAYS ==================== */}
      {showBackdrop && (
        <g>
          <ellipse cx="400" cy="245" rx="350" ry="215" fill="url(#bp-bg-glow)" />

          {/* Mythic Gamma Rotating Bio-Reactor Ring */}
          {isMythic && (
            <g opacity={isActive ? '0.6' : '0.32'} transform="translate(395, 235)">
              <g style={{ animation: `rotateSlowCCW 20s linear infinite` }}>
                <circle
                  cx="0"
                  cy="0"
                  r="174"
                  fill="none"
                  stroke="#34D399"
                  strokeWidth="1.8"
                  strokeDasharray="18 10 4 10"
                />
                <circle
                  cx="0"
                  cy="0"
                  r="150"
                  fill="none"
                  stroke="#A855F7"
                  strokeWidth="1.3"
                  strokeDasharray="6 14"
                />
                {[0, 90, 180, 270].map((deg) => (
                  <circle
                    key={deg}
                    cx="0"
                    cy="-174"
                    r="4.5"
                    fill="#A7F3D0"
                    transform={`rotate(${deg})`}
                  />
                ))}
              </g>
            </g>
          )}

          {/* Floating Emerald & Violet Energy Motes */}
          {[
            { cx: 195, cy: 145, r: 4, c: '#6EE7B7' },
            { cx: 285, cy: 102, r: 4.5, c: '#A7F3D0' },
            { cx: 525, cy: 108, r: 4, c: '#6EE7B7' },
            { cx: 615, cy: 295, r: 4.5, c: '#34D399' },
            { cx: 220, cy: 365, r: 4, c: '#C084FC' },
            { cx: 475, cy: 335, r: 3.5, c: '#6EE7B7' },
          ].map((m, i) => (
            <circle
              key={i}
              cx={m.cx}
              cy={m.cy}
              r={m.r}
              fill={m.c}
              filter="url(#bp-green-glow)"
              style={{
                animation: `sparkleTwinkle ${dur(2.1)} ease-in-out infinite`,
                animationDelay: `${i * 0.25}s`,
                transformOrigin: `${m.cx}px ${m.cy}px`,
              }}
            />
          ))}
        </g>
      )}

      {/* ==================== MAIN WEAPON GROUP (FLOATS & RECOILS) ==================== */}
      <g
        style={{
          animation: isActive
            ? `bioPlasmaRecoil ${dur(0.56)} cubic-bezier(0.22, 1, 0.36, 1) infinite`
            : `floatIdle 3.6s ease-in-out infinite`,
          transformOrigin: '360px 265px',
        }}
      >
        {/* Angled Pose matching Reference (-20 degrees upward-right) */}
        <g transform="translate(385, 250) rotate(-20) translate(-385, -250)">
          {/* 1. TOP CURVED POWER CABLE CONDUIT LOOP (Rear-Top) */}
          <g>
            <path
              d="M234,202 C236,164 286,162 294,196"
              fill="none"
              stroke="#0F172A"
              strokeWidth="12"
              strokeLinecap="round"
            />
            <path
              d="M234,202 C236,164 286,162 294,196"
              fill="none"
              stroke="#475569"
              strokeWidth="6.5"
              strokeLinecap="round"
            />
            <path
              d="M234,202 C236,164 286,162 294,196"
              fill="none"
              stroke="#34D399"
              strokeWidth="2.8"
              strokeDasharray="6 6"
              filter="url(#bp-green-glow)"
              opacity={isActive ? '1' : '0.6'}
            />
          </g>

          {/* 2. ERGONOMIC GUNMETAL PISTOL GRIP WITH GLOWING GREEN PLASMA VEIN */}
          <g>
            {/* Trigger Guard & Glowing Green Trigger */}
            <path
              d="M294,274 L358,268 L346,314 L290,316 Z"
              fill="none"
              stroke="url(#bp-gunmetal)"
              strokeWidth="10.5"
              strokeLinejoin="round"
            />
            <path
              d="M312,276 C310,290 306,298 318,304"
              fill="none"
              stroke="#34D399"
              strokeWidth="6"
              strokeLinecap="round"
              filter="url(#bp-green-glow)"
            />

            {/* Main Curved Gunmetal Grip */}
            <path
              d="M222,272 C226,306 212,354 196,396 L268,402 C274,358 282,318 298,274 Z"
              fill="url(#bp-gunmetal)"
              stroke="#020617"
              strokeWidth="3.6"
              strokeLinejoin="round"
            />

            {/* Recessed Dark Grip Panel */}
            <path
              d="M234,288 C236,318 226,356 214,386 L252,390 C258,354 264,320 276,288 Z"
              fill="#050811"
              stroke="#334155"
              strokeWidth="2.2"
            />

            {/* Glowing Neon-Green Lightning Vein Inside Grip */}
            <path
              d="M248,296 L237,324 L247,342 L231,380"
              fill="none"
              stroke="#10B981"
              strokeWidth="5.5"
              strokeLinecap="round"
              strokeLinejoin="round"
              filter={isActive ? 'url(#bp-gamma-overcharge)' : 'url(#bp-green-glow)'}
            />
            <path
              d="M248,296 L237,324 L247,342 L231,380"
              fill="none"
              stroke="#FFFFFF"
              strokeWidth="2.2"
              strokeLinecap="round"
            />

            {/* Heavy Rounded Grip Baseplate */}
            <rect
              x="188"
              y="390"
              width="86"
              height="19"
              rx="8.5"
              fill="url(#bp-gunmetal)"
              stroke="#020617"
              strokeWidth="3.2"
            />
            <line
              x1="198"
              y1="396"
              x2="264"
              y2="396"
              stroke="#94A3B8"
              strokeWidth="2.5"
              strokeLinecap="round"
            />
          </g>

          {/* 3. REAR RIBBED METALLIC RECEIVER & END-CAP KNOB */}
          <g>
            {/* Rear End-Cap Knob with Green Core Ring */}
            <rect
              x="174"
              y="213"
              width="28"
              height="46"
              rx="11"
              fill="url(#bp-gunmetal)"
              stroke="#020617"
              strokeWidth="3.4"
            />
            <line x1="184" y1="220" x2="184" y2="252" stroke="#34D399" strokeWidth="2.5" filter="url(#bp-green-glow)" />

            {/* Rear Receiver Cylinder */}
            <rect
              x="198"
              y="196"
              width="126"
              height="80"
              rx="14"
              fill="url(#bp-gunmetal)"
              stroke="#020617"
              strokeWidth="3.5"
            />
            {/* Ribbed Cooling Fin Rings on Rear Receiver */}
            {[268, 286, 304].map((rxPos, i) => (
              <g key={i}>
                <rect
                  x={rxPos}
                  y="187"
                  width="12.5"
                  height="96"
                  rx="5.5"
                  fill="url(#bp-gunmetal)"
                  stroke="#020617"
                  strokeWidth="2.8"
                />
                <line
                  x1={rxPos + 4}
                  y1="194"
                  x2={rxPos + 4}
                  y2="276"
                  stroke="#94A3B8"
                  strokeWidth="2"
                  opacity="0.7"
                />
              </g>
            ))}
            {/* Glowing Green Pill Indicator on Rear Receiver */}
            <rect
              x="220"
              y="229"
              width="30"
              height="12"
              rx="6"
              fill="#10B981"
              stroke="#064E3B"
              strokeWidth="1.8"
              filter="url(#bp-green-glow)"
            />
            <rect x="225" y="232" width="20" height="5" rx="2.5" fill="#FFFFFF" />
          </g>

          {/* 4. CENTRAL TRANSPARENT GLASS CYLINDER WITH GREEN LIGHTNING PLASMA */}
          <g>
            {/* Glass Cylinder Body */}
            <rect
              x="316"
              y="188"
              width="184"
              height="94"
              rx="18"
              fill="url(#bp-emerald-glass)"
              stroke="#022C22"
              strokeWidth="3.6"
              filter={isActive ? 'url(#bp-gamma-overcharge)' : 'url(#bp-green-glow)'}
            />

            {/* Internal 3D Cylinder End-Cap Glass Ellipses */}
            <ellipse
              cx="332"
              cy="235"
              rx="10"
              ry="42"
              fill="none"
              stroke="#A7F3D0"
              strokeWidth="2"
              opacity="0.55"
            />
            <ellipse
              cx="484"
              cy="235"
              rx="10"
              ry="42"
              fill="none"
              stroke="#A7F3D0"
              strokeWidth="2"
              opacity="0.55"
            />

            {/* Internal Glowing Radioactive Plasma Core */}
            <ellipse
              cx="408"
              cy="235"
              rx="84"
              ry="34"
              fill="#6EE7B7"
              opacity={isActive ? '0.72' : '0.42'}
              filter="url(#bp-green-glow)"
            />

            {/* Floating Bio-Plasma Bubbles Inside Glass Chamber */}
            <circle cx="348" cy="252" r="4" fill="#D1FAE5" opacity="0.75" />
            <circle cx="388" cy="212" r="3" fill="#FFFFFF" opacity="0.8" />
            <circle cx="445" cy="256" r="4.5" fill="#D1FAE5" opacity="0.75" />
            <circle cx="468" cy="216" r="3.5" fill="#FFFFFF" opacity="0.8" />

            {/* JAGGED WHITE-GREEN LIGHTNING ARCS DANCING INSIDE GLASS TUBE */}
            <g
              style={{
                animation: `bioPlasmaArcJitter ${dur(isActive ? 0.18 : 0.6)} ease-in-out infinite`,
                transformOrigin: '408px 235px',
              }}
            >
              {/* Main Lightning Bolt */}
              <polyline
                points="322,238 352,214 374,246 404,210 432,248 462,216 496,234"
                fill="none"
                stroke="#10B981"
                strokeWidth="8"
                strokeLinecap="round"
                strokeLinejoin="round"
                filter="url(#bp-green-glow)"
              />
              <polyline
                points="322,238 352,214 374,246 404,210 432,248 462,216 496,234"
                fill="none"
                stroke="#FFFFFF"
                strokeWidth="3.5"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
              {/* Secondary Branching Plasma Tendrils */}
              <polyline
                points="352,214 368,200 395,208"
                fill="none"
                stroke="#D1FAE5"
                strokeWidth="2.2"
              />
              <polyline
                points="404,210 422,260 450,252"
                fill="none"
                stroke="#D1FAE5"
                strokeWidth="2.2"
              />
              <polyline
                points="432,248 452,204 478,212"
                fill="none"
                stroke="#A7F3D0"
                strokeWidth="1.8"
              />
            </g>

            {/* Animated Emerald Glass Sheen Sweep */}
            {isMythic && (
              <g clipPath="url(#bp-glass-clip)" pointerEvents="none">
                <rect
                  x="300"
                  y="180"
                  width="75"
                  height="110"
                  fill="url(#bp-sheen-grad)"
                  transform="skewX(-24)"
                  style={{
                    animation: `svgMetalSheen ${dur(3.9)} ease-in-out infinite`,
                  }}
                />
              </g>
            )}

            {/* Top Curved Glossy White Glass Reflection Strip */}
            <path
              d="M332,199 L484,199"
              stroke="#FFFFFF"
              strokeWidth="7.5"
              strokeLinecap="round"
              opacity="0.8"
            />
            {/* Bottom Subtle Glass Rim Highlight */}
            <path
              d="M332,273 L484,273"
              stroke="#A7F3D0"
              strokeWidth="3.2"
              strokeLinecap="round"
              opacity="0.62"
            />
          </g>

          {/* 5. FRONT HEAVY GUNMETAL MUZZLE SHROUD & EMERALD APERTURE LENS */}
          <g>
            {/* Front Collar Ring Clamping the Glass Tube */}
            <rect
              x="492"
              y="183"
              width="25"
              height="104"
              rx="8.5"
              fill="url(#bp-gunmetal)"
              stroke="#020617"
              strokeWidth="3.4"
            />
            <rect
              x="512"
              y="189"
              width="19"
              height="92"
              rx="6.5"
              fill="url(#bp-gunmetal)"
              stroke="#020617"
              strokeWidth="3.2"
            />

            {/* Main Cylindrical Front Muzzle Shroud */}
            <path
              d="M526,188 L592,188 C607,188 615,208 615,235 C615,262 607,282 592,282 L526,282 Z"
              fill="url(#bp-gunmetal)"
              stroke="#020617"
              strokeWidth="3.5"
            />
            <line
              x1="534"
              y1="198"
              x2="588"
              y2="198"
              stroke="#94A3B8"
              strokeWidth="3.5"
              strokeLinecap="round"
            />

            {/* Top Sight Fin with Glowing Green Tip */}
            <path
              d="M558,188 L576,166 L595,166 L595,188 Z"
              fill="url(#bp-gunmetal)"
              stroke="#020617"
              strokeWidth="3"
              strokeLinejoin="round"
            />
            <circle cx="586" cy="175" r="4.5" fill="#34D399" filter="url(#bp-green-glow)" />

            {/* Side Glowing Green Pill Slot on Front Shroud */}
            <rect
              x="546"
              y="228"
              width="34"
              height="13"
              rx="6.5"
              fill="#10B981"
              stroke="#064E3B"
              strokeWidth="1.8"
              filter="url(#bp-green-glow)"
            />
            <rect x="552" y="231.5" width="22" height="5.5" rx="2.7" fill="#FFFFFF" />

            {/* Glowing Emerald-Green Circular Muzzle Lens Aperture */}
            <ellipse
              cx="604"
              cy="235"
              rx="10.5"
              ry="35"
              fill="#022C22"
              stroke="#334155"
              strokeWidth="2.6"
            />
            <ellipse
              cx="605"
              cy="235"
              rx="7.5"
              ry="25"
              fill="#10B981"
              filter={isActive ? 'url(#bp-gamma-overcharge)' : 'url(#bp-green-glow)'}
            />
            <ellipse cx="606" cy="235" rx="4.2" ry="16" fill="#FFFFFF" />
          </g>

          {/* ==================== STATIONARY GAMMA PLASMA CORONA AT MUZZLE (NO PROJECTILES!) ==================== */}
          {isActive && (
            <g
              style={{
                animation: `muzzleCrownPulse ${dur(0.52)} ease-out infinite`,
                transformOrigin: '610px 235px',
              }}
            >
              {/* Contained Emerald-Green Plasma Vortex anchored to Lens */}
              <circle
                cx="612"
                cy="235"
                r="42"
                fill="#10B981"
                opacity="0.52"
                filter="url(#bp-gamma-overcharge)"
              />
              <ellipse
                cx="612"
                cy="235"
                rx="15"
                ry="44"
                fill="none"
                stroke="#A7F3D0"
                strokeWidth="3.8"
                strokeDasharray="8 6"
                filter="url(#bp-gamma-overcharge)"
              />
              <path
                d="M612,176 L621,223 L668,235 L621,247 L612,294 L603,247 L556,235 L603,223 Z"
                fill="#FFFFFF"
                stroke="#10B981"
                strokeWidth="1.8"
                filter="url(#bp-gamma-overcharge)"
              />
            </g>
          )}
        </g>
      </g>
    </svg>
  );
};
