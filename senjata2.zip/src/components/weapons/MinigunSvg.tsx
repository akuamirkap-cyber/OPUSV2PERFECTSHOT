import React from 'react';

interface WeaponSvgProps {
  isActive: boolean;
  speed?: number;
  showBackdrop?: boolean;
  isMythic?: boolean;
  svgRef?: React.RefObject<SVGSVGElement | null>;
}

export const MinigunSvg: React.FC<WeaponSvgProps> = ({
  isActive,
  speed = 1,
  showBackdrop = true,
  isMythic = true,
  svgRef,
}) => {
  const dur = (base: number) => `${(base / speed).toFixed(2)}s`;

  return (
    <svg
      ref={svgRef}
      viewBox="0 0 800 500"
      className="w-full h-full select-none overflow-visible"
      xmlns="http://www.w3.org/2000/svg"
    >
      <defs>
        {/* Background Heavy Titan Glow */}
        <radialGradient id="mg-bg-glow" cx="50%" cy="46%" r="48%">
          <stop offset="0%" stopColor="#F59E0B" stopOpacity="0.54" />
          <stop offset="45%" stopColor="#6B21A8" stopOpacity="0.38" />
          <stop offset="80%" stopColor="#1E1B4B" stopOpacity="0.16" />
          <stop offset="100%" stopColor="#090D1A" stopOpacity="0" />
        </radialGradient>

        {/* Heavy Industrial Gunmetal Steel Gradient */}
        <linearGradient id="mg-heavy-steel" x1="0%" y1="0%" x2="0%" y2="100%">
          <stop offset="0%" stopColor="#CBD5E1" />
          <stop offset="20%" stopColor="#64748B" />
          <stop offset="55%" stopColor="#334155" />
          <stop offset="85%" stopColor="#1E293B" />
          <stop offset="100%" stopColor="#090D16" />
        </linearGradient>

        {/* Cylindrical Barrel Tube Gradient */}
        <linearGradient id="mg-barrel-tube" x1="0%" y1="0%" x2="0%" y2="100%">
          <stop offset="0%" stopColor="#E2E8F0" />
          <stop offset="28%" stopColor="#64748B" />
          <stop offset="72%" stopColor="#1E293B" />
          <stop offset="100%" stopColor="#0F172A" />
        </linearGradient>

        {/* Molten Gold-Orange Muzzle Tip Gradient */}
        <radialGradient id="mg-molten-tip" cx="50%" cy="50%" r="55%">
          <stop offset="0%" stopColor="#1E293B" />
          <stop offset="42%" stopColor="#451A03" />
          <stop offset="65%" stopColor="#F59E0B" />
          <stop offset="86%" stopColor="#FEF08A" />
          <stop offset="100%" stopColor="#EA580C" />
        </radialGradient>

        {/* Titanium Sheen Sweep */}
        <linearGradient id="mg-sheen-grad" x1="0%" y1="0%" x2="100%" y2="0%">
          <stop offset="0%" stopColor="#FFFFFF" stopOpacity="0" />
          <stop offset="45%" stopColor="#FEF08A" stopOpacity="0.45" />
          <stop offset="50%" stopColor="#FFFFFF" stopOpacity="0.88" />
          <stop offset="55%" stopColor="#FEF08A" stopOpacity="0.45" />
          <stop offset="100%" stopColor="#FFFFFF" stopOpacity="0" />
        </linearGradient>

        <clipPath id="mg-motor-clip">
          <rect x="196" y="174" width="184" height="96" rx="22" />
        </clipPath>

        {/* Glow Filters */}
        <filter id="mg-molten-glow" x="-50%" y="-50%" width="200%" height="200%">
          <feGaussianBlur stdDeviation="7" result="blur" />
          <feComposite in="SourceGraphic" in2="blur" operator="over" />
        </filter>

        <filter id="mg-overheat-glow" x="-70%" y="-70%" width="240%" height="240%">
          <feGaussianBlur stdDeviation="14" result="blur1" />
          <feGaussianBlur stdDeviation="4" result="blur2" />
          <feMerge>
            <feMergeNode in="blur1" />
            <feMergeNode in="blur2" />
            <feMergeNode in="SourceGraphic" />
          </feMerge>
        </filter>
      </defs>

      {/* ==================== AMBIENT BACKDROP & PEDESTAL ==================== */}
      {showBackdrop && (
        <g>
          <ellipse cx="400" cy="245" rx="350" ry="215" fill="url(#mg-bg-glow)" />

          {/* Mythic Titan Rotating Gear Halo */}
          {isMythic && (
            <g opacity={isActive ? '0.6' : '0.3'} transform="translate(395, 235)">
              <g style={{ animation: `rotateSlowCW ${isActive ? '5s' : '22s'} linear infinite` }}>
                <circle
                  cx="0"
                  cy="0"
                  r="175"
                  fill="none"
                  stroke="#F59E0B"
                  strokeWidth="2"
                  strokeDasharray="16 8 4 8"
                />
                <circle
                  cx="0"
                  cy="0"
                  r="152"
                  fill="none"
                  stroke="#A855F7"
                  strokeWidth="1.4"
                  strokeDasharray="6 12"
                />
              </g>
            </g>
          )}

          {/* Dark Pedestal Shadow below Minigun */}
          <ellipse
            cx="330"
            cy="415"
            rx="170"
            ry="18"
            fill="#090614"
            stroke="#581C87"
            strokeWidth="2.2"
            opacity="0.82"
          />

          {/* Floating Molten Embers around Muzzle */}
          {[
            { cx: 615, cy: 145, r: 3.5 },
            { cx: 665, cy: 185, r: 4 },
            { cx: 645, cy: 335, r: 4 },
            { cx: 565, cy: 355, r: 3 },
          ].map((em, i) => (
            <circle
              key={i}
              cx={em.cx}
              cy={em.cy}
              r={em.r}
              fill="#FDE047"
              filter="url(#mg-molten-glow)"
              style={{
                animation: `sparkleTwinkle ${dur(1.8)} ease-in-out infinite`,
                animationDelay: `${i * 0.25}s`,
                transformOrigin: `${em.cx}px ${em.cy}px`,
              }}
            />
          ))}
        </g>
      )}

      {/* ==================== MAIN WEAPON GROUP (FLOATS & VIBRATES ON SPIN) ==================== */}
      <g
        style={{
          animation: isActive
            ? `minigunVibration ${dur(0.16)} linear infinite`
            : `floatIdle 3.6s ease-in-out infinite`,
          transformOrigin: '360px 250px',
        }}
      >
        {/* Downward-Right Heavy Pose (+12 deg) matching Reference */}
        <g transform="translate(380, 245) rotate(12) translate(-380, -245)">
          {/* 1. REAR ANGLED CHAINSAW-STYLE GRIP HANDLE & TRIGGER */}
          <g>
            {/* Lower Elbow Bracket with Gold Accent Strip */}
            <path
              d="M148,188 L178,224 L212,224 L212,256 L164,256 L134,202 Z"
              fill="url(#mg-heavy-steel)"
              stroke="#090D16"
              strokeWidth="3.5"
              strokeLinejoin="round"
            />
            <polyline
              points="142,202 166,246 198,246"
              fill="none"
              stroke="#FACC15"
              strokeWidth="4"
              strokeLinecap="round"
              strokeLinejoin="round"
            />

            {/* Main Rear Angled Grip Handle */}
            <path
              d="M128,184 L168,118 C178,108 198,116 202,130 L178,204 Z"
              fill="url(#mg-heavy-steel)"
              stroke="#090D16"
              strokeWidth="3.6"
              strokeLinejoin="round"
            />
            {/* Grip Ribs */}
            {[140, 154, 168].map((gy, i) => (
              <line
                key={i}
                x1={146 + i * 4}
                y1={gy}
                x2={176 + i * 4}
                y2={gy + 12}
                stroke="#0F172A"
                strokeWidth="4.2"
                strokeLinecap="round"
              />
            ))}
            {/* Glowing Orange Trigger Button on Grip */}
            <circle
              cx="178"
              cy="158"
              r="8"
              fill="#F97316"
              stroke="#431407"
              strokeWidth="2.2"
              filter={isActive ? 'url(#mg-overheat-glow)' : 'url(#mg-molten-glow)'}
            />
            <circle cx="176" cy="156" r="3" fill="#FEF08A" />
          </g>

          {/* 2. UNDER-SLUNG HEAVY CYLINDRICAL DRUM MAGAZINE CANISTER */}
          <g>
            {/* Drum Main Body */}
            <rect
              x="212"
              y="264"
              width="136"
              height="84"
              rx="24"
              fill="url(#mg-heavy-steel)"
              stroke="#090D16"
              strokeWidth="3.6"
            />
            {/* Specular Shine on Drum */}
            <line
              x1="228"
              y1="286"
              x2="310"
              y2="286"
              stroke="#E2E8F0"
              strokeWidth="5.5"
              strokeLinecap="round"
              opacity="0.78"
            />
            {/* Vertical Structural Bands on Drum */}
            <rect
              x="224"
              y="262"
              width="15"
              height="88"
              rx="5.5"
              fill="url(#mg-heavy-steel)"
              stroke="#090D16"
              strokeWidth="3"
            />
            <rect
              x="298"
              y="262"
              width="17"
              height="88"
              rx="6"
              fill="url(#mg-heavy-steel)"
              stroke="#090D16"
              strokeWidth="3"
            />
            {/* Front Circular Drum Cap with Rivet Holes */}
            <ellipse
              cx="332"
              cy="306"
              rx="24"
              ry="42"
              fill="#475569"
              stroke="#090D16"
              strokeWidth="3.4"
            />
            <ellipse
              cx="336"
              cy="306"
              rx="10.5"
              ry="18.5"
              fill="#1E293B"
              stroke="#090D16"
              strokeWidth="2.2"
            />
            {/* Rivet Holes around Drum Face */}
            {[
              { x: 330, y: 274 },
              { x: 320, y: 288 },
              { x: 320, y: 324 },
              { x: 330, y: 338 },
              { x: 344, y: 288 },
              { x: 344, y: 324 },
            ].map((rv, i) => (
              <circle key={i} cx={rv.x} cy={rv.y} r="3.8" fill="#0F172A" />
            ))}
          </g>

          {/* 3. CENTRAL HEAVY MOTOR HOUSING & SIDE GAS PISTON */}
          <g>
            {/* Main Cylindrical Motor Body */}
            <rect
              x="196"
              y="174"
              width="184"
              height="96"
              rx="22"
              fill="url(#mg-heavy-steel)"
              stroke="#090D16"
              strokeWidth="3.6"
            />
            {/* Top Specular Highlight on Motor Housing */}
            <line
              x1="214"
              y1="190"
              x2="354"
              y2="190"
              stroke="#FFFFFF"
              strokeWidth="5.5"
              strokeLinecap="round"
              opacity="0.82"
            />
            {/* Vertical Rib Seams on Motor */}
            <line x1="238" y1="176" x2="238" y2="268" stroke="#0F172A" strokeWidth="3.8" />
            <line x1="286" y1="176" x2="286" y2="268" stroke="#0F172A" strokeWidth="3.8" />

            {/* Animated Titanium Sheen Sweep across Motor Housing */}
            {isMythic && (
              <g clipPath="url(#mg-motor-clip)" pointerEvents="none">
                <rect
                  x="185"
                  y="165"
                  width="75"
                  height="115"
                  fill="url(#mg-sheen-grad)"
                  transform="skewX(-24)"
                  style={{
                    animation: `svgMetalSheen ${dur(4.0)} ease-in-out infinite`,
                  }}
                />
              </g>
            )}

            {/* Side Cylindrical Feeder / Piston with Gold Collar */}
            <rect
              x="232"
              y="234"
              width="86"
              height="32"
              rx="10"
              fill="url(#mg-barrel-tube)"
              stroke="#090D16"
              strokeWidth="3.2"
            />
            <rect
              x="266"
              y="234"
              width="13"
              height="32"
              fill="#FACC15"
              stroke="#451A03"
              strokeWidth="2.2"
            />
            <circle
              cx="312"
              cy="250"
              r="9.5"
              fill="#FACC15"
              stroke="#090D16"
              strokeWidth="2.6"
              filter={isActive ? 'url(#mg-molten-glow)' : 'none'}
            />
          </g>

          {/* 4. TOP ANGLED HEAVY CARRY HANDLE BAR (∏) */}
          <g>
            <path
              d="M324,264 L324,142 C324,130 334,124 346,124 L384,124 C396,124 404,132 404,144 L404,184 L384,184 L384,146 L346,146 L346,264 Z"
              fill="url(#mg-heavy-steel)"
              stroke="#090D16"
              strokeWidth="3.5"
              strokeLinejoin="round"
            />
            <line
              x1="336"
              y1="132"
              x2="392"
              y2="132"
              stroke="#FFFFFF"
              strokeWidth="3.2"
              strokeLinecap="round"
              opacity="0.85"
            />
          </g>

          {/* 5. SIX-BARREL ROTARY GATLING CLUSTER & MOLTEN GOLDEN MUZZLE TIPS */}
          <g>
            {/* Rear Rotor Mount Plate */}
            <ellipse
              cx="378"
              cy="224"
              rx="22"
              ry="48"
              fill="#1E293B"
              stroke="#090D16"
              strokeWidth="3.5"
            />

            {/* Animated Spinning 6-Barrel Cluster */}
            <g
              style={{
                animation: isActive
                  ? `minigunBarrelSpin ${dur(0.12)} linear infinite`
                  : 'none',
              }}
            >
              {/* Back-Layer Barrels */}
              <rect
                x="376"
                y="184"
                width="244"
                height="16"
                rx="4"
                fill="url(#mg-barrel-tube)"
                stroke="#090D16"
                strokeWidth="2.8"
              />
              <rect
                x="376"
                y="248"
                width="244"
                height="16"
                rx="4"
                fill="url(#mg-barrel-tube)"
                stroke="#090D16"
                strokeWidth="2.8"
              />

              {/* Mid-Layer Barrels */}
              <rect
                x="376"
                y="200"
                width="254"
                height="17"
                rx="4"
                fill="url(#mg-barrel-tube)"
                stroke="#090D16"
                strokeWidth="3"
              />
              <rect
                x="376"
                y="232"
                width="254"
                height="17"
                rx="4"
                fill="url(#mg-barrel-tube)"
                stroke="#090D16"
                strokeWidth="3"
              />

              {/* Center-Front Main Barrels with Bright Specular Shine */}
              <rect
                x="376"
                y="215"
                width="262"
                height="18"
                rx="4"
                fill="url(#mg-barrel-tube)"
                stroke="#090D16"
                strokeWidth="3.2"
              />
              <line
                x1="386"
                y1="220"
                x2="628"
                y2="220"
                stroke="#FFFFFF"
                strokeWidth="3"
                opacity="0.9"
              />
            </g>

            {/* Two Circular Barrel-Clamp Spacer Rings with Gold Rivets */}
            {[492, 578].map((cxPos, idx) => (
              <g key={idx}>
                <rect
                  x={cxPos}
                  y="175"
                  width="24"
                  height="98"
                  rx="10"
                  fill="url(#mg-heavy-steel)"
                  stroke="#090D16"
                  strokeWidth="3.4"
                />
                <line
                  x1={cxPos + 8}
                  y1="184"
                  x2={cxPos + 8}
                  y2="264"
                  stroke="#FFFFFF"
                  strokeWidth="3.2"
                  strokeLinecap="round"
                  opacity="0.82"
                />
                <circle cx={cxPos + 13} cy="198" r="2.5" fill="#FACC15" />
                <circle cx={cxPos + 13} cy="250" r="2.5" fill="#FACC15" />
              </g>
            ))}

            {/* 6 INCANDESCENT MOLTEN GOLD-ORANGE MUZZLE RINGS AT THE FRONT */}
            <g
              filter={isActive ? 'url(#mg-overheat-glow)' : 'url(#mg-molten-glow)'}
            >
              {[
                { cx: 622, cy: 192 },
                { cx: 636, cy: 202 },
                { cx: 614, cy: 214 },
                { cx: 642, cy: 224 },
                { cx: 618, cy: 240 },
                { cx: 634, cy: 254 },
              ].map((tip, idx) => (
                <g key={idx}>
                  <ellipse
                    cx={tip.cx}
                    cy={tip.cy}
                    rx="8"
                    ry="11.5"
                    fill="url(#mg-molten-tip)"
                    stroke="#78350F"
                    strokeWidth="1.6"
                  />
                  <ellipse
                    cx={tip.cx}
                    cy={tip.cy}
                    rx="3.8"
                    ry="6"
                    fill={isActive ? '#FFFFFF' : '#1E293B'}
                  />
                </g>
              ))}
            </g>
          </g>

          {/* ==================== STATIONARY ROTARY OVERHEAT CORONA (NO PROJECTILES!) ==================== */}
          {isActive && (
            <g
              style={{
                animation: `muzzleCrownPulse ${dur(0.36)} ease-out infinite`,
                transformOrigin: '634px 224px',
              }}
            >
              {/* Contained Molten Golden-Orange Rotary Vortex anchored to the 6 Muzzle Tips */}
              <ellipse
                cx="636"
                cy="224"
                rx="26"
                ry="56"
                fill="none"
                stroke="#FACC15"
                strokeWidth="4.8"
                strokeDasharray="12 8"
                filter="url(#mg-overheat-glow)"
              />
              <circle
                cx="636"
                cy="224"
                r="42"
                fill="#F97316"
                opacity="0.5"
                filter="url(#mg-overheat-glow)"
              />
              <path
                d="M636,162 L645,211 L692,224 L645,237 L636,286 L627,237 L580,224 L627,211 Z"
                fill="#FFFFFF"
                stroke="#F97316"
                strokeWidth="1.8"
                filter="url(#mg-overheat-glow)"
              />
            </g>
          )}
        </g>
      </g>
    </svg>
  );
};
