import React from 'react';

interface WeaponSvgProps {
  isActive: boolean;
  speed?: number;
  showBackdrop?: boolean;
  isMythic?: boolean;
  svgRef?: React.RefObject<SVGSVGElement | null>;
}

export const FireworkLauncherSvg: React.FC<WeaponSvgProps> = ({
  isActive,
  speed = 1,
  showBackdrop = true,
  isMythic = true,
  svgRef,
}) => {
  const dur = (base: number) => `${(base / speed).toFixed(2)}s`;

  // Helper to draw a 5-point star at (cx, cy, radius)
  const starPoints = (cx: number, cy: number, r: number) => {
    const pts: string[] = [];
    for (let i = 0; i < 10; i++) {
      const rad = i % 2 === 0 ? r : r * 0.44;
      const angle = (Math.PI / 5) * i - Math.PI / 2;
      pts.push(`${(cx + rad * Math.cos(angle)).toFixed(1)},${(cy + rad * Math.sin(angle)).toFixed(1)}`);
    }
    return pts.join(' ');
  };

  return (
    <svg
      ref={svgRef}
      viewBox="0 0 800 500"
      className="w-full h-full select-none overflow-visible"
      xmlns="http://www.w3.org/2000/svg"
    >
      <defs>
        {/* Festive Pyro Radial Glow */}
        <radialGradient id="fw-bg-glow" cx="50%" cy="46%" r="48%">
          <stop offset="0%" stopColor="#FACC15" stopOpacity="0.58" />
          <stop offset="40%" stopColor="#EF4444" stopOpacity="0.38" />
          <stop offset="75%" stopColor="#581C87" stopOpacity="0.22" />
          <stop offset="100%" stopColor="#090D1A" stopOpacity="0" />
        </radialGradient>

        {/* Royal Blue Tube Gradient */}
        <linearGradient id="fw-blue-tube" x1="0%" y1="0%" x2="0%" y2="100%">
          <stop offset="0%" stopColor="#93C5FD" />
          <stop offset="22%" stopColor="#2563EB" />
          <stop offset="68%" stopColor="#1D4ED8" />
          <stop offset="100%" stopColor="#172554" />
        </linearGradient>

        {/* Festive Crimson Red Tube Gradient */}
        <linearGradient id="fw-red-tube" x1="0%" y1="0%" x2="0%" y2="100%">
          <stop offset="0%" stopColor="#FECACA" />
          <stop offset="20%" stopColor="#EF4444" />
          <stop offset="65%" stopColor="#B91C1C" />
          <stop offset="100%" stopColor="#450A0A" />
        </linearGradient>

        {/* Heavy Golden Brass Ring Gradient */}
        <linearGradient id="fw-gold-ring" x1="0%" y1="0%" x2="0%" y2="100%">
          <stop offset="0%" stopColor="#78350F" />
          <stop offset="14%" stopColor="#FEF9C3" />
          <stop offset="32%" stopColor="#FACC15" />
          <stop offset="60%" stopColor="#D97706" />
          <stop offset="86%" stopColor="#78350F" />
          <stop offset="100%" stopColor="#3B1302" />
        </linearGradient>

        {/* Dark Steel Breech & Grip Frame */}
        <linearGradient id="fw-dark-steel" x1="0%" y1="0%" x2="0%" y2="100%">
          <stop offset="0%" stopColor="#64748B" />
          <stop offset="35%" stopColor="#334155" />
          <stop offset="80%" stopColor="#1E293B" />
          <stop offset="100%" stopColor="#0F172A" />
        </linearGradient>

        {/* Warm Wood Grip Panel */}
        <linearGradient id="fw-wood-grip" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#EA580C" />
          <stop offset="50%" stopColor="#9A3412" />
          <stop offset="100%" stopColor="#431407" />
        </linearGradient>

        {/* Golden Sheen Sweep */}
        <linearGradient id="fw-sheen-grad" x1="0%" y1="0%" x2="100%" y2="0%">
          <stop offset="0%" stopColor="#FFFFFF" stopOpacity="0" />
          <stop offset="45%" stopColor="#FEF08A" stopOpacity="0.55" />
          <stop offset="50%" stopColor="#FFFFFF" stopOpacity="0.95" />
          <stop offset="55%" stopColor="#FEF08A" stopOpacity="0.55" />
          <stop offset="100%" stopColor="#FFFFFF" stopOpacity="0" />
        </linearGradient>

        <clipPath id="fw-tubes-clip">
          <rect x="212" y="148" width="320" height="146" rx="14" />
        </clipPath>

        {/* Glow Filters */}
        <filter id="fw-pyro-glow" x="-50%" y="-50%" width="200%" height="200%">
          <feGaussianBlur stdDeviation="8" result="blur" />
          <feComposite in="SourceGraphic" in2="blur" operator="over" />
        </filter>

        <filter id="fw-festival-overcharge" x="-70%" y="-70%" width="240%" height="240%">
          <feGaussianBlur stdDeviation="14" result="blur1" />
          <feGaussianBlur stdDeviation="4" result="blur2" />
          <feMerge>
            <feMergeNode in="blur1" />
            <feMergeNode in="blur2" />
            <feMergeNode in="SourceGraphic" />
          </feMerge>
        </filter>
      </defs>

      {/* ==================== AMBIENT BACKDROP, SPARKS & PEDESTAL ==================== */}
      {showBackdrop && (
        <g>
          <ellipse cx="400" cy="240" rx="350" ry="215" fill="url(#fw-bg-glow)" />

          {/* Mythic Pyro Rotating Starburst Ring */}
          {isMythic && (
            <g opacity={isActive ? '0.58' : '0.3'} transform="translate(390, 225)">
              <g style={{ animation: `rotateSlowCW 22s linear infinite` }}>
                <circle
                  cx="0"
                  cy="0"
                  r="175"
                  fill="none"
                  stroke="#FACC15"
                  strokeWidth="1.8"
                  strokeDasharray="14 10 4 10"
                />
                <circle
                  cx="0"
                  cy="0"
                  r="152"
                  fill="none"
                  stroke="#EF4444"
                  strokeWidth="1.3"
                  strokeDasharray="6 14"
                />
              </g>
            </g>
          )}

          {/* Dark Purple Pedestal Oval below Launcher */}
          <ellipse
            cx="365"
            cy="415"
            rx="150"
            ry="18"
            fill="#090414"
            stroke="#7E22CE"
            strokeWidth="2.2"
            opacity="0.82"
          />

          {/* Festive Firework Sparks, Starbursts & Confetti around Front */}
          <g>
            {[
              { x: 525, y: 82, c: '#FEF08A', r: 4.5 },
              { x: 568, y: 74, c: '#F97316', r: 4 },
              { x: 615, y: 98, c: '#FEF08A', r: 5 },
              { x: 545, y: 294, c: '#38BDF8', r: 4.5 },
              { x: 598, y: 278, c: '#FB7185', r: 4.5 },
              { x: 638, y: 245, c: '#FACC15', r: 4 },
            ].map((sp, i) => (
              <circle
                key={i}
                cx={sp.x}
                cy={sp.y}
                r={sp.r}
                fill={sp.c}
                filter="url(#fw-pyro-glow)"
                style={{
                  animation: `sparkleTwinkle ${dur(1.7)} ease-in-out infinite`,
                  animationDelay: `${i * 0.2}s`,
                  transformOrigin: `${sp.x}px ${sp.y}px`,
                }}
              />
            ))}
            {/* Mini Striped Firecrackers floating near bottom-right of muzzle matching Reference */}
            <g transform="translate(568, 265) rotate(32)">
              <rect x="0" y="0" width="24" height="9" rx="3.5" fill="#EF4444" stroke="#7F1D1D" strokeWidth="1.2" />
              <line x1="7" y1="0" x2="7" y2="9" stroke="#FEF08A" strokeWidth="2.8" />
              <line x1="15" y1="0" x2="15" y2="9" stroke="#FEF08A" strokeWidth="2.8" />
            </g>
            <g transform="translate(546, 286) rotate(82)">
              <rect x="0" y="0" width="26" height="9" rx="3.5" fill="#3B82F6" stroke="#1E3A8A" strokeWidth="1.2" />
              <line x1="8" y1="0" x2="8" y2="9" stroke="#FEF08A" strokeWidth="2.8" />
              <line x1="16" y1="0" x2="16" y2="9" stroke="#FEF08A" strokeWidth="2.8" />
            </g>
          </g>
        </g>
      )}

      {/* ==================== MAIN WEAPON GROUP (FLOATS & RECOILS) ==================== */}
      <g
        style={{
          animation: isActive
            ? `fireworkRecoil ${dur(0.6)} cubic-bezier(0.22, 1, 0.36, 1) infinite`
            : `floatIdle 3.6s ease-in-out infinite`,
          transformOrigin: '360px 250px',
        }}
      >
        {/* Slight Upward Angle (-9 deg) matching Reference */}
        <g transform="translate(380, 235) rotate(-9) translate(-380, -235)">
          {/* 1. REAR EXHAUST THRUSTER FLAME & TOP BRAIDED SIZZLING FUSE */}
          <g>
            {/* Rear Exhaust Flame Plume (Flares intensely when used!) */}
            <g
              style={{
                animation: `rearFlameFlicker ${dur(isActive ? 0.22 : 0.68)} ease-in-out infinite`,
                transformOrigin: '146px 228px',
              }}
            >
              <path
                d="M148,206 C110,192 84,202 48,195 C78,214 70,224 38,228 C74,236 84,246 58,258 C92,254 118,254 148,248 Z"
                fill="#F97316"
                filter="url(#fw-festival-overcharge)"
              />
              <path
                d="M148,213 C120,206 96,213 72,211 C94,221 90,228 64,229 C92,235 96,241 78,247 C104,245 126,243 148,239 Z"
                fill="#FEF08A"
              />
              <ellipse cx="135" cy="228" rx="15" ry="9" fill="#FFFFFF" />
            </g>

            {/* Top-Left Braided Fuse Cord & Crackling Spark */}
            <path
              d="M182,194 C180,170 168,156 150,152"
              fill="none"
              stroke="#B45309"
              strokeWidth="6.5"
              strokeLinecap="round"
            />
            <path
              d="M182,194 C180,170 168,156 150,152"
              fill="none"
              stroke="#FEF08A"
              strokeWidth="2.4"
              strokeDasharray="4 4"
              strokeLinecap="round"
            />
            {/* Fuse Flame Tip */}
            <g
              transform="translate(146, 148)"
              style={{
                animation: `sparkleTwinkle ${dur(0.32)} ease-in-out infinite`,
              }}
            >
              <path
                d="M0,10 C-14,5 -20,-10 -7,-20 C0,-11 9,-18 12,-5 C14,5 7,12 0,10 Z"
                fill="#F97316"
                filter="url(#fw-festival-overcharge)"
              />
              <circle cx="0" cy="-2" r="6" fill="#FFFFFF" />
            </g>

            {/* Rear Dark-Steel Breech Cap & Star Collar */}
            <rect
              x="144"
              y="201"
              width="35"
              height="54"
              rx="11"
              fill="url(#fw-dark-steel)"
              stroke="#0F172A"
              strokeWidth="3.4"
            />
            <path
              d="M174,185 L216,177 L216,277 L174,269 Z"
              fill="url(#fw-dark-steel)"
              stroke="#0F172A"
              strokeWidth="3.4"
              strokeLinejoin="round"
            />
            {/* Gold Stars on Rear Dark Collar */}
            <polygon points={starPoints(196, 198, 7.5)} fill="#FDE047" />
            <polygon points={starPoints(194, 226, 8.5)} fill="#FDE047" />
            <polygon points={starPoints(196, 254, 7.5)} fill="#FDE047" />
          </g>

          {/* 2. DUAL UNDER-BARREL GRIPS (REAR PISTOL GRIP + FRONT FOREGRIP) */}
          <g>
            {/* Under-Receiver Mounting Rail */}
            <path
              d="M222,276 L446,276 L436,298 L230,298 Z"
              fill="url(#fw-dark-steel)"
              stroke="#0F172A"
              strokeWidth="3.2"
            />
            {/* Trigger Guard & Orange Trigger */}
            <path
              d="M276,296 L276,326 L316,326 L320,296"
              fill="none"
              stroke="#1E293B"
              strokeWidth="6"
              strokeLinejoin="round"
            />
            <path
              d="M290,296 L290,317 L305,317 L301,296 Z"
              fill="#F97316"
              stroke="#7C2D12"
              strokeWidth="2"
            />

            {/* Rear Angled Pistol Grip with Wood Inlay & Gold Studs */}
            <path
              d="M236,294 L214,378 L266,384 L284,296 Z"
              fill="url(#fw-dark-steel)"
              stroke="#0F172A"
              strokeWidth="3.4"
              strokeLinejoin="round"
            />
            <polygon
              points="244,306 226,370 254,374 268,306"
              fill="url(#fw-wood-grip)"
              stroke="#431407"
              strokeWidth="2.2"
            />
            <circle cx="242" cy="362" r="3" fill="#FDE047" />
            <circle cx="254" cy="318" r="2.5" fill="#FDE047" />

            {/* Front Vertical Tactical Foregrip with Wood Inlay */}
            <path
              d="M380,290 L386,376 L430,374 L422,290 Z"
              fill="url(#fw-dark-steel)"
              stroke="#0F172A"
              strokeWidth="3.4"
              strokeLinejoin="round"
            />
            <polygon
              points="390,300 395,366 418,364 412,300"
              fill="url(#fw-wood-grip)"
              stroke="#431407"
              strokeWidth="2.2"
            />
            <circle cx="406" cy="354" r="3" fill="#FDE047" />
          </g>

          {/* 3. BUNDLED STAR-SPANGLED ROCKET TUBES (BLUE, RED, BLUE) */}
          <g>
            {/* TOP ROYAL-BLUE TUBE */}
            <path
              d="M226,166 L528,150 L530,192 L226,204 Z"
              fill="url(#fw-blue-tube)"
              stroke="#0F172A"
              strokeWidth="3.4"
            />
            <line
              x1="236"
              y1="175"
              x2="518"
              y2="160"
              stroke="#BFDBFE"
              strokeWidth="4"
              strokeLinecap="round"
              opacity="0.82"
            />
            {/* Gold Stars on Top Blue Tube */}
            {[262, 312, 362, 436, 488].map((sx, i) => (
              <polygon
                key={i}
                points={starPoints(sx, 184 - i * 2.5, 9.5)}
                fill="#FEF08A"
                stroke="#92400E"
                strokeWidth="1.2"
              />
            ))}

            {/* MIDDLE CRIMSON-RED TUBE */}
            <rect
              x="226"
              y="200"
              width="308"
              height="48"
              fill="url(#fw-red-tube)"
              stroke="#0F172A"
              strokeWidth="3.4"
            />
            <line
              x1="236"
              y1="210"
              x2="520"
              y2="210"
              stroke="#FFE4E6"
              strokeWidth="4.5"
              strokeLinecap="round"
              opacity="0.82"
            />
            {/* Gold Stars on Middle Red Tube */}
            {[252, 294, 342, 384, 438, 482, 514].map((sx, i) => (
              <polygon
                key={i}
                points={starPoints(sx, i % 2 === 0 ? 218 : 232, 9.5)}
                fill="#FEF08A"
                stroke="#92400E"
                strokeWidth="1.2"
              />
            ))}

            {/* BOTTOM ROYAL-BLUE TUBE */}
            <path
              d="M226,246 L530,246 L526,288 L226,280 Z"
              fill="url(#fw-blue-tube)"
              stroke="#0F172A"
              strokeWidth="3.4"
            />
            {/* Gold Stars on Bottom Blue Tube */}
            {[268, 318, 368, 434, 484].map((sx, i) => (
              <polygon
                key={i}
                points={starPoints(sx, 266, 9.5)}
                fill="#FEF08A"
                stroke="#92400E"
                strokeWidth="1.2"
              />
            ))}

            {/* Animated Golden Sheen Sweep across Rocket Tubes */}
            {isMythic && (
              <g clipPath="url(#fw-tubes-clip)" pointerEvents="none">
                <rect
                  x="200"
                  y="140"
                  width="90"
                  height="165"
                  fill="url(#fw-sheen-grad)"
                  transform="skewX(-24)"
                  style={{
                    animation: `svgMetalSheen ${dur(4.1)} ease-in-out infinite`,
                  }}
                />
              </g>
            )}
          </g>

          {/* 4. TWO HEAVY ORNATE GOLDEN-BRASS COLLAR RINGS BINDING THE TUBES */}
          <g>
            {/* Rear Golden Collar Band */}
            <rect
              x="212"
              y="156"
              width="34"
              height="136"
              rx="15"
              fill="url(#fw-gold-ring)"
              stroke="#3B1302"
              strokeWidth="3.6"
            />
            <line
              x1="224"
              y1="166"
              x2="224"
              y2="282"
              stroke="#FFFFFF"
              strokeWidth="4.5"
              strokeLinecap="round"
              opacity="0.88"
            />
            {/* Ornate Gold Rivets on Rear Collar */}
            {[182, 224, 266].map((ry, i) => (
              <circle key={i} cx="232" cy={ry} r="3.5" fill="#FEF9C3" stroke="#78350F" strokeWidth="1.5" />
            ))}

            {/* Front-Middle Golden Collar Band */}
            <rect
              x="394"
              y="146"
              width="36"
              height="152"
              rx="16"
              fill="url(#fw-gold-ring)"
              stroke="#3B1302"
              strokeWidth="3.6"
            />
            <line
              x1="406"
              y1="156"
              x2="406"
              y2="288"
              stroke="#FFFFFF"
              strokeWidth="5"
              strokeLinecap="round"
              opacity="0.9"
            />
            {/* Ornate Gold Rivets on Front Collar */}
            {[176, 222, 268].map((ry, i) => (
              <circle key={i} cx="415" cy={ry} r="3.8" fill="#FEF9C3" stroke="#78350F" strokeWidth="1.5" />
            ))}
          </g>

          {/* 5. FOUR CONICAL ROCKET WARHEADS SEATED AT THE FRONT TUBES */}
          <g
            style={{
              animation: isActive
                ? `fireworkConeJiggle ${dur(0.3)} ease-in-out infinite`
                : 'none',
              transformOrigin: '550px 220px',
            }}
          >
            {/* Back-Right Crimson Rocket Cone (4th Tube) */}
            <g transform="translate(576, 224) rotate(4)">
              <polygon
                points="0,-33 90,0 0,33"
                fill="url(#fw-red-tube)"
                stroke="#450A0A"
                strokeWidth="3.2"
                strokeLinejoin="round"
              />
              <polygon points="18,-26 42,-17 42,17 18,26" fill="url(#fw-gold-ring)" />
            </g>

            {/* Top Blue & Gold Striped Conical Rocket Nose */}
            <g transform="translate(518, 168) rotate(-6)">
              <polygon
                points="0,-31 84,0 0,31"
                fill="url(#fw-blue-tube)"
                stroke="#0F172A"
                strokeWidth="3.2"
                strokeLinejoin="round"
              />
              <polygon points="14,-25 35,-18 35,18 14,25" fill="url(#fw-gold-ring)" />
              <line x1="8" y1="-13" x2="68" y2="-2" stroke="#FFFFFF" strokeWidth="3.2" opacity="0.85" />
            </g>

            {/* Bottom Blue & Gold Striped Conical Rocket Nose */}
            <g transform="translate(516, 268) rotate(8)">
              <polygon
                points="0,-29 80,0 0,29"
                fill="url(#fw-blue-tube)"
                stroke="#0F172A"
                strokeWidth="3.2"
                strokeLinejoin="round"
              />
              <polygon points="14,-23 35,-16 35,16 14,23" fill="url(#fw-gold-ring)" />
            </g>

            {/* Center Main Red & White/Gold Striped Conical Rocket Nose */}
            <g transform="translate(524, 218)">
              <polygon
                points="0,-35 94,0 0,35"
                fill="url(#fw-red-tube)"
                stroke="#450A0A"
                strokeWidth="3.4"
                strokeLinejoin="round"
              />
              <polygon points="16,-29 39,-20 39,20 16,29" fill="url(#fw-gold-ring)" />
              <polygon points="50,-16 67,-9 67,9 50,16" fill="#FEF08A" opacity="0.92" />
              <line x1="8" y1="-14" x2="78" y2="-2" stroke="#FFFFFF" strokeWidth="4" opacity="0.9" />
            </g>
          </g>

          {/* ==================== STATIONARY GRAND CARNIVAL SPARKBURST CROWN (NO PROJECTILES!) ==================== */}
          {isActive && (
            <g
              style={{
                animation: `muzzleCrownPulse ${dur(0.52)} ease-out infinite`,
                transformOrigin: '615px 220px',
              }}
            >
              {/* Festive Multi-Color Firework Starburst Crown anchored at Rocket Tips */}
              <circle
                cx="615"
                cy="220"
                r="48"
                fill="none"
                stroke="#FDE047"
                strokeWidth="4"
                strokeDasharray="6 8"
                filter="url(#fw-festival-overcharge)"
              />
              <polygon
                points={starPoints(625, 160, 20)}
                fill="#FFFFFF"
                stroke="#FACC15"
                strokeWidth="1.5"
                filter="url(#fw-festival-overcharge)"
              />
              <polygon
                points={starPoints(660, 220, 24)}
                fill="#FF4D5E"
                stroke="#FEF08A"
                strokeWidth="1.5"
                filter="url(#fw-festival-overcharge)"
              />
              <polygon
                points={starPoints(620, 280, 20)}
                fill="#38BDF8"
                stroke="#FFFFFF"
                strokeWidth="1.5"
                filter="url(#fw-festival-overcharge)"
              />
            </g>
          )}
        </g>
      </g>
    </svg>
  );
};
