import React, { useState, useRef } from 'react';
import { WEAPONS_DATA, WeaponSpec } from '../data/weaponsData';
import { WeaponRenderer } from './weapons/WeaponRenderer';
import {
  Play,
  Pause,
  Zap,
  Download,
  Copy,
  Check,
  Eye,
  Grid,
  ZoomIn,
  ZoomOut,
  RotateCcw,
  Sliders,
  Sparkles,
  CheckCircle2,
  Code2,
  Crown,
  Star,
} from 'lucide-react';

interface StudioStageViewProps {
  selectedWeapon: WeaponSpec;
  onSelectWeapon: (weapon: WeaponSpec) => void;
  isActive: boolean;
  onToggleLoop: () => void;
  onTriggerBurst: () => void;
  speed: number;
  onChangeSpeed: (s: number) => void;
  isMythic: boolean;
  onToggleMythic: () => void;
  onDownloadSvg: (weapon: WeaponSpec, svgElement: SVGSVGElement | null) => void;
  onCopySvgCode: (weapon: WeaponSpec, svgElement: SVGSVGElement | null) => boolean;
}

export const StudioStageView: React.FC<StudioStageViewProps> = ({
  selectedWeapon,
  onSelectWeapon,
  isActive,
  onToggleLoop,
  onTriggerBurst,
  speed,
  onChangeSpeed,
  isMythic,
  onToggleMythic,
  onDownloadSvg,
  onCopySvgCode,
}) => {
  const [zoom, setZoom] = useState<number>(1.18);
  const [wireframe, setWireframe] = useState<boolean>(false);
  const [showBackdrop, setShowBackdrop] = useState<boolean>(true);
  const [copied, setCopied] = useState<boolean>(false);
  const [showCodeModal, setShowCodeModal] = useState<boolean>(false);
  const [svgCodePreview, setSvgCodePreview] = useState<string>('');

  const stageSvgRef = useRef<SVGSVGElement | null>(null);

  const handleCopy = () => {
    const ok = onCopySvgCode(selectedWeapon, stageSvgRef.current);
    if (ok) {
      setCopied(true);
      setTimeout(() => setCopied(false), 2200);
    }
  };

  const handleInspectCode = () => {
    if (stageSvgRef.current) {
      const serializer = new XMLSerializer();
      const raw = serializer.serializeToString(stageSvgRef.current);
      setSvgCodePreview(raw);
      setShowCodeModal(true);
    }
  };

  return (
    <div className="w-full max-w-7xl mx-auto px-4 sm:px-6 pb-12">
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
        {/* ==================== LEFT / CENTER: INTERACTIVE SVG STAGE (8 COLS) ==================== */}
        <div
          className="lg:col-span-8 relative rounded-3xl overflow-hidden border-2 flex flex-col justify-between min-h-[490px] sm:min-h-[550px]"
          style={{
            background: showBackdrop ? selectedWeapon.cardBg : '#070A12',
            borderColor: isActive
              ? selectedWeapon.primaryColor
              : isMythic
              ? `${selectedWeapon.primaryColor}88`
              : 'rgba(148, 163, 184, 0.22)',
            boxShadow: isActive
              ? `0 0 55px -8px ${selectedWeapon.glowColor}`
              : '0 24px 60px -15px rgba(0,0,0,0.85)',
          }}
        >
          {/* Tactical Vector Blueprint Grid Overlay */}
          <div className="absolute inset-0 bg-tactical-grid pointer-events-none opacity-85" />

          {/* Stage Top Bar: Weapon Rarity, Status & Viewport Controls */}
          <div className="relative z-20 flex flex-wrap items-center justify-between gap-3 p-4 sm:p-5 bg-slate-950/70 backdrop-blur-md border-b border-slate-800/80">
            <div className="flex items-center gap-3">
              <span
                className="px-3.5 py-1 rounded-md border text-xs font-display font-bold uppercase tracking-wider flex items-center gap-1.5"
                style={{
                  backgroundColor: selectedWeapon.rarityBadgeStyle.bg,
                  borderColor: selectedWeapon.rarityBadgeStyle.border,
                  color: selectedWeapon.rarityBadgeStyle.text,
                }}
              >
                <Crown className="w-3.5 h-3.5 text-amber-300 fill-amber-300" />
                <span>
                  {isMythic ? selectedWeapon.mythicRarity : selectedWeapon.rarity}
                </span>
              </span>
              <div>
                <div className="flex items-center gap-2">
                  <h2 className="font-display font-extrabold text-lg sm:text-xl text-white tracking-wider uppercase">
                    {selectedWeapon.name}
                  </h2>
                  <div className="hidden sm:flex items-center gap-0.5">
                    {Array.from({ length: selectedWeapon.stars }).map((_, i) => (
                      <Star
                        key={i}
                        className="w-3 h-3 text-amber-400 fill-amber-400"
                      />
                    ))}
                  </div>
                </div>
                <p className="text-xs text-slate-300">
                  {selectedWeapon.indonesianTitle}
                </p>
              </div>
            </div>

            {/* Viewport Inspection Tools */}
            <div className="flex flex-wrap items-center gap-1.5 bg-slate-900/90 p-1.5 rounded-xl border border-slate-800">
              <button
                onClick={() => setZoom((z) => Math.max(0.75, +(z - 0.15).toFixed(2)))}
                title="Perkecil Zoom"
                className="p-1.5 rounded-lg hover:bg-slate-800 text-slate-300 transition cursor-pointer"
              >
                <ZoomOut className="w-4 h-4" />
              </button>
              <span className="text-xs font-mono-code text-slate-300 px-2 min-w-[52px] text-center">
                {Math.round(zoom * 100)}%
              </span>
              <button
                onClick={() => setZoom((z) => Math.min(1.85, +(z + 0.15).toFixed(2)))}
                title="Perbesar Zoom"
                className="p-1.5 rounded-lg hover:bg-slate-800 text-slate-300 transition cursor-pointer"
              >
                <ZoomIn className="w-4 h-4" />
              </button>
              <button
                onClick={() => setZoom(1.18)}
                title="Reset Zoom"
                className="p-1.5 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-white transition cursor-pointer"
              >
                <RotateCcw className="w-3.5 h-3.5" />
              </button>

              <div className="w-px h-4 bg-slate-700 mx-1" />

              <button
                onClick={onToggleMythic}
                className={`px-2.5 py-1 rounded-lg text-xs font-mono-code flex items-center gap-1.5 transition cursor-pointer ${
                  isMythic
                    ? 'bg-amber-500/20 text-amber-300 border border-amber-400/50'
                    : 'text-slate-300 hover:bg-slate-800'
                }`}
                title="Aktifkan/Matikan Efek Kilau Logam & Halo Mythic"
              >
                <Crown className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Mythic FX</span>
              </button>

              <button
                onClick={() => setWireframe((w) => !w)}
                className={`px-2.5 py-1 rounded-lg text-xs font-mono-code flex items-center gap-1.5 transition cursor-pointer ${
                  wireframe
                    ? 'bg-sky-500/20 text-sky-300 border border-sky-500/50'
                    : 'text-slate-300 hover:bg-slate-800'
                }`}
                title="Tampilkan Garis Vektor X-Ray"
              >
                <Eye className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">X-Ray SVG</span>
              </button>

              <button
                onClick={() => setShowBackdrop((b) => !b)}
                className={`px-2.5 py-1 rounded-lg text-xs font-mono-code flex items-center gap-1.5 transition cursor-pointer ${
                  showBackdrop
                    ? 'bg-purple-500/20 text-purple-300 border border-purple-500/40'
                    : 'text-slate-300 hover:bg-slate-800'
                }`}
                title="Tampilkan/Sembunyikan Aura Background"
              >
                <Grid className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Aura</span>
              </button>
            </div>
          </div>

          {/* Center SVG Stage Canvas */}
          <div
            onClick={onTriggerBurst}
            className={`relative z-10 flex-1 flex items-center justify-center p-6 overflow-hidden cursor-pointer ${
              wireframe ? 'wireframe-mode' : ''
            }`}
            title="Klik area panggung untuk memicu animasi mekanik senjata!"
          >
            <div
              className="w-full h-full max-h-[390px] flex items-center justify-center transition-transform duration-200"
              style={{ transform: `scale(${zoom})` }}
            >
              <WeaponRenderer
                weaponId={selectedWeapon.id}
                isActive={isActive}
                speed={speed}
                showBackdrop={showBackdrop}
                isMythic={isMythic}
                svgRef={stageSvgRef}
              />
            </div>

            {/* Floating Telemetry Badge inside Stage */}
            <div className="absolute bottom-4 left-4 pointer-events-none flex flex-wrap items-center gap-2">
              <div className="px-3 py-1 rounded-lg bg-slate-950/85 border border-slate-800 text-[11px] font-mono-code text-slate-300 flex items-center gap-2">
                <span
                  className={`w-2 h-2 rounded-full ${
                    isActive ? 'bg-emerald-400 animate-ping' : 'bg-amber-400'
                  }`}
                />
                <span>
                  STATUS: {isActive ? 'ACTIVE MECHANICS (NO PROJECTILE)' : 'MYTHIC IDLE FLOAT'}
                </span>
              </div>
              <div className="px-2.5 py-1 rounded-lg bg-slate-950/85 border border-slate-800 text-[11px] font-mono-code text-amber-300">
                {selectedWeapon.serialCode}
              </div>
            </div>
          </div>

          {/* Stage Bottom Control Deck: Trigger, Auto-Loop, & Speed Slider */}
          <div className="relative z-20 p-4 sm:p-5 bg-slate-950/80 backdrop-blur-md border-t border-slate-800/80 flex flex-wrap items-center justify-between gap-4">
            {/* Primary Activation Buttons */}
            <div className="flex flex-wrap items-center gap-3">
              <button
                onClick={onTriggerBurst}
                className="px-5 py-2.5 rounded-xl font-display font-bold text-sm uppercase tracking-wider flex items-center gap-2 shadow-lg transition hover:brightness-110 active:scale-95 cursor-pointer"
                style={{
                  background: `linear-gradient(135deg, ${selectedWeapon.primaryColor}, ${selectedWeapon.secondaryColor})`,
                  color:
                    selectedWeapon.id === 'banana-blaster' ||
                    selectedWeapon.id === 'golden-tycoon'
                      ? '#0F172A'
                      : '#FFFFFF',
                }}
              >
                <Zap className="w-4 h-4 fill-current" />
                <span>Gunakan Senjata (Sekali)</span>
              </button>

              <button
                onClick={onToggleLoop}
                className={`px-4 py-2.5 rounded-xl font-display font-bold text-sm uppercase tracking-wider flex items-center gap-2 border transition cursor-pointer ${
                  isActive
                    ? 'bg-emerald-500/20 border-emerald-400 text-emerald-200 shadow-[0_0_20px_rgba(16,185,129,0.25)]'
                    : 'bg-slate-900 hover:bg-slate-800 border-slate-700 text-slate-200'
                }`}
              >
                {isActive ? (
                  <>
                    <Pause className="w-4 h-4 fill-current" />
                    <span>Hentikan Animasi Loop</span>
                  </>
                ) : (
                  <>
                    <Play className="w-4 h-4 fill-current" />
                    <span>Animasi Terus-Menerus</span>
                  </>
                )}
              </button>
            </div>

            {/* Animation Speed Control (Slow-Mo to Overdrive) */}
            <div className="flex items-center gap-2 bg-slate-900/90 px-3 py-1.5 rounded-xl border border-slate-800">
              <Sliders className="w-3.5 h-3.5 text-slate-400" />
              <span className="text-xs font-mono-code text-slate-400 mr-1">SPEED:</span>
              {[0.25, 0.5, 1, 1.5].map((s) => (
                <button
                  key={s}
                  onClick={() => onChangeSpeed(s)}
                  className={`px-2 py-1 rounded-md text-xs font-mono-code font-semibold transition cursor-pointer ${
                    speed === s
                      ? 'bg-sky-500 text-slate-950'
                      : 'text-slate-300 hover:bg-slate-800'
                  }`}
                >
                  {s}x
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* ==================== RIGHT PANEL: MECHANICAL TELEMETRY & SVG EXPORT (4 COLS) ==================== */}
        <div className="lg:col-span-4 flex flex-col justify-between gap-4 bg-slate-900/70 border border-slate-800/90 rounded-3xl p-5 backdrop-blur-md">
          <div className="space-y-4">
            {/* Weapon Details Header */}
            <div>
              <div className="flex items-center justify-between">
                <span className="text-xs font-mono-code uppercase tracking-widest text-amber-300">
                  ★ {selectedWeapon.mythicTitle}
                </span>
                <span className="text-xs font-mono-code text-emerald-400 flex items-center gap-1">
                  <Sparkles className="w-3.5 h-3.5" /> Tanpa Peluru
                </span>
              </div>
              <h3 className="font-display font-extrabold text-2xl text-white mt-1">
                {selectedWeapon.name}
              </h3>
              <p className="text-xs text-slate-300 leading-relaxed mt-1.5">
                {selectedWeapon.description}
              </p>
            </div>

            {/* Collector Stat Bars */}
            <div className="grid grid-cols-3 gap-2.5 p-3 rounded-2xl bg-slate-950/85 border border-slate-800">
              <div>
                <div className="flex justify-between text-[10px] font-mono-code text-slate-400">
                  <span>POWER</span>
                  <span className="text-white font-bold">{selectedWeapon.stats.power}</span>
                </div>
                <div className="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden mt-1">
                  <div
                    className="h-full rounded-full"
                    style={{
                      width: `${selectedWeapon.stats.power}%`,
                      backgroundColor: selectedWeapon.primaryColor,
                    }}
                  />
                </div>
              </div>
              <div>
                <div className="flex justify-between text-[10px] font-mono-code text-slate-400">
                  <span>AURA</span>
                  <span className="text-white font-bold">
                    {selectedWeapon.stats.resonance}
                  </span>
                </div>
                <div className="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden mt-1">
                  <div
                    className="h-full rounded-full"
                    style={{
                      width: `${selectedWeapon.stats.resonance}%`,
                      backgroundColor: selectedWeapon.primaryColor,
                    }}
                  />
                </div>
              </div>
              <div>
                <div className="flex justify-between text-[10px] font-mono-code text-slate-400">
                  <span>VEKTOR</span>
                  <span className="text-amber-300 font-bold">
                    {selectedWeapon.stats.craftsmanship}%
                  </span>
                </div>
                <div className="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden mt-1">
                  <div
                    className="h-full rounded-full bg-amber-400"
                    style={{ width: `${selectedWeapon.stats.craftsmanship}%` }}
                  />
                </div>
              </div>
            </div>

            {/* Mechanical Animation Breakdown List */}
            <div className="bg-slate-950/80 rounded-2xl p-4 border border-slate-800/80 space-y-2.5">
              <h4 className="text-xs font-display font-bold uppercase tracking-wider text-amber-300 flex items-center gap-2">
                <Zap className="w-4 h-4" />
                <span>Animasi Mekanik & Energi Saat Digunakan:</span>
              </h4>
              <ul className="space-y-2">
                {selectedWeapon.mechanicalActions.map((act, index) => (
                  <li
                    key={index}
                    className="text-xs text-slate-300 flex items-start gap-2.5 leading-relaxed"
                  >
                    <CheckCircle2
                      className="w-4 h-4 shrink-0 mt-0.5"
                      style={{ color: selectedWeapon.primaryColor }}
                    />
                    <span>{act}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Vector Craftsmanship Tags */}
            <div>
              <h4 className="text-xs font-mono-code uppercase tracking-wider text-slate-400 mb-2">
                DETAIL LAYER MYTHIC SVG 2D:
              </h4>
              <div className="flex flex-wrap gap-1.5">
                {selectedWeapon.svgFeatures.map((feat, idx) => (
                  <span
                    key={idx}
                    className="text-xs px-2.5 py-1 rounded-lg bg-slate-950 border border-slate-800 text-slate-200 font-medium"
                  >
                    {feat}
                  </span>
                ))}
              </div>
            </div>
          </div>

          {/* Export / Copy SVG Code Buttons */}
          <div className="pt-3 border-t border-slate-800/80 space-y-2.5">
            <button
              onClick={() => onDownloadSvg(selectedWeapon, stageSvgRef.current)}
              className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-amber-300 via-yellow-400 to-amber-400 hover:brightness-110 text-slate-950 font-display font-extrabold text-xs uppercase tracking-wider flex items-center justify-center gap-2 transition shadow-lg cursor-pointer"
            >
              <Download className="w-4 h-4" />
              <span>Download File {selectedWeapon.id}.svg</span>
            </button>

            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={handleCopy}
                className="py-2.5 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 font-display font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-1.5 transition cursor-pointer"
              >
                {copied ? (
                  <>
                    <Check className="w-4 h-4 text-emerald-400" />
                    <span className="text-emerald-300">Tersalin!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-4 h-4" />
                    <span>Salin Kode SVG</span>
                  </>
                )}
              </button>

              <button
                onClick={handleInspectCode}
                className="py-2.5 px-3 rounded-xl bg-slate-950 hover:bg-slate-800 text-sky-300 border border-slate-800 font-display font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-1.5 transition cursor-pointer"
              >
                <Code2 className="w-4 h-4" />
                <span>Lihat Kode XML</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* ==================== BOTTOM 10-WEAPON QUICK SWITCHER DOCK ==================== */}
      <div className="mt-6">
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-xs font-mono-code uppercase tracking-wider text-slate-400">
            PILIH SENJATA UNTUK INSPEKSI DETAIL (10 SENJATA MYTHIC LENGKAP — SET #1 & SET #2):
          </h3>
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
          {WEAPONS_DATA.map((w) => {
            const isSelected = w.id === selectedWeapon.id;
            return (
              <button
                key={w.id}
                onClick={() => onSelectWeapon(w)}
                className={`group rounded-2xl p-3 border text-left transition-all cursor-pointer flex flex-col justify-between ${
                  isSelected
                    ? 'bg-slate-900/95 scale-[1.02]'
                    : 'bg-slate-950/70 hover:bg-slate-900/60 opacity-80 hover:opacity-100'
                }`}
                style={{
                  borderColor: isSelected
                    ? w.primaryColor
                    : 'rgba(148, 163, 184, 0.18)',
                  boxShadow: isSelected ? `0 0 24px -6px ${w.glowColor}` : 'none',
                }}
              >
                <div className="flex items-center justify-between w-full mb-1">
                  <span
                    className="text-[10px] font-display font-bold px-2 py-0.5 rounded uppercase"
                    style={{
                      backgroundColor: w.rarityBadgeStyle.bg,
                      color: w.rarityBadgeStyle.text,
                      border: `1px solid ${w.rarityBadgeStyle.border}`,
                    }}
                  >
                    {isMythic ? w.mythicRarity : w.rarity}
                  </span>
                  <span className="text-[10px] font-mono-code text-amber-400">
                    ★★★★★
                  </span>
                </div>

                <div className="w-full h-24 flex items-center justify-center my-1">
                  <WeaponRenderer
                    weaponId={w.id}
                    isActive={isSelected && isActive}
                    speed={speed}
                    showBackdrop={false}
                    isMythic={isMythic}
                  />
                </div>

                <div>
                  <div className="font-display font-bold text-xs text-white truncate">
                    {w.name}
                  </div>
                  <div className="text-[10px] text-slate-400 truncate">
                    {w.indonesianTitle}
                  </div>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* ==================== MODAL VIEW RAW SVG CODE ==================== */}
      {showCodeModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-2xl max-w-3xl w-full p-5 flex flex-col gap-4 shadow-2xl">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-display font-bold text-lg text-white">
                  Kode Vektor SVG Murni — {selectedWeapon.name}
                </h3>
                <p className="text-xs text-slate-400">
                  Kode SVG 2D ini mandiri dan dapat digunakan langsung di game atau website Anda.
                </p>
              </div>
              <button
                onClick={() => setShowCodeModal(false)}
                className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-mono-code text-slate-200 cursor-pointer"
              >
                Tutup [X]
              </button>
            </div>
            <textarea
              readOnly
              value={svgCodePreview}
              className="w-full h-72 bg-slate-950 text-sky-300 font-mono-code text-xs p-4 rounded-xl border border-slate-800 focus:outline-none select-all"
            />
            <div className="flex justify-end gap-2">
              <button
                onClick={() => {
                  navigator.clipboard.writeText(svgCodePreview);
                  setCopied(true);
                  setTimeout(() => setCopied(false), 2000);
                }}
                className="px-4 py-2 rounded-xl bg-sky-500 hover:bg-sky-400 text-slate-950 font-display font-bold text-xs uppercase cursor-pointer"
              >
                {copied ? 'Kode Tersalin!' : 'Salin Semua Kode SVG'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
