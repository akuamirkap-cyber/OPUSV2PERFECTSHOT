import type { CSSProperties } from "react";
import { BlurFilter, Flame, FlameDefs, GlowFilter, Sparks } from "./shared";

const TRACES = [
  "M30,150 L60,150 L68,158 L110,158 L118,150 L136,150",
  "M34,182 L58,182 L66,174 L96,174",
  "M142,142 L176,142 L184,150 L226,150 L232,144 L244,144",
  "M142,164 L170,164 L178,158 L212,158 L218,166 L298,166",
  "M232,144 L232,138 L296,138",
  "M302,146 L320,146 L326,152 L342,152",
  "M70,140 L96,142 L104,148",
];
const NODES: [number, number][] = [
  [60, 150], [110, 158], [96, 174], [176, 142], [226, 150], [212, 158], [244, 144], [296, 138], [342, 152], [104, 148], [298, 166], [58, 182],
];

export default function CircuitSniper() {
  return (
    <svg viewBox="0 0 480 300" className="w-full h-full overflow-visible">
      <defs>
        <linearGradient id="cs-lime" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#2c4d02" />
          <stop offset="0.15" stopColor="#efff8a" />
          <stop offset="0.4" stopColor="#a6e622" />
          <stop offset="0.78" stopColor="#5c9a06" />
          <stop offset="1" stopColor="#1f3a00" />
        </linearGradient>
        <linearGradient id="cs-black" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#2a2c36" />
          <stop offset="0.25" stopColor="#7d8090" />
          <stop offset="0.5" stopColor="#262830" />
          <stop offset="1" stopColor="#07070a" />
        </linearGradient>
        <linearGradient id="cs-steel" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#3a3c47" />
          <stop offset="0.3" stopColor="#c9ccd8" />
          <stop offset="0.6" stopColor="#5d606e" />
          <stop offset="1" stopColor="#15161c" />
        </linearGradient>
        <radialGradient id="cs-lens" cx="0.4" cy="0.35" r="0.7">
          <stop offset="0" stopColor="#f2ffd0" />
          <stop offset="0.35" stopColor="#7dff3a" />
          <stop offset="1" stopColor="#1a6b00" />
        </radialGradient>
        <radialGradient id="cs-halo">
          <stop offset="0" stopColor="#fbffe0" />
          <stop offset="0.35" stopColor="#b6ff3a" stopOpacity="0.75" />
          <stop offset="1" stopColor="#7dff2a" stopOpacity="0" />
        </radialGradient>
        <radialGradient id="cs-flash">
          <stop offset="0" stopColor="#ffffff" />
          <stop offset="0.3" stopColor="#fff6b0" />
          <stop offset="0.65" stopColor="#ffb02e" stopOpacity="0.7" />
          <stop offset="1" stopColor="#ff6a00" stopOpacity="0" />
        </radialGradient>
        <radialGradient id="cs-smoke">
          <stop offset="0" stopColor="#e3dfe9" stopOpacity="0.8" />
          <stop offset="1" stopColor="#8d88a3" stopOpacity="0" />
        </radialGradient>
        <FlameDefs id="cs-f" />
        <GlowFilter id="cs-glow" std={2.5} />
        <BlurFilter id="cs-blur" std={16} />
      </defs>

      <ellipse cx="240" cy="150" rx="210" ry="70" fill="#9bff2a" opacity="0.15" filter="url(#cs-blur)" transform="rotate(-18 240 150)" className="pulse" />

      <g transform="rotate(-18 240 150)">
        <g className="recoil">
          {/* barrel */}
          <rect x="342" y="144" width="90" height="12" rx="3" fill="url(#cs-steel)" stroke="#07070a" strokeWidth="0.8" />
          <rect x="380" y="141" width="10" height="18" rx="2" fill="#7dff3a" filter="url(#cs-glow)" className="pulse" />
          {/* muzzle brake */}
          <rect x="428" y="137" width="36" height="26" rx="4" fill="url(#cs-black)" stroke="#07070a" />
          {[436, 446, 456].map((x) => (
            <rect key={x} x={x} y="139" width="4" height="22" rx="1.5" fill="#050506" />
          ))}

          {/* stock */}
          <path d="M22,132 L136,138 L138,176 L100,180 Q74,192 22,198 Z" fill="url(#cs-lime)" stroke="#1a3000" strokeWidth="1.2" />
          <rect x="10" y="128" width="16" height="74" rx="6" fill="url(#cs-black)" stroke="#050506" />
          {[140, 152, 164, 176, 188].map((y) => (
            <line key={y} x1="12" y1={y} x2="24" y2={y} stroke="#3a3c47" strokeWidth="1.5" />
          ))}
          {/* stock window */}
          <rect x="40" y="158" width="52" height="14" rx="4" fill="#0b0d08" stroke="#1a3000" />
          <rect x="44" y="161" width="20" height="8" rx="3" fill="#7dff3a" filter="url(#cs-glow)" className="pulse" />

          {/* receiver */}
          <rect x="134" y="134" width="170" height="40" rx="7" fill="url(#cs-lime)" stroke="#1a3000" strokeWidth="1.2" />
          <rect x="138" y="137" width="162" height="3" rx="1.5" fill="#fbffd0" opacity="0.6" />
          {/* handguard */}
          <path d="M302,138 L346,142 L346,160 L302,168 Z" fill="url(#cs-lime)" stroke="#1a3000" />
          {[312, 326].map((x) => (
            <rect key={x} x={x} y="148" width="9" height="8" rx="2" fill="#0b0d08" />
          ))}
          {/* vents */}
          {[246, 264, 282].map((x, i) => (
            <g key={x}>
              <rect x={x} y="146" width="13" height="11" rx="4" fill="#0b0d08" />
              <rect x={x + 2} y="148" width="9" height="7" rx="3" fill="#ff6a3d" className="seq" filter="url(#cs-glow)" style={{ animationDelay: `${0.1 + i * 0.06}s` }} />
            </g>
          ))}

          {/* circuit traces */}
          {TRACES.map((d, i) => (
            <g key={i}>
              <path d={d} stroke="#2f5a00" strokeWidth="2.2" fill="none" strokeLinejoin="round" />
              <path d={d} pathLength={100} stroke="#f6ffb0" strokeWidth="2.4" fill="none" strokeLinecap="round" className="trace-run" filter="url(#cs-glow)" style={{ animationDelay: `${-i * 0.37}s` } as CSSProperties} />
              <path d={d} stroke="#ffffff" strokeWidth="2.6" fill="none" className="seq" filter="url(#cs-glow)" style={{ animationDelay: `${i * 0.04}s` }} />
            </g>
          ))}
          {NODES.map(([x, y], i) => (
            <circle key={i} cx={x} cy={y} r="2.4" fill="#d9ff6a" stroke="#2f5a00" strokeWidth="1" />
          ))}

          {/* bolt handle */}
          <g className="bolt-slide">
            <rect x="214" y="166" width="22" height="5" rx="2.5" fill="url(#cs-steel)" />
            <circle cx="238" cy="178" r="5" fill="url(#cs-black)" stroke="#07070a" />
            <line x1="232" y1="170" x2="237" y2="176" stroke="#7d8090" strokeWidth="3" strokeLinecap="round" />
          </g>

          {/* pistol grip */}
          <path d="M170,172 L196,172 L190,224 Q188,232 178,231 L166,229 Q159,226 162,218 Z" fill="url(#cs-black)" stroke="#050506" />
          {[190, 202, 214].map((y) => (
            <line key={y} x1={166} y1={y} x2={190} y2={y} stroke="#050506" strokeWidth="2" />
          ))}
          <path d="M196,176 Q222,178 222,196 Q214,204 196,202" fill="none" stroke="#1a1b22" strokeWidth="4.5" strokeLinecap="round" />
          <path d="M200,178 Q208,188 203,196" stroke="#7dff3a" strokeWidth="3.5" fill="none" strokeLinecap="round" />
          {/* magazine */}
          <path d="M240,172 L264,172 L262,206 L242,204 Z" fill="url(#cs-black)" stroke="#050506" />
          <rect x="246" y="178" width="12" height="3" fill="#7dff3a" opacity="0.8" />

          {/* top rail & mounts */}
          <rect x="146" y="128" width="154" height="7" rx="2" fill="url(#cs-black)" />
          {[154, 168, 182, 196, 210, 224, 238, 252, 266, 280].map((x) => (
            <rect key={x} x={x} y="129" width="6" height="3" fill="#3a3c47" />
          ))}
          <path d="M178,128 L184,112 L200,112 L204,128 Z" fill="url(#cs-black)" stroke="#050506" />
          <path d="M252,128 L256,112 L272,112 L278,128 Z" fill="url(#cs-black)" stroke="#050506" />

          {/* scope */}
          <rect x="166" y="96" width="124" height="20" rx="9" fill="url(#cs-black)" stroke="#050506" />
          <rect x="172" y="99" width="110" height="2" rx="1" fill="#ff7ad9" opacity="0.9" filter="url(#cs-glow)" />
          <path d="M148,94 L168,98 L168,114 L148,118 Z" fill="url(#cs-black)" stroke="#050506" />
          <rect x="142" y="92" width="8" height="28" rx="3" fill="#7dff3a" stroke="#1a3000" />
          <path d="M288,98 L312,88 L312,124 L288,114 Z" fill="url(#cs-black)" stroke="#050506" />
          <rect x="310" y="85" width="10" height="42" rx="4" fill="url(#cs-black)" stroke="#050506" />
          <rect x="312" y="85" width="2" height="42" fill="#ff7ad9" opacity="0.85" />
          <ellipse cx="320" cy="106" rx="4.5" ry="17" fill="url(#cs-lens)" stroke="#050506" />
          <ellipse cx="320" cy="106" rx="4.5" ry="17" fill="#ffffff" className="flash" />
          {/* turret */}
          <rect x="220" y="86" width="16" height="12" rx="3" fill="url(#cs-black)" stroke="#050506" />
          <rect x="221" y="84" width="14" height="4" rx="2" fill="#7dff3a" />
          <rect x="196" y="112" width="6" height="8" fill="#ff7ad9" opacity="0.7" />
          {/* scope glint */}
          <g transform="translate(321 99)">
            <path d="M0,-10 L2,-2 L10,0 L2,2 L0,10 L-2,2 L-10,0 L-2,-2 Z" fill="#ffffff" className="glint" filter="url(#cs-glow)" />
          </g>
        </g>

        {/* ===== FIRING FX (no projectile) ===== */}
        <circle cx="474" cy="150" r="46" fill="url(#cs-flash)" className="fx-quick" />
        <Flame id="cs-f" x={466} y={150} rot={90} w={30} h={62} className="fire-burst" />
        {[438, 448, 458].map((x, i) => (
          <g key={x}>
            <Flame id="cs-f" x={x + 2} y={138} rot={-10} w={9} h={30 - i * 3} className="fire-burst" style={{ animationDelay: `${i * 0.03}s` }} />
            <Flame id="cs-f" x={x + 2} y={162} rot={190} w={9} h={30 - i * 3} className="fire-burst" style={{ animationDelay: `${i * 0.03}s` }} />
          </g>
        ))}
        {[0, 0.1, 0.2].map((d) => (
          <ellipse key={d} cx="470" cy="150" rx="10" ry="24" fill="none" stroke="#efff8a" strokeWidth="2.5" className="shock" style={{ animationDelay: `${d}s` }} />
        ))}
        <circle cx="240" cy="150" r="90" fill="url(#cs-halo)" className="heat" opacity="0.4" />
        {[
          [444, 132, 0.1],
          [452, 168, 0.2],
          [470, 146, 0.3],
          [436, 126, 0.4],
        ].map(([x, y, d], i) => (
          <circle key={i} cx={x} cy={y} r="10" fill="url(#cs-smoke)" className="smoke" style={{ animationDelay: `${d}s` }} />
        ))}
        <Sparks cx={468} cy={150} color="#efff8a" count={16} spread={70} seed={31} angleFrom={-1.3} angleTo={1.3} />
      </g>
    </svg>
  );
}
