import type { CSSProperties } from "react";

function rng(seed: number) {
  let s = seed;
  return () => {
    s = (s * 9301 + 49297) % 233280;
    return s / 233280;
  };
}

export function zig(
  x1: number,
  y1: number,
  x2: number,
  y2: number,
  n = 8,
  amp = 8,
  seed = 1
) {
  const r = rng(seed);
  const dx = x2 - x1;
  const dy = y2 - y1;
  const len = Math.hypot(dx, dy) || 1;
  const nx = -dy / len;
  const ny = dx / len;
  let d = `M${x1},${y1}`;
  for (let i = 1; i < n; i++) {
    const t = i / n;
    const o = (r() - 0.5) * 2 * amp;
    d += ` L${(x1 + dx * t + nx * o).toFixed(1)},${(y1 + dy * t + ny * o).toFixed(1)}`;
  }
  return d + ` L${x2},${y2}`;
}

type BoltProps = {
  x1: number;
  y1: number;
  x2: number;
  y2: number;
  color: string;
  n?: number;
  amp?: number;
  seed?: number;
  width?: number;
  className?: string;
  style?: CSSProperties;
};

export function Bolt({
  x1,
  y1,
  x2,
  y2,
  color,
  n = 8,
  amp = 8,
  seed = 1,
  width = 2,
  className,
  style,
}: BoltProps) {
  const d = zig(x1, y1, x2, y2, n, amp, seed);
  return (
    <g className={className} style={style}>
      <path d={d} stroke={color} strokeWidth={width * 4} opacity={0.3} fill="none" strokeLinecap="round" strokeLinejoin="round" />
      <path d={d} stroke={color} strokeWidth={width * 2} opacity={0.8} fill="none" strokeLinecap="round" strokeLinejoin="round" />
      <path d={d} stroke="#ffffff" strokeWidth={width * 0.8} fill="none" strokeLinecap="round" strokeLinejoin="round" />
    </g>
  );
}

/** Two flickering bolts alternating -> living electricity */
export function LiveBolt(props: Omit<BoltProps, "className">) {
  const s = props.seed ?? 1;
  return (
    <g>
      <Bolt {...props} seed={s} className="flickA" />
      <Bolt {...props} seed={s + 17} className="flickB" />
    </g>
  );
}

export function Sparks({
  cx,
  cy,
  color,
  count = 14,
  spread = 70,
  seed = 3,
  angleFrom = 0,
  angleTo = Math.PI * 2,
}: {
  cx: number;
  cy: number;
  color: string;
  count?: number;
  spread?: number;
  seed?: number;
  angleFrom?: number;
  angleTo?: number;
}) {
  const r = rng(seed);
  const items = Array.from({ length: count }, (_, i) => {
    const a = angleFrom + ((angleTo - angleFrom) * (i + r() * 0.8)) / count;
    const dist = spread * (0.45 + r() * 0.55);
    return {
      dx: Math.cos(a) * dist,
      dy: Math.sin(a) * dist,
      rad: 1.2 + r() * 2.2,
      delay: r() * 0.18,
      white: r() > 0.6,
    };
  });
  return (
    <g>
      {items.map((it, i) => (
        <circle
          key={i}
          cx={cx}
          cy={cy}
          r={it.rad}
          fill={it.white ? "#ffffff" : color}
          className="spark"
          style={
            {
              "--dx": `${it.dx}px`,
              "--dy": `${it.dy}px`,
              animationDelay: `${it.delay}s`,
            } as CSSProperties
          }
        />
      ))}
    </g>
  );
}

/* ---------------- FIRE ---------------- */
export function flamePath(w: number, h: number) {
  return [
    `M${-w / 2},0`,
    `C${-w / 2},${w * 0.35} ${w / 2},${w * 0.35} ${w / 2},0`,
    `C${w / 2},${-h * 0.3} ${w * 0.15},${-h * 0.45} ${w * 0.3},${-h * 0.7}`,
    `C${w * 0.05},${-h * 0.6} ${w * 0.06},${-h * 0.85} 0,${-h}`,
    `C${-w * 0.12},${-h * 0.75} ${-w * 0.42},${-h * 0.65} ${-w * 0.3},${-h * 0.45}`,
    `C${-w * 0.5},${-h * 0.5} ${-w * 0.56},${-h * 0.6} ${-w * 0.5},${-h * 0.74}`,
    `C${-w * 0.72},${-h * 0.4} ${-w / 2},${-h * 0.2} ${-w / 2},0 Z`,
  ].join(" ");
}

type FlamePalette = "fire" | "blue" | "toxic";
const PALETTES: Record<FlamePalette, { o: string[]; m: string[]; i: string[]; g: string }> = {
  fire: { o: ["#ffb300", "#ff4d00", "#b51200"], m: ["#ffe27a", "#ff9800"], i: ["#ffffff", "#fff1a1"], g: "#ff6a00" },
  blue: { o: ["#7fe1ff", "#2a7bff", "#1a2a9a"], m: ["#e6fbff", "#5cc8ff"], i: ["#ffffff", "#d9f6ff"], g: "#3aa0ff" },
  toxic: { o: ["#d9ff4a", "#5cd600", "#1d6b00"], m: ["#f4ffb0", "#9bff2a"], i: ["#ffffff", "#f7ffd0"], g: "#7dff2a" },
};

export function FlameDefs({ id, palette = "fire" }: { id: string; palette?: FlamePalette }) {
  const p = PALETTES[palette];
  return (
    <>
      <linearGradient id={`${id}-o`} x1="0" y1="1" x2="0" y2="0">
        <stop offset="0" stopColor={p.o[0]} />
        <stop offset="0.45" stopColor={p.o[1]} />
        <stop offset="1" stopColor={p.o[2]} stopOpacity="0.15" />
      </linearGradient>
      <linearGradient id={`${id}-m`} x1="0" y1="1" x2="0" y2="0">
        <stop offset="0" stopColor={p.m[0]} />
        <stop offset="1" stopColor={p.m[1]} stopOpacity="0.6" />
      </linearGradient>
      <linearGradient id={`${id}-i`} x1="0" y1="1" x2="0" y2="0">
        <stop offset="0" stopColor={p.i[0]} />
        <stop offset="1" stopColor={p.i[1]} stopOpacity="0.7" />
      </linearGradient>
      <radialGradient id={`${id}-g`}>
        <stop offset="0" stopColor={p.g} stopOpacity="0.7" />
        <stop offset="1" stopColor={p.g} stopOpacity="0" />
      </radialGradient>
    </>
  );
}

/** Flame pointing UP by default (rot=90 -> right, rot=-90 -> left). Base at (x,y). */
export function Flame({
  id,
  x,
  y,
  rot = 0,
  w = 30,
  h = 70,
  className,
  style,
}: {
  id: string;
  x: number;
  y: number;
  rot?: number;
  w?: number;
  h?: number;
  className?: string;
  style?: CSSProperties;
}) {
  return (
    <g transform={`translate(${x} ${y}) rotate(${rot})`}>
      <g className={className} style={style}>
        <ellipse cx={0} cy={-h * 0.42} rx={w * 1.1} ry={h * 0.7} fill={`url(#${id}-g)`} className="pulse" />
        <path d={flamePath(w, h)} fill={`url(#${id}-o)`} className="flame" />
        <path d={flamePath(w * 0.72, h * 0.74)} fill={`url(#${id}-m)`} className="flame f2" />
        <path d={flamePath(w * 0.46, h * 0.5)} fill={`url(#${id}-i)`} className="flame f3" />
        <path d={flamePath(w * 0.24, h * 0.24)} fill="#ffffff" className="flame f2" />
      </g>
    </g>
  );
}

export function Embers({
  x,
  y,
  color = "#ffb347",
  count = 12,
  spreadX = 60,
  rise = 90,
  seed = 7,
}: {
  x: number;
  y: number;
  color?: string;
  count?: number;
  spreadX?: number;
  rise?: number;
  seed?: number;
}) {
  const r = rng(seed);
  return (
    <g>
      {Array.from({ length: count }, (_, i) => {
        const ox = (r() - 0.5) * spreadX * 0.6;
        return (
          <circle
            key={i}
            cx={x + ox}
            cy={y + (r() - 0.5) * 20}
            r={0.8 + r() * 1.8}
            fill={r() > 0.7 ? "#fff3c4" : color}
            className="ember"
            style={
              {
                "--dx": `${(r() - 0.5) * spreadX}px`,
                "--dy": `${-rise * (0.5 + r() * 0.6)}px`,
                animationDuration: `${1.6 + r() * 1.8}s`,
                animationDelay: `${-r() * 3}s`,
              } as CSSProperties
            }
          />
        );
      })}
    </g>
  );
}

export function GlowFilter({ id, std = 4 }: { id: string; std?: number }) {
  return (
    <filter id={id} x="-60%" y="-60%" width="220%" height="220%">
      <feGaussianBlur stdDeviation={std} result="b" />
      <feMerge>
        <feMergeNode in="b" />
        <feMergeNode in="SourceGraphic" />
      </feMerge>
    </filter>
  );
}

export function BlurFilter({ id, std = 10 }: { id: string; std?: number }) {
  return (
    <filter id={id} x="-100%" y="-100%" width="300%" height="300%">
      <feGaussianBlur stdDeviation={std} />
    </filter>
  );
}
