import { Bolt, GlowFilter, BlurFilter, LiveBolt, Sparks } from "./shared";

const RINGS = [158, 194, 230, 266, 302];

export default function TeslaStaff() {
  return (
    <svg viewBox="0 0 420 320" className="w-full h-full overflow-visible">
      <defs>
        <linearGradient id="t-body" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#0a1650" />
          <stop offset="0.18" stopColor="#3f7bff" />
          <stop offset="0.32" stopColor="#bcd4ff" />
          <stop offset="0.45" stopColor="#2a5ae8" />
          <stop offset="0.75" stopColor="#0c1f78" />
          <stop offset="1" stopColor="#040a2c" />
        </linearGradient>
        <linearGradient id="t-handle" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#142050" />
          <stop offset="0.3" stopColor="#4a5d9e" />
          <stop offset="0.55" stopColor="#1a2556" />
          <stop offset="1" stopColor="#070b22" />
        </linearGradient>
        <linearGradient id="t-gold" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#7a4a06" />
          <stop offset="0.2" stopColor="#ffe9a3" />
          <stop offset="0.45" stopColor="#f2b631" />
          <stop offset="0.75" stopColor="#a66a0b" />
          <stop offset="1" stopColor="#4d2c02" />
        </linearGradient>
        <linearGradient id="t-goldH" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0" stopColor="#8a5508" />
          <stop offset="0.4" stopColor="#ffe9a3" />
          <stop offset="0.7" stopColor="#e3a221" />
          <stop offset="1" stopColor="#6b3e04" />
        </linearGradient>
        <linearGradient id="t-shield" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#5fb7ff" stopOpacity="0.55" />
          <stop offset="0.5" stopColor="#1b4fd6" stopOpacity="0.35" />
          <stop offset="1" stopColor="#0a2a9a" stopOpacity="0.6" />
        </linearGradient>
        <radialGradient id="t-orb">
          <stop offset="0" stopColor="#ffffff" />
          <stop offset="0.4" stopColor="#9fe4ff" />
          <stop offset="1" stopColor="#1e7bff" stopOpacity="0" />
        </radialGradient>
        <radialGradient id="t-halo">
          <stop offset="0" stopColor="#dff6ff" />
          <stop offset="0.35" stopColor="#5cc8ff" stopOpacity="0.8" />
          <stop offset="1" stopColor="#1e6bff" stopOpacity="0" />
        </radialGradient>
        <GlowFilter id="t-glow" std={3} />
        <BlurFilter id="t-blur" std={16} />
      </defs>

      <ellipse cx="210" cy="160" rx="180" ry="80" fill="#2b6bff" opacity="0.28" filter="url(#t-blur)" transform="rotate(-32 210 160)" className="pulse" />

      <g transform="rotate(-32 210 160)">
        <g className="recoil">
          {/* hex shield frame */}
          <polygon points="138,160 160,124 334,124 356,160 334,196 160,196" fill="url(#t-shield)" stroke="#6fd0ff" strokeWidth="2.5" filter="url(#t-glow)" />
          <polygon points="146,160 164,130 330,130 348,160 330,190 164,190" fill="none" stroke="#bfe8ff" strokeWidth="1" opacity="0.6" />

          {/* handle */}
          <rect x="22" y="146" width="104" height="28" rx="6" fill="url(#t-handle)" stroke="#2c3a78" />
          {Array.from({ length: 9 }, (_, i) => (
            <rect key={i} x={30 + i * 10.5} y="145" width="5" height="30" rx="2.5" fill="#0a0f2e" opacity="0.75" />
          ))}
          <rect x="24" y="149" width="100" height="4" rx="2" fill="#8fa6ff" opacity="0.35" />
          {/* end cap */}
          <rect x="10" y="142" width="16" height="36" rx="4" fill="url(#t-gold)" />
          <rect x="6" y="146" width="6" height="28" rx="3" fill="url(#t-gold)" />

          {/* collar */}
          <rect x="124" y="138" width="18" height="44" rx="4" fill="url(#t-gold)" />
          <rect x="128" y="140" width="3" height="40" fill="#fff6d2" opacity="0.6" />

          {/* main body */}
          <rect x="140" y="138" width="198" height="44" rx="8" fill="url(#t-body)" stroke="#0a1650" />
          {/* energy core window */}
          <rect x="146" y="154" width="186" height="12" rx="6" fill="#06123d" />
          <rect x="146" y="154" width="186" height="12" rx="6" fill="#39b8ff" opacity="0.55" className="pulse" />
          <g filter="url(#t-glow)">
            <LiveBolt x1={150} y1={160} x2={328} y2={160} color="#5fd4ff" n={18} amp={4} seed={3} width={1} />
          </g>

          {/* gold spiral rings */}
          {RINGS.map((x) => (
            <g key={x}>
              <path d={`M${x + 6},132 L${x + 22},132 L${x + 10},188 L${x - 6},188 Z`} fill="url(#t-gold)" stroke="#5a3503" strokeWidth="1" />
              <path d={`M${x + 12},133 L${x + 16},133 L${x + 4},187 L${x},187 Z`} fill="#fff4c4" opacity="0.65" />
              <path d={`M${x + 6},132 L${x + 22},132 L${x + 10},188 L${x - 6},188 Z`} fill="#7fe1ff" className="seq" filter="url(#t-glow)" style={{ animationDelay: `${(RINGS.length - RINGS.indexOf(x)) * 0.06}s` }} />
            </g>
          ))}

          {/* head collar */}
          <rect x="336" y="140" width="16" height="40" rx="4" fill="url(#t-gold)" />
          <rect x="350" y="146" width="14" height="28" rx="3" fill="url(#t-handle)" />
          <circle cx="357" cy="160" r="4" fill="#7fe1ff" filter="url(#t-glow)" className="pulse" />

          {/* fork prongs */}
          <path d="M362,150 C380,150 384,128 398,120 L404,126 C394,134 390,156 368,160 Z" fill="url(#t-goldH)" stroke="#5a3503" strokeWidth="0.8" />
          <path d="M362,170 C380,170 384,192 398,200 L404,194 C394,186 390,164 368,160 Z" fill="url(#t-goldH)" stroke="#5a3503" strokeWidth="0.8" />
          <path d="M400,121 C410,116 414,124 408,130" stroke="url(#t-goldH)" strokeWidth="4" fill="none" strokeLinecap="round" />
          <path d="M400,199 C410,204 414,196 408,190" stroke="url(#t-goldH)" strokeWidth="4" fill="none" strokeLinecap="round" />

          {/* orbs */}
          <g className="charge">
            <circle cx="406" cy="124" r="16" fill="url(#t-halo)" className="pulse" />
            <circle cx="406" cy="124" r="5" fill="#fff" filter="url(#t-glow)" />
          </g>
          <g className="charge">
            <circle cx="406" cy="196" r="16" fill="url(#t-halo)" className="pulse" />
            <circle cx="406" cy="196" r="5" fill="#fff" filter="url(#t-glow)" />
          </g>
          <g className="idle-zap" filter="url(#t-glow)">
            <Bolt x1={406} y1={128} x2={406} y2={192} color="#5fd4ff" n={7} amp={7} seed={12} width={1} />
          </g>
        </g>

        {/* ===== FIRING FX ===== */}
        <circle cx="414" cy="160" r="70" fill="url(#t-halo)" className="fx" />
        <g className="fx" filter="url(#t-glow)">
          <LiveBolt x1={406} y1={124} x2={406} y2={196} color="#4fc8ff" n={8} amp={12} seed={22} width={1.8} />
          <LiveBolt x1={406} y1={124} x2={448} y2={100} color="#4fc8ff" n={6} amp={9} seed={31} width={1.2} />
          <LiveBolt x1={406} y1={196} x2={450} y2={220} color="#4fc8ff" n={6} amp={9} seed={37} width={1.2} />
          <LiveBolt x1={406} y1={160} x2={458} y2={160} color="#9fe8ff" n={7} amp={10} seed={44} width={1.4} />
          <LiveBolt x1={406} y1={124} x2={440} y2={150} color="#9fe8ff" n={5} amp={7} seed={49} width={1} />
          {/* body crawl lightning */}
          <LiveBolt x1={140} y1={138} x2={338} y2={182} color="#4fc8ff" n={16} amp={10} seed={61} width={1} />
        </g>
        <rect x="146" y="154" width="186" height="12" rx="6" fill="#e6f8ff" className="flash" filter="url(#t-glow)" />
        <circle cx="410" cy="160" r="16" fill="#fff" className="fx-quick" filter="url(#t-glow)" />
        {[0, 0.12, 0.24].map((d) => (
          <circle key={d} cx="410" cy="160" r="24" fill="none" stroke="#7fe1ff" strokeWidth="3" className="shock" style={{ animationDelay: `${d}s` }} />
        ))}
        <Sparks cx={406} cy={124} color="#7fe1ff" count={10} spread={60} seed={4} />
        <Sparks cx={406} cy={196} color="#7fe1ff" count={10} spread={60} seed={14} />
      </g>
    </svg>
  );
}
