import type { CSSProperties } from "react";
import { BlurFilter, Flame, FlameDefs, GlowFilter, LiveBolt, Sparks } from "./shared";

type Variant = "volt" | "star";
const OL = "#0b0a10";

const PAL = {
  volt: {
    tube: ["#4a1d00", "#ffe1a3", "#ffab2e", "#c46a06", "#4a1f00"],
    bell: ["#14151b", "#7d8191", "#2c2e38", "#0b0c10"],
    war: ["#16380a", "#c8f59a", "#5aaa2c", "#25551a", "#0e2606"],
    tip: ["#6b3e04", "#fff4c0", "#f0b42c", "#6b3e04"],
    aura: "#ffa62b",
    elec: "#ffe066",
    lens: "#ff2a3d",
  },
  star: {
    tube: ["#151d06", "#d8e6a0", "#86a03a", "#4a5e18", "#121a05"],
    bell: ["#151d06", "#a7bd62", "#4a5e18", "#0e1404"],
    war: ["#1a2408", "#cddc94", "#6f8a2c", "#3c4c14", "#141c06"],
    tip: ["#5a0805", "#ffb0a0", "#e62a1c", "#5a0805"],
    aura: "#a3d63a",
    elec: "#ffb347",
    lens: "#4dff7a",
  },
};

function star5(cx: number, cy: number, R: number, r: number) {
  return Array.from({ length: 10 }, (_, i) => {
    const a = -Math.PI / 2 + (Math.PI * i) / 5;
    const rad = i % 2 === 0 ? R : r;
    return `${(cx + Math.cos(a) * rad).toFixed(1)},${(cy + Math.sin(a) * rad).toFixed(1)}`;
  }).join(" ");
}

function vGrad(id: string, c: string[], stops: number[]) {
  return (
    <linearGradient id={id} x1="0" y1="0" x2="0" y2="1">
      {c.map((col, i) => (
        <stop key={i} offset={stops[i]} stopColor={col} />
      ))}
    </linearGradient>
  );
}

export default function Rpg({ variant }: { variant: Variant }) {
  const p = PAL[variant];
  const id = `rq-${variant}`;
  const u = (n: string) => `url(#${id}-${n})`;
  const volt = variant === "volt";

  // ring helper (gold band around a tube of radius r at x)
  const Ring = ({ x, r, w = 9, d = 0 }: { x: number; r: number; w?: number; d?: number }) => (
    <g>
      <rect x={x} y={160 - r - 3} width={w} height={(r + 3) * 2} rx={3} fill={u("gold")} stroke={OL} strokeWidth={1.4} />
      <rect x={x + w * 0.28} y={160 - r - 1} width={w * 0.22} height={(r + 1) * 2} fill="#fff8d8" opacity={0.75} />
      <rect x={x} y={160 - r - 3} width={w} height={(r + 3) * 2} rx={3} fill="#fff6c8" className="seq" style={{ animationDelay: `${d}s` }} />
    </g>
  );

  return (
    <svg viewBox="0 0 500 340" className="w-full h-full overflow-visible">
      <defs>
        {vGrad(`${id}-tube`, p.tube, [0, 0.2, 0.45, 0.8, 1])}
        {vGrad(`${id}-bell`, p.bell, [0, 0.25, 0.6, 1])}
        {vGrad(`${id}-war`, p.war, [0, 0.2, 0.48, 0.82, 1])}
        {vGrad(`${id}-tip`, p.tip, [0, 0.3, 0.6, 1])}
        {vGrad(`${id}-gold`, ["#5a3303", "#fff2b8", "#f2b430", "#9a5c08", "#3d2202"], [0, 0.22, 0.5, 0.82, 1])}
        {vGrad(`${id}-dark`, ["#1c1d24", "#8e92a3", "#3a3c47", "#121318", "#050506"], [0, 0.22, 0.5, 0.82, 1])}
        {vGrad(`${id}-black`, ["#2a2b33", "#5d606e", "#1a1b21", "#060607"], [0, 0.25, 0.6, 1])}
        <linearGradient id={`${id}-goldD`} x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#fff2b8" />
          <stop offset="0.45" stopColor="#e3a020" />
          <stop offset="1" stopColor="#5a3303" />
        </linearGradient>
        <radialGradient id={`${id}-halo`}>
          <stop offset="0" stopColor="#fffbe6" />
          <stop offset="0.35" stopColor={p.aura} stopOpacity="0.8" />
          <stop offset="1" stopColor={p.aura} stopOpacity="0" />
        </radialGradient>
        <radialGradient id={`${id}-smoke`}>
          <stop offset="0" stopColor="#ebe7f2" stopOpacity="0.85" />
          <stop offset="1" stopColor="#7d7890" stopOpacity="0" />
        </radialGradient>
        <radialGradient id={`${id}-hole`}>
          <stop offset="0" stopColor={volt ? "#ff8a1f" : "#ffb347"} stopOpacity="0.7" />
          <stop offset="0.6" stopColor="#1a0a02" />
          <stop offset="1" stopColor="#050505" />
        </radialGradient>
        <clipPath id={`${id}-warclip`}>
          <path d="M368,147 Q372,136 392,134 Q438,132 462,152 L462,168 Q438,188 392,186 Q372,184 368,173 Z" />
        </clipPath>
        <FlameDefs id={`${id}-f`} />
        <GlowFilter id={`${id}-glow`} std={2.6} />
        <BlurFilter id={`${id}-blur`} std={18} />
      </defs>

      <ellipse cx="250" cy="170" rx="210" ry="70" fill={p.aura} opacity="0.22" filter={u("blur")} transform="rotate(-38 250 170)" className="pulse" />

      <g transform="translate(6 18) rotate(-38 250 160)">
        <g className="recoil">
          {/* ========== CABLE (behind) ========== */}
          <path d="M112,176 C128,214 176,216 196,190" stroke={OL} strokeWidth="6" fill="none" strokeLinecap="round" />
          <path d="M112,176 C128,214 176,216 196,190" stroke="#3a3c47" strokeWidth="3" fill="none" strokeLinecap="round" />

          {/* ========== FRONT VERTICAL GRIP ========== */}
          <path d="M300,174 L322,174 L330,222 Q331,232 321,233 L311,234 Q302,234 301,224 Z" fill={u("black")} stroke={OL} strokeWidth="1.8" strokeLinejoin="round" />
          {[188, 198, 208, 218].map((y) => (
            <line key={y} x1={303 + (y - 188) * 0.02} y1={y} x2={325 + (y - 188) * 0.12} y2={y} stroke="#000" strokeWidth="2.4" />
          ))}
          <path d="M304,178 L308,226" stroke="#7d8191" strokeWidth="1.4" opacity="0.6" />
          <rect x="296" y="172" width="30" height="8" rx="2" fill={u("dark")} stroke={OL} strokeWidth="1.4" />

          {/* ========== PISTOL GRIP + TRIGGER ========== */}
          <path d="M196,176 L222,176 L216,226 Q214,238 202,237 L188,235 Q180,232 183,222 Z" fill={u("black")} stroke={OL} strokeWidth="1.8" strokeLinejoin="round" />
          {[194, 206, 218].map((y) => (
            <line key={y} x1={188} y1={y} x2={216} y2={y + 1} stroke="#000" strokeWidth="2.2" />
          ))}
          <path d="M200,182 L194,228" stroke="#7d8191" strokeWidth="1.3" opacity="0.6" />
          {/* trigger guard (gold) */}
          <path d="M222,180 Q254,180 254,200 Q252,212 222,212" fill="none" stroke={OL} strokeWidth="7.5" strokeLinecap="round" />
          <path d="M222,180 Q254,180 254,200 Q252,212 222,212" fill="none" stroke={u("goldD")} strokeWidth="4.5" strokeLinecap="round" />
          <path d="M228,182 Q238,192 232,204" stroke={OL} strokeWidth="5.5" fill="none" strokeLinecap="round" />
          <path d="M228,182 Q238,192 232,204" stroke={u("goldD")} strokeWidth="3" fill="none" strokeLinecap="round" />

          {/* gold side fins (volt) / ammo pouch (star) */}
          {volt ? (
            <>
              <path d="M162,176 L190,176 L176,204 L150,198 Z" fill={u("goldD")} stroke={OL} strokeWidth="1.6" strokeLinejoin="round" />
              <path d="M164,180 L184,180 L172,198" stroke="#fff2b8" strokeWidth="1.2" fill="none" />
              <path d="M262,176 L290,176 L284,196 L270,194 Z" fill={u("goldD")} stroke={OL} strokeWidth="1.6" strokeLinejoin="round" />
            </>
          ) : (
            <>
              <rect x="146" y="176" width="34" height="16" rx="3" fill={u("tube")} stroke={OL} strokeWidth="1.6" />
              <rect x="150" y="180" width="26" height="3" fill="#f5f3e6" opacity="0.6" />
            </>
          )}

          {/* ========== BELL / VENTURI ========== */}
          <path d="M108,146 C84,140 64,128 50,112 L50,208 C64,192 84,180 108,174 Z" fill={u("bell")} stroke={OL} strokeWidth="2" strokeLinejoin="round" />
          <path d="M104,149 C84,144 68,134 56,122" stroke="#ffffff" strokeWidth="1.6" fill="none" opacity="0.5" />
          {volt ? (
            <>
              <path d="M98,150 C82,146 70,138 60,128 L60,136 C70,144 82,150 98,154 Z" fill="#ff9a1f" stroke={OL} strokeWidth="0.8" />
              <path d="M98,170 C82,174 70,182 60,192 L60,184 C70,176 82,170 98,166 Z" fill="#ff9a1f" stroke={OL} strokeWidth="0.8" />
            </>
          ) : (
            <>
              <path d="M70,130 L82,136 L82,150 L70,146 Z" fill="#e8a020" stroke={OL} strokeWidth="0.8" />
              <path d="M70,190 L82,184 L82,170 L70,174 Z" fill="#e8a020" stroke={OL} strokeWidth="0.8" />
            </>
          )}
          {/* gold rim */}
          <ellipse cx="50" cy="160" rx="11" ry="50" fill={u("gold")} stroke={OL} strokeWidth="2" />
          <ellipse cx="48" cy="160" rx="7.5" ry="43" fill={u("hole")} />
          <ellipse cx="48" cy="160" rx="4" ry="26" fill={volt ? "#ff7a1a" : "#ffb347"} opacity="0.5" className="pulse" />
          <path d="M54,114 Q60,140 58,160" stroke="#fff8d8" strokeWidth="1.5" fill="none" opacity="0.8" />

          {/* ========== REAR TUBE (dark) ========== */}
          <rect x="104" y="145" width="56" height="30" rx="4" fill={u("dark")} stroke={OL} strokeWidth="1.8" />
          <rect x="108" y="149" width="48" height="3" rx="1.5" fill="#ffffff" opacity="0.5" />

          {/* ========== MAIN TUBE ========== */}
          <rect x="156" y="143" width="178" height="34" rx="5" fill={u("tube")} stroke={OL} strokeWidth="2" />
          <rect x="160" y="148" width="170" height="4" rx="2" fill="#ffffff" opacity="0.55" />
          <rect x="160" y="168" width="170" height="2" rx="1" fill="#000" opacity="0.25" />
          {!volt &&
            [124, 132, 140].map((x) => <rect key={x} x={x} y="146" width="3" height="28" fill="#000" opacity="0.4" />)}
          {/* star emblem */}
          {!volt && (
            <g>
              <circle cx="232" cy="160" r="14" fill="#2c3810" stroke={OL} strokeWidth="1.6" />
              <circle cx="232" cy="160" r="11.5" fill="none" stroke="#f5f3e6" strokeWidth="1.6" />
              <polygon points={star5(232, 160, 10, 4)} fill="#f5f3e6" stroke={OL} strokeWidth="0.6" />
              <polygon points={star5(232, 160, 10, 4)} fill="#ffffff" className="flash" filter={u("glow")} />
            </g>
          )}
          {volt && <rect x="196" y="157" width="96" height="3" rx="1.5" fill="#ff3d2e" filter={u("glow")} className="pulse" />}

          {/* gold rings */}
          <Ring x={100} r={15} d={0.3} />
          <Ring x={152} r={17} d={0.25} />
          <Ring x={176} r={17} w={7} d={0.2} />
          <Ring x={262} r={17} d={0.12} />
          <Ring x={326} r={17} d={0.05} />

          {/* ========== SIGHT / SCOPE ========== */}
          {volt ? (
            <g>
              <rect x="238" y="136" width="14" height="8" fill={OL} />
              <path d="M226,118 L282,116 Q290,116 290,124 L290,132 Q290,138 282,138 L226,138 Q220,138 220,130 L220,124 Q220,118 226,118 Z" fill={u("dark")} stroke={OL} strokeWidth="1.8" />
              <rect x="226" y="121" width="56" height="2.5" rx="1.2" fill="#fff" opacity="0.55" />
              <rect x="232" y="108" width="10" height="10" rx="2" fill={u("dark")} stroke={OL} strokeWidth="1.4" />
              <rect x="256" y="110" width="8" height="8" rx="2" fill={u("gold")} stroke={OL} strokeWidth="1.2" />
              <circle cx="291" cy="127" r="6" fill={OL} />
              <circle cx="291" cy="127" r="3.6" fill={p.lens} filter={u("glow")} className="pulse" />
              {/* laser */}
              <line x1="294" y1="127" x2="470" y2="112" stroke={p.lens} strokeWidth="3" opacity="0.35" filter={u("glow")} className="pulse" />
              <line x1="294" y1="127" x2="470" y2="112" stroke="#ff9a9a" strokeWidth="1" />
            </g>
          ) : (
            <g>
              <rect x="268" y="136" width="12" height="8" fill={OL} />
              <rect x="254" y="118" width="40" height="18" rx="9" fill={u("black")} stroke={OL} strokeWidth="1.8" />
              <rect x="258" y="121" width="32" height="2.5" rx="1.2" fill="#fff" opacity="0.45" />
              <path d="M292,116 L302,114 L302,140 L292,138 Z" fill={u("black")} stroke={OL} strokeWidth="1.6" />
              <ellipse cx="302" cy="127" rx="4.5" ry="12" fill={p.lens} stroke={OL} strokeWidth="1.4" filter={u("glow")} className="pulse" />
              <ellipse cx="301" cy="123" rx="1.4" ry="4" fill="#ffffff" />
              <path d="M246,120 L254,122 L254,132 L246,134 Z" fill={u("black")} stroke={OL} strokeWidth="1.4" />
              <rect x="200" y="132" width="20" height="11" rx="2" fill={u("black")} stroke={OL} strokeWidth="1.4" />
              <rect x="204" y="135" width="12" height="3" fill={p.lens} opacity="0.85" />
            </g>
          )}

          {/* ========== FRONT COLLAR & NECK ========== */}
          <rect x="334" y="146" width="22" height="28" rx="3" fill={u("dark")} stroke={OL} strokeWidth="1.8" />
          <rect x="338" y="149" width="14" height="2.5" fill="#fff" opacity="0.5" />
          <rect x="354" y="151" width="16" height="18" rx="2" fill={u("dark")} stroke={OL} strokeWidth="1.6" />

          {/* ========== WARHEAD ========== */}
          <g className="charge">
            <path d="M368,147 Q372,136 392,134 Q438,132 462,152 L462,168 Q438,188 392,186 Q372,184 368,173 Z" fill={u("war")} />
            <g clipPath={u("warclip")}>
              <rect x="374" y="128" width="9" height="64" fill={u("gold")} />
              <rect x="386" y="128" width="4" height="64" fill={u("gold")} />
              <rect x="444" y="128" width="8" height="64" fill={u("gold")} />
              <rect x="376.5" y="128" width="2" height="64" fill="#fff8d8" opacity="0.7" />
              <path d="M392,140 Q430,138 452,152" stroke="#ffffff" strokeWidth="3" fill="none" opacity="0.6" strokeLinecap="round" />
            </g>
            <path d="M368,147 Q372,136 392,134 Q438,132 462,152 L462,168 Q438,188 392,186 Q372,184 368,173 Z" fill="none" stroke={OL} strokeWidth="2" />
            {/* tip */}
            <path d="M460,151 L488,160 L460,169 Q457,160 460,151 Z" fill={u("tip")} stroke={OL} strokeWidth="1.8" strokeLinejoin="round" />
            <path d="M462,154 L480,159" stroke="#ffffff" strokeWidth="1.2" opacity="0.8" />
            <path d="M368,147 Q372,136 392,134 Q438,132 462,152 L462,168 Q438,188 392,186 Q372,184 368,173 Z" fill="#fffbe6" className="flash" />
          </g>
          {volt ? (
            <g className="idle-zap" filter={u("glow")}>
              <LiveBolt x1={394} y1={138} x2={444} y2={146} color={p.elec} n={6} amp={5} seed={3} width={0.9} />
              <LiveBolt x1={394} y1={182} x2={444} y2={172} color={p.elec} n={6} amp={5} seed={8} width={0.9} />
            </g>
          ) : (
            <circle cx="488" cy="160" r="4.5" fill="#ff5a4a" filter={u("glow")} className="pulse-scale" />
          )}
        </g>

        {/* ========== FIRING FX (no projectile — warhead stays) ========== */}
        <Flame id={`${id}-f`} x={44} y={160} rot={-90} w={60} h={120} className="fire-burst" />
        <circle cx="40" cy="160" r="46" fill={u("halo")} className="fx-quick" />
        {[
          [42, 146, -30, 0.05],
          [38, 174, 14, 0.12],
          [48, 136, -54, 0.2],
          [46, 184, 34, 0.28],
          [34, 160, -10, 0.36],
        ].map(([x, y, sy, d], i) => (
          <circle key={i} cx={x} cy={y} r="18" fill={u("smoke")} className="smoke-back" style={{ "--sy": `${sy}px`, animationDelay: `${d}s` } as CSSProperties} />
        ))}
        <circle cx="486" cy="160" r="56" fill={u("halo")} className="fx" />
        {[0, 0.12, 0.24].map((d) => (
          <circle key={d} cx="486" cy="160" r="20" fill="none" stroke={volt ? p.elec : "#ffd29a"} strokeWidth="3" className="shock" style={{ animationDelay: `${d}s` }} />
        ))}
        {volt && (
          <g className="fx" filter={u("glow")}>
            <LiveBolt x1={488} y1={160} x2={530} y2={128} color={p.elec} n={6} amp={9} seed={21} width={1.4} />
            <LiveBolt x1={488} y1={160} x2={536} y2={168} color={p.elec} n={6} amp={9} seed={27} width={1.4} />
            <LiveBolt x1={488} y1={160} x2={524} y2={200} color={p.elec} n={6} amp={9} seed={33} width={1.2} />
            <LiveBolt x1={104} y1={145} x2={334} y2={177} color={p.elec} n={18} amp={10} seed={41} width={1} />
            <LiveBolt x1={392} y1={134} x2={392} y2={186} color="#ffffff" n={5} amp={6} seed={47} width={0.9} />
          </g>
        )}
        <Sparks cx={486} cy={160} color={volt ? p.elec : "#ffb347"} count={14} spread={70} seed={volt ? 4 : 9} />
        <Sparks cx={44} cy={160} color="#ff8a1f" count={14} spread={80} seed={13} angleFrom={Math.PI * 0.6} angleTo={Math.PI * 1.4} />
      </g>
    </svg>
  );
}

export function RpgVolt() {
  return <Rpg variant="volt" />;
}
export function RpgStar() {
  return <Rpg variant="star" />;
}
