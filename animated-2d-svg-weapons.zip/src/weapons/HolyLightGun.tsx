import type { CSSProperties } from "react";
import { BlurFilter, GlowFilter, Sparks } from "./shared";

const OL = "#4a3208";
const FS = "#7a6440"; // soft feather outline

// leading edge of wing (quadratic): root(0,0) -> ctrl -> tip
const C1 = [0, -128];
const TP = [-100, -170];
function arm(t: number) {
  const u = 1 - t;
  return [2 * u * t * C1[0] + t * t * TP[0], 2 * u * t * C1[1] + t * t * TP[1]];
}
/** rounded, soft feather pointing along +x */
function feather(L: number, W: number) {
  return `M0,${-W * 0.42} C${L * 0.35},${-W * 0.6} ${L * 0.82},${-W * 0.52} ${L},${-W * 0.08} C${L * 1.02},${W * 0.3} ${L * 0.7},${W * 0.56} ${L * 0.35},${W * 0.52} C${L * 0.2},${W * 0.5} ${L * 0.08},${W * 0.46} 0,${W * 0.42} Z`;
}

type F = { x: number; y: number; ang: number; L: number; W: number };

function row(n: number, t0: number, t1: number, a0: number, a1: number, l0: number, l1: number, w: number): F[] {
  return Array.from({ length: n }, (_, i) => {
    const k = i / (n - 1);
    const [x, y] = arm(t0 + (t1 - t0) * k);
    return { x, y, ang: a0 + (a1 - a0) * k, L: l0 + (l1 - l0) * Math.pow(k, 1.1), W: w };
  });
}

function Wing({ g }: { g: string }) {
  const prim = row(14, 0.26, 1, 140, 194, 74, 154, 40);
  const cov = row(13, 0.1, 0.97, 128, 188, 48, 92, 38);
  const fl = row(12, 0.02, 0.92, 112, 180, 28, 50, 34);
  const draw = (arr: F[], fill: string, key: string, vein: boolean, flash: boolean) =>
    [...arr].reverse().map((f, k) => (
      <g key={`${key}${k}`} transform={`translate(${f.x.toFixed(1)} ${f.y.toFixed(1)}) rotate(${f.ang.toFixed(1)})`}>
        <path d={feather(f.L, f.W)} fill={fill} stroke={FS} strokeWidth="1.2" strokeLinejoin="round" />
        {vein && <path d={`M3,-1 C${f.L * 0.4},-2 ${f.L * 0.7},-2 ${f.L * 0.9},${-f.W * 0.08}`} stroke="#d4b46a" strokeWidth="1" fill="none" opacity="0.75" />}
        <path d={`M${f.L * 0.12},${-f.W * 0.28} C${f.L * 0.4},${-f.W * 0.4} ${f.L * 0.7},${-f.W * 0.36} ${f.L * 0.86},${-f.W * 0.16}`} stroke="#ffffff" strokeWidth="2.2" fill="none" opacity="0.8" strokeLinecap="round" />
        {flash && <path d={feather(f.L, f.W)} fill="#fffbe6" className="flash" style={{ animationDelay: `${k * 0.02}s` }} />}
      </g>
    ));
  return (
    <g>
      {draw(prim, `url(#${g}-p)`, "p", true, true)}
      {draw(cov, `url(#${g}-c)`, "c", true, false)}
      {draw(fl, `url(#${g}-f)`, "f", false, false)}
      {/* leading edge (bone) */}
      <path d={`M0,0 Q${C1[0]},${C1[1]} ${TP[0]},${TP[1]}`} stroke={FS} strokeWidth="15" fill="none" strokeLinecap="round" />
      <path d={`M0,0 Q${C1[0]},${C1[1]} ${TP[0]},${TP[1]}`} stroke={`url(#${g}-a)`} strokeWidth="11.5" fill="none" strokeLinecap="round" />
      <path d={`M3,-6 Q${C1[0] + 4},${C1[1] - 3} ${TP[0] + 6},${TP[1] - 4}`} stroke="#ffffff" strokeWidth="2.4" fill="none" strokeLinecap="round" />
      <path d={`M-2,4 Q${C1[0] - 2},${C1[1] + 8} ${TP[0] + 4},${TP[1] + 5}`} stroke="#e2c46e" strokeWidth="1.4" fill="none" strokeLinecap="round" opacity="0.8" />
    </g>
  );
}

function Diamond({ x, y, s = 1 }: { x: number; y: number; s?: number }) {
  return (
    <g>
      <line x1={x} y1={y - 12 * s} x2={x} y2={y - 6 * s} stroke="#c9a24a" strokeWidth="1.2" />
      <circle cx={x} cy={y - 6 * s} r={2.2 * s} fill="url(#hl-gold)" stroke={OL} strokeWidth="0.6" />
      <polygon points={`${x},${y - 4 * s} ${x + 6.5 * s},${y + 2 * s} ${x},${y + 17 * s} ${x - 6.5 * s},${y + 2 * s}`} fill="url(#hl-crys)" stroke={OL} strokeWidth="0.9" strokeLinejoin="round" />
      <polygon points={`${x},${y - 4 * s} ${x + 6.5 * s},${y + 2 * s} ${x},${y + 4 * s}`} fill="#ffffff" opacity="0.85" />
    </g>
  );
}

function Star4({ x, y, r, d }: { x: number; y: number; r: number; d: number }) {
  return <path d={`M${x},${y - r} L${x + r * 0.22},${y - r * 0.22} L${x + r},${y} L${x + r * 0.22},${y + r * 0.22} L${x},${y + r} L${x - r * 0.22},${y + r * 0.22} L${x - r},${y} L${x - r * 0.22},${y - r * 0.22} Z`} fill="#fff6c8" className="sparkle" style={{ animationDelay: `${d}s` }} />;
}

/** embossed gold scroll */
function Scroll({ d, w = 2.4 }: { d: string; w?: number }) {
  return (
    <g fill="none" strokeLinecap="round" strokeLinejoin="round">
      <path d={d} stroke="#7a4a06" strokeWidth={w + 1.2} transform="translate(0.6 0.9)" opacity="0.55" />
      <path d={d} stroke="#dba735" strokeWidth={w} />
      <path d={d} stroke="#fff4c4" strokeWidth={w * 0.35} transform="translate(-0.4 -0.6)" />
    </g>
  );
}

export default function HolyLightGun() {
  const MZ: [number, number] = [414, 170];
  const rays = Array.from({ length: 14 }, (_, i) => i * (360 / 14));
  const feathers = [
    [90, 40, 30, 120, 0],
    [40, 110, -20, 110, -1.5],
    [190, 0, 40, 140, -3],
    [20, 190, -30, 100, -2.2],
  ];

  return (
    <svg viewBox="-60 -150 560 525" className="w-full h-full overflow-visible">
      <defs>
        <linearGradient id="hl-pearl" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#cdbf9e" />
          <stop offset="0.12" stopColor="#ffffff" />
          <stop offset="0.42" stopColor="#fbf6ea" />
          <stop offset="0.78" stopColor="#e3d6b8" />
          <stop offset="1" stopColor="#ae9a72" />
        </linearGradient>
        <linearGradient id="hl-gold" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#7a4a06" />
          <stop offset="0.22" stopColor="#fff2b8" />
          <stop offset="0.52" stopColor="#e9b030" />
          <stop offset="1" stopColor="#6b3e04" />
        </linearGradient>
        <linearGradient id="hl-goldD" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#fff2b8" />
          <stop offset="0.5" stopColor="#d99a1e" />
          <stop offset="1" stopColor="#6b3e04" />
        </linearGradient>
        <linearGradient id="hl-crys" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#ffffff" />
          <stop offset="0.5" stopColor="#e6dcff" />
          <stop offset="1" stopColor="#a99ad6" />
        </linearGradient>
        {/* front wing: white with warm golden shade */}
        <linearGradient id="wf-p" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#ffffff" />
          <stop offset="0.55" stopColor="#fbf7ee" />
          <stop offset="1" stopColor="#e6d7b4" />
        </linearGradient>
        <linearGradient id="wf-c" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#ffffff" />
          <stop offset="0.6" stopColor="#faf5ea" />
          <stop offset="1" stopColor="#e4d4ae" />
        </linearGradient>
        <linearGradient id="wf-f" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#ffffff" />
          <stop offset="1" stopColor="#ece0c4" />
        </linearGradient>
        <linearGradient id="wf-a" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#ffffff" />
          <stop offset="1" stopColor="#efe5cf" />
        </linearGradient>
        {/* back wing: shaded */}
        <linearGradient id="wb-p" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#efe8da" />
          <stop offset="0.55" stopColor="#ddd0b4" />
          <stop offset="1" stopColor="#b9a47a" />
        </linearGradient>
        <linearGradient id="wb-c" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#f2ecdf" />
          <stop offset="1" stopColor="#cdbb94" />
        </linearGradient>
        <linearGradient id="wb-f" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#f4efe4" />
          <stop offset="1" stopColor="#d6c6a2" />
        </linearGradient>
        <linearGradient id="wb-a" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#f2ecdf" />
          <stop offset="1" stopColor="#d2c29e" />
        </linearGradient>
        <pattern id="hl-fil" width="22" height="22" patternUnits="userSpaceOnUse">
          <path d="M2,11 C2,4 11,3 12,9 C13,13 8,14 8,11" stroke="#d4a93a" strokeWidth="1" fill="none" />
          <path d="M12,9 C16,16 22,16 22,11" stroke="#d4a93a" strokeWidth="1" fill="none" />
          <circle cx="18" cy="4" r="0.9" fill="#d4a93a" />
        </pattern>
        <radialGradient id="hl-halo">
          <stop offset="0" stopColor="#ffffff" />
          <stop offset="0.3" stopColor="#fff2b0" stopOpacity="0.9" />
          <stop offset="1" stopColor="#ffd24a" stopOpacity="0" />
        </radialGradient>
        <linearGradient id="hl-ray" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0" stopColor="#ffffff" />
          <stop offset="0.5" stopColor="#fff2b0" stopOpacity="0.8" />
          <stop offset="1" stopColor="#ffd24a" stopOpacity="0" />
        </linearGradient>
        <GlowFilter id="hl-glow" std={3} />
        <BlurFilter id="hl-blur" std={24} />
      </defs>

      <ellipse cx="220" cy="150" rx="240" ry="130" fill="#ffe8a8" opacity="0.22" filter="url(#hl-blur)" className="pulse" />

      <g transform="rotate(-16 280 200)">
        <g className="recoil">
          {/* ===== WINGS ===== */}
          <g transform="translate(270 148) rotate(30) scale(0.86)">
            <g className="flap back">
              <Wing g="wb" />
            </g>
          </g>
          <g transform="translate(228 158) rotate(14) scale(1.06)">
            <g className="flap">
              <Wing g="wf" />
            </g>
          </g>

          {/* ===== PENDANT ===== */}
          <g transform="translate(192 296)">
            <g className="swing">
              <path d="M0,0 L0,12" stroke="#c9a24a" strokeWidth="1.8" />
              <path d="M-16,12 Q0,22 16,12" stroke="#c9a24a" strokeWidth="1.8" fill="none" />
              <circle cx="0" cy="12" r="4" fill="url(#hl-gold)" stroke={OL} strokeWidth="0.8" />
              <Diamond x={0} y={30} s={1.35} />
              <Diamond x={-15} y={25} s={0.85} />
              <Diamond x={15} y={25} s={0.85} />
            </g>
          </g>

          {/* ===== GRIP ===== */}
          <path d="M156,192 L226,194 Q214,230 220,262 Q224,286 210,294 L170,294 Q152,290 156,272 Q166,234 156,192 Z" fill="url(#hl-pearl)" stroke={OL} strokeWidth="2.2" strokeLinejoin="round" />
          <path d="M156,192 L226,194 Q214,230 220,262 Q224,286 210,294 L170,294 Q152,290 156,272 Q166,234 156,192 Z" fill="url(#hl-fil)" opacity="0.55" />
          <path d="M168,204 L214,206 Q206,234 210,262 Q212,278 204,284 L176,284 Q166,280 168,266 Q174,236 168,204 Z" fill="none" stroke="#d4a93a" strokeWidth="2.4" />
          <Scroll d="M178,224 C188,212 206,220 200,236 C196,244 182,240 186,232" />
          <Scroll d="M200,236 C206,248 196,258 186,254" w={2} />
          <Scroll d="M180,266 C190,256 206,262 200,276" />
          <path d="M162,198 Q166,240 162,278" stroke="#ffffff" strokeWidth="2.6" fill="none" opacity="0.85" />
          <path d="M162,288 L220,288 Q222,300 208,302 L174,302 Q158,300 162,288 Z" fill="url(#hl-gold)" stroke={OL} strokeWidth="1.8" />

          {/* trigger guard */}
          <path d="M224,200 Q270,200 272,226 Q270,246 228,244" fill="none" stroke={OL} strokeWidth="9" strokeLinecap="round" />
          <path d="M224,200 Q270,200 272,226 Q270,246 228,244" fill="none" stroke="url(#hl-goldD)" strokeWidth="5.5" strokeLinecap="round" />
          <path d="M262,206 C272,212 276,226 266,232" stroke="#fff2b8" strokeWidth="1.3" fill="none" />
          <path d="M234,202 Q246,216 238,232" stroke={OL} strokeWidth="7" fill="none" strokeLinecap="round" />
          <path d="M234,202 Q246,216 238,232" stroke="url(#hl-goldD)" strokeWidth="3.8" fill="none" strokeLinecap="round" />

          {/* ===== FRAME ===== */}
          <path d="M146,186 L344,182 L338,206 L184,210 Z" fill="url(#hl-pearl)" stroke={OL} strokeWidth="2" strokeLinejoin="round" />
          <path d="M190,200 L330,196" stroke="#d4a93a" strokeWidth="2" />
          <Scroll d="M290,192 C298,186 308,190 306,198" w={1.6} />

          {/* ===== BARREL ===== */}
          <rect x="206" y="142" width="200" height="12" rx="4.5" fill="url(#hl-pearl)" stroke={OL} strokeWidth="1.8" />
          <path d="M210,145 L402,145" stroke="#ffffff" strokeWidth="1.6" opacity="0.9" />
          <path d="M144,156 L400,150 Q410,150 410,160 L410,184 Q410,192 400,192 L144,196 Q136,196 136,186 L136,164 Q136,156 144,156 Z" fill="url(#hl-pearl)" stroke={OL} strokeWidth="2.2" strokeLinejoin="round" />
          <path d="M144,156 L400,150 Q410,150 410,160 L410,184 Q410,192 400,192 L144,196 Q136,196 136,186 L136,164 Q136,156 144,156 Z" fill="url(#hl-fil)" opacity="0.5" />
          {/* gold trim edges */}
          <path d="M142,159.5 L400,153.5" stroke="#e2b23e" strokeWidth="2.2" strokeLinecap="round" />
          <path d="M144,162 L398,156" stroke="#ffffff" strokeWidth="2" strokeLinecap="round" />
          <path d="M144,191 L400,187" stroke="#d4a93a" strokeWidth="2.4" />
          <Scroll d="M170,178 C176,164 196,164 200,176 C204,186 188,190 186,182" />
          <Scroll d="M200,176 C208,164 228,166 232,178 C234,186 222,188 220,180" />
          <Scroll d="M282,172 C290,160 310,160 312,172 C314,182 300,186 298,178" />
          <Scroll d="M312,172 C322,162 340,166 344,176 C346,184 334,186 332,178" />
          <g stroke="#fff8d8" strokeWidth="2.6" fill="none" strokeLinecap="round" className="flash">
            <path d="M170,178 C176,164 196,164 200,176 C204,186 188,190 186,182" />
            <path d="M282,172 C290,160 310,160 312,172 C314,182 300,186 298,178" />
          </g>
          {/* hammer */}
          <path d="M136,164 L120,156 Q111,158 116,168 L136,180 Z" fill="url(#hl-gold)" stroke={OL} strokeWidth="1.8" />
          {/* gold bands */}
          {[246, 358, 390].map((x, i) => (
            <g key={x}>
              <path d={`M${x},146 L${x + 10},146 Q${x + 14},170 ${x + 10},194 L${x},194 Q${x + 4},170 ${x},146 Z`} fill="url(#hl-gold)" stroke={OL} strokeWidth="1.5" />
              <path d={`M${x + 3},149 Q${x + 7},170 ${x + 3},191`} stroke="#fff6cc" strokeWidth="1.6" fill="none" opacity="0.8" />
              <path d={`M${x},146 L${x + 10},146 Q${x + 14},170 ${x + 10},194 L${x},194 Q${x + 4},170 ${x},146 Z`} fill="#fffbe6" className="seq" style={{ animationDelay: `${0.25 - i * 0.08}s` }} />
            </g>
          ))}
          <circle cx="270" cy="174" r="6" fill="url(#hl-gold)" stroke={OL} strokeWidth="1.2" />
          <circle cx="270" cy="174" r="4" fill="url(#hl-crys)" stroke={OL} strokeWidth="0.8" />
          {/* muzzle */}
          <ellipse cx={MZ[0]} cy={MZ[1]} rx="7.5" ry="22" fill="url(#hl-gold)" stroke={OL} strokeWidth="2" />
          <ellipse cx={MZ[0] + 1} cy={MZ[1]} rx="4.2" ry="13" fill="#fffbe6" filter="url(#hl-glow)" className="pulse" />
        </g>

        {/* ===== HALO ===== */}
        <g className="halo-float">
          <ellipse cx="378" cy="70" rx="76" ry="30" fill="url(#hl-halo)" opacity="0.45" className="pulse" />
          <ellipse cx="378" cy="70" rx="56" ry="15" fill="none" stroke="#f2c94c" strokeWidth="8" filter="url(#hl-glow)" />
          <ellipse cx="378" cy="70" rx="56" ry="15" fill="none" stroke={OL} strokeWidth="1" opacity="0.35" />
          <ellipse cx="378" cy="70" rx="56" ry="15" pathLength={100} fill="none" stroke="#fffbe6" strokeWidth="2.6" className="halo-spin" />
          <ellipse cx="378" cy="70" rx="56" ry="15" fill="none" stroke="#ffffff" strokeWidth="8" className="flash" filter="url(#hl-glow)" />
        </g>

        {/* ===== FIRING FX: holy light (no projectile) ===== */}
        <g transform={`translate(${MZ[0]} ${MZ[1]})`}>
          <g className="rays-burst">
            {rays.map((a, i) => (
              <polygon key={a} points={`0,-3 ${i % 2 ? 72 : 112},0 0,3`} fill="url(#hl-ray)" transform={`rotate(${a})`} />
            ))}
          </g>
        </g>
        <circle cx={MZ[0]} cy={MZ[1]} r="72" fill="url(#hl-halo)" className="fx" />
        <circle cx={MZ[0]} cy={MZ[1]} r="16" fill="#ffffff" className="fx-quick" filter="url(#hl-glow)" />
        {[0, 0.14, 0.28].map((d) => (
          <circle key={d} cx={MZ[0]} cy={MZ[1]} r="22" fill="none" stroke="#ffe08a" strokeWidth="3" className="shock" style={{ animationDelay: `${d}s` }} />
        ))}
        <ellipse cx="378" cy="70" rx="56" ry="15" fill="none" stroke="#fff2b0" strokeWidth="3" className="shock" />
        <Sparks cx={MZ[0]} cy={MZ[1]} color="#ffe08a" count={18} spread={90} seed={61} />
        <Sparks cx={90} cy={70} color="#ffffff" count={14} spread={80} seed={67} />
      </g>

      {feathers.map(([x, y, dx, dy, d], i) => (
        <path key={i} d={`M${x},${y} c4,-6 12,-6 16,0 c-4,4 -12,4 -16,0 z`} fill="#ffffff" stroke="#c9b48a" strokeWidth="0.6" className="feather" style={{ "--dx": `${dx}px`, "--dy": `${dy}px`, animationDelay: `${d}s` } as CSSProperties} />
      ))}
      <Star4 x={10} y={20} r={6} d={0} />
      <Star4 x={240} y={-20} r={5} d={0.8} />
      <Star4 x={450} y={130} r={6} d={1.6} />
      <Star4 x={0} y={200} r={4} d={2.1} />
      <Star4 x={320} y={280} r={5} d={1.2} />
    </svg>
  );
}
