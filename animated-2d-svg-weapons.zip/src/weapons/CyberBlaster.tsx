import { Bolt, BlurFilter, GlowFilter, LiveBolt, Sparks } from "./shared";

const OL = "#03050b";
const CY = "#2ee6ff";

export default function CyberBlaster() {
  // diamond core
  const cx = 150;
  const cy = 136;
  const R = 22;
  const T = [cx, cy - R];
  const Rt = [cx + R, cy];
  const B = [cx, cy + R];
  const L = [cx - R, cy];
  const iT = [cx, cy - R * 0.45];
  const iR = [cx + R * 0.45, cy];
  const iB = [cx, cy + R * 0.45];
  const iL = [cx - R * 0.45, cy];
  const p = (pts: number[][]) => pts.map((q) => q.join(",")).join(" ");
  const hex = (r: number) =>
    Array.from({ length: 6 }, (_, i) => {
      const a = (Math.PI / 3) * i;
      return `${(cx + Math.cos(a) * r).toFixed(1)},${(cy + Math.sin(a) * r).toFixed(1)}`;
    }).join(" ");

  return (
    <svg viewBox="20 40 450 250" className="w-full h-full overflow-visible">
      <defs>
        <linearGradient id="cp-body" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#1a2033" />
          <stop offset="0.1" stopColor="#8a97b8" />
          <stop offset="0.22" stopColor="#3a445e" />
          <stop offset="0.55" stopColor="#171c2a" />
          <stop offset="0.85" stopColor="#0a0d16" />
          <stop offset="1" stopColor="#222a40" />
        </linearGradient>
        <linearGradient id="cp-plate" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#5d6a8c" />
          <stop offset="0.3" stopColor="#2a3248" />
          <stop offset="1" stopColor="#0c0f18" />
        </linearGradient>
        <linearGradient id="cp-chrome" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#4a5468" />
          <stop offset="0.25" stopColor="#ffffff" />
          <stop offset="0.5" stopColor="#a9b6cc" />
          <stop offset="0.8" stopColor="#3c4558" />
          <stop offset="1" stopColor="#1a1f2b" />
        </linearGradient>
        <linearGradient id="cp-chromeH" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0" stopColor="#2a3142" />
          <stop offset="0.45" stopColor="#ffffff" />
          <stop offset="1" stopColor="#3c4558" />
        </linearGradient>
        <linearGradient id="cp-grip" x1="0" y1="0" x2="1" y2="0.25">
          <stop offset="0" stopColor="#0a3a9a" />
          <stop offset="0.3" stopColor="#4aa8ff" />
          <stop offset="0.5" stopColor="#1e6fe0" />
          <stop offset="1" stopColor="#061f5a" />
        </linearGradient>
        <linearGradient id="cp-plasma" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#d6fbff" />
          <stop offset="0.35" stopColor="#3fe6ff" />
          <stop offset="0.75" stopColor="#0a8ad6" />
          <stop offset="1" stopColor="#043a7a" />
        </linearGradient>
        <linearGradient id="cp-holo" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor={CY} stopOpacity="0.5" />
          <stop offset="1" stopColor={CY} stopOpacity="0.05" />
        </linearGradient>
        <radialGradient id="cp-halo">
          <stop offset="0" stopColor="#f0ffff" />
          <stop offset="0.3" stopColor="#38e8ff" stopOpacity="0.85" />
          <stop offset="1" stopColor="#0091ff" stopOpacity="0" />
        </radialGradient>
        <radialGradient id="cp-pink">
          <stop offset="0" stopColor="#fff0fa" />
          <stop offset="0.35" stopColor="#ff6ec7" stopOpacity="0.7" />
          <stop offset="1" stopColor="#ff2ea6" stopOpacity="0" />
        </radialGradient>
        <pattern id="cp-carbon" width="6" height="6" patternUnits="userSpaceOnUse" patternTransform="rotate(45)">
          <rect width="3" height="3" fill="#ffffff" opacity="0.05" />
          <rect x="3" y="3" width="3" height="3" fill="#ffffff" opacity="0.05" />
        </pattern>
        <GlowFilter id="cp-glow" std={2.6} />
        <BlurFilter id="cp-blur" std={20} />
      </defs>

      <ellipse cx="250" cy="160" rx="200" ry="85" fill="#1ec8ff" opacity="0.22" filter="url(#cp-blur)" className="pulse" />

      <g transform="rotate(-8 240 160)">
        <g className="recoil">
          {/* ========== GRIP ========== */}
          <path d="M120,174 L176,176 Q168,194 172,212 Q180,240 170,262 Q162,276 140,274 L114,272 Q100,268 104,250 Q114,218 108,196 Q106,182 120,174 Z" fill="url(#cp-grip)" stroke={OL} strokeWidth="2" strokeLinejoin="round" />
          {/* back panel */}
          <path d="M112,192 Q118,220 110,250 Q108,262 120,264 L130,264 Q122,226 128,192 Z" fill="#06205a" opacity="0.8" />
          {/* finger grooves */}
          {[200, 218, 236].map((y) => (
            <path key={y} d={`M172,${y} Q160,${y + 8} 172,${y + 16}`} stroke={OL} strokeWidth="2" fill="#0a3a9a" />
          ))}
          <path d="M134,184 Q130,218 136,252" stroke="#bfe3ff" strokeWidth="2" fill="none" opacity="0.7" strokeLinecap="round" />
          <path d="M142,186 Q140,220 146,258" stroke={CY} strokeWidth="1.6" fill="none" filter="url(#cp-glow)" className="pulse" />
          <path d="M108,264 L168,266 Q166,280 150,282 L114,280 Q102,276 108,264 Z" fill="url(#cp-plate)" stroke={OL} strokeWidth="1.6" />

          {/* trigger guard + trigger */}
          <path d="M176,180 Q218,180 220,204 Q218,222 182,220" fill="none" stroke={OL} strokeWidth="8" strokeLinecap="round" />
          <path d="M176,180 Q218,180 220,204 Q218,222 182,220" fill="none" stroke="url(#cp-plate)" strokeWidth="5" strokeLinecap="round" />
          <path d="M184,184 Q196,196 188,210" stroke={OL} strokeWidth="6.5" fill="none" strokeLinecap="round" />
          <path d="M184,184 Q196,196 188,210" stroke={CY} strokeWidth="3.5" fill="none" strokeLinecap="round" filter="url(#cp-glow)" />

          {/* ========== HOLO DISPLAY (floating, rear top) ========== */}
          <g opacity="0.9">
            <path d="M92,94 L134,86 L134,58 L92,66 Z" fill="url(#cp-holo)" stroke={CY} strokeWidth="1" />
            {[14, 8, 18, 11].map((hgt, i) => {
              const x = 98 + i * 8;
              const yb = 91 - ((x - 92) * 8) / 42;
              return <rect key={i} x={x} y={yb - hgt} width="5" height={hgt} fill={CY} opacity="0.8" />;
            })}
            <rect x="94" y="64" width="38" height="1.5" fill="#e6fdff" className="scan" />
            <path d="M104,96 L112,104 L120,94" stroke={CY} strokeWidth="1" fill="none" opacity="0.6" />
          </g>

          {/* ========== TOP RAIL ========== */}
          <path d="M126,104 L136,92 L266,90 L278,102 Z" fill="url(#cp-plate)" stroke={OL} strokeWidth="1.8" strokeLinejoin="round" />
          {[146, 162, 178, 194, 210, 226, 242, 258].map((x, i) => (
            <rect key={x} x={x} y="95" width="9" height="4" rx="1.5" fill={CY} filter="url(#cp-glow)" className="pulse" style={{ animationDelay: `${i * 0.12}s` }} />
          ))}

          {/* ========== MAIN BODY ========== */}
          <path d="M66,110 L104,100 L282,100 L304,114 L304,160 L286,174 L178,178 L120,176 L66,166 Q52,138 66,110 Z" fill="url(#cp-body)" stroke={OL} strokeWidth="2" strokeLinejoin="round" />
          <path d="M66,110 L104,100 L282,100 L304,114 L304,160 L286,174 L178,178 L120,176 L66,166 Q52,138 66,110 Z" fill="url(#cp-carbon)" />
          <path d="M70,113 L106,104 L280,104 L298,115" stroke="#d6e2ff" strokeWidth="1.6" fill="none" opacity="0.7" strokeLinecap="round" />

          {/* rear cap */}
          <path d="M48,116 L74,106 L74,170 L48,160 Q40,138 48,116 Z" fill="url(#cp-plate)" stroke={OL} strokeWidth="1.8" strokeLinejoin="round" />
          <path d="M52,122 L70,115 M52,154 L70,160" stroke={CY} strokeWidth="2.2" strokeLinecap="round" filter="url(#cp-glow)" className="pulse" />

          {/* neon inlays */}
          <g filter="url(#cp-glow)">
            <path d="M84,118 L120,112 M184,112 L238,112 L248,120 L298,120" stroke={CY} strokeWidth="2.4" fill="none" strokeLinecap="round" className="pulse" />
            <path d="M84,160 L118,166 M182,166 L276,166 L298,154" stroke={CY} strokeWidth="2.4" fill="none" strokeLinecap="round" className="pulse" style={{ animationDelay: "0.6s" }} />
          </g>
          <g className="flash" filter="url(#cp-glow)">
            <path d="M84,118 L120,112 M184,112 L238,112 L248,120 L298,120" stroke="#ffffff" strokeWidth="3" fill="none" strokeLinecap="round" />
            <path d="M84,160 L118,166 M182,166 L276,166 L298,154" stroke="#ffffff" strokeWidth="3" fill="none" strokeLinecap="round" />
          </g>

          {/* ========== PLASMA CHAMBER ========== */}
          <rect x="190" y="124" width="104" height="28" rx="14" fill="#020812" stroke={OL} strokeWidth="2" />
          <rect x="195" y="129" width="94" height="18" rx="9" fill="url(#cp-plasma)" filter="url(#cp-glow)" className="pulse" />
          {[0, 0.6, 1.2].map((d, i) => (
            <circle key={d} cx="200" cy={134 + i * 4} r="1.8" fill="#ffffff" className="bubble" style={{ animationDelay: `${d}s` }} />
          ))}
          <g filter="url(#cp-glow)">
            <LiveBolt x1={198} y1={138} x2={286} y2={138} color="#e6fdff" n={10} amp={4} seed={5} width={0.8} />
          </g>
          <rect x="199" y="130" width="86" height="4" rx="2" fill="#ffffff" opacity="0.55" />
          <rect x="195" y="129" width="94" height="18" rx="9" fill="#ffffff" className="flash" />
          {[218, 242, 266].map((x) => (
            <rect key={x} x={x} y="121" width="5" height="34" rx="1.5" fill="url(#cp-chromeH)" stroke={OL} strokeWidth="1" />
          ))}

          {/* ========== DIAMOND CORE ========== */}
          <polygon points={hex(34)} fill="url(#cp-chrome)" stroke={OL} strokeWidth="2" strokeLinejoin="round" />
          <polygon points={hex(28)} fill="#050a14" stroke={OL} strokeWidth="1.2" />
          <polygon points={hex(28)} fill="none" stroke={CY} strokeWidth="1.4" filter="url(#cp-glow)" className="pulse" />
          <g className="charge">
            <circle cx={cx} cy={cy} r="30" fill="url(#cp-halo)" opacity="0.55" className="pulse" />
            <polygon points={p([T, Rt, iR, iT])} fill="#e9fdff" />
            <polygon points={p([Rt, B, iB, iR])} fill="#4fd6ff" />
            <polygon points={p([B, L, iL, iB])} fill="#1678c9" />
            <polygon points={p([L, T, iT, iL])} fill="#9df0ff" />
            <polygon points={p([iT, iR, iB, iL])} fill="#c9f8ff" />
            <polygon points={p([iT, iR, [cx, cy]])} fill="#ffffff" />
            <polygon points={p([T, Rt, B, L])} fill="none" stroke={OL} strokeWidth="1.6" strokeLinejoin="round" />
            <path d={`M${T} L${iT} M${Rt} L${iR} M${B} L${iB} M${L} L${iL}`} stroke="#ffffff" strokeWidth="0.8" opacity="0.7" />
            <polygon points={p([T, Rt, B, L])} fill="#ffffff" className="flash" />
          </g>
          <g transform={`translate(${cx - 10} ${cy - 12})`}>
            <path d="M0,-6 L1.3,-1.3 L6,0 L1.3,1.3 L0,6 L-1.3,1.3 L-6,0 L-1.3,-1.3 Z" fill="#ffffff" className="glint" />
          </g>

          {/* ========== BARREL with cooling fins ========== */}
          <rect x="302" y="116" width="62" height="42" rx="5" fill="url(#cp-body)" stroke={OL} strokeWidth="2" />
          {[310, 326, 342].map((x, i) => (
            <g key={x}>
              <rect x={x} y="108" width="10" height="58" rx="3" fill="url(#cp-plate)" stroke={OL} strokeWidth="1.6" />
              <rect x={x + 3} y="112" width="4" height="50" rx="2" fill={CY} filter="url(#cp-glow)" className="pulse" style={{ animationDelay: `${i * 0.25}s` }} />
              <rect x={x} y="108" width="10" height="58" rx="3" fill="#ffffff" className="seq" style={{ animationDelay: `${i * 0.07}s` }} />
            </g>
          ))}
          {/* muzzle cone */}
          <path d="M362,118 L392,126 L392,148 L362,156 Z" fill="url(#cp-chrome)" stroke={OL} strokeWidth="2" strokeLinejoin="round" />
          <path d="M364,122 L390,129" stroke="#ffffff" strokeWidth="1.4" opacity="0.8" />
          <rect x="390" y="124" width="8" height="26" rx="3" fill="url(#cp-plate)" stroke={OL} strokeWidth="1.6" />
          <ellipse cx="398" cy="137" rx="3.5" ry="10" fill={CY} filter="url(#cp-glow)" className="pulse" />

          {/* ========== HOLO RINGS (3D) ========== */}
          <circle cx="430" cy="137" r="30" fill="url(#cp-pink)" opacity="0.5" className="pulse" />
          {[412, 428, 444].map((x, i) => {
            const ry = 24 - i * 2.5;
            return (
              <g key={x} className="ring-out" style={{ animationDelay: `${i * 0.06}s` }}>
                {/* back half (dim) */}
                <path d={`M${x},${137 - ry} A7,${ry} 0 0 0 ${x},${137 + ry}`} stroke="#ff6ec7" strokeWidth="2.5" fill="none" opacity="0.4" />
                {/* front half glow */}
                <path d={`M${x},${137 - ry} A7,${ry} 0 0 1 ${x},${137 + ry}`} stroke="#ff4fbf" strokeWidth="5" fill="none" filter="url(#cp-glow)" />
                <path d={`M${x},${137 - ry} A7,${ry} 0 0 1 ${x},${137 + ry}`} pathLength={100} stroke="#ffe6f6" strokeWidth="2" fill="none" className="ring-spin" style={{ animationDelay: `${-i * 0.5}s` }} />
              </g>
            );
          })}

          {/* idle electricity */}
          <g filter="url(#cp-glow)">
            <LiveBolt x1={400} y1={137} x2={446} y2={137} color={CY} n={6} amp={6} seed={4} width={0.9} />
          </g>
          <g className="idle-zap" filter="url(#cp-glow)">
            <Bolt x1={444} y1={118} x2={470} y2={86} color={CY} n={6} amp={7} seed={8} width={1.1} />
          </g>
          <g className="idle-zap" style={{ animationDelay: "1.3s" }} filter="url(#cp-glow)">
            <Bolt x1={444} y1={156} x2={474} y2={184} color={CY} n={6} amp={7} seed={15} width={1.1} />
          </g>
        </g>

        {/* ========== FIRING FX (no projectile) ========== */}
        <circle cx="420" cy="137" r="80" fill="url(#cp-halo)" className="fx" />
        <g className="fx" filter="url(#cp-glow)">
          <LiveBolt x1={398} y1={137} x2={470} y2={74} color={CY} n={9} amp={12} seed={27} width={1.8} />
          <LiveBolt x1={398} y1={137} x2={480} y2={140} color="#a8f6ff" n={9} amp={12} seed={34} width={1.6} />
          <LiveBolt x1={398} y1={137} x2={466} y2={202} color={CY} n={8} amp={12} seed={41} width={1.4} />
          <LiveBolt x1={412} y1={114} x2={444} y2={160} color="#ff8fd2" n={6} amp={6} seed={47} width={1} />
          <LiveBolt x1={70} y1={108} x2={302} y2={172} color={CY} n={18} amp={10} seed={53} width={0.9} />
        </g>
        <circle cx="400" cy="137" r="16" fill="#ffffff" className="fx-quick" filter="url(#cp-glow)" />
        {[0, 0.1, 0.2, 0.3].map((d, i) => (
          <ellipse key={d} cx="428" cy="137" rx="10" ry="28" fill="none" stroke={i % 2 === 0 ? "#ff8fd2" : CY} strokeWidth="2.5" className="shock" style={{ animationDelay: `${d}s` }} />
        ))}
        <circle cx={cx} cy={cy} r="30" fill="none" stroke="#ffffff" strokeWidth="2" className="shock" />
        <Sparks cx={404} cy={137} color={CY} count={18} spread={80} seed={19} />
      </g>
    </svg>
  );
}
