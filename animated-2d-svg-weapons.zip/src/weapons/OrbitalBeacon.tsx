import { BlurFilter, Flame, FlameDefs, GlowFilter, Sparks } from "./shared";

const OL = "#0b0f1e";

function Panel({ x, y, w, h, d = 0 }: { x: number; y: number; w: number; h: number; d?: number }) {
  const cols = 4;
  const rows = 5;
  const pad = 5;
  const gap = 2.2;
  const cw = (w - pad * 2 - gap * (cols - 1)) / cols;
  const ch = (h - pad * 2 - gap * (rows - 1)) / rows;
  const cells: { cx: number; cy: number; i: number }[] = [];
  for (let r = 0; r < rows; r++) for (let c = 0; c < cols; c++) cells.push({ cx: x + pad + c * (cw + gap), cy: y + pad + r * (ch + gap), i: r * cols + c });
  return (
    <g>
      <rect x={x + 3} y={y + 4} width={w} height={h} rx={4} fill="#000" opacity={0.25} />
      <rect x={x} y={y} width={w} height={h} rx={4} fill="url(#ob-frame)" stroke={OL} strokeWidth={2.2} />
      <rect x={x + pad - 1.5} y={y + pad - 1.5} width={w - pad * 2 + 3} height={h - pad * 2 + 3} rx={2} fill="#0a1a4a" />
      {cells.map((c) => (
        <g key={c.i}>
          <rect x={c.cx} y={c.cy} width={cw} height={ch} rx={1.2} fill="url(#ob-cell)" />
          <line x1={c.cx + cw / 2} y1={c.cy + 1} x2={c.cx + cw / 2} y2={c.cy + ch - 1} stroke="#7fb4ff" strokeWidth={0.5} opacity={0.5} />
          <rect x={c.cx + 1} y={c.cy + 1} width={cw - 2} height={1.6} fill="#bfe2ff" opacity={0.55} />
          <rect x={c.cx} y={c.cy} width={cw} height={ch} rx={1.2} fill="#e2f6ff" className="seq" style={{ animationDelay: `${d + c.i * 0.025}s` }} />
        </g>
      ))}
      {/* glass reflections */}
      <polygon points={`${x + pad},${y + h * 0.7} ${x + w * 0.62},${y + pad} ${x + w * 0.8},${y + pad} ${x + pad},${y + h * 0.9}`} fill="#ffffff" opacity={0.14} />
      <polygon points={`${x + w * 0.4},${y + h - pad} ${x + w - pad},${y + h * 0.36} ${x + w - pad},${y + h * 0.46} ${x + w * 0.52},${y + h - pad}`} fill="#ffffff" opacity={0.1} />
    </g>
  );
}

/** curved band around a capsule (gives cylinder feel) */
function Band({ x, t, b, w = 9, fill = "url(#ob-blue)" }: { x: number; t: number; b: number; w?: number; fill?: string }) {
  const m = (t + b) / 2;
  return (
    <path
      d={`M${x},${t} L${x + w},${t} Q${x + w + 5},${m} ${x + w},${b} L${x},${b} Q${x + 5},${m} ${x},${t} Z`}
      fill={fill}
      stroke={OL}
      strokeWidth={1.6}
      strokeLinejoin="round"
    />
  );
}

export default function OrbitalBeacon() {
  const DC: [number, number] = [384, 160]; // dish center
  const TIP: [number, number] = [432, 160];
  const ribs = Array.from({ length: 10 }, (_, i) => (i * Math.PI * 2) / 10);

  return (
    <svg viewBox="10 -10 450 360" className="w-full h-full overflow-visible">
      <defs>
        <linearGradient id="ob-silver" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#7a8296" />
          <stop offset="0.1" stopColor="#ffffff" />
          <stop offset="0.3" stopColor="#f1f4f9" />
          <stop offset="0.58" stopColor="#b9c0cf" />
          <stop offset="0.82" stopColor="#6c7488" />
          <stop offset="0.93" stopColor="#4a5164" />
          <stop offset="1" stopColor="#a8b0c2" />
        </linearGradient>
        <linearGradient id="ob-frame" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#ffffff" />
          <stop offset="0.45" stopColor="#b3bbcc" />
          <stop offset="1" stopColor="#5a6276" />
        </linearGradient>
        <linearGradient id="ob-cell" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#5c9bff" />
          <stop offset="0.45" stopColor="#2457d6" />
          <stop offset="1" stopColor="#0b2575" />
        </linearGradient>
        <linearGradient id="ob-gold" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#7a4a06" />
          <stop offset="0.18" stopColor="#fff3bf" />
          <stop offset="0.45" stopColor="#f2b52e" />
          <stop offset="0.82" stopColor="#a36208" />
          <stop offset="1" stopColor="#5a3303" />
        </linearGradient>
        <linearGradient id="ob-goldBack" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0" stopColor="#6b3e04" />
          <stop offset="0.5" stopColor="#c98a1c" />
          <stop offset="1" stopColor="#8a5206" />
        </linearGradient>
        <radialGradient id="ob-dishIn" cx="0.38" cy="0.4" r="0.75">
          <stop offset="0" stopColor="#fff8d8" />
          <stop offset="0.35" stopColor="#f6c64e" />
          <stop offset="0.75" stopColor="#c27e12" />
          <stop offset="1" stopColor="#7a4705" />
        </radialGradient>
        <linearGradient id="ob-black" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0" stopColor="#555a6a" />
          <stop offset="0.3" stopColor="#24262f" />
          <stop offset="1" stopColor="#08080b" />
        </linearGradient>
        <linearGradient id="ob-blue" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#0a3a80" />
          <stop offset="0.2" stopColor="#a8e4ff" />
          <stop offset="0.5" stopColor="#3aa0f0" />
          <stop offset="1" stopColor="#0a2f6e" />
        </linearGradient>
        <radialGradient id="ob-halo">
          <stop offset="0" stopColor="#fff8dc" />
          <stop offset="0.35" stopColor="#ffb02e" stopOpacity="0.8" />
          <stop offset="1" stopColor="#ff7a00" stopOpacity="0" />
        </radialGradient>
        <radialGradient id="ob-screen" cx="0.5" cy="0.5" r="0.7">
          <stop offset="0" stopColor="#0c2a44" />
          <stop offset="1" stopColor="#020a14" />
        </radialGradient>
        <FlameDefs id="ob-f" />
        <GlowFilter id="ob-glow" std={2.5} />
        <BlurFilter id="ob-blur" std={20} />
      </defs>

      <ellipse cx="230" cy="170" rx="190" ry="100" fill="#7aa8ff" opacity="0.22" filter="url(#ob-blur)" className="pulse" />

      <g transform="translate(6 20) rotate(-38 236 170)">
        <g className="recoil">
          {/* ===== SOLAR PANELS (behind) ===== */}
          <rect x="176" y="92" width="10" height="38" fill="url(#ob-frame)" stroke={OL} strokeWidth="1.6" />
          <rect x="170" y="88" width="22" height="10" rx="3" fill="url(#ob-black)" stroke={OL} strokeWidth="1.4" />
          <Panel x={128} y={-6} w={118} h={96} d={0} />
          <rect x="262" y="190" width="10" height="40" fill="url(#ob-frame)" stroke={OL} strokeWidth="1.6" />
          <rect x="256" y="224" width="22" height="10" rx="3" fill="url(#ob-black)" stroke={OL} strokeWidth="1.4" />
          <Panel x={212} y={232} w={118} h={96} d={0.15} />

          {/* ===== THRUSTER ===== */}
          <path d="M94,144 L66,134 L66,186 L94,176 Z" fill="url(#ob-silver)" stroke={OL} strokeWidth="2" strokeLinejoin="round" />
          <path d="M92,148 L70,140" stroke="#ffffff" strokeWidth="1.5" opacity="0.8" />
          <ellipse cx="66" cy="160" rx="6" ry="26" fill="#1a1d26" stroke={OL} strokeWidth="1.6" />
          <ellipse cx="65" cy="160" rx="3.5" ry="18" fill="#ff9a2a" filter="url(#ob-glow)" className="pulse" />
          <Flame id="ob-f" x={62} y={160} rot={-90} w={22} h={42} className="grow" />

          {/* ===== GRIP (raked) ===== */}
          <path d="M150,188 L202,188 L190,236 Q182,268 172,282 L134,282 Q120,278 125,262 Q140,228 150,188 Z" fill="url(#ob-black)" stroke={OL} strokeWidth="2.2" strokeLinejoin="round" />
          <path d="M196,194 L184,240 Q176,266 168,276" stroke="#ff8a1f" strokeWidth="3.5" fill="none" strokeLinecap="round" />
          <path d="M156,196 Q146,232 134,268" stroke="#7d8395" strokeWidth="1.6" fill="none" opacity="0.7" />
          {[214, 230, 246, 262].map((y, i) => (
            <path key={y} d={`M${146 - i * 4},${y} L${180 - i * 4.5},${y}`} stroke="#000" strokeWidth="3" strokeLinecap="round" />
          ))}
          <path d="M128,276 L172,276 Q172,290 160,292 L130,292 Q120,288 128,276 Z" fill="url(#ob-silver)" stroke={OL} strokeWidth="1.6" />
          {/* trigger guard */}
          <path d="M200,194 Q244,194 246,216 Q244,232 204,230" fill="none" stroke={OL} strokeWidth="8" strokeLinecap="round" />
          <path d="M200,194 Q244,194 246,216 Q244,232 204,230" fill="none" stroke="url(#ob-silver)" strokeWidth="5" strokeLinecap="round" />
          <path d="M210,196 Q222,208 214,222" stroke={OL} strokeWidth="6" fill="none" strokeLinecap="round" />
          <path d="M210,196 Q222,208 214,222" stroke="#ff8a1f" strokeWidth="3.4" fill="none" strokeLinecap="round" />

          {/* ===== BODY (capsule) ===== */}
          <path d="M122,124 L268,124 Q294,124 294,160 Q294,196 268,196 L122,196 Q88,196 88,160 Q88,124 122,124 Z" fill="url(#ob-silver)" stroke={OL} strokeWidth="2.2" strokeLinejoin="round" />
          <path d="M100,138 Q108,130 124,130 L266,130 Q280,130 286,138" stroke="#ffffff" strokeWidth="3" fill="none" strokeLinecap="round" />
          <path d="M104,186 Q112,191 124,191 L266,191" stroke="#d9e4ff" strokeWidth="1.4" fill="none" opacity="0.6" />
          <Band x={112} t={126} b={194} w={10} />
          <Band x={128} t={124} b={196} w={5} />
          <Band x={256} t={125} b={195} w={10} />
          {/* screen */}
          <rect x="152" y="136" width="94" height="44" rx="9" fill="url(#ob-frame)" stroke={OL} strokeWidth="2" />
          <rect x="157" y="140" width="84" height="36" rx="6" fill="url(#ob-screen)" stroke={OL} strokeWidth="1" />
          <g filter="url(#ob-glow)">
            {[10, 17, 8, 20, 13, 6].map((h, i) => (
              <rect key={i} x={162 + i * 6.5} y={170 - h} width="4" height={h} rx="1" fill="#3fdcff" className="pulse" style={{ animationDelay: `${i * 0.18}s` }} />
            ))}
            <path d="M206,148 L232,148 M206,155 L226,155 M206,162 L232,162" stroke="#3fdcff" strokeWidth="2" strokeLinecap="round" />
            <circle cx="230" cy="170" r="2.6" fill="#ff8a1f" className="blink" />
          </g>
          <rect x="159" y="142" width="80" height="1.5" fill="#c9f6ff" className="scan" />
          <path d="M160,143 L196,143 L186,158 L160,158 Z" fill="#ffffff" opacity="0.1" />
          <rect x="157" y="140" width="84" height="36" rx="6" fill="#ffffff" className="flash" />
          {[166, 178, 190].map((x, i) => (
            <g key={x}>
              <circle cx={x} cy="187" r="3.6" fill="#3a1a04" stroke={OL} strokeWidth="1" />
              <circle cx={x} cy="187" r="2.5" fill="#ff9a2a" filter="url(#ob-glow)" className="pulse" style={{ animationDelay: `${i * 0.3}s` }} />
            </g>
          ))}

          {/* ===== NECK ===== */}
          <path d="M290,144 L340,146 L340,174 L290,176 Z" fill="url(#ob-silver)" stroke={OL} strokeWidth="2" strokeLinejoin="round" />
          <path d="M292,149 L338,150" stroke="#ffffff" strokeWidth="2" strokeLinecap="round" />
          <Band x={308} t={142} b={178} w={8} />
          <rect x="338" y="150" width="14" height="20" rx="3" fill="url(#ob-black)" stroke={OL} strokeWidth="1.6" />

          {/* ===== DISH ===== */}
          <g className="charge">
            {/* back bowl */}
            <path d={`M${DC[0]},${DC[1] - 66} C${DC[0] - 26},${DC[1] - 58} ${DC[0] - 36},${DC[1] - 24} ${DC[0] - 34},${DC[1]} C${DC[0] - 36},${DC[1] + 24} ${DC[0] - 26},${DC[1] + 58} ${DC[0]},${DC[1] + 66} Z`} fill="url(#ob-goldBack)" stroke={OL} strokeWidth="2.2" strokeLinejoin="round" />
            <path d={`M${DC[0] - 6},${DC[1] - 60} C${DC[0] - 24},${DC[1] - 50} ${DC[0] - 30},${DC[1] - 24} ${DC[0] - 30},${DC[1] - 4}`} stroke="#ffe08a" strokeWidth="2" fill="none" opacity="0.7" strokeLinecap="round" />
            {/* inner face */}
            <ellipse cx={DC[0]} cy={DC[1]} rx="26" ry="66" fill="url(#ob-dishIn)" stroke={OL} strokeWidth="2.2" />
            {ribs.map((a, i) => (
              <line key={i} x1={DC[0] + 2} y1={DC[1]} x2={DC[0] + Math.cos(a) * 24} y2={DC[1] + Math.sin(a) * 63} stroke="#9a5a08" strokeWidth="1.1" opacity="0.75" />
            ))}
            <ellipse cx={DC[0] + 1} cy={DC[1]} rx="17" ry="44" fill="none" stroke="#9a5a08" strokeWidth="1.2" opacity="0.8" />
            <ellipse cx={DC[0] + 2} cy={DC[1]} rx="9" ry="22" fill="none" stroke="#9a5a08" strokeWidth="1.2" opacity="0.8" />
            <ellipse cx={DC[0]} cy={DC[1]} rx="26" ry="66" fill="none" stroke="url(#ob-gold)" strokeWidth="4.5" />
            <ellipse cx={DC[0]} cy={DC[1]} rx="26" ry="66" fill="none" stroke={OL} strokeWidth="1" />
            <path d={`M${DC[0] - 14},${DC[1] - 50} Q${DC[0] - 20},${DC[1] - 20} ${DC[0] - 16},${DC[1] + 4}`} stroke="#ffffff" strokeWidth="3" fill="none" opacity="0.7" strokeLinecap="round" />
            <circle cx={DC[0] + 2} cy={DC[1]} r="5" fill="url(#ob-gold)" stroke={OL} strokeWidth="1.2" />
            <ellipse cx={DC[0]} cy={DC[1]} rx="26" ry="66" fill="#fff8dc" className="flash" />
          </g>
          {/* feed struts */}
          <path d={`M${DC[0] + 6},${DC[1] - 60} L${TIP[0]},${TIP[1]} M${DC[0] + 6},${DC[1] + 60} L${TIP[0]},${TIP[1]} M${DC[0] + 4},${DC[1]} L${TIP[0]},${TIP[1]}`} stroke={OL} strokeWidth="4.5" strokeLinecap="round" />
          <path d={`M${DC[0] + 6},${DC[1] - 60} L${TIP[0]},${TIP[1]} M${DC[0] + 6},${DC[1] + 60} L${TIP[0]},${TIP[1]} M${DC[0] + 4},${DC[1]} L${TIP[0]},${TIP[1]}`} stroke="#e6c26a" strokeWidth="2.2" strokeLinecap="round" />
          {/* antenna hook */}
          <path d={`M${TIP[0]},${TIP[1]} q16,-4 18,-22 q1,-10 -8,-14`} stroke={OL} strokeWidth="4" fill="none" strokeLinecap="round" />
          <path d={`M${TIP[0]},${TIP[1]} q16,-4 18,-22 q1,-10 -8,-14`} stroke="#e6c26a" strokeWidth="2" fill="none" strokeLinecap="round" />
          <circle cx={TIP[0]} cy={TIP[1]} r="16" fill="url(#ob-halo)" className="pulse" />
          <circle cx={TIP[0]} cy={TIP[1]} r="6" fill="#ffd27a" stroke={OL} strokeWidth="1.6" />
          <circle cx={TIP[0]} cy={TIP[1]} r="3.4" fill="#ffffff" className="blink" />

          {/* idle signal waves */}
          {[0, 1.2].map((d) => (
            <path key={d} d={`M${TIP[0] + 8},${TIP[1] - 12} A6,12 0 0 1 ${TIP[0] + 8},${TIP[1] + 12}`} stroke="#ffc65a" strokeWidth="2.5" fill="none" strokeLinecap="round" className="wave-idle" style={{ animationDelay: `${d}s` }} />
          ))}
        </g>

        {/* ===== FIRING FX (no projectile) ===== */}
        <circle cx={TIP[0]} cy={TIP[1]} r="64" fill="url(#ob-halo)" className="fx" />
        {[0, 0.12, 0.24, 0.36].map((d, i) => (
          <path key={d} d={`M${TIP[0] + 8},${TIP[1] - 16 - i * 4} A${8 + i * 2},${16 + i * 4} 0 0 1 ${TIP[0] + 8},${TIP[1] + 16 + i * 4}`} stroke={i % 2 ? "#7fd6ff" : "#ffc65a"} strokeWidth="3.5" fill="none" strokeLinecap="round" className="wave" filter="url(#ob-glow)" style={{ animationDelay: `${d}s` }} />
        ))}
        <circle cx={TIP[0]} cy={TIP[1]} r="14" fill="#ffffff" className="fx-quick" filter="url(#ob-glow)" />
        <circle cx={TIP[0]} cy={TIP[1]} r="22" fill="none" stroke="#ffd27a" strokeWidth="2.5" className="shock" />
        <Flame id="ob-f" x={62} y={160} rot={-90} w={44} h={100} className="fire-burst" />
        <Sparks cx={TIP[0]} cy={TIP[1]} color="#ffc65a" count={16} spread={70} seed={41} />
        <Sparks cx={64} cy={160} color="#ff8a1f" count={10} spread={60} seed={43} angleFrom={Math.PI * 0.6} angleTo={Math.PI * 1.4} />
      </g>
    </svg>
  );
}
