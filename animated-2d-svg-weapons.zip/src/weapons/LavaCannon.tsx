import { BlurFilter, Embers, Flame, FlameDefs, GlowFilter, Sparks } from "./shared";

function rng(seed: number) {
  let s = seed;
  return () => {
    s = (s * 9301 + 49297) % 233280;
    return s / 233280;
  };
}

/** jagged rock rectangle-ish outline around axis y=160 */
function rock(x1: number, x2: number, r1: number, r2: number, seed: number, step = 12, jit = 3) {
  const r = rng(seed);
  const top: string[] = [];
  const bot: string[] = [];
  for (let x = x1; x <= x2; x += step) {
    const t = (x - x1) / (x2 - x1);
    const rad = r1 + (r2 - r1) * t;
    top.push(`${x.toFixed(1)},${(160 - rad + (r() - 0.5) * jit * 2).toFixed(1)}`);
    bot.unshift(`${x.toFixed(1)},${(160 + rad + (r() - 0.5) * jit * 2).toFixed(1)}`);
  }
  const lx = x2;
  top.push(`${lx},${160 - r2}`);
  bot.unshift(`${lx},${160 + r2}`);
  return [...top, `${x2 + 3},160`, ...bot, `${x1 - 3},160`].join(" ");
}

const CRACKS = [
  "M112,140 L128,148 L136,142 L150,150 L160,146",
  "M120,178 L134,170 L146,176 L156,168",
  "M172,132 L180,146 L176,158 L188,168 L184,182 L192,192",
  "M196,140 L214,146 L226,138 L240,148",
  "M210,176 L224,170 L232,180 L248,174 L256,182",
  "M268,128 L272,140 L266,150",
  "M330,136 L340,150 L334,162 L344,176 L340,188",
  "M266,178 L276,186 L272,194",
  "M226,138 L230,126",
  "M188,168 L204,164 L210,176",
];

export default function LavaCannon() {
  const r = rng(42);
  const blotches = Array.from({ length: 30 }, () => ({
    x: 110 + r() * 250,
    y: 132 + r() * 56,
    rx: 2 + r() * 7,
    ry: 1.5 + r() * 4,
    light: r() > 0.6,
  }));

  return (
    <svg viewBox="0 0 440 320" className="w-full h-full overflow-visible">
      <defs>
        <linearGradient id="lv-stone" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#2a262e" />
          <stop offset="0.15" stopColor="#8a8290" />
          <stop offset="0.38" stopColor="#58515f" />
          <stop offset="0.75" stopColor="#2c2832" />
          <stop offset="1" stopColor="#100e13" />
        </linearGradient>
        <linearGradient id="lv-ring" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#1e1b22" />
          <stop offset="0.2" stopColor="#9c94a3" />
          <stop offset="0.45" stopColor="#4c4553" />
          <stop offset="1" stopColor="#0c0a0e" />
        </linearGradient>
        <linearGradient id="lv-handle" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#1a120d" />
          <stop offset="0.3" stopColor="#6b4a36" />
          <stop offset="0.6" stopColor="#2e1f16" />
          <stop offset="1" stopColor="#0a0604" />
        </linearGradient>
        <radialGradient id="lv-mouth">
          <stop offset="0" stopColor="#fff6c0" />
          <stop offset="0.35" stopColor="#ffb02e" />
          <stop offset="0.75" stopColor="#ff4d00" />
          <stop offset="1" stopColor="#5a0e00" />
        </radialGradient>
        <radialGradient id="lv-halo">
          <stop offset="0" stopColor="#fff2b0" />
          <stop offset="0.35" stopColor="#ff8a1f" stopOpacity="0.8" />
          <stop offset="1" stopColor="#ff3d00" stopOpacity="0" />
        </radialGradient>
        <FlameDefs id="lv-f" />
        <GlowFilter id="lv-glow" std={2.5} />
        <BlurFilter id="lv-blur" std={16} />
        <filter id="lv-crackblur" x="-20%" y="-50%" width="140%" height="200%">
          <feGaussianBlur stdDeviation="2.5" />
        </filter>
      </defs>

      <ellipse cx="220" cy="160" rx="190" ry="80" fill="#ff5a00" opacity="0.22" filter="url(#lv-blur)" transform="rotate(-35 220 160)" className="pulse" />

      <g transform="rotate(-35 220 160)">
        <g className="recoil">
          {/* handle */}
          <rect x="38" y="149" width="76" height="22" rx="9" fill="url(#lv-handle)" stroke="#050302" />
          {[56, 70, 84, 98].map((x) => (
            <path key={x} d={`M${x},150 Q${x + 4},160 ${x},170`} stroke="#0a0604" strokeWidth="2.5" fill="none" />
          ))}
          <rect x="42" y="152" width="68" height="3" rx="1.5" fill="#b08466" opacity="0.4" />
          <circle cx="36" cy="160" r="15" fill="url(#lv-ring)" stroke="#050405" />
          <circle cx="36" cy="160" r="6" fill="#ff7a1a" filter="url(#lv-glow)" className="pulse" />

          {/* stone body */}
          <polygon points={rock(104, 372, 33, 37, 7)} fill="url(#lv-stone)" stroke="#0a090c" strokeWidth="1.5" strokeLinejoin="round" />
          {blotches.map((b, i) => (
            <ellipse key={i} cx={b.x} cy={b.y} rx={b.rx} ry={b.ry} fill={b.light ? "#a59dac" : "#15121a"} opacity={b.light ? 0.25 : 0.45} />
          ))}
          <path d="M110,132 Q240,124 368,128" stroke="#c9c1cf" strokeWidth="2" opacity="0.35" fill="none" />

          {/* lava cracks */}
          <g>
            {CRACKS.map((d, i) => (
              <g key={i}>
                <path d={d} stroke="#ff4d00" strokeWidth="7" fill="none" strokeLinecap="round" strokeLinejoin="round" filter="url(#lv-crackblur)" className="pulse" style={{ animationDelay: `${i * 0.23}s` }} />
                <path d={d} stroke="#ff9a1f" strokeWidth="3" fill="none" strokeLinecap="round" strokeLinejoin="round" />
                <path d={d} stroke="#fff1a1" strokeWidth="1.1" fill="none" strokeLinecap="round" strokeLinejoin="round" />
                <path d={d} stroke="#ffffff" strokeWidth="4" fill="none" strokeLinecap="round" strokeLinejoin="round" className="seq" filter="url(#lv-glow)" style={{ animationDelay: `${0.04 * i}s` }} />
              </g>
            ))}
          </g>

          {/* stone rings */}
          {[
            [128, 146, 40, 11],
            [252, 270, 41, 23],
            [354, 378, 43, 31],
          ].map(([a, b, rad, s]) => (
            <g key={a}>
              <polygon points={rock(a, b, rad, rad, s, 6, 2)} fill="url(#lv-ring)" stroke="#060508" strokeWidth="1.2" />
              <line x1={(a + b) / 2} y1={160 - rad + 4} x2={(a + b) / 2 + 2} y2={160 + rad - 4} stroke="#ff7a1a" strokeWidth="1.5" opacity="0.7" className="pulse" />
            </g>
          ))}

          {/* rune eye */}
          <g className="charge">
            <circle cx="306" cy="160" r="20" fill="#1a0f0a" opacity="0.6" />
            <circle cx="306" cy="160" r="18" fill="none" stroke="#ff7a1a" strokeWidth="6" opacity="0.45" filter="url(#lv-crackblur)" className="pulse" />
            <circle cx="306" cy="160" r="18" fill="none" stroke="#ffb02e" strokeWidth="2.5" />
            <circle cx="306" cy="160" r="18" fill="none" stroke="#fff1a1" strokeWidth="0.8" />
            {[0, 45, 90, 135, 180, 225, 270, 315].map((a) => {
              const rad = (a * Math.PI) / 180;
              return (
                <line key={a} x1={306 + Math.cos(rad) * 18} y1={160 + Math.sin(rad) * 18} x2={306 + Math.cos(rad) * 23} y2={160 + Math.sin(rad) * 23} stroke="#ffb02e" strokeWidth="2" strokeLinecap="round" />
              );
            })}
            <path d="M292,160 Q306,148 320,160 Q306,172 292,160 Z" fill="none" stroke="#ffb02e" strokeWidth="2.2" />
            <circle cx="306" cy="160" r="5" fill="#fff1a1" filter="url(#lv-glow)" className="pulse-scale" />
            <circle cx="306" cy="160" r="20" fill="#fff6c0" className="flash" />
          </g>

          {/* mouth */}
          <ellipse cx="380" cy="160" rx="8" ry="33" fill="#120d0b" />
          <ellipse cx="381" cy="160" rx="6" ry="27" fill="url(#lv-mouth)" filter="url(#lv-glow)" className="pulse" />

          {/* idle fire */}
          <Flame id="lv-f" x={384} y={160} rot={90} w={46} h={88} className="grow" />
        </g>

        {/* ===== FIRING FX ===== */}
        <Flame id="lv-f" x={386} y={160} rot={90} w={80} h={170} className="fire-burst" />
        <circle cx="400" cy="160" r="70" fill="url(#lv-halo)" className="fx" />
        {[0, 0.12, 0.24].map((d) => (
          <ellipse key={d} cx="390" cy="160" rx="12" ry="34" fill="none" stroke="#ffb02e" strokeWidth="3" className="shock" style={{ animationDelay: `${d}s` }} />
        ))}
        <Sparks cx={392} cy={160} color="#ffb02e" count={20} spread={90} seed={17} angleFrom={-1.3} angleTo={1.3} />
        <Sparks cx={230} cy={160} color="#ff7a1a" count={10} spread={60} seed={29} />
      </g>

      {/* rising embers (world space) */}
      <Embers x={360} y={70} count={16} spreadX={90} rise={90} seed={5} />
      <Embers x={250} y={140} count={8} spreadX={120} rise={70} seed={11} color="#ff7a1a" />
    </svg>
  );
}
