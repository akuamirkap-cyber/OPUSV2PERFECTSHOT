import { GlowFilter, BlurFilter, LiveBolt, Sparks } from "./shared";

const COILS = [194, 210, 226, 242, 258, 274, 290];

function octagon(cx: number, cy: number, r: number) {
  return Array.from({ length: 8 }, (_, i) => {
    const a = (Math.PI / 4) * i + Math.PI / 8;
    return `${(cx + Math.cos(a) * r).toFixed(1)},${(cy + Math.sin(a) * r).toFixed(1)}`;
  }).join(" ");
}

export default function EmeraldRayGun() {
  const gx = 118;
  const gy = 134;
  const outer = Array.from({ length: 8 }, (_, i) => {
    const a = (Math.PI / 4) * i + Math.PI / 8;
    return [gx + Math.cos(a) * 20, gy + Math.sin(a) * 20];
  });
  const inner = Array.from({ length: 8 }, (_, i) => {
    const a = (Math.PI / 4) * i + Math.PI / 8;
    return [gx + Math.cos(a) * 10, gy + Math.sin(a) * 10];
  });
  const facetColors = ["#7dffb0", "#2fd673", "#0f9c4c", "#06753a", "#0a8a44", "#1fbf62", "#5ef59a", "#b8ffd6"];

  return (
    <svg viewBox="0 0 440 300" className="w-full h-full overflow-visible">
      <defs>
        <linearGradient id="e-silver" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#7a7d8c" />
          <stop offset="0.2" stopColor="#ffffff" />
          <stop offset="0.45" stopColor="#c9ccd8" />
          <stop offset="0.75" stopColor="#7c8091" />
          <stop offset="1" stopColor="#353844" />
        </linearGradient>
        <linearGradient id="e-gold" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#7a4a06" />
          <stop offset="0.25" stopColor="#fff0b0" />
          <stop offset="0.5" stopColor="#e6ac2c" />
          <stop offset="1" stopColor="#5e3803" />
        </linearGradient>
        <linearGradient id="e-goldD" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#fff0b0" />
          <stop offset="0.5" stopColor="#d99a1e" />
          <stop offset="1" stopColor="#6b3e04" />
        </linearGradient>
        <linearGradient id="e-grip" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0" stopColor="#0c6b33" />
          <stop offset="0.35" stopColor="#1fa456" />
          <stop offset="1" stopColor="#063d1c" />
        </linearGradient>
        <pattern id="e-diamond" width="10" height="10" patternUnits="userSpaceOnUse" patternTransform="rotate(45)">
          <rect width="10" height="10" fill="none" />
          <line x1="0" y1="0" x2="0" y2="10" stroke="#e8b84a" strokeWidth="1" opacity="0.8" />
          <line x1="0" y1="0" x2="10" y2="0" stroke="#e8b84a" strokeWidth="1" opacity="0.8" />
          <circle cx="5" cy="5" r="1" fill="#7dffb0" opacity="0.7" />
        </pattern>
        <radialGradient id="e-halo">
          <stop offset="0" stopColor="#eaffef" />
          <stop offset="0.3" stopColor="#4dff8a" stopOpacity="0.85" />
          <stop offset="1" stopColor="#00c853" stopOpacity="0" />
        </radialGradient>
        <linearGradient id="e-beam" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0" stopColor="#ffffff" />
          <stop offset="0.25" stopColor="#7dffab" />
          <stop offset="0.8" stopColor="#1fe068" stopOpacity="0.6" />
          <stop offset="1" stopColor="#00c853" stopOpacity="0" />
        </linearGradient>
        <GlowFilter id="e-glow" std={3} />
        <BlurFilter id="e-blur" std={16} />
      </defs>

      <ellipse cx="220" cy="160" rx="170" ry="80" fill="#1fe068" opacity="0.18" filter="url(#e-blur)" className="pulse" />

      <g transform="rotate(-12 220 150)">
        <g className="recoil">
          {/* grip */}
          <path d="M96,160 L150,160 Q146,190 152,222 Q155,248 142,256 L104,258 Q91,254 94,238 Q99,200 96,160 Z" fill="url(#e-grip)" />
          <path d="M96,160 L150,160 Q146,190 152,222 Q155,248 142,256 L104,258 Q91,254 94,238 Q99,200 96,160 Z" fill="url(#e-diamond)" />
          <path d="M96,160 L150,160 Q146,190 152,222 Q155,248 142,256 L104,258 Q91,254 94,238 Q99,200 96,160 Z" fill="none" stroke="url(#e-gold)" strokeWidth="4" />
          <path d="M102,252 L144,252 Q150,262 140,266 L106,266 Q96,262 102,252 Z" fill="url(#e-gold)" />

          {/* trigger guard */}
          <path d="M150,168 Q192,170 194,196 Q192,216 158,214" fill="none" stroke="url(#e-goldD)" strokeWidth="6" strokeLinecap="round" />
          <path d="M156,172 Q168,184 162,200" stroke="url(#e-silver)" strokeWidth="4.5" fill="none" strokeLinecap="round" />

          {/* barrel */}
          <rect x="172" y="121" width="146" height="26" rx="11" fill="url(#e-silver)" stroke="#3a3d48" />
          <rect x="176" y="125" width="138" height="4" rx="2" fill="#fff" opacity="0.7" />
          {/* gold coil (back) */}
          {COILS.map((x) => (
            <ellipse key={`b${x}`} cx={x} cy="134" rx="4.5" ry="18" fill="none" stroke="#6b4205" strokeWidth="4" transform={`rotate(18 ${x} 134)`} />
          ))}
          {/* gold coil (front) */}
          {COILS.map((x, i) => (
            <g key={x}>
              <path d={`M${x + 6},116 Q${x - 4},134 ${x - 6},152`} stroke="url(#e-goldD)" strokeWidth="5" fill="none" strokeLinecap="round" />
              <path d={`M${x + 5},118 Q${x - 3},132 ${x - 4},140`} stroke="#fff6cf" strokeWidth="1.4" fill="none" strokeLinecap="round" opacity="0.8" />
              <path d={`M${x + 6},116 Q${x - 4},134 ${x - 6},152`} stroke="#6dff9e" strokeWidth="6" fill="none" strokeLinecap="round" className="seq" filter="url(#e-glow)" style={{ animationDelay: `${i * 0.05}s` }} />
            </g>
          ))}

          {/* rear body */}
          <rect x="58" y="98" width="126" height="72" rx="32" fill="url(#e-silver)" stroke="#3a3d48" strokeWidth="1.2" />
          <path d="M80,104 Q120,96 170,106" stroke="#fff" strokeWidth="3" fill="none" opacity="0.8" strokeLinecap="round" />
          <rect x="164" y="104" width="12" height="60" rx="4" fill="url(#e-gold)" />
          <rect x="52" y="112" width="12" height="44" rx="6" fill="url(#e-gold)" />
          {[150, 156].map((x) => (
            <line key={x} x1={x} y1="108" x2={x} y2="160" stroke="#8a8d9c" strokeWidth="1" />
          ))}

          {/* gem */}
          <polygon points={octagon(gx, gy, 28)} fill="url(#e-gold)" stroke="#5e3803" strokeWidth="1" />
          <polygon points={octagon(gx, gy, 24)} fill="#0b3d1f" />
          <g className="charge">
            <circle cx={gx} cy={gy} r="30" fill="url(#e-halo)" opacity="0.6" className="pulse" />
            {outer.map((p, i) => {
              const n = outer[(i + 1) % 8];
              const ip = inner[i];
              const inn = inner[(i + 1) % 8];
              return <polygon key={i} points={`${p[0]},${p[1]} ${n[0]},${n[1]} ${inn[0]},${inn[1]} ${ip[0]},${ip[1]}`} fill={facetColors[i]} stroke="#033b1a" strokeWidth="0.5" />;
            })}
            <polygon points={inner.map((p) => p.join(",")).join(" ")} fill="#3ee67f" stroke="#a6ffc9" strokeWidth="0.6" />
            <polygon points={`${gx - 6},${gy - 7} ${gx + 2},${gy - 9} ${gx - 3},${gy - 1}`} fill="#fff" opacity="0.9" />
            <polygon points={octagon(gx, gy, 20)} fill="#ffffff" className="flash" />
          </g>
          {/* gold prongs */}
          {[0, 90, 180, 270].map((a) => (
            <circle key={a} cx={gx + Math.cos((a * Math.PI) / 180) * 26} cy={gy + Math.sin((a * Math.PI) / 180) * 26} r="3" fill="url(#e-gold)" stroke="#5e3803" strokeWidth="0.5" />
          ))}

          {/* front collar & cone */}
          <rect x="312" y="113" width="15" height="42" rx="5" fill="url(#e-gold)" stroke="#5e3803" />
          <path d="M327,120 L344,128 L344,140 L327,148 Z" fill="url(#e-silver)" />

          {/* emitter C-ring */}
          <g className="ring-out">
            <path d="M378.9,119.9 A22,22 0 1 0 378.9,148.1" fill="none" stroke="#5e3803" strokeWidth="10" strokeLinecap="round" />
            <path d="M378.9,119.9 A22,22 0 1 0 378.9,148.1" fill="none" stroke="url(#e-gold)" strokeWidth="7" strokeLinecap="round" />
            <path d="M352,118 A20,20 0 0 0 343,132" fill="none" stroke="#fff6cf" strokeWidth="1.6" strokeLinecap="round" opacity="0.9" />
          </g>
          <g className="charge">
            <circle cx="362" cy="134" r="26" fill="url(#e-halo)" className="pulse" />
            <circle cx="362" cy="134" r="8" fill="#eaffef" filter="url(#e-glow)" className="pulse-scale" />
          </g>
          <g className="idle-zap" filter="url(#e-glow)">
            <LiveBolt x1={348} y1={124} x2={376} y2={144} color="#4dff8a" n={5} amp={5} seed={3} width={0.9} />
          </g>
        </g>

        {/* ===== FIRING FX ===== */}
        <g className="beam" filter="url(#e-glow)">
          <polygon points="362,124 450,114 478,134 450,154 362,144" fill="url(#e-beam)" />
          <polygon points="362,130 440,128 460,134 440,140 362,138" fill="#ffffff" opacity="0.9" />
        </g>
        <circle cx="362" cy="134" r="60" fill="url(#e-halo)" className="fx" />
        <circle cx="362" cy="134" r="16" fill="#fff" className="fx-quick" filter="url(#e-glow)" />
        {[0, 0.12, 0.24, 0.36].map((d) => (
          <ellipse key={d} cx="372" cy="134" rx="8" ry="22" fill="none" stroke="#7dffab" strokeWidth="2.5" className="shock" style={{ animationDelay: `${d}s` }} />
        ))}
        <g className="fx" filter="url(#e-glow)">
          <LiveBolt x1={172} y1={134} x2={318} y2={134} color="#4dff8a" n={14} amp={8} seed={18} width={0.9} />
        </g>
        <Sparks cx={366} cy={134} color="#4dff8a" count={16} spread={70} seed={12} />
        <Sparks cx={118} cy={134} color="#ffd86b" count={8} spread={40} seed={22} />
      </g>
    </svg>
  );
}
