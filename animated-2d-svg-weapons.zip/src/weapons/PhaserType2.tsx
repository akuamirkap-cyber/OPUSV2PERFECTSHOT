import { BlurFilter, GlowFilter, LiveBolt, Sparks } from "./shared";

const OL = "#08090e";
const OR = "#ff8a1f";

function starBurst(cx: number, cy: number, r1: number, r2: number, n: number) {
  return Array.from({ length: n * 2 }, (_, i) => {
    const r = i % 2 === 0 ? r1 : r2;
    const a = (Math.PI * i) / n;
    return `${(cx + Math.cos(a) * r).toFixed(1)},${(cy + Math.sin(a) * r * 0.7).toFixed(1)}`;
  }).join(" ");
}

function Screw({ x, y, r = 2.6 }: { x: number; y: number; r?: number }) {
  return (
    <g>
      <circle cx={x} cy={y} r={r} fill="url(#p3-chrome)" stroke={OL} strokeWidth="1" />
      <line x1={x - r * 0.6} y1={y - r * 0.3} x2={x + r * 0.6} y2={y + r * 0.3} stroke={OL} strokeWidth="0.9" />
    </g>
  );
}

export default function PhaserType2() {
  const MZ: [number, number] = [418, 96];
  return (
    <svg viewBox="20 -30 470 390" className="w-full h-full overflow-visible">
      <defs>
        <linearGradient id="p3-slide" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#e6e9ef" />
          <stop offset="0.16" stopColor="#b5bbc7" />
          <stop offset="0.45" stopColor="#7b8291" />
          <stop offset="0.75" stopColor="#555c6a" />
          <stop offset="1" stopColor="#363b46" />
        </linearGradient>
        <linearGradient id="p3-top" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#ffffff" />
          <stop offset="1" stopColor="#c3c8d3" />
        </linearGradient>
        <linearGradient id="p3-recess" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#14161c" />
          <stop offset="1" stopColor="#2c303a" />
        </linearGradient>
        <linearGradient id="p3-frame" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#7a8190" />
          <stop offset="0.3" stopColor="#474d5a" />
          <stop offset="1" stopColor="#1c1f26" />
        </linearGradient>
        <linearGradient id="p3-grip" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0" stopColor="#9ba2b0" />
          <stop offset="0.18" stopColor="#5a6170" />
          <stop offset="0.6" stopColor="#323743" />
          <stop offset="1" stopColor="#1a1d24" />
        </linearGradient>
        <linearGradient id="p3-panel" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#30343f" />
          <stop offset="1" stopColor="#111318" />
        </linearGradient>
        <pattern id="p3-tex" width="5" height="5" patternUnits="userSpaceOnUse" patternTransform="rotate(45)">
          <rect width="2.5" height="2.5" fill="#ffffff" opacity="0.06" />
        </pattern>
        <linearGradient id="p3-chrome" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#5a6070" />
          <stop offset="0.2" stopColor="#ffffff" />
          <stop offset="0.5" stopColor="#b8bdca" />
          <stop offset="0.85" stopColor="#4a505e" />
          <stop offset="1" stopColor="#2a2e38" />
        </linearGradient>
        <linearGradient id="p3-neon" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#fff6d0" />
          <stop offset="0.35" stopColor="#ffb040" />
          <stop offset="1" stopColor="#e65a00" />
        </linearGradient>
        <linearGradient id="p3-neonH" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0" stopColor="#e65a00" />
          <stop offset="0.5" stopColor="#ffd88a" />
          <stop offset="1" stopColor="#e65a00" />
        </linearGradient>
        <radialGradient id="p3-halo">
          <stop offset="0" stopColor="#fff6dc" />
          <stop offset="0.3" stopColor="#ffa53a" stopOpacity="0.85" />
          <stop offset="1" stopColor="#ff6a00" stopOpacity="0" />
        </radialGradient>
        <radialGradient id="p3-cap" cx="0.45" cy="0.4" r="0.6">
          <stop offset="0" stopColor="#ffffff" />
          <stop offset="0.3" stopColor="#ffe0a0" />
          <stop offset="0.7" stopColor="#ff9a2a" />
          <stop offset="1" stopColor="#c24a00" />
        </radialGradient>
        <GlowFilter id="p3-glow" std={2.4} />
        <BlurFilter id="p3-blur" std={20} />
      </defs>

      <ellipse cx="250" cy="160" rx="190" ry="90" fill="#ff8a1f" opacity="0.16" filter="url(#p3-blur)" className="pulse" />

      <g transform="translate(0 24) rotate(-20 250 160)">
        <g className="recoil">
          {/* ===== FRONT POST ===== */}
          <path d="M288,138 L338,138 L346,264 Q347,276 335,276 L306,277 Q296,277 295,265 Z" fill="url(#p3-grip)" stroke={OL} strokeWidth="2.2" strokeLinejoin="round" />
          <path d="M288,138 L338,138 L346,264 Q347,276 335,276 L306,277 Q296,277 295,265 Z" fill="url(#p3-tex)" />
          <path d="M292,144 L300,264" stroke="#c3c8d3" strokeWidth="1.6" opacity="0.7" />
          <path d="M306,154 L330,154 L337,258 L313,258 Z" fill="#1a0902" stroke={OL} strokeWidth="1.5" strokeLinejoin="round" />
          <path d="M310,158 L326,158 L332,254 L316,254 Z" fill="url(#p3-neon)" filter="url(#p3-glow)" className="pulse" />
          <path d="M313,160 L317,160 L322,252 L318,252 Z" fill="#fff6d0" opacity="0.8" />
          {[0, 1, 2, 3, 4, 5].map((k) => (
            <line key={k} x1={308 + k * 0.6} y1={172 + k * 14} x2={333 + k * 0.6} y2={172 + k * 14} stroke="#1a0902" strokeWidth="2" />
          ))}
          <path d="M306,154 L330,154 L337,258 L313,258 Z" fill="#fff6dc" className="seq" />
          <Screw x={298} y={150} r={2.3} />
          <Screw x={338} y={266} r={2.2} />

          {/* ===== GRIP ===== */}
          <path d="M108,138 L192,138 L180,182 Q168,226 166,260 Q165,278 148,280 L104,280 Q88,278 90,262 Q96,232 94,206 Q92,174 108,138 Z" fill="url(#p3-grip)" stroke={OL} strokeWidth="2.2" strokeLinejoin="round" />
          <path d="M108,138 Q88,146 82,160 Q96,158 104,152 Z" fill="url(#p3-frame)" stroke={OL} strokeWidth="1.8" strokeLinejoin="round" />
          <path d="M114,160 L176,156 Q162,200 156,234 Q152,258 146,266 L108,266 Q104,240 106,214 Q106,184 114,160 Z" fill="url(#p3-panel)" stroke={OL} strokeWidth="1.4" />
          <path d="M114,160 L176,156 Q162,200 156,234 Q152,258 146,266 L108,266 Q104,240 106,214 Q106,184 114,160 Z" fill="url(#p3-tex)" />
          {/* curved orange ribs following front edge */}
          {[0, 1, 2].map((i) => {
            const y = 176 + i * 27;
            const d = `M${128 - i * 4},${y + 14} Q${146 - i * 4},${y - 2} ${172 - i * 6},${y - 6}`;
            return (
              <g key={i}>
                <path d={d} stroke={OL} strokeWidth="11" fill="none" strokeLinecap="round" />
                <path d={d} stroke="url(#p3-neonH)" strokeWidth="6.5" fill="none" strokeLinecap="round" filter="url(#p3-glow)" className="pulse" style={{ animationDelay: `${i * 0.25}s` }} />
                <path d={d} stroke="#fff6d0" strokeWidth="1.6" fill="none" strokeLinecap="round" opacity="0.85" transform="translate(0 -1.5)" />
                <path d={d} stroke="#fff6dc" strokeWidth="6.5" fill="none" strokeLinecap="round" className="seq" style={{ animationDelay: `${i * 0.05}s` }} />
              </g>
            );
          })}
          <path d="M100,160 Q98,212 98,264" stroke="#c3c8d3" strokeWidth="2" fill="none" opacity="0.6" />
          <path d="M94,270 L166,270 Q166,284 152,286 L100,286 Q88,284 94,270 Z" fill="url(#p3-chrome)" stroke={OL} strokeWidth="1.6" />

          {/* trigger guard + trigger */}
          <path d="M192,144 L186,196 Q185,216 206,216 L296,212" fill="none" stroke={OL} strokeWidth="9.5" strokeLinecap="round" strokeLinejoin="round" />
          <path d="M192,144 L186,196 Q185,216 206,216 L296,212" fill="none" stroke="url(#p3-frame)" strokeWidth="6" strokeLinecap="round" strokeLinejoin="round" />
          <path d="M190,150 L185,196" stroke="#d6dae2" strokeWidth="1.2" opacity="0.6" />
          <path d="M224,144 Q240,164 228,190" stroke={OL} strokeWidth="7.5" fill="none" strokeLinecap="round" />
          <path d="M224,144 Q240,164 228,190" stroke="url(#p3-chrome)" strokeWidth="4" fill="none" strokeLinecap="round" />

          {/* ===== FRAME ===== */}
          <path d="M84,120 L374,114 L374,138 L296,142 L192,146 L84,144 Z" fill="url(#p3-frame)" stroke={OL} strokeWidth="2.2" strokeLinejoin="round" />
          <path d="M88,124 L370,118" stroke="#c3c8d3" strokeWidth="1.2" opacity="0.6" />
          <path d="M198,134 L286,131" stroke={OL} strokeWidth="5" strokeLinecap="round" />
          <path d="M198,134 L286,131" stroke={OR} strokeWidth="2.4" strokeLinecap="round" filter="url(#p3-glow)" className="pulse" />
          {[300, 316, 332, 348].map((x, i) => (
            <rect key={x} x={x} y="126" width="11" height="6" rx="1.2" fill={i === 0 ? OR : "#111318"} stroke={OL} strokeWidth="0.6" opacity={i === 0 ? 0.9 : 1} />
          ))}

          {/* ===== MUZZLE (fixed) ===== */}
          <rect x="370" y="80" width="44" height="32" rx="7" fill="url(#p3-chrome)" stroke={OL} strokeWidth="2.2" />
          <rect x="382" y="78" width="6" height="36" rx="2" fill="url(#p3-frame)" stroke={OL} strokeWidth="1.2" />
          <rect x="394" y="78" width="4" height="36" rx="1.5" fill="url(#p3-frame)" stroke={OL} strokeWidth="1" />
          <rect x="374" y="84" width="36" height="3.5" rx="1.7" fill="#ffffff" opacity="0.8" />
          <circle cx={MZ[0] + 4} cy={MZ[1]} r="24" fill="url(#p3-halo)" opacity="0.8" className="pulse" />
          <ellipse cx={MZ[0]} cy={MZ[1]} rx="9" ry="17" fill="url(#p3-cap)" stroke={OL} strokeWidth="1.8" filter="url(#p3-glow)" />
          <ellipse cx={MZ[0] - 2} cy={MZ[1] - 6} rx="2.5" ry="5" fill="#ffffff" opacity="0.85" />

          {/* ===== SLIDE (recoils) ===== */}
          <g className="slide">
            <path d="M58,90 L84,64 L348,56 L378,70 L378,116 L58,122 Z" fill="url(#p3-slide)" stroke={OL} strokeWidth="2.2" strokeLinejoin="round" />
            {/* top bevel */}
            <path d="M84,64 L348,56 L362,64 L92,73 Z" fill="url(#p3-top)" stroke={OL} strokeWidth="1.2" strokeLinejoin="round" />
            {/* slanted orange vents on top-front */}
            {[0, 1, 2, 3, 4].map((i) => {
              const x = 250 + i * 19;
              return (
                <g key={i}>
                  <path d={`M${x + 8},60 L${x + 16},59.8 L${x + 6},80 L${x - 2},80.2 Z`} fill="#1a0902" stroke={OL} strokeWidth="1" strokeLinejoin="round" />
                  <path d={`M${x + 9},62 L${x + 14},61.8 L${x + 5.5},78 L${x + 0.5},78.2 Z`} fill="url(#p3-neon)" filter="url(#p3-glow)" className="pulse" style={{ animationDelay: `${i * 0.15}s` }} />
                  <path d={`M${x + 8},60 L${x + 16},59.8 L${x + 6},80 L${x - 2},80.2 Z`} fill="#fff6dc" className="seq" style={{ animationDelay: `${i * 0.05}s` }} />
                </g>
              );
            })}
            {/* long orange line */}
            <path d="M108,84 L240,80 L358,76" stroke={OL} strokeWidth="6" fill="none" strokeLinecap="round" strokeLinejoin="round" />
            <path d="M108,84 L240,80 L358,76" stroke="url(#p3-neonH)" strokeWidth="3" fill="none" strokeLinecap="round" strokeLinejoin="round" filter="url(#p3-glow)" />
            <path d="M108,84 L240,80 L358,76" stroke="#ffffff" strokeWidth="3.4" fill="none" className="flash" />
            {/* front face */}
            <path d="M362,64 L378,70 L378,116 L366,116 L366,70 Z" fill="#3a3f4a" stroke={OL} strokeWidth="1.2" strokeLinejoin="round" />
            {/* rear bevel */}
            <path d="M58,90 L84,64 L92,73 L68,94 Z" fill="#d6dae2" stroke={OL} strokeWidth="1.2" strokeLinejoin="round" />
            {/* dark recess panel */}
            <path d="M140,96 L366,90 L366,110 L140,114 Z" fill="url(#p3-recess)" stroke={OL} strokeWidth="1.4" strokeLinejoin="round" />
            <path d="M150,106 L232,104 L244,98 L358,95" stroke={OL} strokeWidth="5.5" fill="none" strokeLinejoin="round" strokeLinecap="round" />
            <path d="M150,106 L232,104 L244,98 L358,95" stroke="url(#p3-neon)" strokeWidth="2.8" fill="none" strokeLinejoin="round" strokeLinecap="round" filter="url(#p3-glow)" />
            <path d="M150,106 L232,104 L244,98 L358,95" stroke="#ffffff" strokeWidth="3" fill="none" className="flash" />
            <path d="M58,116 L376,110 L376,116 L58,122 Z" fill="#000" opacity="0.3" />
            {/* rear serrations */}
            {[74, 81, 88, 95, 102].map((x) => (
              <line key={x} x1={x} y1="94" x2={x - 3} y2="118" stroke={OL} strokeWidth="2.2" />
            ))}
            {/* rear sight & front sight */}
            <path d="M92,64 L104,56 L118,56 L118,64 Z" fill="url(#p3-frame)" stroke={OL} strokeWidth="1.4" strokeLinejoin="round" />
            <rect x="334" y="51" width="10" height="7" rx="1.5" fill="url(#p3-frame)" stroke={OL} strokeWidth="1.2" />
            <Screw x={134} y={78} />
            <Screw x={150} y={108} r={2.2} />
            {/* emblem */}
            <circle cx="112" cy="98" r="20" fill="url(#p3-chrome)" stroke={OL} strokeWidth="2" />
            <circle cx="112" cy="98" r="15" fill="#14161c" stroke={OL} strokeWidth="1.2" />
            <circle cx="112" cy="98" r="10.5" fill="none" stroke={OR} strokeWidth="6.5" opacity="0.45" filter="url(#p3-glow)" />
            <circle cx="112" cy="98" r="10.5" pathLength={100} fill="none" stroke="url(#p3-neon)" strokeWidth="3.6" className="ring-spin" />
            <circle cx="112" cy="98" r="4.5" fill="#fff2c8" filter="url(#p3-glow)" className="pulse-scale" />
            <path d="M99,89 A15,15 0 0 1 121,85" stroke="#ffffff" strokeWidth="1.6" fill="none" opacity="0.85" />
            <circle cx="112" cy="98" r="15" fill="#ffffff" className="flash" />
          </g>

          <g className="idle-zap" filter="url(#p3-glow)">
            <LiveBolt x1={MZ[0] + 4} y1={MZ[1] - 10} x2={MZ[0] + 4} y2={MZ[1] + 10} color={OR} n={4} amp={4} seed={3} width={0.8} />
          </g>
        </g>

        {/* ===== FIRING FX (no projectile) ===== */}
        <circle cx={MZ[0] + 8} cy={MZ[1]} r="72" fill="url(#p3-halo)" className="fx" />
        <polygon points={starBurst(MZ[0] + 14, MZ[1], 48, 12, 8)} fill="#ffb347" className="fx-quick" filter="url(#p3-glow)" />
        <polygon points={starBurst(MZ[0] + 10, MZ[1], 24, 7, 6)} fill="#ffffff" className="fx-quick" />
        {[0, 0.1, 0.2].map((d) => (
          <ellipse key={d} cx={MZ[0] + 10} cy={MZ[1]} rx="10" ry="24" fill="none" stroke="#ffc27a" strokeWidth="3" className="shock" style={{ animationDelay: `${d}s` }} />
        ))}
        <g className="fx" filter="url(#p3-glow)">
          <LiveBolt x1={MZ[0] + 4} y1={MZ[1]} x2={MZ[0] + 52} y2={MZ[1] - 22} color={OR} n={6} amp={8} seed={17} width={1.3} />
          <LiveBolt x1={MZ[0] + 4} y1={MZ[1]} x2={MZ[0] + 56} y2={MZ[1] + 18} color={OR} n={6} amp={8} seed={23} width={1.3} />
        </g>
        <Sparks cx={MZ[0] + 8} cy={MZ[1]} color="#ffb347" count={18} spread={80} seed={29} angleFrom={-1.3} angleTo={1.3} />
      </g>
    </svg>
  );
}
