import { BlurFilter, GlowFilter, LiveBolt, Sparks } from "./shared";

/** Faceted hexagonal crystal. Base at (x,y), points "up" before rotation (rot=90 → right, -90 → left). */
function Crystal({ x, y, len, w, rot, delay = 0 }: { x: number; y: number; len: number; w: number; rot: number; delay?: number }) {
  const h = w / 2;
  const q = w * 0.18;
  const s = len - w * 0.85;
  const sh = -s + w * 0.12;
  const b = w * 0.08;
  const outline = `${-h},0 ${-h},${sh} 0,${-len} ${h},${sh} ${h},0 ${q},${b} ${-q},${b}`;
  return (
    <g transform={`translate(${x} ${y}) rotate(${rot})`}>
      <polygon points={outline} fill="#b45cff" filter="url(#cv-soft)" className="pulse" style={{ animationDelay: `${delay * 4}s` }} />
      <polygon points={`${-h},0 ${-q},${b} ${-q},${-s} ${-h},${sh}`} fill="url(#cv-cL)" />
      <polygon points={`${-q},${b} ${q},${b} ${q},${-s} ${-q},${-s}`} fill="url(#cv-cC)" />
      <polygon points={`${q},${b} ${h},0 ${h},${sh} ${q},${-s}`} fill="url(#cv-cR)" />
      <polygon points={`${-h},${sh} ${-q},${-s} 0,${-len}`} fill="#c99dff" />
      <polygon points={`${-q},${-s} ${q},${-s} 0,${-len}`} fill="url(#cv-tC)" />
      <polygon points={`${q},${-s} ${h},${sh} 0,${-len}`} fill="#8a4ff0" />
      <line x1={0} y1={-s * 0.1} x2={0} y2={-s * 0.92} stroke="#ffffff" strokeWidth={w * 0.09} strokeLinecap="round" opacity={0.6} />
      <line x1={-h * 0.72} y1={-s * 0.25} x2={-h * 0.72} y2={-s * 0.78} stroke="#f3e6ff" strokeWidth={w * 0.05} strokeLinecap="round" opacity={0.55} />
      <circle cx={-q * 0.4} cy={-s * 0.94} r={w * 0.07} fill="#ffffff" />
      <line x1={-q} y1={b} x2={-q} y2={-s} stroke="#ffffff" strokeWidth={0.6} opacity={0.45} />
      <line x1={q} y1={b} x2={q} y2={-s} stroke="#ffffff" strokeWidth={0.6} opacity={0.3} />
      <polygon points={outline} fill="none" stroke="#f6eaff" strokeWidth={0.9} strokeOpacity={0.85} strokeLinejoin="round" />
      <polygon points={outline} fill="#ffffff" className="flash" style={{ animationDelay: `${delay}s` }} />
    </g>
  );
}

export default function CrystalBlaster() {
  return (
    <svg viewBox="10 20 530 280" className="w-full h-full overflow-visible">
      <defs>
        <linearGradient id="cv-chrome" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#3a2f5c" />
          <stop offset="0.08" stopColor="#d9d2f5" />
          <stop offset="0.2" stopColor="#ffffff" />
          <stop offset="0.34" stopColor="#a497d4" />
          <stop offset="0.55" stopColor="#40346a" />
          <stop offset="0.74" stopColor="#1a1330" />
          <stop offset="0.88" stopColor="#6a59a6" />
          <stop offset="1" stopColor="#221a3b" />
        </linearGradient>
        <linearGradient id="cv-chromeR" x1="0" y1="1" x2="0" y2="0">
          <stop offset="0" stopColor="#2a2145" />
          <stop offset="0.25" stopColor="#c9bff0" />
          <stop offset="0.5" stopColor="#5b4d8f" />
          <stop offset="1" stopColor="#120c22" />
        </linearGradient>
        <linearGradient id="cv-chromeH" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0" stopColor="#241b3d" />
          <stop offset="0.3" stopColor="#9b8fcc" />
          <stop offset="0.5" stopColor="#ffffff" />
          <stop offset="0.7" stopColor="#8d80c0" />
          <stop offset="1" stopColor="#1e1633" />
        </linearGradient>
        <linearGradient id="cv-blade" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#ffffff" />
          <stop offset="0.25" stopColor="#c6bce8" />
          <stop offset="0.6" stopColor="#4b3f78" />
          <stop offset="1" stopColor="#140e24" />
        </linearGradient>
        <linearGradient id="cv-grip" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0" stopColor="#3b3358" />
          <stop offset="0.35" stopColor="#1a1529" />
          <stop offset="1" stopColor="#07050c" />
        </linearGradient>
        <linearGradient id="cv-cL" x1="0" y1="1" x2="0" y2="0">
          <stop offset="0" stopColor="#3b0f7a" />
          <stop offset="1" stopColor="#9a62ff" />
        </linearGradient>
        <linearGradient id="cv-cC" x1="0" y1="1" x2="0" y2="0">
          <stop offset="0" stopColor="#5a1fc0" />
          <stop offset="0.55" stopColor="#b682ff" />
          <stop offset="1" stopColor="#f5eaff" />
        </linearGradient>
        <linearGradient id="cv-cR" x1="0" y1="1" x2="0" y2="0">
          <stop offset="0" stopColor="#24084f" />
          <stop offset="1" stopColor="#6d33d6" />
        </linearGradient>
        <linearGradient id="cv-tC" x1="0" y1="1" x2="0" y2="0">
          <stop offset="0" stopColor="#d7b8ff" />
          <stop offset="1" stopColor="#ffffff" />
        </linearGradient>
        <linearGradient id="cv-glass" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#e3c9ff" stopOpacity="0.75" />
          <stop offset="0.25" stopColor="#8f4dff" stopOpacity="0.55" />
          <stop offset="0.7" stopColor="#3a0d7a" stopOpacity="0.8" />
          <stop offset="1" stopColor="#1a0638" stopOpacity="0.95" />
        </linearGradient>
        <radialGradient id="cv-orb" cx="0.45" cy="0.45" r="0.6">
          <stop offset="0" stopColor="#ffffff" />
          <stop offset="0.18" stopColor="#ffe9ff" />
          <stop offset="0.42" stopColor="#d27bff" />
          <stop offset="0.75" stopColor="#7a1fe0" />
          <stop offset="1" stopColor="#2a0560" />
        </radialGradient>
        <radialGradient id="cv-halo">
          <stop offset="0" stopColor="#ffffff" />
          <stop offset="0.3" stopColor="#d58bff" stopOpacity="0.85" />
          <stop offset="1" stopColor="#7a1fff" stopOpacity="0" />
        </radialGradient>
        <GlowFilter id="cv-glow" std={3} />
        <BlurFilter id="cv-blur" std={22} />
        <filter id="cv-soft" x="-80%" y="-40%" width="260%" height="180%">
          <feGaussianBlur stdDeviation="5" />
        </filter>
      </defs>

      <ellipse cx="270" cy="150" rx="230" ry="95" fill="#8a3dff" opacity="0.3" filter="url(#cv-blur)" className="pulse" />

      <g transform="rotate(-6 270 150)">
        <g className="recoil">
          {/* rear crystal cluster */}
          <Crystal x={112} y={128} len={72} w={25} rot={-58} delay={0.02} />
          <Crystal x={124} y={122} len={56} w={20} rot={-26} delay={0.06} />
          <Crystal x={106} y={142} len={88} w={29} rot={-88} delay={0} />
          <Crystal x={110} y={158} len={66} w={24} rot={-120} delay={0.04} />
          <Crystal x={124} y={168} len={46} w={18} rot={-148} delay={0.08} />

          {/* top crystals */}
          <Crystal x={190} y={116} len={38} w={15} rot={-22} delay={0.1} />
          <Crystal x={232} y={114} len={44} w={16} rot={-4} delay={0.12} />
          <Crystal x={256} y={118} len={74} w={23} rot={14} delay={0.14} />

          {/* grip */}
          <path d="M148,168 L208,170 Q198,196 192,222 Q186,250 172,268 Q162,278 138,273 L120,268 Q106,262 113,247 Q130,212 148,168 Z" fill="url(#cv-chrome)" stroke="#0e0a18" strokeWidth="1.2" />
          <path d="M157,184 L194,186 Q186,210 180,232 Q174,252 163,261 L136,259 Q127,255 131,244 Q145,214 157,184 Z" fill="url(#cv-grip)" />
          {[200, 213, 226, 239, 251].map((y, i) => (
            <path key={y} d={`M${150 - i * 4},${y} L${188 - i * 3.5},${y + 1}`} stroke="#000" strokeWidth="3.2" strokeLinecap="round" opacity="0.85" />
          ))}
          {[204, 217, 230, 243].map((y, i) => (
            <path key={y} d={`M${150 - i * 4},${y} L${186 - i * 3.5},${y + 1}`} stroke="#5d5285" strokeWidth="1" strokeLinecap="round" opacity="0.6" />
          ))}
          <path d="M122,264 Q140,270 166,266" stroke="#ffffff" strokeWidth="1.5" opacity="0.4" fill="none" />

          {/* trigger guard + trigger */}
          <path d="M206,178 Q256,176 256,200 Q254,216 200,216" fill="none" stroke="#120c22" strokeWidth="8" strokeLinecap="round" />
          <path d="M206,178 Q256,176 256,200 Q254,216 200,216" fill="none" stroke="url(#cv-chromeR)" strokeWidth="5.5" strokeLinecap="round" />
          <path d="M216,182 Q232,194 222,208" stroke="url(#cv-chromeH)" strokeWidth="4.5" fill="none" strokeLinecap="round" />

          {/* lower housing */}
          <path d="M146,168 L334,166 Q344,178 330,188 L196,190 Q160,188 146,168 Z" fill="url(#cv-chromeR)" stroke="#0e0a18" />
          <path d="M200,186 L326,184" stroke="#c58bff" strokeWidth="1.2" opacity="0.6" />

          {/* main body */}
          <path d="M122,114 L252,112 L252,178 L122,176 Q88,172 88,145 Q88,118 122,114 Z" fill="url(#cv-chrome)" stroke="#0e0a18" strokeWidth="1.2" />
          <path d="M100,124 Q110,118 124,117 L250,115" stroke="#ffffff" strokeWidth="1.6" fill="none" opacity="0.8" />
          <path d="M96,166 Q106,172 124,173 L250,175" stroke="#c58bff" strokeWidth="1.5" fill="none" opacity="0.55" />
          <ellipse cx="94" cy="145" rx="6" ry="20" fill="#c77dff" opacity="0.5" filter="url(#cv-glow)" className="pulse" />
          <path d="M156,152 L196,150" stroke="#0e0a18" strokeWidth="2" />
          <path d="M156,156 L192,154" stroke="#d29bff" strokeWidth="1.4" filter="url(#cv-glow)" className="pulse" />

          <Crystal x={144} y={140} len={62} w={21} rot={-78} delay={0.03} />
          <rect x="136" y="110" width="16" height="70" rx="5" fill="url(#cv-chromeH)" stroke="#0e0a18" />
          <rect x="164" y="112" width="10" height="66" rx="4" fill="url(#cv-chromeH)" stroke="#0e0a18" opacity="0.9" />

          {/* top rail */}
          <path d="M236,111 L336,103 L352,103 L352,118 L236,121 Z" fill="url(#cv-blade)" stroke="#0e0a18" />
          <path d="M240,113 L340,105" stroke="#ffffff" strokeWidth="1.2" opacity="0.8" />

          {/* glass chamber with braided energy */}
          <rect x="250" y="123" width="90" height="44" rx="10" fill="#14062a" />
          <rect x="250" y="123" width="90" height="44" rx="10" fill="url(#cv-glass)" />
          <g filter="url(#cv-glow)">
            <path d="M252,145 Q263,124 274,145 T296,145 T318,145 T340,145" stroke="#e070ff" strokeWidth="3" fill="none" opacity="0.7" />
            <path d="M252,145 Q263,166 274,145 T296,145 T318,145 T340,145" stroke="#e070ff" strokeWidth="3" fill="none" opacity="0.7" />
            <path d="M252,145 Q263,124 274,145 T296,145 T318,145 T340,145" pathLength={100} stroke="#ffe3ff" strokeWidth="1.6" fill="none" className="braid" />
            <path d="M252,145 Q263,166 274,145 T296,145 T318,145 T340,145" pathLength={100} stroke="#ffe3ff" strokeWidth="1.6" fill="none" className="braid" style={{ animationDelay: "-0.7s" }} />
            <path d="M252,135 Q274,155 296,135 T340,135" stroke="#b56bff" strokeWidth="1" fill="none" opacity="0.7" />
            <path d="M252,155 Q274,135 296,155 T340,155" stroke="#b56bff" strokeWidth="1" fill="none" opacity="0.7" />
          </g>
          <g className="seq" filter="url(#cv-glow)">
            <path d="M252,145 Q263,124 274,145 T296,145 T318,145 T340,145" stroke="#ffffff" strokeWidth="3" fill="none" />
            <path d="M252,145 Q263,166 274,145 T296,145 T318,145 T340,145" stroke="#ffffff" strokeWidth="3" fill="none" />
          </g>
          <rect x="256" y="126" width="80" height="5" rx="2.5" fill="#ffffff" opacity="0.45" />
          <rect x="256" y="160" width="80" height="2" rx="1" fill="#e7b6ff" opacity="0.5" />
          <rect x="246" y="119" width="9" height="52" rx="3" fill="url(#cv-chromeH)" stroke="#0e0a18" />

          {/* collar */}
          <path d="M336,116 L366,114 Q374,114 374,122 L374,168 Q374,176 366,176 L336,174 Z" fill="url(#cv-chrome)" stroke="#0e0a18" strokeWidth="1.2" />
          <rect x="346" y="115" width="4" height="60" fill="#120c22" opacity="0.7" />
          <rect x="358" y="114" width="4" height="62" fill="#120c22" opacity="0.7" />
          <path d="M338,119 L370,117" stroke="#ffffff" strokeWidth="1.4" opacity="0.8" />
          <rect x="370" y="122" width="6" height="46" rx="3" fill="#d58bff" opacity="0.7" filter="url(#cv-glow)" className="pulse" />

          {/* claws */}
          <path d="M340,106 Q398,92 452,94 Q492,97 516,120 Q490,111 460,111 Q422,113 394,124 L364,124 Z" fill="url(#cv-blade)" stroke="#0e0a18" strokeWidth="1.2" strokeLinejoin="round" />
          <path d="M346,107 Q400,95 452,97 Q486,100 508,116" stroke="#ffffff" strokeWidth="1.5" fill="none" opacity="0.85" />
          <path d="M404,121 Q440,112 470,113" stroke="#c58bff" strokeWidth="1.2" fill="none" opacity="0.7" />
          <path d="M420,98 L432,84 L440,98 Z" fill="url(#cv-blade)" stroke="#0e0a18" strokeWidth="0.8" />
          <path d="M352,170 Q404,178 446,190 Q482,198 510,186 Q488,208 450,207 Q410,202 376,190 L350,184 Z" fill="url(#cv-blade)" stroke="#0e0a18" strokeWidth="1.2" strokeLinejoin="round" />
          <path d="M358,173 Q404,181 446,193 Q478,200 502,190" stroke="#ffffff" strokeWidth="1.3" fill="none" opacity="0.7" />
          <path d="M390,196 Q420,204 452,204" stroke="#c58bff" strokeWidth="1.2" fill="none" opacity="0.6" />

          {/* muzzle crystals (in front of claws) */}
          <Crystal x={374} y={131} len={58} w={22} rot={58} delay={0.18} />
          <Crystal x={374} y={159} len={58} w={22} rot={122} delay={0.2} />
          <Crystal x={374} y={138} len={50} w={18} rot={76} delay={0.22} />
          <Crystal x={374} y={145} len={86} w={32} rot={90} delay={0.16} />
          <path d="M368,118 L380,120 Q384,121 384,126 L384,164 Q384,169 380,170 L368,172 Z" fill="url(#cv-chromeH)" stroke="#0e0a18" />
          <rect x="374" y="122" width="3" height="46" fill="#ffffff" opacity="0.5" />

          {/* orb housing */}
          <circle cx="214" cy="145" r="43" fill="url(#cv-chrome)" stroke="#0e0a18" strokeWidth="1.5" />
          <circle cx="214" cy="145" r="36" fill="url(#cv-chromeR)" />
          <circle cx="214" cy="145" r="31" fill="#0d0718" />
          <path d="M184,124 A36,36 0 0 1 236,116" stroke="#ffffff" strokeWidth="2.2" fill="none" opacity="0.85" strokeLinecap="round" />
          <path d="M190,176 A36,36 0 0 0 244,168" stroke="#c58bff" strokeWidth="1.6" fill="none" opacity="0.7" strokeLinecap="round" />
          <g className="charge">
            <circle cx="214" cy="145" r="34" fill="url(#cv-halo)" opacity="0.75" className="pulse" />
            <circle cx="214" cy="145" r="27" fill="url(#cv-orb)" />
            <g filter="url(#cv-glow)">
              <LiveBolt x1={196} y1={140} x2={232} y2={152} color="#f0b8ff" n={5} amp={6} seed={2} width={0.8} />
              <LiveBolt x1={206} y1={128} x2={222} y2={164} color="#f0b8ff" n={5} amp={6} seed={7} width={0.8} />
            </g>
            <g className="star-spin">
              <path d="M214,121 L216.5,142.5 L238,145 L216.5,147.5 L214,169 L211.5,147.5 L190,145 L211.5,142.5 Z" fill="#ffffff" opacity="0.9" />
            </g>
            <circle cx="214" cy="145" r="7" fill="#ffffff" filter="url(#cv-glow)" className="pulse-scale" />
            <ellipse cx="204" cy="133" rx="8" ry="4" fill="#ffffff" opacity="0.65" transform="rotate(-35 204 133)" />
            <circle cx="214" cy="145" r="27" fill="#ffffff" className="flash" />
          </g>

          <g className="idle-zap" filter="url(#cv-glow)">
            <LiveBolt x1={514} y1={120} x2={508} y2={188} color="#c77dff" n={7} amp={8} seed={11} width={1} />
          </g>
          <circle cx="462" cy="145" r="7" fill="#ffffff" filter="url(#cv-glow)" className="pulse-scale" />
        </g>

        {/* firing fx (no projectile) */}
        <circle cx="440" cy="145" r="90" fill="url(#cv-halo)" className="fx" />
        <g className="fx" filter="url(#cv-glow)">
          <LiveBolt x1={514} y1={120} x2={508} y2={188} color="#c77dff" n={8} amp={12} seed={21} width={1.8} />
          <LiveBolt x1={460} y1={145} x2={514} y2={120} color="#e7b6ff" n={7} amp={9} seed={27} width={1.5} />
          <LiveBolt x1={460} y1={145} x2={508} y2={188} color="#e7b6ff" n={7} amp={9} seed={33} width={1.5} />
          <LiveBolt x1={460} y1={145} x2={540} y2={140} color="#b56bff" n={7} amp={10} seed={39} width={1.3} />
          <LiveBolt x1={242} y1={145} x2={372} y2={145} color="#d58bff" n={12} amp={9} seed={45} width={1} />
          <LiveBolt x1={40} y1={130} x2={112} y2={145} color="#c77dff" n={6} amp={10} seed={51} width={1} />
        </g>
        <circle cx="460" cy="145" r="20" fill="#ffffff" className="fx-quick" filter="url(#cv-glow)" />
        {[0, 0.14, 0.28].map((d) => (
          <circle key={d} cx="440" cy="145" r="24" fill="none" stroke="#e0a8ff" strokeWidth="3" className="shock" style={{ animationDelay: `${d}s` }} />
        ))}
        <circle cx="214" cy="145" r="30" fill="none" stroke="#ffffff" strokeWidth="2.5" className="shock" />
        <Sparks cx={440} cy={145} color="#d29bff" count={20} spread={90} seed={5} />
        <Sparks cx={80} cy={140} color="#e8c8ff" count={10} spread={60} seed={8} />
        <Sparks cx={260} cy={60} color="#e8c8ff" count={8} spread={45} seed={14} />
      </g>
    </svg>
  );
}
