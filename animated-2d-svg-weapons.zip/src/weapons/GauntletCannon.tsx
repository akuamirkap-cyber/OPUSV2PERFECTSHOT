import { BlurFilter, Embers, Flame, FlameDefs, GlowFilter, Sparks } from "./shared";

const OL = "#2a1202";

/** raised (embossed) gold filigree line */
function Emboss({ d, w = 2.4 }: { d: string; w?: number }) {
  return (
    <g fill="none" strokeLinecap="round" strokeLinejoin="round">
      <path d={d} stroke="#5a3303" strokeWidth={w + 1.6} transform="translate(0.8 1)" opacity="0.8" />
      <path d={d} stroke="#e8a828" strokeWidth={w} />
      <path d={d} stroke="#fff4c4" strokeWidth={w * 0.4} transform="translate(-0.5 -0.7)" />
    </g>
  );
}

function Gem({ x, y, s = 1, d = 0 }: { x: number; y: number; s?: number; d?: number }) {
  const o = `${x},${y - 18 * s} ${x + 14 * s},${y} ${x},${y + 18 * s} ${x - 14 * s},${y}`;
  const i = `${x},${y - 11 * s} ${x + 8.5 * s},${y} ${x},${y + 11 * s} ${x - 8.5 * s},${y}`;
  return (
    <g>
      <polygon points={o} fill="url(#gc-gold)" stroke={OL} strokeWidth="1.6" strokeLinejoin="round" />
      <polygon points={`${x},${y - 18 * s} ${x + 14 * s},${y} ${x + 8.5 * s},${y} ${x},${y - 11 * s}`} fill="#fff2b8" opacity="0.5" />
      <polygon points={i} fill="url(#gc-gem)" stroke={OL} strokeWidth="1" />
      <polygon points={`${x},${y - 11 * s} ${x + 8.5 * s},${y} ${x},${y}`} fill="#ff9a9a" opacity="0.7" />
      <polygon points={`${x},${y} ${x - 8.5 * s},${y} ${x},${y + 11 * s}`} fill="#4a0004" opacity="0.5" />
      <polygon points={`${x - 3.5 * s},${y - 4 * s} ${x},${y - 8 * s} ${x - 1 * s},${y - 1.5 * s}`} fill="#ffffff" />
      <polygon points={i} fill="#fff2f2" className="flash" style={{ animationDelay: `${d}s` }} />
    </g>
  );
}

/** cylinder band with curved edges */
function Band({ x, t = 106, b = 214, w = 13, d = 0 }: { x: number; t?: number; b?: number; w?: number; d?: number }) {
  const m = (t + b) / 2;
  const path = `M${x},${t} L${x + w},${t} Q${x + w + 7},${m} ${x + w},${b} L${x},${b} Q${x + 7},${m} ${x},${t} Z`;
  return (
    <g>
      <path d={path} fill="url(#gc-gold)" stroke={OL} strokeWidth="1.8" strokeLinejoin="round" />
      <path d={`M${x + w * 0.35},${t + 3} Q${x + w * 0.35 + 7},${m} ${x + w * 0.35},${b - 3}`} stroke="#fff6c8" strokeWidth={w * 0.18} fill="none" opacity="0.7" />
      <circle cx={x + w / 2 + 3} cy={m} r={w * 0.26} fill="url(#gc-gem)" stroke={OL} strokeWidth="1" />
      {[t + 14, b - 14].map((y) => (
        <circle key={y} cx={x + w / 2 + 1.5} cy={y} r="1.6" fill="#fff2b8" stroke="#7a4a06" strokeWidth="0.5" />
      ))}
      <path d={path} fill="#fff6c8" className="seq" style={{ animationDelay: `${d}s` }} />
    </g>
  );
}

export default function GauntletCannon() {
  // perforations on bell shroud (cylinder perspective: squash near top/bottom)
  const holes: { x: number; y: number; ry: number; i: number }[] = [];
  const cols = [338, 354, 370, 386];
  cols.forEach((x, c) => {
    const ys = c % 2 ? [122, 146, 172, 198] : [110, 134, 160, 186, 210];
    ys.forEach((y, r) => {
      const half = 52 + c * 2;
      const k = Math.max(0.2, Math.sqrt(1 - Math.pow((y - 160) / (half + 6), 2)));
      holes.push({ x, y, ry: 6 * k, i: c * 5 + r });
    });
  });

  return (
    <svg viewBox="10 30 460 290" className="w-full h-full overflow-visible">
      <defs>
        <linearGradient id="gc-gold" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#6b3e04" />
          <stop offset="0.14" stopColor="#fff4c4" />
          <stop offset="0.36" stopColor="#f6bd38" />
          <stop offset="0.7" stopColor="#b06c0a" />
          <stop offset="0.9" stopColor="#5a3303" />
          <stop offset="1" stopColor="#c48a1e" />
        </linearGradient>
        <linearGradient id="gc-goldD" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#fff2b8" />
          <stop offset="0.45" stopColor="#e3a020" />
          <stop offset="1" stopColor="#5a3303" />
        </linearGradient>
        <linearGradient id="gc-red" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#4a0204" />
          <stop offset="0.14" stopColor="#ff9a9a" />
          <stop offset="0.32" stopColor="#e2262c" />
          <stop offset="0.7" stopColor="#8a060c" />
          <stop offset="1" stopColor="#3a0103" />
        </linearGradient>
        <radialGradient id="gc-gem" cx="0.4" cy="0.35" r="0.7">
          <stop offset="0" stopColor="#ffd6d6" />
          <stop offset="0.35" stopColor="#ff2a3a" />
          <stop offset="1" stopColor="#6a0006" />
        </radialGradient>
        <radialGradient id="gc-hole">
          <stop offset="0" stopColor="#fff2a0" />
          <stop offset="0.4" stopColor="#ff8a1f" />
          <stop offset="0.8" stopColor="#5a1a00" />
          <stop offset="1" stopColor="#1a0600" />
        </radialGradient>
        <radialGradient id="gc-mouth" cx="0.5" cy="0.5" r="0.5">
          <stop offset="0" stopColor="#ffffff" />
          <stop offset="0.25" stopColor="#fff2a0" />
          <stop offset="0.55" stopColor="#ffa21f" />
          <stop offset="0.85" stopColor="#e04400" />
          <stop offset="1" stopColor="#5a1000" />
        </radialGradient>
        <radialGradient id="gc-halo">
          <stop offset="0" stopColor="#fff2b0" />
          <stop offset="0.35" stopColor="#ff8a1f" stopOpacity="0.8" />
          <stop offset="1" stopColor="#ff3d00" stopOpacity="0" />
        </radialGradient>
        <radialGradient id="gc-smoke">
          <stop offset="0" stopColor="#e3dfe9" stopOpacity="0.8" />
          <stop offset="1" stopColor="#8d88a3" stopOpacity="0" />
        </radialGradient>
        <pattern id="gc-damask" width="20" height="20" patternUnits="userSpaceOnUse">
          <polygon points="10,3 14,10 10,17 6,10" fill="#ffcf5a" opacity="0.22" />
          <circle cx="0" cy="0" r="1.6" fill="#ffcf5a" opacity="0.3" />
          <circle cx="20" cy="20" r="1.6" fill="#ffcf5a" opacity="0.3" />
        </pattern>
        <FlameDefs id="gc-f" />
        <GlowFilter id="gc-glow" std={2.6} />
        <BlurFilter id="gc-blur" std={20} />
      </defs>

      <ellipse cx="240" cy="175" rx="210" ry="95" fill="#ff7a1a" opacity="0.2" filter="url(#gc-blur)" className="pulse" />

      <g transform="rotate(-14 240 170)">
        <g className="recoil">
          {/* ===== TOP PIPES (behind) ===== */}
          <path d="M150,110 L150,86 Q150,78 158,78 L294,78 Q302,78 302,86 L302,114" stroke={OL} strokeWidth="12" fill="none" strokeLinejoin="round" />
          <path d="M150,110 L150,86 Q150,78 158,78 L294,78 Q302,78 302,86 L302,114" stroke="url(#gc-goldD)" strokeWidth="7.5" fill="none" strokeLinejoin="round" />
          <path d="M154,84 L296,82" stroke="#fff6c8" strokeWidth="1.6" opacity="0.8" />
          <path d="M318,110 L318,92 Q318,86 324,86 L348,86 L348,106" stroke={OL} strokeWidth="10" fill="none" strokeLinejoin="round" />
          <path d="M318,110 L318,92 Q318,86 324,86 L348,86 L348,106" stroke="url(#gc-goldD)" strokeWidth="6" fill="none" strokeLinejoin="round" />
          {[178, 228, 274].map((x) => (
            <g key={x}>
              <rect x={x - 6} y="71" width="12" height="14" rx="2.5" fill="url(#gc-gold)" stroke={OL} strokeWidth="1.3" />
              <circle cx={x} cy="78" r="2" fill="url(#gc-gem)" />
            </g>
          ))}

          {/* ===== GRIP ===== */}
          <path d="M138,200 L202,200 Q190,230 196,260 Q200,286 186,296 L150,298 Q132,296 135,278 Q142,240 138,200 Z" fill="url(#gc-goldD)" stroke={OL} strokeWidth="2.2" strokeLinejoin="round" />
          <path d="M150,208 L190,208 Q180,234 184,260 Q186,278 178,286 L156,287 Q148,284 150,274 Q155,238 150,208 Z" fill="url(#gc-red)" stroke={OL} strokeWidth="1.4" />
          <path d="M150,208 L190,208 Q180,234 184,260 Q186,278 178,286 L156,287 Q148,284 150,274 Q155,238 150,208 Z" fill="url(#gc-damask)" />
          <Emboss d="M158,226 C166,216 180,222 174,234 C170,240 160,238 164,230" w={1.6} />
          <Emboss d="M160,258 C168,250 182,256 176,268" w={1.6} />
          <path d="M142,206 Q146,240 140,282" stroke="#fff6c8" strokeWidth="1.6" fill="none" opacity="0.7" />
          <ellipse cx="168" cy="298" rx="24" ry="7.5" fill="url(#gc-gold)" stroke={OL} strokeWidth="1.8" />
          <circle cx="168" cy="298" r="4.5" fill="url(#gc-gem)" stroke={OL} strokeWidth="0.8" />
          {/* trigger guard */}
          <path d="M200,206 Q244,206 246,230 Q244,248 204,246" fill="none" stroke={OL} strokeWidth="8.5" strokeLinecap="round" />
          <path d="M200,206 Q244,206 246,230 Q244,248 204,246" fill="none" stroke="url(#gc-goldD)" strokeWidth="5" strokeLinecap="round" />
          <path d="M210,208 Q222,220 214,236" stroke={OL} strokeWidth="6.5" fill="none" strokeLinecap="round" />
          <path d="M210,208 Q222,220 214,236" stroke="url(#gc-goldD)" strokeWidth="3.6" fill="none" strokeLinecap="round" />

          {/* ===== REAR FLARED CAP ===== */}
          <path d="M74,108 Q54,108 46,120 L36,122 Q26,160 36,198 L46,200 Q54,212 74,212 Z" fill="url(#gc-gold)" stroke={OL} strokeWidth="2.2" strokeLinejoin="round" />
          <path d="M36,122 Q26,160 36,198" stroke="#5a3303" strokeWidth="2" fill="none" />
          <Emboss d="M56,128 C46,140 46,180 56,192" w={1.8} />
          <circle cx="56" cy="160" r="10" fill="url(#gc-gold)" stroke={OL} strokeWidth="1.6" />
          <circle cx="56" cy="160" r="7" fill="url(#gc-gem)" stroke={OL} strokeWidth="1" />
          <circle cx="53.5" cy="157" r="2.2" fill="#ffffff" />

          {/* ===== RED SECTION ===== */}
          <rect x="70" y="110" width="146" height="100" rx="6" fill="url(#gc-red)" stroke={OL} strokeWidth="2.2" />
          <rect x="70" y="110" width="146" height="100" rx="6" fill="url(#gc-damask)" />
          <rect x="72" y="110" width="142" height="8" fill="url(#gc-gold)" stroke={OL} strokeWidth="1" />
          <rect x="72" y="202" width="142" height="8" fill="url(#gc-gold)" stroke={OL} strokeWidth="1" />
          <path d="M80,124 L208,124" stroke="#ffd6d6" strokeWidth="3" opacity="0.55" strokeLinecap="round" />
          <Gem x={108} y={160} s={1.15} d={0.12} />
          <Gem x={176} y={160} s={1.15} d={0.08} />
          <Emboss d="M90,140 L96,146 M90,180 L96,174 M126,140 L120,146 M126,180 L120,174" w={1.4} />
          <Emboss d="M158,140 L164,146 M158,180 L164,174 M194,140 L188,146 M194,180 L188,174" w={1.4} />

          {/* ===== GOLD SECTION ===== */}
          <rect x="212" y="112" width="114" height="96" rx="6" fill="url(#gc-gold)" stroke={OL} strokeWidth="2.2" />
          <path d="M218,120 L320,120" stroke="#fff6c8" strokeWidth="2.6" opacity="0.8" strokeLinecap="round" />
          <Emboss d="M226,148 C230,130 252,128 256,144 C258,154 246,158 242,150" />
          <Emboss d="M256,144 C262,128 286,128 292,144 C296,156 282,162 276,152" />
          <Emboss d="M226,172 C230,190 252,192 256,176 C258,166 246,162 242,170" />
          <Emboss d="M256,176 C262,192 286,192 292,176 C296,164 282,158 276,168" />
          <Emboss d="M292,144 C304,136 314,146 310,160 C314,174 304,184 292,176" w={1.8} />
          <ellipse cx="256" cy="160" rx="9" ry="12" fill="url(#gc-gold)" stroke={OL} strokeWidth="1.4" />
          <ellipse cx="256" cy="160" rx="6.5" ry="9" fill="url(#gc-gem)" stroke={OL} strokeWidth="1" />
          <ellipse cx="254" cy="156" rx="1.8" ry="2.6" fill="#ffffff" />
          <ellipse cx="256" cy="160" rx="6.5" ry="9" fill="#fff2f2" className="flash" style={{ animationDelay: "0.04s" }} />

          <Band x={64} d={0.3} />
          <Band x={132} w={10} d={0.22} />
          <Band x={206} d={0.15} />
          <Band x={320} t={102} b={218} w={14} d={0.06} />

          {/* ===== BELL MUZZLE SHROUD ===== */}
          <path d="M332,106 Q370,102 408,92 L408,228 Q370,218 332,214 Z" fill="url(#gc-gold)" stroke={OL} strokeWidth="2.2" strokeLinejoin="round" />
          <path d="M336,112 Q370,108 404,98" stroke="#fff6c8" strokeWidth="2.6" fill="none" opacity="0.8" strokeLinecap="round" />
          {holes.map((h) => (
            <g key={h.i}>
              <ellipse cx={h.x} cy={h.y} rx="6.2" ry={h.ry + 0.8} fill="#2a0e02" stroke={OL} strokeWidth="1" />
              <ellipse cx={h.x + 0.6} cy={h.y + 0.4} rx="4.4" ry={h.ry * 0.75} fill="url(#gc-hole)" className="pulse" style={{ animationDelay: `${(h.i % 5) * 0.3}s` }} />
              <path d={`M${h.x - 6},${h.y - h.ry * 0.3} A6.2,${h.ry + 0.8} 0 0 1 ${h.x + 4},${h.y - h.ry}`} stroke="#fff4c4" strokeWidth="0.9" fill="none" opacity="0.8" />
              <ellipse cx={h.x} cy={h.y} rx="6" ry={h.ry + 0.6} fill="#fff6c0" className="seq" filter="url(#gc-glow)" style={{ animationDelay: `${h.i * 0.02}s` }} />
            </g>
          ))}

          {/* mouth */}
          <ellipse cx="408" cy="160" rx="16" ry="68" fill="url(#gc-gold)" stroke={OL} strokeWidth="2.2" />
          <ellipse cx="409" cy="160" rx="12" ry="58" fill="#3a0e00" stroke={OL} strokeWidth="1.2" />
          <ellipse cx="410" cy="160" rx="10" ry="52" fill="url(#gc-mouth)" filter="url(#gc-glow)" className="pulse" />
          <path d="M398,100 Q392,130 394,160" stroke="#fff6c8" strokeWidth="2" fill="none" opacity="0.8" strokeLinecap="round" />

          {/* idle flame curling upward */}
          <Flame id="gc-f" x={412} y={150} rot={62} w={48} h={78} className="grow" />
        </g>

        {/* ===== FIRING FX (no projectile) ===== */}
        <Flame id="gc-f" x={414} y={160} rot={90} w={100} h={180} className="fire-burst" />
        <Flame id="gc-f" x={414} y={138} rot={68} w={44} h={96} className="fire-burst" style={{ animationDelay: "0.06s" }} />
        <Flame id="gc-f" x={414} y={182} rot={112} w={44} h={96} className="fire-burst" style={{ animationDelay: "0.1s" }} />
        <circle cx="426" cy="160" r="84" fill="url(#gc-halo)" className="fx" />
        {[0, 0.12, 0.24].map((d) => (
          <ellipse key={d} cx="414" cy="160" rx="16" ry="66" fill="none" stroke="#ffcf5a" strokeWidth="3" className="shock" style={{ animationDelay: `${d}s` }} />
        ))}
        {[
          [360, 92, 0.2],
          [384, 86, 0.3],
          [414, 96, 0.15],
          [424, 214, 0.35],
        ].map(([x, y, d], i) => (
          <circle key={i} cx={x} cy={y} r="15" fill="url(#gc-smoke)" className="smoke" style={{ animationDelay: `${d}s` }} />
        ))}
        <Sparks cx={418} cy={160} color="#ffcf5a" count={22} spread={100} seed={51} angleFrom={-1.3} angleTo={1.3} />
      </g>

      <Embers x={420} y={90} count={14} spreadX={90} rise={80} seed={9} />
    </svg>
  );
}
