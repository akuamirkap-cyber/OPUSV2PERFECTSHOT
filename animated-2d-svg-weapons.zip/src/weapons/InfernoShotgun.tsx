import { GlowFilter, BlurFilter, Sparks } from "./shared";

const COILS = Array.from({ length: 9 }, (_, i) => 296 + i * 9);
const LIGHTS = [178, 192, 206, 220, 234];

function star(cx: number, cy: number, r1: number, r2: number, n: number) {
  const pts: string[] = [];
  for (let i = 0; i < n * 2; i++) {
    const r = i % 2 === 0 ? r1 : r2;
    const a = (Math.PI * i) / n;
    pts.push(`${(cx + Math.cos(a) * r * (i % 4 === 0 ? 1.25 : 1)).toFixed(1)},${(cy + Math.sin(a) * r * 0.75).toFixed(1)}`);
  }
  return pts.join(" ");
}

export default function InfernoShotgun() {
  return (
    <svg viewBox="0 0 460 320" className="w-full h-full overflow-visible">
      <defs>
        <linearGradient id="s-steel" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#5e6170" />
          <stop offset="0.18" stopColor="#f4f5fa" />
          <stop offset="0.4" stopColor="#b7bac8" />
          <stop offset="0.7" stopColor="#6c6f80" />
          <stop offset="1" stopColor="#2a2c36" />
        </linearGradient>
        <linearGradient id="s-dark" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#5a5c68" />
          <stop offset="0.3" stopColor="#9a9cab" />
          <stop offset="0.6" stopColor="#3a3c47" />
          <stop offset="1" stopColor="#15161c" />
        </linearGradient>
        <linearGradient id="s-wood" x1="0" y1="0" x2="0.3" y2="1">
          <stop offset="0" stopColor="#e58a3c" />
          <stop offset="0.3" stopColor="#b9581b" />
          <stop offset="0.7" stopColor="#8a3a0e" />
          <stop offset="1" stopColor="#4f1d05" />
        </linearGradient>
        <linearGradient id="s-copper" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#5a2306" />
          <stop offset="0.25" stopColor="#ffb27a" />
          <stop offset="0.5" stopColor="#d4691f" />
          <stop offset="0.8" stopColor="#8a3a0c" />
          <stop offset="1" stopColor="#3d1603" />
        </linearGradient>
        <pattern id="s-holes" width="12" height="10" patternUnits="userSpaceOnUse" x="262" y="128">
          <circle cx="3" cy="2.5" r="2.4" fill="#16171e" />
          <circle cx="9" cy="7.5" r="2.4" fill="#16171e" />
          <circle cx="2.4" cy="1.9" r="0.8" fill="#000" />
        </pattern>
        <radialGradient id="s-fire">
          <stop offset="0" stopColor="#ffffff" />
          <stop offset="0.25" stopColor="#fff2a8" />
          <stop offset="0.55" stopColor="#ff9a1f" />
          <stop offset="1" stopColor="#ff3d00" stopOpacity="0" />
        </radialGradient>
        <radialGradient id="s-smoke">
          <stop offset="0" stopColor="#d9d6e6" stopOpacity="0.8" />
          <stop offset="1" stopColor="#8d88a3" stopOpacity="0" />
        </radialGradient>
        <GlowFilter id="s-glow" std={3} />
        <BlurFilter id="s-blur" std={16} />
      </defs>

      <ellipse cx="230" cy="160" rx="190" ry="70" fill="#ff7a2b" opacity="0.15" filter="url(#s-blur)" transform="rotate(-28 230 160)" className="pulse" />

      <g transform="rotate(-28 230 160)">
        <g className="recoil">
          {/* ===== STOCK ===== */}
          <path d="M28,146 L172,158 L172,188 Q160,192 152,202 Q140,216 118,212 L28,228 Z" fill="url(#s-wood)" stroke="#3a1403" strokeWidth="1.5" />
          <path d="M34,152 L168,163" stroke="#ffc58a" strokeWidth="2" opacity="0.6" />
          {/* wood grain */}
          <path d="M40,170 Q90,166 150,176" stroke="#5a2207" strokeWidth="1" fill="none" opacity="0.5" />
          <path d="M40,200 Q80,190 128,198" stroke="#5a2207" strokeWidth="1" fill="none" opacity="0.5" />
          <path d="M50,214 Q90,205 120,206" stroke="#5a2207" strokeWidth="1" fill="none" opacity="0.4" />
          {/* swirl ornament */}
          <g stroke="#2b1003" strokeWidth="3.5" fill="none" strokeLinecap="round">
            <path d="M58,196 C52,176 74,166 86,178 C96,190 82,202 74,194" />
            <path d="M86,178 C96,166 116,170 118,184 C120,198 106,204 100,196" />
            <path d="M118,184 C126,194 140,190 142,180" />
            <path d="M58,196 C62,206 72,208 78,204" />
          </g>
          {/* butt plate */}
          <path d="M14,144 L30,146 L30,229 L14,232 Q8,188 14,144 Z" fill="#1b1a20" />
          {[156, 170, 184, 198, 212, 224].map((y) => (
            <line key={y} x1="15" y1={y} x2="28" y2={y} stroke="#3a3944" strokeWidth="2" />
          ))}

          {/* ===== PUMP TUBE ===== */}
          <rect x="258" y="158" width="164" height="20" rx="8" fill="url(#s-dark)" />

          {/* ===== BARREL HEAT SHIELD ===== */}
          <rect x="258" y="126" width="176" height="32" rx="9" fill="url(#s-steel)" stroke="#2a2c36" />
          <rect x="262" y="128" width="168" height="28" rx="7" fill="url(#s-holes)" />
          <rect x="262" y="129" width="168" height="5" rx="2.5" fill="#fff" opacity="0.45" />
          <rect x="258" y="124" width="10" height="36" rx="3" fill="url(#s-dark)" />
          {/* muzzle */}
          <rect x="430" y="121" width="18" height="42" rx="5" fill="url(#s-dark)" stroke="#121218" />
          <rect x="433" y="125" width="3" height="34" fill="#c9cbd6" opacity="0.6" />
          <ellipse cx="447" cy="142" rx="2.5" ry="10" fill="#050507" />
          <g className="charge">
            <ellipse cx="447" cy="142" rx="2" ry="7" fill="#ff7a1a" opacity="0.6" className="pulse" />
          </g>

          {/* ===== PUMP with copper coils ===== */}
          <g className="pump">
            <rect x="288" y="154" width="94" height="28" rx="8" fill="url(#s-dark)" stroke="#121218" />
            {COILS.map((x, i) => (
              <g key={x}>
                <rect x={x} y="151" width="6.5" height="34" rx="3" fill="url(#s-copper)" stroke="#3d1603" strokeWidth="0.6" />
                <rect x={x + 1.2} y="153" width="1.6" height="30" rx="0.8" fill="#ffd6b0" opacity="0.7" />
                <rect x={x} y="151" width="6.5" height="34" rx="3" fill="#ffb347" className="seq" filter="url(#s-glow)" style={{ animationDelay: `${0.05 + i * 0.03}s` }} />
              </g>
            ))}
          </g>

          {/* ===== RECEIVER ===== */}
          <path d="M168,130 L262,128 L262,186 L244,190 L204,190 Q186,194 168,190 Z" fill="url(#s-steel)" stroke="#2a2c36" strokeWidth="1.2" />
          <path d="M172,134 L258,132" stroke="#fff" strokeWidth="2" opacity="0.7" />
          {/* side plate */}
          <rect x="178" y="146" width="72" height="30" rx="4" fill="url(#s-dark)" opacity="0.85" />
          {/* red light */}
          <rect x="186" y="155" width="40" height="9" rx="4.5" fill="#3a0505" />
          <rect x="188" y="156.5" width="36" height="6" rx="3" fill="#ff3b2f" filter="url(#s-glow)" className="pulse" />
          <rect x="186" y="155" width="40" height="9" rx="4.5" fill="#fff" className="flash" />
          {[184, 244].map((x) => (
            <g key={x}>
              <circle cx={x} cy="150" r="2.4" fill="#d6d8e2" stroke="#2a2c36" />
              <circle cx={x} cy="172" r="2.4" fill="#d6d8e2" stroke="#2a2c36" />
            </g>
          ))}
          <rect x="232" y="153" width="12" height="12" rx="2" fill="#1a1b22" />
          {/* shell lights */}
          {LIGHTS.map((x, i) => (
            <g key={x}>
              <rect x={x} y="135.5" width="9" height="7" rx="2" fill="#ff8a1f" filter="url(#s-glow)" className="pulse" style={{ animationDelay: `${i * 0.2}s` }} />
              <rect x={x} y="135.5" width="9" height="7" rx="2" fill="#fff6c8" className="seq" style={{ animationDelay: `${i * 0.08}s` }} />
            </g>
          ))}

          {/* trigger guard + trigger */}
          <path d="M202,190 Q204,214 226,214 Q246,212 246,190" fill="none" stroke="url(#s-dark)" strokeWidth="5.5" strokeLinecap="round" />
          <path d="M222,192 Q230,200 226,208" stroke="#c9cbd6" strokeWidth="4" fill="none" strokeLinecap="round" />
        </g>

        {/* ===== FIRING FX ===== */}
        <circle cx="462" cy="142" r="60" fill="url(#s-fire)" className="fx-quick" />
        <polygon points={star(470, 142, 46, 14, 8)} fill="#ffd24a" className="fx-quick" filter="url(#s-glow)" />
        <polygon points={star(462, 142, 26, 8, 6)} fill="#ffffff" className="fx-quick" />
        {[0, 0.1].map((d) => (
          <ellipse key={d} cx="456" cy="142" rx="14" ry="20" fill="none" stroke="#ffb347" strokeWidth="3" className="shock" style={{ animationDelay: `${d}s` }} />
        ))}
        <Sparks cx={456} cy={142} color="#ffb347" count={18} spread={70} seed={9} angleFrom={-1.2} angleTo={1.2} />
        {/* smoke from barrel holes */}
        {[
          [300, 122, 0.25],
          [340, 120, 0.35],
          [380, 122, 0.3],
          [420, 120, 0.45],
          [452, 132, 0.15],
          [462, 146, 0.25],
        ].map(([x, y, d], i) => (
          <circle key={i} cx={x} cy={y} r="12" fill="url(#s-smoke)" className="smoke" style={{ animationDelay: `${d}s` }} />
        ))}
      </g>
    </svg>
  );
}
