import { BlurFilter, Embers, Flame, FlameDefs, GlowFilter, Sparks } from "./shared";

function decal(x: number, y: number, s: number) {
  // flame decal pointing right
  return `M${x},${y} C${x + 8 * s},${y - 9 * s} ${x + 18 * s},${y - 4 * s} ${x + 26 * s},${y - 12 * s} C${x + 24 * s},${y - 4 * s} ${x + 34 * s},${y - 3 * s} ${x + 44 * s},${y - 8 * s} C${x + 38 * s},${y + 2 * s} ${x + 30 * s},${y + 8 * s} ${x + 14 * s},${y + 9 * s} C${x + 6 * s},${y + 9 * s} ${x},${y + 5 * s} ${x},${y} Z`;
}

export default function Flamethrower() {
  return (
    <svg viewBox="-10 -10 480 320" className="w-full h-full overflow-visible">
      <defs>
        <linearGradient id="ft-metal" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#4a4d5a" />
          <stop offset="0.18" stopColor="#b9bccb" />
          <stop offset="0.42" stopColor="#5d606e" />
          <stop offset="0.8" stopColor="#25262e" />
          <stop offset="1" stopColor="#0d0d11" />
        </linearGradient>
        <linearGradient id="ft-silver" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#5e6170" />
          <stop offset="0.25" stopColor="#ffffff" />
          <stop offset="0.5" stopColor="#b5b8c6" />
          <stop offset="1" stopColor="#3a3c47" />
        </linearGradient>
        <linearGradient id="ft-brass" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#5a3505" />
          <stop offset="0.22" stopColor="#ffe3a0" />
          <stop offset="0.5" stopColor="#c98a24" />
          <stop offset="0.85" stopColor="#6e4208" />
          <stop offset="1" stopColor="#331d02" />
        </linearGradient>
        <linearGradient id="ft-brassD" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#ffd98a" />
          <stop offset="0.45" stopColor="#b5761a" />
          <stop offset="1" stopColor="#4d2c02" />
        </linearGradient>
        <linearGradient id="ft-red" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#4a0402" />
          <stop offset="0.18" stopColor="#ff9a8a" />
          <stop offset="0.4" stopColor="#e3261b" />
          <stop offset="0.8" stopColor="#7a0a05" />
          <stop offset="1" stopColor="#2e0201" />
        </linearGradient>
        <linearGradient id="ft-decal" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0" stopColor="#ffe066" />
          <stop offset="0.6" stopColor="#ff9a1f" />
          <stop offset="1" stopColor="#ff5a00" />
        </linearGradient>
        <pattern id="ft-engrave" width="14" height="14" patternUnits="userSpaceOnUse">
          <path d="M2,7 C2,2 9,2 9,7 C9,10 5,10 5,7" stroke="#4d2c02" strokeWidth="1" fill="none" />
          <path d="M9,7 C9,12 14,12 14,7" stroke="#4d2c02" strokeWidth="1" fill="none" />
        </pattern>
        <radialGradient id="ft-halo">
          <stop offset="0" stopColor="#fff2b0" />
          <stop offset="0.35" stopColor="#ff8a1f" stopOpacity="0.8" />
          <stop offset="1" stopColor="#ff3d00" stopOpacity="0" />
        </radialGradient>
        <FlameDefs id="ft-f" />
        <FlameDefs id="ft-p" palette="blue" />
        <GlowFilter id="ft-glow" std={2.5} />
        <BlurFilter id="ft-blur" std={16} />
      </defs>

      <ellipse cx="220" cy="160" rx="180" ry="80" fill="#ff5a00" opacity="0.18" filter="url(#ft-blur)" className="pulse" />

      <g transform="rotate(-12 220 150)">
        <g className="recoil">
          {/* ===== hoses (behind) ===== */}
          <path d="M84,120 C86,64 236,62 266,116" stroke="#121216" strokeWidth="10" fill="none" strokeLinecap="round" />
          <path d="M84,120 C86,64 236,62 266,116" stroke="#4a4d5a" strokeWidth="10" fill="none" strokeDasharray="2 3" opacity="0.6" />
          <path d="M86,116 C90,70 230,68 262,112" stroke="#9a9dab" strokeWidth="1.5" fill="none" opacity="0.6" />
          <path d="M84,120 C86,64 236,62 266,116" stroke="#ff9a1f" strokeWidth="6" fill="none" className="seq" filter="url(#ft-glow)" />

          <path d="M74,178 C46,240 196,252 254,186" stroke="#121216" strokeWidth="11" fill="none" strokeLinecap="round" />
          <path d="M74,178 C46,240 196,252 254,186" stroke="#4a4d5a" strokeWidth="11" fill="none" strokeDasharray="2 3" opacity="0.6" />
          <path d="M74,178 C46,240 196,252 254,186" stroke="#ff9a1f" strokeWidth="6" fill="none" className="seq" filter="url(#ft-glow)" style={{ animationDelay: "0.1s" }} />

          {/* ===== grip ===== */}
          <path d="M98,174 L138,174 Q132,204 138,234 Q141,252 128,257 L104,258 Q93,254 96,238 Q102,206 98,174 Z" fill="url(#ft-brassD)" stroke="#331d02" strokeWidth="1.2" />
          <path d="M98,174 L138,174 Q132,204 138,234 Q141,252 128,257 L104,258 Q93,254 96,238 Q102,206 98,174 Z" fill="url(#ft-engrave)" opacity="0.8" />
          <path d="M104,182 Q102,214 106,246" stroke="#fff0c0" strokeWidth="2" fill="none" opacity="0.6" />
          <rect x="98" y="252" width="40" height="10" rx="4" fill="url(#ft-brass)" />

          {/* trigger guard */}
          <path d="M138,176 Q178,178 180,200 Q178,216 144,214" fill="none" stroke="url(#ft-brassD)" strokeWidth="5" strokeLinecap="round" />
          <path d="M144,180 Q156,190 150,204" stroke="url(#ft-silver)" strokeWidth="4.5" fill="none" strokeLinecap="round" />

          {/* ===== rear brass block ===== */}
          <rect x="48" y="118" width="64" height="62" rx="10" fill="url(#ft-brass)" stroke="#331d02" />
          <rect x="54" y="124" width="52" height="50" rx="6" fill="url(#ft-engrave)" />
          <rect x="54" y="124" width="52" height="50" rx="6" fill="none" stroke="#fff0c0" strokeOpacity="0.5" />
          <rect x="40" y="128" width="12" height="42" rx="5" fill="url(#ft-brass)" stroke="#331d02" />
          {[132, 166].map((y) => (
            <circle key={y} cx="60" cy={y} r="2.5" fill="#fff0c0" stroke="#4d2c02" />
          ))}

          {/* ===== main body ===== */}
          <path d="M106,110 L250,106 Q262,106 264,118 L264,162 Q262,172 250,172 L106,176 Z" fill="url(#ft-metal)" stroke="#0a0a0d" strokeWidth="1.2" />
          <path d="M110,113 L248,109" stroke="#fff" strokeWidth="2" opacity="0.5" />

          {/* green level gauge */}
          <rect x="124" y="122" width="64" height="20" rx="4" fill="#07120a" stroke="#2a2c36" strokeWidth="2" />
          {[0, 1, 2, 3, 4, 5].map((i) => (
            <rect key={i} x={128 + i * 10} y="126" width="7" height="12" rx="1.5" fill={i < 4 ? "#3dff6a" : "#1a5a2a"} filter={i < 4 ? "url(#ft-glow)" : undefined} className="pulse" style={{ animationDelay: `${i * 0.18}s` }} />
          ))}
          {[0, 1, 2, 3, 4, 5].map((i) => (
            <rect key={`s${i}`} x={128 + i * 10} y="126" width="7" height="12" rx="1.5" fill="#d9ffe0" className="seq" style={{ animationDelay: `${i * 0.06}s` }} />
          ))}

          {/* orange stripes */}
          {[200, 214, 228].map((x, i) => (
            <g key={x}>
              <path d={`M${x},112 L${x + 8},112 L${x + 2},144 L${x - 6},144 Z`} fill="#ff8a1f" filter="url(#ft-glow)" className="pulse" style={{ animationDelay: `${i * 0.3}s` }} />
              <path d={`M${x},112 L${x + 8},112 L${x + 2},144 L${x - 6},144 Z`} fill="#fff6c8" className="seq" style={{ animationDelay: `${i * 0.07}s` }} />
            </g>
          ))}
          {/* rivets */}
          {[118, 246].map((x) => (
            <g key={x}>
              <circle cx={x} cy="154" r="2.5" fill="#c9cbd6" stroke="#2a2c36" />
              <circle cx={x} cy="166" r="2.5" fill="#c9cbd6" stroke="#2a2c36" />
            </g>
          ))}

          {/* ===== barrel ===== */}
          <rect x="262" y="118" width="94" height="24" rx="6" fill="url(#ft-silver)" stroke="#2a2c36" />
          {[274, 288, 302, 316, 330].map((x) => (
            <rect key={x} x={x} y="116" width="6" height="28" rx="2" fill="url(#ft-metal)" />
          ))}
          {/* nozzle */}
          <path d="M354,116 L378,108 L378,152 L354,144 Z" fill="url(#ft-brass)" stroke="#331d02" />
          <rect x="376" y="106" width="8" height="48" rx="3" fill="url(#ft-brass)" stroke="#331d02" />
          <ellipse cx="384" cy="130" rx="2.5" ry="14" fill="#1a0a04" />

          {/* ===== red fuel tank ===== */}
          <rect x="250" y="148" width="116" height="50" rx="25" fill="url(#ft-red)" stroke="#2e0201" strokeWidth="1.2" />
          <path d={decal(266, 176, 1.25)} fill="url(#ft-decal)" />
          <path d={decal(300, 180, 0.9)} fill="url(#ft-decal)" opacity="0.9" />
          <path d={decal(266, 176, 1.25)} fill="#fff6c8" className="seq" filter="url(#ft-glow)" />
          <path d={decal(300, 180, 0.9)} fill="#fff6c8" className="seq" filter="url(#ft-glow)" style={{ animationDelay: "0.08s" }} />
          <rect x="262" y="153" width="92" height="5" rx="2.5" fill="#fff" opacity="0.4" />
          <rect x="246" y="150" width="12" height="46" rx="4" fill="url(#ft-brass)" stroke="#331d02" />
          <rect x="356" y="152" width="12" height="42" rx="4" fill="url(#ft-brass)" stroke="#331d02" />
          <path d="M366,164 L394,172 L366,182 Z" fill="url(#ft-brassD)" stroke="#331d02" />

          {/* pressure dial */}
          <circle cx="320" cy="203" r="12" fill="url(#ft-brass)" stroke="#331d02" />
          <circle cx="320" cy="203" r="9" fill="#f5f0e1" />
          {[-150, -110, -70, -30, 10].map((a) => {
            const rad = (a * Math.PI) / 180;
            return <line key={a} x1={320 + Math.cos(rad) * 6} y1={203 + Math.sin(rad) * 6} x2={320 + Math.cos(rad) * 8.5} y2={203 + Math.sin(rad) * 8.5} stroke={a > -40 ? "#e3261b" : "#333"} strokeWidth="1.2" />;
          })}
          <g transform="translate(320 203) rotate(-160)">
            <polygon points="0,-1.4 8,0 0,1.4" fill="#c4140c" className="needle" />
          </g>
          <circle cx="320" cy="203" r="1.8" fill="#333" />

          {/* pilot flame */}
          <Flame id="ft-p" x={386} y={130} rot={90} w={14} h={26} className="grow" />
        </g>

        {/* ===== FIRING FX: flame stream (no projectile) ===== */}
        <Flame id="ft-f" x={386} y={130} rot={90} w={70} h={150} className="fire-burst" />
        <Flame id="ft-f" x={386} y={130} rot={82} w={40} h={110} className="fire-burst" style={{ animationDelay: "0.08s" }} />
        <Flame id="ft-f" x={386} y={130} rot={98} w={40} h={105} className="fire-burst" style={{ animationDelay: "0.14s" }} />
        <circle cx="400" cy="130" r="60" fill="url(#ft-halo)" className="fx" />
        <ellipse cx="390" cy="130" rx="10" ry="26" fill="none" stroke="#ffd29a" strokeWidth="3" className="shock" />
        <Sparks cx={420} cy={130} color="#ffb02e" count={22} spread={100} seed={23} angleFrom={-1.1} angleTo={1.1} />
      </g>

      <Embers x={420} y={90} count={14} spreadX={110} rise={80} seed={3} />
    </svg>
  );
}
