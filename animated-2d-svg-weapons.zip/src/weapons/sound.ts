let ctx: AudioContext | null = null;

function ac() {
  if (!ctx) {
    const C = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    ctx = new C();
  }
  if (ctx.state === "suspended") ctx.resume();
  return ctx;
}

function tone(type: OscillatorType, f1: number, f2: number, dur: number, vol = 0.15, delay = 0) {
  const a = ac();
  const t = a.currentTime + delay;
  const o = a.createOscillator();
  const g = a.createGain();
  o.type = type;
  o.frequency.setValueAtTime(f1, t);
  o.frequency.exponentialRampToValueAtTime(Math.max(20, f2), t + dur);
  g.gain.setValueAtTime(0.0001, t);
  g.gain.exponentialRampToValueAtTime(vol, t + 0.015);
  g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
  o.connect(g).connect(a.destination);
  o.start(t);
  o.stop(t + dur + 0.05);
}

function noise(dur: number, vol = 0.3, filterFreq = 1200, delay = 0, type: BiquadFilterType = "lowpass") {
  const a = ac();
  const t = a.currentTime + delay;
  const len = Math.floor(a.sampleRate * dur);
  const buf = a.createBuffer(1, len, a.sampleRate);
  const d = buf.getChannelData(0);
  for (let i = 0; i < len; i++) d[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / len, 2);
  const src = a.createBufferSource();
  src.buffer = buf;
  const f = a.createBiquadFilter();
  f.type = type;
  f.frequency.value = filterFreq;
  const g = a.createGain();
  g.gain.value = vol;
  src.connect(f).connect(g).connect(a.destination);
  src.start(t);
}

export type WeaponSound = "crystal" | "tesla" | "shotgun" | "emerald" | "cyber" | "rpg" | "rpgvolt" | "lava" | "flame" | "sniper" | "beacon" | "phaser" | "gauntlet" | "holy";

export function playSound(kind: WeaponSound) {
  try {
    switch (kind) {
      case "crystal":
        tone("sine", 1400, 2600, 0.5, 0.08);
        tone("sine", 2100, 3200, 0.6, 0.05, 0.05);
        tone("triangle", 300, 80, 0.5, 0.15);
        noise(0.3, 0.12, 4000, 0, "highpass");
        break;
      case "tesla":
        tone("sawtooth", 120, 60, 0.5, 0.08);
        tone("square", 900, 200, 0.25, 0.04);
        noise(0.5, 0.18, 3000, 0, "bandpass");
        break;
      case "shotgun":
        noise(0.45, 0.6, 900);
        tone("sine", 120, 40, 0.35, 0.3);
        noise(0.05, 0.25, 3000, 0.45, "highpass");
        noise(0.05, 0.25, 2500, 0.65, "highpass");
        break;
      case "emerald":
        tone("sine", 300, 1200, 0.35, 0.12);
        tone("sine", 1200, 400, 0.6, 0.08, 0.2);
        tone("triangle", 600, 1800, 0.4, 0.05);
        break;
      case "rpg":
        noise(0.9, 0.5, 700);
        tone("sine", 90, 30, 0.7, 0.35);
        noise(1.2, 0.2, 2500, 0.05, "bandpass");
        break;
      case "rpgvolt":
        noise(0.8, 0.45, 800);
        tone("sine", 100, 30, 0.6, 0.3);
        tone("sawtooth", 1400, 300, 0.4, 0.05);
        noise(0.4, 0.15, 4000, 0.05, "bandpass");
        break;
      case "lava":
        noise(1.1, 0.45, 500);
        tone("sine", 70, 35, 0.9, 0.3);
        noise(0.8, 0.12, 3000, 0.1, "highpass");
        break;
      case "flame":
        noise(1.3, 0.4, 1400, 0, "bandpass");
        noise(1.2, 0.25, 400);
        tone("sine", 60, 45, 1.0, 0.15);
        break;
      case "sniper":
        noise(0.12, 0.7, 6000, 0, "highpass");
        tone("sine", 160, 40, 0.4, 0.35);
        noise(0.6, 0.12, 900, 0.08);
        noise(0.06, 0.2, 3000, 0.55, "highpass");
        noise(0.06, 0.2, 2500, 0.75, "highpass");
        break;
      case "beacon":
        tone("sine", 880, 880, 0.08, 0.1);
        tone("sine", 1320, 1320, 0.08, 0.1, 0.1);
        tone("sine", 1760, 1760, 0.1, 0.1, 0.2);
        tone("sine", 400, 1600, 0.6, 0.06, 0.05);
        noise(0.5, 0.15, 900, 0.05);
        break;
      case "phaser":
        tone("sawtooth", 1400, 160, 0.35, 0.07);
        tone("square", 700, 110, 0.3, 0.05);
        noise(0.12, 0.2, 4000, 0, "highpass");
        break;
      case "gauntlet":
        noise(1.0, 0.55, 600);
        tone("sine", 85, 30, 0.8, 0.35);
        noise(0.7, 0.15, 2200, 0.08, "bandpass");
        break;
      case "holy":
        [1046, 1318, 1568, 2093].forEach((f, i) => tone("sine", f, f, 1.0, 0.06, i * 0.07));
        tone("triangle", 523, 1046, 0.8, 0.07);
        noise(0.6, 0.06, 6000, 0, "highpass");
        break;
      case "cyber":
        tone("square", 1800, 200, 0.35, 0.06);
        tone("sawtooth", 400, 90, 0.4, 0.07);
        noise(0.25, 0.15, 5000, 0, "bandpass");
        break;
    }
  } catch {
    /* ignore */
  }
}
