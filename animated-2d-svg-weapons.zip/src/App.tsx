import { useCallback, useEffect, useMemo, useRef, useState, type ComponentType } from "react";
import CrystalBlaster from "./weapons/CrystalBlaster";
import TeslaStaff from "./weapons/TeslaStaff";
import InfernoShotgun from "./weapons/InfernoShotgun";
import EmeraldRayGun from "./weapons/EmeraldRayGun";
import CyberBlaster from "./weapons/CyberBlaster";
import { RpgVolt, RpgStar } from "./weapons/Rpg";
import LavaCannon from "./weapons/LavaCannon";
import Flamethrower from "./weapons/Flamethrower";
import CircuitSniper from "./weapons/CircuitSniper";
import OrbitalBeacon from "./weapons/OrbitalBeacon";
import PhaserType2 from "./weapons/PhaserType2";
import GauntletCannon from "./weapons/GauntletCannon";
import HolyLightGun from "./weapons/HolyLightGun";
import { playSound, type WeaponSound } from "./weapons/sound";

type Weapon = {
  id: string;
  name: string;
  type: string;
  rarity: string;
  desc: string;
  color: string;
  color2: string;
  sound: WeaponSound;
  Comp: ComponentType;
  stats: { label: string; value: number }[];
  rays?: boolean;
};

const WEAPONS: Weapon[] = [
  {
    id: "crystal",
    name: "Void Crystal Reaver",
    type: "Blaster Kristal",
    rarity: "MYTHIC",
    desc: "Kristal ametis kuno menyalurkan energi void ke inti orb lalu melepaskan badai petir ungu di antara cakarnya.",
    color: "#a855f7",
    color2: "#581c87",
    sound: "crystal",
    Comp: CrystalBlaster,
    stats: [
      { label: "Kekuatan", value: 92 },
      { label: "Energi", value: 98 },
      { label: "Kecepatan", value: 64 },
    ],
  },
  {
    id: "tesla",
    name: "Tesla Storm Scepter",
    type: "Tongkat Petir",
    rarity: "LEGENDARY",
    desc: "Kumparan emas berputar mengalirkan listrik biru menuju garpu tesla yang memercikkan busur petir.",
    color: "#3b82f6",
    color2: "#1e3a8a",
    sound: "tesla",
    Comp: TeslaStaff,
    stats: [
      { label: "Kekuatan", value: 84 },
      { label: "Energi", value: 95 },
      { label: "Kecepatan", value: 78 },
    ],
  },
  {
    id: "shotgun",
    name: "Inferno Pump-Action",
    type: "Shotgun Api",
    rarity: "EPIC",
    desc: "Laras berlubang pelepas panas, kumparan tembaga membara, dan gagang kayu berukir. Kokang dan rasakan ledakannya!",
    color: "#f97316",
    color2: "#7c2d12",
    sound: "shotgun",
    Comp: InfernoShotgun,
    stats: [
      { label: "Kekuatan", value: 97 },
      { label: "Energi", value: 55 },
      { label: "Kecepatan", value: 48 },
    ],
  },
  {
    id: "emerald",
    name: "Emerald Ray Relic",
    type: "Ray Gun Retro",
    rarity: "LEGENDARY",
    desc: "Permata zamrud bertatah emas memberi daya pada kumparan spiral dan cincin emitor hijau yang bercahaya.",
    color: "#22c55e",
    color2: "#14532d",
    sound: "emerald",
    Comp: EmeraldRayGun,
    stats: [
      { label: "Kekuatan", value: 80 },
      { label: "Energi", value: 90 },
      { label: "Kecepatan", value: 86 },
    ],
  },
  {
    id: "cyber",
    name: "Cyber Pulse Disruptor",
    type: "Blaster Siber",
    rarity: "EPIC",
    desc: "Rangka karbon dengan garis neon cyan, inti berlian, dan cincin holografik yang memancarkan gelombang kejut.",
    color: "#22d3ee",
    color2: "#1e3a8a",
    sound: "cyber",
    Comp: CyberBlaster,
    stats: [
      { label: "Kekuatan", value: 76 },
      { label: "Energi", value: 88 },
      { label: "Kecepatan", value: 95 },
    ],
    rays: true,
  },
];

const WEAPONS2: Weapon[] = [
  {
    id: "rpgvolt",
    name: "Elemental RPG: Volt",
    type: "Peluncur Elemental",
    rarity: "LEGENDARY",
    desc: "Tabung emas-oranye dengan hulu ledak hijau bermuatan listrik. Semburan api keluar dari belakang dan petir kuning menyambar di ujungnya.",
    color: "#f59e0b",
    color2: "#7c2d12",
    sound: "rpgvolt",
    Comp: RpgVolt,
    stats: [
      { label: "Kekuatan", value: 99 },
      { label: "Energi", value: 86 },
      { label: "Kecepatan", value: 38 },
    ],
  },
  {
    id: "rpgstar",
    name: "Military RPG: Star",
    type: "Peluncur Militer",
    rarity: "EPIC",
    desc: "RPG hijau zaitun berlambang bintang putih dan cincin emas. Semburan api di belakang, kepulan asap, dan gelombang kejut di hulu ledak merahnya.",
    color: "#84cc16",
    color2: "#365314",
    sound: "rpg",
    Comp: RpgStar,
    stats: [
      { label: "Kekuatan", value: 96 },
      { label: "Energi", value: 60 },
      { label: "Kecepatan", value: 42 },
    ],
  },
  {
    id: "lava",
    name: "Magma Rune Cannon",
    type: "Meriam Vulkanik",
    rarity: "MYTHIC",
    desc: "Diukir dari batu vulkanik dengan retakan magma yang menyala dan mata rune kuno. Mulutnya terus menyemburkan api abadi.",
    color: "#f97316",
    color2: "#7f1d1d",
    sound: "lava",
    Comp: LavaCannon,
    stats: [
      { label: "Kekuatan", value: 94 },
      { label: "Energi", value: 92 },
      { label: "Kecepatan", value: 52 },
    ],
  },
  {
    id: "flame",
    name: "Dragonbreath Igniter",
    type: "Flamethrower",
    rarity: "LEGENDARY",
    desc: "Gagang kuningan berukir, tangki bahan bakar merah bergambar api, dan selang bertekanan. Satu tarikan pelatuk menyemburkan api naga.",
    color: "#ef4444",
    color2: "#7c2d12",
    sound: "flame",
    Comp: Flamethrower,
    stats: [
      { label: "Kekuatan", value: 88 },
      { label: "Energi", value: 80 },
      { label: "Kecepatan", value: 70 },
    ],
  },
  {
    id: "sniper",
    name: "Neon Viper Circuit",
    type: "Sniper Siber",
    rarity: "EPIC",
    desc: "Rangka hijau lime dengan jalur sirkuit yang mengalirkan cahaya, teropong berlensa hijau, dan muzzle brake yang memuntahkan api ke samping.",
    color: "#a3e635",
    color2: "#1a2e05",
    sound: "sniper",
    Comp: CircuitSniper,
    stats: [
      { label: "Kekuatan", value: 90 },
      { label: "Energi", value: 74 },
      { label: "Kecepatan", value: 99 },
    ],
    rays: true,
  },
];

const WEAPONS3: Weapon[] = [
  {
    id: "beacon",
    name: "Orbital Beacon",
    type: "Pemancar Satelit",
    rarity: "EPIC",
    desc: "Badan perak dengan panel surya biru, layar hologram, dan antena parabola emas yang memancarkan gelombang sinyal orbit.",
    color: "#60a5fa",
    color2: "#1e3a8a",
    sound: "beacon",
    Comp: OrbitalBeacon,
    stats: [
      { label: "Kekuatan", value: 70 },
      { label: "Energi", value: 94 },
      { label: "Kecepatan", value: 82 },
    ],
    rays: true,
  },
  {
    id: "phaser",
    name: "Phaser Type-II",
    type: "Pistol Phaser",
    rarity: "EPIC",
    desc: "Pistol gunmetal dengan neon oranye, ventilasi miring, dan inti emblem yang berputar. Slide menghentak setiap ditembakkan.",
    color: "#fb923c",
    color2: "#431407",
    sound: "phaser",
    Comp: PhaserType2,
    stats: [
      { label: "Kekuatan", value: 78 },
      { label: "Energi", value: 84 },
      { label: "Kecepatan", value: 97 },
    ],
  },
  {
    id: "gauntlet",
    name: "Gauntlet Cannon",
    type: "Meriam Kerajaan",
    rarity: "LEGENDARY",
    desc: "Meriam tangan merah-emas berukir dengan permata delima dan selubung berlubang yang membara. Menyemburkan api kerajaan.",
    color: "#f59e0b",
    color2: "#7f1d1d",
    sound: "gauntlet",
    Comp: GauntletCannon,
    stats: [
      { label: "Kekuatan", value: 98 },
      { label: "Energi", value: 76 },
      { label: "Kecepatan", value: 50 },
    ],
  },
  {
    id: "holy",
    name: "Holy Light Gun",
    type: "Pistol Suci",
    rarity: "LEGENDARY",
    desc: "Pistol mutiara berukir emas dengan sayap malaikat, halo bercahaya, dan liontin kristal. Memancarkan cahaya suci yang menyilaukan.",
    color: "#fde68a",
    color2: "#78350f",
    sound: "holy",
    Comp: HolyLightGun,
    stats: [
      { label: "Kekuatan", value: 88 },
      { label: "Energi", value: 99 },
      { label: "Kecepatan", value: 80 },
    ],
    rays: true,
  },
];

const RARITY_STYLE: Record<string, string> = {
  MYTHIC: "from-fuchsia-500 to-purple-700",
  LEGENDARY: "from-amber-300 to-orange-600",
  EPIC: "from-violet-400 to-indigo-600",
};

const keyLabel = (i: number) => (i < 9 ? String(i + 1) : i === 9 ? "0" : ["Q", "W", "E", "R"][i - 10] ?? "");

function WeaponCard({ w, index, soundOn, fireAll, className = "" }: { w: Weapon; index: number; soundOn: boolean; fireAll: number; className?: string }) {
  const [fireId, setFireId] = useState(0);
  const [firing, setFiring] = useState(false);
  const [uses, setUses] = useState(0);
  const timer = useRef<number | undefined>(undefined);
  const Comp = w.Comp;

  const fire = useCallback(() => {
    setFireId((i) => i + 1);
    setUses((u) => u + 1);
    setFiring(false);
    requestAnimationFrame(() => requestAnimationFrame(() => setFiring(true)));
    if (soundOn) playSound(w.sound);
    window.clearTimeout(timer.current);
    timer.current = window.setTimeout(() => setFiring(false), 1500);
  }, [soundOn, w.sound]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key.toUpperCase() === keyLabel(index)) fire();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [fire, index]);

  useEffect(() => {
    if (fireAll > 0) {
      const t = window.setTimeout(fire, index * 140);
      return () => window.clearTimeout(t);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [fireAll]);

  return (
    <div className={`group relative ${className}`}>
      <div
        className="absolute -inset-px rounded-3xl opacity-70 blur-[2px] transition group-hover:opacity-100"
        style={{ background: `linear-gradient(135deg, ${w.color}, transparent 40%, transparent 60%, ${w.color})` }}
      />
      <div
        className={`relative h-full overflow-hidden rounded-3xl border border-white/10 ${firing && fireId ? "is-firing shake" : ""}`}
        style={{
          background: `radial-gradient(120% 90% at 50% 40%, ${w.color2} 0%, #1a0b2e 55%, #0b0416 100%)`,
        }}
      >
        {/* rays */}
        {w.rays && (
          <div className="pointer-events-none absolute inset-0 flex items-center justify-center opacity-25">
            <svg viewBox="-100 -100 200 200" className="rays h-[180%] w-[180%] shrink-0">
              {Array.from({ length: 16 }, (_, i) => (
                <polygon key={i} points="0,0 -9,-100 9,-100" fill="#c4b5fd" transform={`rotate(${i * 22.5})`} opacity={0.5} />
              ))}
            </svg>
          </div>
        )}
        {/* background flash */}
        <div className="bg-flash pointer-events-none absolute inset-0" style={{ background: `radial-gradient(circle at 70% 45%, ${w.color}aa, transparent 60%)` }} />

        {/* header */}
        <div className="relative z-10 flex items-start justify-between p-5 pb-0">
          <div>
            <span className={`inline-block rounded-full bg-gradient-to-r ${RARITY_STYLE[w.rarity]} px-3 py-0.5 text-[11px] font-bold tracking-[0.2em] text-white shadow-lg`}>
              {w.rarity}
            </span>
            <p className="mt-2 text-xs font-semibold uppercase tracking-[0.3em]" style={{ color: w.color }}>
              {w.type}
            </p>
          </div>
          <div className="flex items-center gap-2">
            <span className="rounded-lg border border-white/15 bg-black/30 px-2 py-1 text-xs font-bold text-white/70">
              Dipakai <span className="text-white">{uses}x</span>
            </span>
            <kbd className="flex h-7 w-7 items-center justify-center rounded-lg border border-white/20 bg-white/5 text-sm font-bold text-white/80">{keyLabel(index)}</kbd>
          </div>
        </div>

        {/* weapon stage */}
        <button onClick={fire} aria-label={`Gunakan ${w.name}`} className="relative z-10 block w-full cursor-crosshair px-4 outline-none">
          <div className="relative mx-auto aspect-[4/3] max-h-[340px] w-full">
            {/* pedestal */}
            <div
              className="absolute bottom-[6%] left-1/2 h-8 w-2/3 -translate-x-1/2 rounded-[50%] blur-xl"
              style={{ background: w.color, opacity: 0.35 }}
            />
            <div className="floaty absolute inset-0 p-2">
              <Comp />
            </div>
          </div>
        </button>

        {/* info */}
        <div className="relative z-10 p-5 pt-0">
          <h3 className="font-title text-2xl font-extrabold text-white drop-shadow" style={{ textShadow: `0 0 18px ${w.color}88` }}>
            {w.name}
          </h3>
          <p className="mt-1 text-sm leading-snug text-white/65">{w.desc}</p>

          <div className="mt-4 space-y-2">
            {w.stats.map((s) => (
              <div key={s.label} className="flex items-center gap-3">
                <span className="w-20 text-xs font-semibold uppercase tracking-wider text-white/55">{s.label}</span>
                <div className="h-2 flex-1 overflow-hidden rounded-full bg-white/10">
                  <div className="h-full rounded-full" style={{ width: `${s.value}%`, background: `linear-gradient(90deg, ${w.color2}, ${w.color})`, boxShadow: `0 0 10px ${w.color}` }} />
                </div>
                <span className="w-7 text-right text-xs font-bold text-white/80">{s.value}</span>
              </div>
            ))}
          </div>

          <button
            onClick={fire}
            className="mt-5 w-full rounded-xl py-3 font-title text-sm font-extrabold tracking-[0.25em] text-white transition active:scale-95"
            style={{
              background: `linear-gradient(180deg, ${w.color}, ${w.color2})`,
              boxShadow: `0 0 24px ${w.color}66, inset 0 1px 0 rgba(255,255,255,.35)`,
            }}
          >
            ⚡ GUNAKAN
          </button>
        </div>
      </div>
    </div>
  );
}

function SectionTitle({ n, title, sub }: { n: string; title: string; sub: string }) {
  return (
    <div className="mb-6 mt-14 flex items-center gap-4 first:mt-0">
      <span className="font-title flex h-12 w-12 shrink-0 items-center justify-center rounded-xl border border-fuchsia-300/30 bg-gradient-to-br from-fuchsia-500/30 to-violet-800/30 text-lg font-black text-fuchsia-100 shadow-[0_0_20px_rgba(217,70,239,0.35)]">
        {n}
      </span>
      <div>
        <h2 className="font-title text-2xl font-extrabold tracking-wide text-white sm:text-3xl">{title}</h2>
        <p className="text-xs font-semibold uppercase tracking-[0.3em] text-white/45">{sub}</p>
      </div>
      <div className="h-px flex-1 bg-gradient-to-r from-fuchsia-400/40 to-transparent" />
    </div>
  );
}

export default function App() {
  const [soundOn, setSoundOn] = useState(true);
  const [fireAll, setFireAll] = useState(0);

  const stars = useMemo(
    () =>
      Array.from({ length: 70 }, (_, i) => ({
        left: (i * 37.7) % 100,
        top: (i * 53.3) % 100,
        size: 1 + ((i * 7) % 3),
        delay: (i % 10) * 0.3,
      })),
    []
  );

  const layout = ["lg:col-span-3", "lg:col-span-3", "lg:col-span-2", "lg:col-span-2", "lg:col-span-2"];
  const layout2 = ["lg:col-span-2", "lg:col-span-2", "lg:col-span-2", "lg:col-span-3", "lg:col-span-3"];

  return (
    <div className="relative min-h-screen overflow-hidden text-white">
      {/* background */}
      <div className="pointer-events-none fixed inset-0 bg-[radial-gradient(ellipse_at_top,#3b0f6b_0%,#14062a_45%,#07020f_100%)]" />
      <div className="pointer-events-none fixed -left-40 top-1/3 h-[500px] w-[500px] rounded-full bg-fuchsia-700/20 blur-[120px]" />
      <div className="pointer-events-none fixed -right-40 top-0 h-[500px] w-[500px] rounded-full bg-indigo-600/20 blur-[120px]" />
      <div className="pointer-events-none fixed inset-0">
        {stars.map((s, i) => (
          <span
            key={i}
            className="twinkle absolute rounded-full bg-white"
            style={{ left: `${s.left}%`, top: `${s.top}%`, width: s.size, height: s.size, animationDelay: `${s.delay}s` }}
          />
        ))}
      </div>

      <div className="relative mx-auto max-w-7xl px-4 py-10 sm:px-6">
        <header className="mb-10 flex flex-col items-center text-center">
          <p className="text-sm font-bold uppercase tracking-[0.5em] text-fuchsia-300/80">✦ Gudang Senjata Legendaris ✦</p>
          <h1 className="font-title mt-3 bg-gradient-to-b from-white via-fuchsia-200 to-purple-400 bg-clip-text text-4xl font-black text-transparent drop-shadow-[0_0_25px_rgba(192,132,252,0.5)] sm:text-6xl">
            ARSENAL MISTIK
          </h1>
          <p className="mt-4 max-w-xl text-white/60">
            Klik senjata atau tombol <b className="text-white">GUNAKAN</b> untuk melihat animasinya: hentakan, petir, gelombang energi, dan percikan, tanpa peluru. Tekan tombol <b className="text-white">1–9</b> dan <b className="text-white">0</b>, serta <b className="text-white">Q W E R</b> di keyboard.
          </p>
          <div className="mt-6 flex flex-wrap justify-center gap-3">
            <button
              onClick={() => setFireAll((n) => n + 1)}
              className="rounded-full bg-gradient-to-r from-fuchsia-500 to-violet-600 px-6 py-2.5 font-title text-sm font-extrabold tracking-[0.2em] shadow-[0_0_30px_rgba(217,70,239,0.5)] transition hover:brightness-110 active:scale-95"
            >
              ✦ AKTIFKAN SEMUA
            </button>
            <button
              onClick={() => setSoundOn((s) => !s)}
              className="rounded-full border border-white/20 bg-white/5 px-5 py-2.5 text-sm font-bold tracking-wider backdrop-blur transition hover:bg-white/10"
            >
              {soundOn ? "🔊 Suara Aktif" : "🔇 Suara Mati"}
            </button>
          </div>
        </header>

        <SectionTitle n="I" title="Koleksi Energi" sub="Kristal • Petir • Zamrud • Siber" />
        <div className="grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-6">
          {WEAPONS.map((w, i) => (
            <WeaponCard key={w.id} w={w} index={i} soundOn={soundOn} fireAll={fireAll} className={`${layout[i]} ${i === 4 ? "md:col-span-2 lg:col-span-2" : ""}`} />
          ))}
        </div>

        <SectionTitle n="II" title="Koleksi Api & Ledakan" sub="Peluncur • Magma • Api Naga • Sniper" />
        <div className="grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-6">
          {WEAPONS2.map((w, i) => (
            <WeaponCard key={w.id} w={w} index={i + 5} soundOn={soundOn} fireAll={fireAll} className={`${layout2[i]} ${i === 4 ? "md:col-span-2" : ""}`} />
          ))}
        </div>

        <SectionTitle n="III" title="Koleksi Teknologi & Suci" sub="Satelit • Phaser • Kerajaan • Malaikat" />
        <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
          {WEAPONS3.map((w, i) => (
            <WeaponCard key={w.id} w={w} index={i + 10} soundOn={soundOn} fireAll={fireAll} />
          ))}
        </div>

        <footer className="mt-12 text-center text-xs tracking-widest text-white/35">SEMUA SENJATA DIGAMBAR SEBAGAI SVG 2D • ANIMASI CSS MURNI</footer>
      </div>
    </div>
  );
}
