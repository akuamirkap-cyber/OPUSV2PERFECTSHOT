import { Component, Suspense, lazy, useEffect, useState, type ReactNode } from 'react';
import ScaledFrame from './components/ScaledFrame';
import { displaySize } from './games/gunhit/game/layout';
import {
  getSavedSgaOrientation,
  subscribeSgaOrientation,
  type SgaOrientation,
} from './games/gunhit/game/orientation';
import { SlideActivityProvider } from './games/shared/SlideActivity';
import { useAndroidBack, installAndroidBack, exitAndroidApp } from './utils/androidBack';
import { sfx as studioSfx } from './games/perfect-shot/audio/sfx';
import { installErrorHooks, reportError } from './telemetry/errorHooks';
import { trackSessionStart } from './telemetry/gameAnalytics';

// Gun page only: no SANS STUDIO intro, no other pages. The game is the single
// lazy chunk and mounts immediately.
const GunHitGame = lazy(() => import('./games/gunhit/App'));

function Boot({ message = 'MEMUAT GAME' }: { message?: string }) {
  return (
    <div
      className="flex h-full w-full flex-col items-center justify-center gap-3 bg-[#05060a] text-slate-200"
      role="status"
      aria-live="polite"
    >
      <span className="h-7 w-7 animate-spin rounded-full border-2 border-slate-700 border-t-sky-400" />
      <span className="text-xs font-semibold tracking-[0.16em]">{message}</span>
    </div>
  );
}

class GameLoadBoundary extends Component<{ children: ReactNode }, { failed: boolean }> {
  state = { failed: false };
  static getDerivedStateFromError() {
    return { failed: true };
  }

  componentDidCatch(error: unknown, info: { componentStack?: string | null }) {
    reportError('react-boundary', error, {
      where: 'game-boundary',
      component: (info.componentStack ?? '').trim().split('\n')[0] ?? '',
    });
  }

  render() {
    if (this.state.failed) {
      return (
        <div
          className="flex h-full w-full flex-col items-center justify-center gap-3 bg-[#05060a] px-6 text-center text-slate-200"
          role="alert"
        >
          <span className="text-sm font-semibold">Game belum berhasil dimuat.</span>
          <button
            className="rounded-md bg-sky-700 px-4 py-2 text-sm font-semibold text-white"
            onClick={() => window.location.reload()}
          >
            Coba muat ulang
          </button>
        </div>
      );
    }
    return this.props.children;
  }
}

export default function App() {
  const [pageVisible, setPageVisible] = useState(() => !document.hidden);
  const [orientation, setOrientation] = useState<SgaOrientation>(() => getSavedSgaOrientation());

  useEffect(() => subscribeSgaOrientation(setOrientation), []);

  useEffect(() => {
    trackSessionStart();
    installErrorHooks();
  }, []);

  // Pause the simulation while the tab / app is in the background.
  useEffect(() => {
    const onVisibility = () => setPageVisible(!document.hidden);
    document.addEventListener('visibilitychange', onVisibility);
    return () => document.removeEventListener('visibilitychange', onVisibility);
  }, []);

  useEffect(() => {
    let disposed = false;
    let remove: (() => void) | undefined;
    void installAndroidBack(() => {
      void exitAndroidApp();
    }).then((off) => {
      if (disposed) off();
      else remove = off;
    });
    return () => {
      disposed = true;
      remove?.();
    };
  }, []);

  useAndroidBack(() => false, true);

  const frame = displaySize(orientation);

  return (
    <div
      className="fixed inset-0 flex h-dvh w-full flex-col overflow-hidden bg-[#05060a] select-none touch-manipulation"
      onPointerDownCapture={(event) => {
        const target = event.target as Element | null;
        if (!target?.closest('button, [role="button"]')) return;
        studioSfx.init();
        if (studioSfx.getState().music) studioSfx.startMusic();
      }}
      style={{
        paddingTop: 'env(safe-area-inset-top)',
        paddingBottom: 'env(safe-area-inset-bottom)',
        paddingLeft: 'env(safe-area-inset-left)',
        paddingRight: 'env(safe-area-inset-right)',
      }}
    >
      <main
        className="relative flex min-h-0 w-full flex-1 items-center justify-center"
        data-game-id="A"
        data-game-name="GUNHIT"
        aria-label="Gun Hit SGA"
      >
        <SlideActivityProvider active={pageVisible}>
          <GameLoadBoundary>
            <ScaledFrame baseWidth={frame.w} baseHeight={frame.h}>
              <div className="relative overflow-hidden" style={{ width: frame.w, height: frame.h }}>
                <Suspense fallback={<Boot />}>
                  <GunHitGame introReady />
                </Suspense>
              </div>
            </ScaledFrame>
          </GameLoadBoundary>
        </SlideActivityProvider>
      </main>
    </div>
  );
}
