/**
 * How each zip weapon moves when it fires (`svg-weapons-with-glow-animation.zip`).
 *
 * The zip's own page kicks the whole card with a translate (its `kick` per
 * weapon) and re-runs a one-shot CSS animation (`.dg-fire`, `.wb-fire`, …).
 * Our five guns stand upright, so the same numbers become "travel straight down
 * the barrel axis + tip back", and the class name is what the page re-applies to
 * the mounted SVG so the zip's own flashes, sheen, spins and chomps play.
 *
 * Kept markup-free so the engine can read the numbers without pulling the
 * 190 KB artwork chunk into itself.
 */
import { ZIP_PACK2_IDS, type ZipShotWeaponId, type ZipWeaponId } from './ids';

export interface ZipKick {
  /**
   * EXTRA pixels the gun travels back (down, away from the wheel) at full
   * recoil, on top of the shared 22 px jump every gun's pose already carries.
   */
  y: number;
  /** Radians the barrel tips back at full recoil. */
  rot: number;
  /** Scale pulse at full recoil — the punch that makes the shot read. */
  punch: number;
}

const ZIP_SHOT_KICK: Record<ZipShotWeaponId, ZipKick> = {
  // zip "Diamond Gun": kick { x: -11, y: 11 } of its 512 box, a heavy rifle.
  diamond: { y: 16, rot: 0.11, punch: 0.045 },
  // zip "Wars Blaster": kick { x: -12, y: 10 }.
  blaster: { y: 14, rot: 0.09, punch: 0.04 },
  // zip "Paintball Gun": the lightest of the five, kick { x: -9, y: 9 }.
  paintball: { y: 10, rot: 0.06, punch: 0.03 },
  // zip "Shark Launcher": kick { x: -14, y: 6 }, the hardest hit.
  shark: { y: 21, rot: 0.13, punch: 0.06 },
  // zip "Martian Heat-Ray": a pivot (`rot: -9`) rather than a slide.
  heat_ray: { y: 20, rot: 0.15, punch: 0.055 },
};

/**
 * animated-2d-svg-weapons.zip: each SVG already recoils inside its own art
 * (`.wx-recoil`), so the engine's extra kick is lighter than the first zip's.
 */
const PACK2_KICK: Record<string, ZipKick> = {
  crystal: { y: 8, rot: 0.05, punch: 0.02 },
  tesla_rifle: { y: 7, rot: 0.04, punch: 0.02 },
  shotgun: { y: 12, rot: 0.07, punch: 0.03 },
  emerald: { y: 7, rot: 0.05, punch: 0.02 },
  electro: { y: 8, rot: 0.05, punch: 0.025 },
  rpg: { y: 14, rot: 0.06, punch: 0.03 },
  bazooka: { y: 12, rot: 0.06, punch: 0.03 },
  meteor: { y: 12, rot: 0.05, punch: 0.03 },
  flamethrower: { y: 8, rot: 0.04, punch: 0.02 },
  sniper: { y: 10, rot: 0.05, punch: 0.025 },
  orbital_beacon: { y: 6, rot: 0.04, punch: 0.02 },
  phaser: { y: 8, rot: 0.05, punch: 0.02 },
  gauntlet_cannon: { y: 12, rot: 0.06, punch: 0.03 },
  // Noisy-Cricket style: pure straight knockback, no rotation / scale punch.
  holy: { y: 9, rot: 0, punch: 0 },
};

export const ZIP_KICK: Record<ZipWeaponId, ZipKick> = { ...ZIP_SHOT_KICK, ...PACK2_KICK } as Record<ZipWeaponId, ZipKick>;

/** The zip's own one-shot fire class, on the SVG root. */
const ZIP_SHOT_FIRE_CLASS: Record<ZipShotWeaponId, string> = {
  diamond: 'dg-fire',
  blaster: 'wb-fire',
  paintball: 'pb-fire',
  shark: 'sl-fire',
  heat_ray: 'mh-fire',
};

/** animated-2d-svg-weapons.zip fires by adding `wx-is-firing` to the SVG root. */
export const PACK2_FIRE_CLASS = 'wx-is-firing';

export const ZIP_FIRE_CLASS: Record<ZipWeaponId, string> = {
  ...ZIP_SHOT_FIRE_CLASS,
  ...Object.fromEntries(ZIP_PACK2_IDS.map((id) => [id, PACK2_FIRE_CLASS])),
} as Record<ZipWeaponId, string>;

/** The zip's idle float class, so a re-fire restarts from the same pose. */
const ZIP_SHOT_IDLE_CLASS: Record<ZipShotWeaponId, string> = {
  diamond: 'dg-bob',
  blaster: 'wb-idle',
  paintball: 'pb-neon',
  shark: 'sl-jet',
  heat_ray: 'mh-seg',
};

export const ZIP_IDLE_CLASS: Record<ZipWeaponId, string> = {
  ...ZIP_SHOT_IDLE_CLASS,
  ...Object.fromEntries(ZIP_PACK2_IDS.map((id) => [id, 'wx-pulse'])),
} as Record<ZipWeaponId, string>;

/** Length of the zip's own fire animation, in ms (its longest keyframe). */
export const ZIP_FIRE_MS = 780;
/** animated-2d-svg-weapons.zip: smoke and shockwaves play for up to ~1.8 s. */
export const PACK2_FIRE_MS = 1800;

export function zipFireMs(id: string): number {
  return (ZIP_PACK2_IDS as readonly string[]).includes(id) ? PACK2_FIRE_MS : ZIP_FIRE_MS;
}

export const SHARK_JAW_CLOSED_DEGREES = 38;
export const SHARK_JAW_FIRE_MS = 350;

/** The jaw opens for a shot, then returns to its closed resting pose. */
export function sharkJawDegrees(elapsedMs: number): number {
  if (!Number.isFinite(elapsedMs) || elapsedMs < 0 || elapsedMs >= SHARK_JAW_FIRE_MS) return SHARK_JAW_CLOSED_DEGREES;
  const smooth = (n: number) => n * n * (3 - 2 * n);
  if (elapsedMs < 90) return SHARK_JAW_CLOSED_DEGREES * (1 - smooth(elapsedMs / 90));
  if (elapsedMs < 135) return 0;
  return SHARK_JAW_CLOSED_DEGREES * smooth((elapsedMs - 135) / (SHARK_JAW_FIRE_MS - 135));
}

export function zipKick(id: string): ZipKick {
  return (ZIP_KICK as Record<string, ZipKick>)[id] ?? { y: 30, rot: 0.08, punch: 0.035 };
}

export function zipFireClass(id: string): string | null {
  return (ZIP_FIRE_CLASS as Record<string, string>)[id] ?? null;
}
