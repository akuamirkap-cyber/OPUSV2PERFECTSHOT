import perfectRaw from './perfect.txt?raw';
import cardRaw from './card.txt?raw';
import senjataRaw from './senjata.txt?raw';
import senjata2Raw from './senjata2.txt?raw';
import senjata3Raw from './senjata3.txt?raw';

/**
 * The five games are embedded as text instead of external files. The hosting
 * environment may serve only dist/index.html, so file-based iframe URLs would
 * 404 and show a blank screen.
 *
 * Closing script tags are stored as a token because a literal one inside this
 * module would terminate the inlined <script> in the single-file build.
 */
const TOKEN = '__OPUS_SCRIPT_END_9f3__';
const CLOSE = '</scr' + 'ipt>';
const restore = (html: string): string => html.split(TOKEN).join(CLOSE);

export const SCREEN_HTML = {
  perfect: restore(perfectRaw),
  card: restore(cardRaw),
  senjata: restore(senjataRaw),
  senjata2: restore(senjata2Raw),
  senjata3: restore(senjata3Raw),
} as const;

export type ScreenId = keyof typeof SCREEN_HTML;
