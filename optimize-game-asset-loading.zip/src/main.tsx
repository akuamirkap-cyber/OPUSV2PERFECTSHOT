import { createRoot } from "react-dom/client";
import "./fonts.css";
import "./index.css";
// Perfect Shot shell + shared motion/art stylesheet (menu, transitions, HUD keyframes)
import "./shell.css";
import "./games/perfect-shot/index.css";
import App from "./App";

createRoot(document.getElementById("root")!).render(<App />);
