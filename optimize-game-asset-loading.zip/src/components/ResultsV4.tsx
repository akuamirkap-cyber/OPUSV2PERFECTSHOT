import Title3D from "./Title3D";
import { Bullet } from "./Target";
import { Coin, Diamond } from "./Icons";
import { ActionRow, AdTag, MorphMedal, MorphValue } from "./FancyButtons";
import { MiniGift } from "./GiftBox";
import { WEAPONS, WeaponArt } from "./Weapons";
import { NewBestRibbon, Trophy, fmt, type ResultsProps } from "./ResultParts";
import { CrosshairIcon, FlagIcon, TargetIcon, useShowcase } from "./ResultsV2";

function Chip({ icon, label, value, color, show, delay }: { icon: React.ReactNode; label: string; value: string; color: string; show: boolean; delay: number }) {
  return (
    <div
      className={`flex flex-1 flex-col items-center justify-center rounded-2xl border border-white/10 bg-black/30 py-2 ${show ? "" : "invisible"}`}
      style={{ animation: show ? `pop .42s cubic-bezier(.2,.9,.3,1.2) ${delay}s both` : undefined }}
    >
      <span className="flex items-center gap-1 font-russo text-[10px] tracking-wider text-white/55">
        {icon} {label}
      </span>
      <span className="mt-1 font-russo text-[20px] leading-none" style={{ color, textShadow: "0 2px 0 rgba(0,0,0,0.45)" }}>
        {value}
      </span>
    </div>
  );
}

/** full-width reward bar */
function Bar({
  show,
  delay = 0,
  tone,
  medal,
  title,
  sub,
  right,
  disabled,
  done,
  onClick,
}: {
  show: boolean;
  delay?: number;
  tone: "purple" | "blue";
  medal: React.ReactNode;
  title: string;
  sub: string;
  right: React.ReactNode;
  disabled: boolean;
  done: string;
  onClick: () => void;
}) {
  return (
    <div className={`relative w-full ${show ? "" : "invisible"}`} style={{ animation: show ? `slide-up .5s cubic-bezier(.2,.8,.3,1.1) ${delay}s both` : undefined }}>
      <button
        onClick={onClick}
        disabled={disabled}
        className={`b3d b3d-${tone} h-[60px] w-full`}
        style={{ ["--lip" as string]: "5px", ["--r" as string]: "18px", ["--shine-delay" as string]: tone === "purple" ? "2s" : "3.2s" }}
      >
        <span className="b3d-move b3d-face gap-3 pl-2 pr-3 text-white">
          <span className="relative z-10 shrink-0">{medal}</span>
          {disabled ? (
            <span className="relative z-10 flex-1 text-left font-lilita text-[19px] text-white/85">{done}</span>
          ) : (
            <>
              <span className="relative z-10 flex flex-1 flex-col items-start leading-none">
                <span className="lbl-3d font-lilita text-[21px]">{title}</span>
                <span className="mt-1 font-russo text-[10px] tracking-wide text-white/85">{sub}</span>
              </span>
              <span className="relative z-10 flex min-w-[76px] justify-end rounded-xl bg-black/20 px-2.5 py-1.5 shadow-[inset_0_2px_3px_rgba(0,0,0,0.25)]">{right}</span>
            </>
          )}
        </span>
      </button>
      {!disabled && <AdTag className="-right-2 -top-3" />}
    </div>
  );
}

/** V4 – "Split": gun + score side by side, reward bars, actions at the bottom */
export default function ResultsV4(p: ResultsProps) {
  const { at, intro, skip, rewardRef, gemRef, isNewBest, shots, score, acc, reward, best } = useShowcase(p);
  const aura = WEAPONS[p.gun].aura;

  return (
    <div className="relative flex h-full flex-col items-center px-6 pt-[66px]" onPointerDown={intro ? skip : undefined}>
      {/* one-line title */}
      <div className="relative z-20 flex w-full items-end justify-center gap-3" style={{ animation: at("GUN") ? "title-bob 3.2s ease-in-out infinite" : undefined }}>
        <Title3D text="GAME" variant="red" size={62} anim="drop" stagger={70} sound />
        {at("OVER") ? <Title3D text="OVER" variant="gold" size={62} anim="slam" stagger={55} /> : <div className="h-[60px] w-[170px]" />}
        {at("BULLET") && (
          <div className="pointer-events-none absolute left-0 top-[22px]" style={{ animation: "bullet-across .7s cubic-bezier(.3,.1,.4,1) both" }}>
            <Bullet className="scale-75" />
          </div>
        )}
      </div>
      <div className={`mt-2 font-russo text-[12px] tracking-[0.3em] text-white/60 ${at("GUN") ? "anim-fade-up" : "invisible"}`}>STAGE {p.stage} · TARGET MISSED</div>

      {/* hero card */}
      <div className={`panel relative mt-6 w-full rounded-[26px] px-4 pb-9 pt-4 ${at("CARD") ? "anim-slide-up" : "invisible"}`}>
        <div className="flex h-[178px] items-center">
          {/* gun side */}
          <div className="relative flex h-full w-[46%] items-center justify-center">
            {at("GUN") && (
              <>
                <div className="rays anim-rays anim-fade absolute h-[230px] w-[230px] rounded-full opacity-50" />
                <div className="absolute bottom-3 h-4 w-28 rounded-[50%] bg-black/50 blur-md" />
                <div style={{ animation: "gun-in .75s cubic-bezier(.2,.8,.3,1.1) both" }}>
                  <div className="anim-float" style={{ filter: aura ? `drop-shadow(0 0 14px ${aura})` : undefined }}>
                    <WeaponArt id={p.gun} scale={1.02} tilt={-22} />
                  </div>
                </div>
              </>
            )}
          </div>
          {/* score side */}
          <div className="flex flex-1 flex-col items-start pl-2">
            <span className="font-russo text-[11px] tracking-[0.3em] text-white/55">SCORE</span>
            <span className="txt-gold mt-1 font-russo text-[46px] leading-none">{fmt(score)}</span>
            <div className="mt-3 flex items-center gap-2 rounded-full border border-white/10 bg-black/25 px-3 py-[3px]">
              <span className="flex items-center gap-1 font-russo text-[10px] tracking-widest text-white/55">
                <Trophy size={12} /> BEST
              </span>
              <span key={best} className={`inline-block font-russo text-[16px] leading-tight text-white ${at("BEST") && isNewBest ? "anim-pop" : ""}`}>
                {fmt(best)}
              </span>
            </div>
          </div>
        </div>

        <div className="mt-1 flex gap-2.5">
          <Chip icon={<FlagIcon />} label="STAGE" value={String(p.stage)} color="#ffffff" show={at("STATS")} delay={0} />
          <Chip icon={<TargetIcon />} label="HITS" value={`${p.hits}/${shots}`} color="#9dffb0" show={at("STATS")} delay={0.08} />
          <Chip icon={<CrosshairIcon />} label="ACC" value={`${acc}%`} color="#a8e2ff" show={at("STATS")} delay={0.16} />
        </div>

        {at("BEST") && isNewBest && <NewBestRibbon className="-right-4 -top-4" />}

        {/* reward pill */}
        <div className="absolute -bottom-6 left-1/2 -translate-x-1/2">
          <div
            className={`flex h-[48px] items-center gap-2.5 whitespace-nowrap rounded-full border-2 border-[#ffc531]/45 pl-2 pr-4 shadow-[0_6px_16px_rgba(0,0,0,0.45)] ${at("REWARD") ? "anim-pop" : "invisible"}`}
            style={{ background: "linear-gradient(180deg,#1d3940,#0c1d22)" }}
          >
            <div ref={rewardRef} className="flex items-center gap-1.5">
              <Coin size={30} />
              <span className="font-lilita text-[24px] text-[#ffc531]" style={{ textShadow: "0 2px 0 #7a4200" }}>
                +{reward}
              </span>
            </div>
            <span className="h-6 w-px bg-white/15" />
            <span ref={gemRef} className="flex items-center gap-1">
              <Diamond size={24} />
              <span className="font-lilita text-[22px] text-[#bfeaff]" style={{ textShadow: "0 2px 0 #0c4c91" }}>
                +{p.gems}
              </span>
            </span>
          </div>
        </div>
      </div>

      {/* reward bars */}
      <div className="mt-[46px] flex w-full flex-col gap-3.5">
        <Bar
          show={at("EXTRA")}
          tone="purple"
          medal={<MorphMedal size={44} />}
          title="x2 REWARD"
          sub="GANDAKAN COIN + DIAMOND"
          right={<MorphValue coins={p.reward} gems={p.gems} size={18} />}
          disabled={p.doubleUsed}
          done="x2 REWARD · CLAIMED ✓"
          onClick={p.onDouble}
        />
        <Bar
          show={at("EXTRA")}
          delay={0.08}
          tone="blue"
          medal={
            <span className="medal h-[44px] w-[44px]" style={{ background: "radial-gradient(circle at 35% 30%, #f0e2ff, #b07cff 45%, #6a2fd6)" }}>
              <MiniGift size={28} />
            </span>
          }
          title="KADO BOSS"
          sub="UMUM · RARE · EPIC · LEGEND"
          right={
            <span className="font-lilita text-[20px] leading-none" style={{ animation: "rarity-cycle 3s steps(1) infinite" }}>
              ???
            </span>
          }
          disabled={p.gift !== "new"}
          done="KADO BOSS · DIBUKA ✓"
          onClick={p.onGift}
        />
      </div>

      {/* actions */}
      <div className="mt-[22px] w-full">
        <ActionRow show={at("BUTTONS")} onHome={p.onHome} onRetry={p.onRetry} />
      </div>
    </div>
  );
}
