import { useEffect, useState } from 'react';
import { SCREEN_HTML } from './games/html/screens';

type Screen = {
  id: string;
  name: string;
  source: string;
  description: string;
  html: string;
  accent: string;
  glyph: string;
};

/** Perfect Shot stays first; the four archives from the GitHub repo follow it. */
const SCREENS: Screen[] = [
  {
    id: 'perfect',
    name: 'PERFECT SHOT',
    source: 'Game utama · Gun Hit SGA',
    description: 'Halaman gun yang sudah ada, dengan seluruh perubahan senjata dan efek HOLY LIGHT GUN.',
    html: SCREEN_HTML.perfect,
    accent: 'from-sky-400 to-indigo-600',
    glyph: '🎯',
  },
  {
    id: 'card',
    name: 'CARD GUN',
    source: 'card.zip',
    description: 'Etalase Card Gun SVG animasi dari arsip card.zip.',
    html: SCREEN_HTML.card,
    accent: 'from-rose-400 to-amber-500',
    glyph: '🃏',
  },
  {
    id: 'senjata',
    name: 'ARSENAL AJAIB',
    source: 'senjata.zip',
    description: '10 senjata SVG animasi: Nature Gun, Keris, Ruby, Angel Pistol, dan lainnya.',
    html: SCREEN_HTML.senjata,
    accent: 'from-fuchsia-400 to-violet-700',
    glyph: '✨',
  },
  {
    id: 'senjata2',
    name: 'ARMORY STUDIO',
    source: 'senjata2.zip',
    description: 'Collage showcase + studio stage untuk 10 senjata SVG kustom.',
    html: SCREEN_HTML.senjata2,
    accent: 'from-cyan-300 to-blue-700',
    glyph: '🛠️',
  },
  {
    id: 'senjata3',
    name: 'WEAPON ARSENAL',
    source: 'senjata 3.zip',
    description: 'Arsenal 5 senjata SVG animasi dengan stage dan efek tembak.',
    html: SCREEN_HTML.senjata3,
    accent: 'from-emerald-300 to-teal-700',
    glyph: '⚔️',
  },
];

const PREVIEW_W = 1280;
const PREVIEW_H = 1800;
const PREVIEW_SCALE = 0.205;

export default function App() {
  const [selected, setSelected] = useState(0);
  const [running, setRunning] = useState<number | null>(null);

  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      if (event.key >= '1' && event.key <= '5') {
        const index = Number(event.key) - 1;
        setSelected(index);
        if (running !== null) setRunning(index);
      } else if (event.key === 'Enter' && running === null) {
        setRunning(selected);
      } else if (event.key === 'Escape') {
        setRunning(null);
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [selected, running]);

  const chosen = SCREENS[selected];
  const active = running === null ? null : SCREENS[running];

  return (
    <div className="min-h-dvh bg-[#070814] text-white selection:bg-fuchsia-500/40">
      <div className="pointer-events-none fixed inset-0 bg-[radial-gradient(ellipse_at_top,#241b4d_0%,#0b0a1c_55%,#05050d_100%)]" />
      <div className="pointer-events-none fixed -left-32 top-24 h-96 w-96 rounded-full bg-fuchsia-600/15 blur-[120px]" />
      <div className="pointer-events-none fixed -right-32 bottom-0 h-96 w-96 rounded-full bg-cyan-500/10 blur-[120px]" />

      <div className="relative mx-auto flex min-h-dvh max-w-[1500px] flex-col px-4 py-5 sm:px-8">
        <header className="mb-5 flex flex-wrap items-center justify-between gap-3">
          <div>
            <p className="text-[11px] font-bold uppercase tracking-[0.35em] text-fuchsia-300/80">OPUSV2PERFECTSHOT</p>
            <h1 className="mt-1 text-3xl font-black tracking-tight sm:text-4xl">5 LAYAR GAME</h1>
            <p className="mt-1 max-w-2xl text-sm text-white/55">
              Perfect Shot di kiri, lalu 4 aplikasi dari <code className="text-fuchsia-200">card.zip</code>,{' '}
              <code className="text-fuchsia-200">senjata.zip</code>, <code className="text-fuchsia-200">senjata2.zip</code>, dan{' '}
              <code className="text-fuchsia-200">senjata 3.zip</code>. Pilih layar, lalu jalankan.
            </p>
          </div>
          <div className="flex flex-wrap gap-1.5" role="tablist" aria-label="Pilih layar">
            {SCREENS.map((screen, index) => (
              <button
                key={screen.id}
                role="tab"
                aria-selected={selected === index}
                onClick={() => {
                  setSelected(index);
                  if (running !== null) setRunning(index);
                }}
                className={`h-10 min-w-10 rounded-xl border px-3 text-sm font-bold transition ${
                  selected === index
                    ? 'border-white/70 bg-white text-[#120b25] shadow-[0_0_18px_rgba(255,255,255,0.25)]'
                    : 'border-white/15 bg-white/5 text-white/70 hover:bg-white/10'
                }`}
                title={screen.name}
              >
                {index + 1}
              </button>
            ))}
          </div>
        </header>

        <main className="flex min-h-0 flex-1 flex-col">
          <div className="mb-3 flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-white/10 bg-white/5 px-4 py-3 backdrop-blur">
            <div className="flex items-center gap-3">
              <span className={`grid h-9 w-9 place-items-center rounded-xl bg-gradient-to-br ${chosen.accent} text-lg shadow-lg`}>
                {chosen.glyph}
              </span>
              <div>
                <p className="text-[10px] font-bold uppercase tracking-[0.25em] text-white/45">Layar dipilih · {selected + 1}/5</p>
                <p className="text-sm font-bold">{chosen.name}</p>
              </div>
            </div>
            <button
              onClick={() => setRunning(selected)}
              className="rounded-xl bg-gradient-to-r from-fuchsia-500 to-indigo-500 px-5 py-2.5 text-sm font-black tracking-wide shadow-[0_8px_24px_rgba(217,70,239,0.35)] transition hover:brightness-110 active:scale-95"
            >
              ▶ JALANKAN LAYAR {selected + 1}
            </button>
          </div>

          <div className="flex snap-x snap-mandatory gap-4 overflow-x-auto pb-5">
            {SCREENS.map((screen, index) => {
              const isSelected = selected === index;
              return (
                <section
                  key={screen.id}
                  onClick={() => setSelected(index)}
                  className={`group relative w-[260px] shrink-0 snap-start cursor-pointer overflow-hidden rounded-3xl border transition ${
                    isSelected
                      ? 'border-fuchsia-300/80 shadow-[0_0_0_2px_rgba(240,171,252,0.35),0_20px_45px_rgba(0,0,0,0.55)]'
                      : 'border-white/10 shadow-[0_16px_35px_rgba(0,0,0,0.45)] hover:border-white/25'
                  }`}
                >
                  <div className="relative h-[369px] overflow-hidden bg-[#0b0a16]">
                    <iframe
                      srcDoc={screen.html}
                      title={`Preview ${screen.name}`}
                      loading="lazy"
                      referrerPolicy="no-referrer"
                      allow="autoplay; fullscreen"
                      className="pointer-events-none absolute left-0 top-0 border-0"
                      style={{
                        width: PREVIEW_W,
                        height: PREVIEW_H,
                        transform: `scale(${PREVIEW_SCALE})`,
                        transformOrigin: 'top left',
                      }}
                    />
                    <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-[#070814] via-transparent to-black/10" />
                    <span className="absolute left-3 top-3 rounded-full border border-white/20 bg-black/55 px-2.5 py-1 text-[10px] font-black tracking-widest backdrop-blur">
                      LAYAR {index + 1}
                    </span>
                    {isSelected && (
                      <span className="absolute right-3 top-3 rounded-full bg-fuchsia-400 px-2.5 py-1 text-[10px] font-black text-[#221036]">
                        DIPILIH
                      </span>
                    )}
                    <span className="absolute bottom-3 left-3 text-2xl drop-shadow-lg">{screen.glyph}</span>
                  </div>
                  <div className="relative border-t border-white/10 bg-[#100d20] p-4">
                    <div className={`h-1 w-12 rounded-full bg-gradient-to-r ${screen.accent}`} />
                    <h2 className="mt-3 text-base font-extrabold leading-tight">{screen.name}</h2>
                    <p className="mt-0.5 text-[11px] font-semibold text-fuchsia-200/70">{screen.source}</p>
                    <p className="mt-2 line-clamp-2 text-[11px] leading-snug text-white/50">{screen.description}</p>
                    <button
                      onClick={(event) => {
                        event.stopPropagation();
                        setSelected(index);
                        setRunning(index);
                      }}
                      className="mt-3 w-full rounded-xl border border-white/15 bg-white/10 py-2 text-xs font-black tracking-wider transition hover:bg-white/20 active:scale-95"
                    >
                      ▶ JALANKAN
                    </button>
                  </div>
                </section>
              );
            })}
          </div>
          <p className="mt-1 text-center text-[11px] text-white/35">
            Klik kartu untuk memilih · tombol 1–5 untuk berpindah · Enter menjalankan · Esc kembali
          </p>
        </main>
      </div>

      {active && (
        <div className="fixed inset-0 z-50 bg-[#05050d]">
          <div className="absolute inset-x-0 top-0 z-10 flex h-12 items-center justify-between gap-2 border-b border-white/10 bg-[#0b0918]/95 px-3 backdrop-blur">
            <button
              onClick={() => setRunning(null)}
              className="rounded-lg border border-white/15 bg-white/10 px-3 py-1.5 text-xs font-bold transition hover:bg-white/20"
            >
              ← KEMBALI
            </button>
            <span className="truncate text-xs font-black tracking-wide text-white/80">
              LAYAR {running! + 1}/5 · {active.name}
            </span>
            <button
              onClick={() => {
                const next = (running! + 1) % SCREENS.length;
                setSelected(next);
                setRunning(next);
              }}
              className="rounded-lg border border-white/15 bg-white/10 px-3 py-1.5 text-xs font-bold transition hover:bg-white/20"
            >
              BERIKUTNYA →
            </button>
          </div>
          <iframe
            key={active.id}
            srcDoc={active.html}
            title={active.name}
            allow="autoplay; fullscreen"
            allowFullScreen
            referrerPolicy="no-referrer"
            className="absolute inset-x-0 bottom-0 top-12 h-[calc(100%-3rem)] w-full border-0"
          />
        </div>
      )}
    </div>
  );
}
