import { Stage, Shiny } from '../components/Stage';
import { burstStyle, spread, star4, v } from '../lib/fx';

const PITCH = 14;
const BARRELS = Array.from({ length: 9 }, (_, i) => -36 - PITCH * 2 + i * PITCH);
const HOLES = Array.from({ length: 6 }, (_, i) => {
  const a = (i * 60 * Math.PI) / 180;
  return [Math.cos(a) * 18, Math.sin(a) * 18];
});
const FX_SPARK = spread(16, -70, 70, 40, 110, 51);
const FX_SMOKE = [
  { dx: 30, dy: -50, d: 0.3 },
  { dx: 50, dy: -30, d: 0.5 },
  { dx: 20, dy: -70, d: 0.7 },
  { dx: 60, dy: -60, d: 0.9 },
];

export default function Minigun({ fire, label, rarity }: { fire: number; label?: string; rarity?: 'Rare' | 'Epic' | 'Legendary' | 'Mythic' }) {
  return (
    <Stage id="mini" fire={fire} label={label} rarity={rarity} glow="#ffcf5a" mote="#ffe6a8" outline="#06070a" bg={['#a596c8', '#4e3e7e', '#140c2c']}>
      <defs>
        <linearGradient id="m-metal" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#a8b0bc" />
          <stop offset="0.25" stopColor="#5c6470" />
          <stop offset="0.7" stopColor="#2a2f37" />
          <stop offset="1" stopColor="#0e1014" />
        </linearGradient>
        <linearGradient id="m-metalh" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0" stopColor="#1a1d22" />
          <stop offset="0.4" stopColor="#7a8290" />
          <stop offset="0.7" stopColor="#3e444e" />
          <stop offset="1" stopColor="#14161a" />
        </linearGradient>
        <linearGradient id="m-barrel" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#22262c" />
          <stop offset="0.3" stopColor="#c4ccd8" />
          <stop offset="0.55" stopColor="#6a727e" />
          <stop offset="1" stopColor="#16181c" />
        </linearGradient>
        <linearGradient id="m-cyl" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#000" stopOpacity="0.5" />
          <stop offset="0.2" stopColor="#000" stopOpacity="0" />
          <stop offset="0.36" stopColor="#ffffff" stopOpacity="0.35" />
          <stop offset="0.55" stopColor="#000" stopOpacity="0" />
          <stop offset="1" stopColor="#000" stopOpacity="0.6" />
        </linearGradient>
        <linearGradient id="m-heat" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0" stopColor="#ff5a1a" stopOpacity="0" />
          <stop offset="0.6" stopColor="#ff7a1a" stopOpacity="0.6" />
          <stop offset="1" stopColor="#ffd84a" stopOpacity="0.9" />
        </linearGradient>
        <linearGradient id="m-grip" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0" stopColor="#0a0b0e" />
          <stop offset="0.45" stopColor="#3a3f48" />
          <stop offset="1" stopColor="#0a0b0e" />
        </linearGradient>
        <radialGradient id="m-flash">
          <stop offset="0" stopColor="#ffffff" />
          <stop offset="0.3" stopColor="#ffe46a" stopOpacity="0.95" />
          <stop offset="0.7" stopColor="#ff8a1a" stopOpacity="0.5" />
          <stop offset="1" stopColor="#ff5a1a" stopOpacity="0" />
        </radialGradient>
        <clipPath id="m-barclip">
          <rect x="0" y="-36" width="172" height="56" rx="8" />
        </clipPath>
      </defs>

      <g className="floaty">
        <g transform="translate(186 200) rotate(-12) scale(0.94)">
          <g key={fire} className={fire ? 'shake' : ''}>
            <Shiny id="mini" fire={fire}>
              {/* ---------- spade grip (rear top) ---------- */}
              <g transform="translate(-116 -46) rotate(-12)">
                <rect x="-6" y="-24" width="12" height="26" fill="url(#m-metalh)" />
                <rect x="-13" y="-92" width="26" height="72" rx="12" fill="url(#m-grip)" />
                {Array.from({ length: 7 }, (_, i) => (
                  <rect key={i} x="-12" y={-84 + i * 9} width="24" height="3" rx="1.5" fill="#000" opacity="0.6" />
                ))}
                <rect x="-9" y="-88" width="4" height="62" rx="2" fill="#6a7280" opacity="0.6" />
                <rect x="-15" y="-100" width="30" height="12" rx="6" fill="url(#m-metal)" />
                <rect x="10" y="-80" width="7" height="14" rx="3" fill="#d02020" />
              </g>

              {/* ---------- carry handle ---------- */}
              <path d="M-80 -46 L-80 -70 Q-80 -84 -66 -84 L14 -84 Q28 -84 28 -70 L28 -40" stroke="#0a0b0e" strokeWidth="14" fill="none" strokeLinejoin="round" />
              <path d="M-80 -46 L-80 -70 Q-80 -84 -66 -84 L14 -84 Q28 -84 28 -70 L28 -40" stroke="url(#m-metal)" strokeWidth="10" fill="none" strokeLinejoin="round" />
              <path d="M-76 -70 Q-76 -80 -66 -80 L14 -80" stroke="#c8d0dc" strokeWidth="2" fill="none" opacity="0.7" />

              {/* ---------- rear housing ---------- */}
              <path d="M-128 -48 L-42 -48 L-32 -38 L-32 26 L-42 36 L-122 36 Q-134 32 -134 20 L-134 -40 Q-134 -48 -128 -48Z" fill="url(#m-metal)" />
              <path d="M-128 -42 L-44 -42" stroke="#d0d8e2" strokeWidth="2" opacity="0.7" strokeLinecap="round" />
              <rect x="-120" y="-30" width="60" height="30" rx="4" fill="#1a1d22" />
              {Array.from({ length: 6 }, (_, i) => (
                <rect key={i} x={-116 + i * 9.5} y="-26" width="5" height="22" rx="2" fill="#4a505a" />
              ))}
              {[
                [-126, -40],
                [-42, -40],
                [-126, 28],
                [-42, 28],
                [-90, 14],
                [-70, 14],
              ].map(([x, y], i) => (
                <g key={i}>
                  <circle cx={x} cy={y} r="3.4" fill="url(#m-metal)" stroke="#0a0b0e" strokeWidth="1" />
                  <path d={`M${x - 2} ${y} L${x + 2} ${y}`} stroke="#0a0b0e" strokeWidth="1" />
                </g>
              ))}
              {/* brass plate */}
              <rect x="-58" y="-30" width="14" height="30" rx="3" fill="#c89a3a" stroke="#5a3a06" strokeWidth="1" />
              <path d="M-55 -26 L-55 -4" stroke="#fff0b0" strokeWidth="1.5" opacity="0.8" />
              {/* ammo box */}
              <rect x="-116" y="34" width="62" height="30" rx="4" fill="url(#m-metal)" />
              <rect x="-110" y="40" width="50" height="4" rx="2" fill="#c8a04a" opacity="0.8" />
              <path d="M-104 52 L-70 52" stroke="#0a0b0e" strokeWidth="2" />

              {/* motor drum */}
              <rect x="-38" y="-42" width="44" height="70" rx="10" fill="url(#m-metalh)" />
              {Array.from({ length: 6 }, (_, i) => (
                <rect key={i} x="-36" y={-34 + i * 10} width="40" height="3" rx="1.5" fill="#0a0b0e" opacity="0.55" />
              ))}

              {/* ---------- barrel cluster ---------- */}
              <rect x="0" y="-36" width="172" height="56" rx="8" fill="#0e1014" />
              <g clipPath="url(#m-barclip)">
                <g className="bar-idle" style={v({ '--pitch': `${PITCH}px` })}>
                  <g key={`b${fire}`} className={fire ? 'bar-fire' : ''} style={v({ '--pitch': `${PITCH}px` })}>
                    {BARRELS.map((y, i) => (
                      <g key={i}>
                        <rect x="0" y={y} width="172" height={PITCH - 3} rx="5" fill="url(#m-barrel)" />
                        <rect x="0" y={y + 3} width="172" height="1.6" fill="#d8dee8" opacity="0.6" />
                      </g>
                    ))}
                  </g>
                </g>
                <rect x="0" y="-36" width="172" height="56" fill="url(#m-cyl)" />
                {fire > 0 && <rect x="100" y="-36" width="72" height="56" fill="url(#m-heat)" className="heat" />}
                {fire > 0 && (
                  <g key={`st${fire}`} className="flick-1s">
                    {[-30, -20, -10, 0, 10].map((y) => (
                      <rect key={y} x="0" y={y} width="172" height="1.6" fill="#ffffff" opacity="0.55" />
                    ))}
                  </g>
                )}
              </g>
              {/* clamps */}
              {[
                [26, 20],
                [110, 14],
                [158, 12],
              ].map(([x, w]) => (
                <g key={x}>
                  <rect x={x} y="-42" width={w} height="68" rx="5" fill="url(#m-metalh)" />
                  <rect x={x + 3} y="-40" width="2.5" height="64" rx="1" fill="#d0d8e2" opacity="0.6" />
                  <circle cx={x + w / 2} cy="-34" r="2.4" fill="#0a0b0e" />
                  <circle cx={x + w / 2} cy="18" r="2.4" fill="#0a0b0e" />
                </g>
              ))}

              {/* muzzle face */}
              <g transform="translate(172 -8) scale(0.55 1)">
                <circle r="32" fill="url(#m-metal)" stroke="#0a0b0e" strokeWidth="3" />
                <g className="face-idle">
                  <g key={`fc${fire}`} className={fire ? 'face-fire' : ''}>
                    <circle r="28" fill="#1a1d22" />
                    {HOLES.map(([x, y], i) => (
                      <g key={i}>
                        <circle cx={x} cy={y} r="9" fill="#ffcf3a" stroke="#8a5a06" strokeWidth="1.5" />
                        <circle cx={x} cy={y} r="5.5" fill="#0a0604" />
                        <circle cx={x - 3} cy={y - 3} r="1.6" fill="#fff6c0" />
                      </g>
                    ))}
                    <circle r="5" fill="#5c6470" />
                  </g>
                </g>
              </g>
            </Shiny>
            {/* muzzle glow rings */}
            <g transform="translate(174 -8)">
              <ellipse rx="14" ry="30" fill="#ffcf3a" opacity="0.4" filter="url(#mini-soft)" className="pulse-op" />
            </g>
            <path d={star4(60, -30, 6)} fill="#fff" className="twinkle" />
            <path d={star4(-60, -76, 5)} fill="#fff" className="twinkle" style={v({ '--delay': '1.2s' })} />
          </g>

          {/* ---------- use effects (no projectile) ---------- */}
          {fire > 0 && (
            <g key={`fx${fire}`} transform="translate(188 -8)">
              {FX_SMOKE.map((s, i) => (
                <circle key={`sm${i}`} r="12" fill="#b8b0c8" className="smoke" style={v({ '--dx': `${s.dx}px`, '--dy': `${s.dy}px`, '--delay': `${s.d}s` })} />
              ))}
              <g className="strobe">
                <circle r="40" fill="url(#m-flash)" />
                <path d={star4(0, 0, 46, 0.1)} fill="#fff6c0" />
                <g transform="rotate(45)">
                  <path d={star4(0, 0, 24, 0.14)} fill="#ffb84a" />
                </g>
              </g>
              <circle r="10" fill="none" stroke="#ffd84a" strokeWidth="3" className="fx-ring" style={v({ '--s': 5 })} />
              <ellipse rx="14" ry="30" fill="#ff7a1a" opacity="0.7" className="heat" />
              {[0, 0.35, 0.7].flatMap((d0) =>
                FX_SPARK.slice(0, 8).map((p, i) => (
                  <path
                    key={`w${d0}-${i}`}
                    d="M0 -1.2 L9 0 L0 1.2Z"
                    fill={i % 2 ? '#fff0a0' : '#ffb84a'}
                    className="burst"
                    style={burstStyle({ ...p, delay: d0 + p.delay, r: (Math.atan2(p.dy, p.dx) * 180) / Math.PI }, 0.6)}
                  />
                )),
              )}
              {FX_SPARK.map((p, i) => (
                <path key={i} d="M0 -1.2 L9 0 L0 1.2Z" fill={i % 2 ? '#ffe46a' : '#ff8a1a'} className="burst" style={burstStyle({ ...p, delay: p.delay * 5, r: (Math.atan2(p.dy, p.dx) * 180) / Math.PI }, 0.7)} />
              ))}
            </g>
          )}
        </g>
      </g>
    </Stage>
  );
}
