import { Stage, Shiny } from '../components/Stage';
import { Gem } from '../components/Gem';
import { burstStyle, spread, star4, v } from '../lib/fx';

const FX_EMBERS = spread(16, -75, 75, 50, 120, 4);
const FX_SPARK = spread(10, -60, 60, 30, 80, 8);
const FX_SMOKE = [
  { dx: 30, dy: -40, d: 0.1 },
  { dx: 50, dy: -20, d: 0.2 },
  { dx: 15, dy: -55, d: 0.3 },
  { dx: 45, dy: -50, d: 0.15 },
];

const GRIP_O = 'M-76 -12 C-86 18 -100 52 -112 84 C-118 100 -110 114 -94 113 L-60 109 C-48 107 -44 98 -47 88 C-46 60 -40 28 -28 -4 Z';
const GRIP_I = 'M-69 -2 C-78 24 -91 54 -102 84 C-106 96 -100 104 -91 103 L-62 100 C-55 99 -53 93 -55 87 C-54 61 -47 30 -37 4 Z';
const FRAME = 'M-80 -66 L32 -66 L32 -6 L-22 -6 Q-30 -6 -34 -2 L-74 -10 Q-86 -22 -86 -42 Q-86 -62 -80 -66Z';

const Diamond = ({ x, y, s = 8 }: { x: number; y: number; s?: number }) => (
  <g>
    <path d={`M${x} ${y - s} L${x + s * 0.8} ${y} L${x} ${y + s} L${x - s * 0.8} ${y}Z`} fill="url(#r-gold)" stroke="#5a3006" strokeWidth="1" />
    <path d={`M${x} ${y - s * 0.55} L${x + s * 0.42} ${y} L${x} ${y + s * 0.55} L${x - s * 0.42} ${y}Z`} fill="#ff3d63" />
    <path d={`M${x} ${y - s * 0.55} L${x - s * 0.42} ${y} L${x} ${y}Z`} fill="#ffb3c2" />
  </g>
);

export default function RubyRevolver({ fire }: { fire: number }) {
  return (
    <Stage id="ruby" fire={fire} glow="#ff4d6d" mote="#ffb3c4" outline="#2a0208">
      <defs>
        <linearGradient id="r-red" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#ff9aa6" />
          <stop offset="0.18" stopColor="#f2304c" />
          <stop offset="0.6" stopColor="#b30d2a" />
          <stop offset="1" stopColor="#4e0310" />
        </linearGradient>
        <linearGradient id="r-gold" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#fff6c4" />
          <stop offset="0.28" stopColor="#ffd25a" />
          <stop offset="0.65" stopColor="#d08a1c" />
          <stop offset="1" stopColor="#6e3a06" />
        </linearGradient>
        <linearGradient id="r-goldh" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0" stopColor="#8a4e0a" />
          <stop offset="0.35" stopColor="#ffe08a" />
          <stop offset="0.7" stopColor="#e3a232" />
          <stop offset="1" stopColor="#7a4206" />
        </linearGradient>
        <pattern id="r-quilt" width="14" height="14" patternUnits="userSpaceOnUse" patternTransform="rotate(13) translate(2 0)">
          <rect width="14" height="14" fill="#7d0619" />
          <path d="M0 7 L7 0 L14 7 L7 14Z" fill="#d81c3c" stroke="#4a0210" strokeWidth="1.1" />
          <path d="M2.5 7 L7 2.5 L9.5 5" stroke="#ffa1b0" strokeWidth="1.1" fill="none" opacity="0.8" />
          <circle cx="7" cy="0" r="1.1" fill="#ffd36b" />
        </pattern>
        <linearGradient id="r-gripshade" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0" stopColor="#000" stopOpacity="0.45" />
          <stop offset="0.45" stopColor="#fff" stopOpacity="0.12" />
          <stop offset="1" stopColor="#000" stopOpacity="0.35" />
        </linearGradient>
        <radialGradient id="r-flash">
          <stop offset="0" stopColor="#fffbe6" />
          <stop offset="0.35" stopColor="#ffd36b" stopOpacity="0.9" />
          <stop offset="0.7" stopColor="#ff3a5c" stopOpacity="0.5" />
          <stop offset="1" stopColor="#ff3a5c" stopOpacity="0" />
        </radialGradient>
      </defs>

      <g className="floaty">
        <g transform="translate(204 204) rotate(-27) scale(1.05)">
          <g key={fire} className={fire ? 'recoil' : ''}>
            <Shiny id="ruby" fire={fire}>
              {/* ---------- grip ---------- */}
              <path d={GRIP_O} fill="url(#r-goldh)" stroke="#5a3006" strokeWidth="1.5" strokeLinejoin="round" />
              <path d={GRIP_I} fill="url(#r-quilt)" />
              <path d={GRIP_I} fill="url(#r-gripshade)" />
              <path d="M-66 4 C-74 28 -86 58 -96 86" stroke="#ffd6dd" strokeWidth="2" fill="none" opacity="0.35" strokeLinecap="round" />
              <path d="M-72 -10 C-80 14 -94 50 -106 82" stroke="#fff3c4" strokeWidth="1.6" fill="none" opacity="0.7" />
              <g transform="rotate(13 -70 46)">
                <path d="M-70 26 L-58 46 L-70 66 L-82 46Z" fill="url(#r-gold)" stroke="#5a3006" strokeWidth="1.2" />
                <path d="M-70 31 L-62 46 L-70 61 L-78 46Z" fill="#ff5c8d" />
                <path d="M-70 31 L-78 46 L-70 46Z" fill="#ffd0dc" />
                <path d="M-70 46 L-62 46 L-70 61Z" fill="#b0103f" />
              </g>
              <g transform="rotate(13 -80 92)">
                <path d="M-93 98 L-95 85 L-88 91 L-80 80 L-72 91 L-65 85 L-67 98Z" fill="url(#r-gold)" stroke="#5a3006" strokeWidth="1.2" strokeLinejoin="round" />
                <circle cx="-80" cy="80" r="2" fill="#fff6c4" />
                <circle cx="-95" cy="85" r="1.5" fill="#fff6c4" />
                <circle cx="-65" cy="85" r="1.5" fill="#fff6c4" />
                <rect x="-94" y="97" width="28" height="4" rx="2" fill="url(#r-gold)" />
                <circle cx="-80" cy="93" r="2" fill="#ff3d63" />
              </g>
              {/* grip top scroll */}
              <path d="M-70 -8 C-58 2 -46 -2 -44 -10 C-42 -16 -50 -18 -52 -13" stroke="url(#r-gold)" strokeWidth="3" fill="none" strokeLinecap="round" />

              {/* ---------- trigger guard ---------- */}
              <path d="M-30 -6 C-36 22 -10 36 12 26 C24 20 30 6 27 -6" stroke="#5a3006" strokeWidth="9" fill="none" strokeLinecap="round" />
              <path d="M-30 -6 C-36 22 -10 36 12 26 C24 20 30 6 27 -6" stroke="url(#r-goldh)" strokeWidth="6" fill="none" strokeLinecap="round" />
              <path d="M-26 0 C-28 18 -12 28 6 24" stroke="#fff6c4" strokeWidth="1.5" fill="none" opacity="0.8" />
              <path d="M0 -6 C-7 6 -5 16 4 22" stroke="#5a3006" strokeWidth="7" fill="none" strokeLinecap="round" />
              <path d="M0 -6 C-7 6 -5 16 4 22" stroke="url(#r-gold)" strokeWidth="4.5" fill="none" strokeLinecap="round" />

              {/* ---------- frame ---------- */}
              <path d={FRAME} fill="url(#r-red)" stroke="url(#r-gold)" strokeWidth="3.5" strokeLinejoin="round" />
              <path d="M-80 -30 C-70 -14 -54 -18 -58 -30 C-60 -38 -68 -34 -65 -28" stroke="url(#r-gold)" strokeWidth="2.5" fill="none" strokeLinecap="round" />
              <path d="M-80 -56 L-60 -56" stroke="#ffb3c0" strokeWidth="2" opacity="0.6" strokeLinecap="round" />
              <rect x="-82" y="-72" width="116" height="8" rx="4" fill="url(#r-gold)" stroke="#5a3006" strokeWidth="1" />

              {/* hammer */}
              <g className={fire ? 'hammer' : ''}>
                <path d="M-74 -68 C-86 -76 -96 -90 -106 -90 C-108 -82 -98 -66 -82 -58Z" fill="url(#r-gold)" stroke="#5a3006" strokeWidth="1.5" strokeLinejoin="round" />
                <path d="M-100 -86 L-94 -84 M-97 -80 L-91 -78" stroke="#5a3006" strokeWidth="1.2" />
              </g>

              {/* ---------- barrel ---------- */}
              <path d="M30 -36 L126 -36 Q132 -36 132 -30 L132 -26 Q132 -20 126 -20 L30 -20Z" fill="url(#r-red)" stroke="#4a0210" strokeWidth="1.2" />
              <circle cx="132" cy="-28" r="5.5" fill="url(#r-gold)" stroke="#5a3006" strokeWidth="1" />
              <rect x="30" y="-63" width="134" height="27" rx="6" fill="url(#r-red)" stroke="#4a0210" strokeWidth="1.2" />
              <rect x="34" y="-58" width="126" height="4.5" rx="2.2" fill="#fff" opacity="0.5" />
              <rect x="30" y="-45" width="134" height="8" rx="3" fill="#3a0008" opacity="0.28" />
              <rect x="26" y="-70" width="142" height="8" rx="4" fill="url(#r-gold)" stroke="#5a3006" strokeWidth="1" />
              <rect x="30" y="-39" width="134" height="3" rx="1.5" fill="url(#r-gold)" />
              <Diamond x={64} y={-49} />
              <Diamond x={100} y={-49} />
              <Diamond x={136} y={-49} />
              <circle cx="82" cy="-49" r="2" fill="url(#r-gold)" />
              <circle cx="118" cy="-49" r="2" fill="url(#r-gold)" />
              <path d="M146 -70 L152 -79 L158 -70Z" fill="url(#r-gold)" stroke="#5a3006" strokeWidth="1" />
              <rect x="26" y="-70" width="11" height="50" rx="3" fill="url(#r-gold)" stroke="#5a3006" strokeWidth="1" />

              {/* muzzle */}
              <rect x="160" y="-72" width="18" height="54" rx="6" fill="url(#r-gold)" stroke="#5a3006" strokeWidth="1.5" />
              <rect x="164" y="-69" width="3" height="48" rx="1.5" fill="#fff6c4" opacity="0.8" />
              <ellipse cx="178" cy="-45" rx="6" ry="21" fill="#f0bd4e" stroke="#5a3006" strokeWidth="1.5" />
              <ellipse cx="179" cy="-45" rx="3.5" ry="11" fill="#2a0005" />

              {/* ---------- cylinder ---------- */}
              <rect x="-48" y="-78" width="78" height="70" rx="20" fill="url(#r-gold)" stroke="#5a3006" strokeWidth="1.5" />
              <rect x="-41" y="-71" width="64" height="56" rx="15" fill="#4a0210" />
              <rect x="-41" y="-71" width="64" height="56" rx="15" fill="none" stroke="#fff6c4" strokeWidth="1" opacity="0.4" />
              <Gem cx={-9} cy={-43} r={25} light="#ff9fb2" mid="#e3173f" dark="#7d0019" />
              {[
                [-35, -66],
                [17, -66],
                [-35, -20],
                [17, -20],
              ].map(([x, y], i) => (
                <circle key={i} cx={x} cy={y} r="3" fill="url(#r-gold)" stroke="#5a3006" strokeWidth="0.8" />
              ))}
              {fire > 0 && <circle cx={-9} cy={-43} r={25} fill="#ffe1e8" className="overlay-flash" />}
            </Shiny>
            <path d={star4(-20, -58, 7)} fill="#fff" className="twinkle" />
            <path d={star4(170, -72, 9)} fill="#fff6d6" className="twinkle" style={v({ '--delay': '1.2s' })} />
          </g>

          {/* ---------- use effects ---------- */}
          {fire > 0 && (
            <g key={`fx${fire}`} transform="translate(186 -45)">
              {FX_SMOKE.map((s, i) => (
                <circle key={`sm${i}`} r="10" fill="#f3c7d2" className="smoke" style={v({ '--dx': `${s.dx}px`, '--dy': `${s.dy}px`, '--delay': `${s.d}s` })} />
              ))}
              <circle r="40" fill="url(#r-flash)" className="fx-flash" />
              <path d={star4(0, 0, 48, 0.1)} fill="#fff3c4" className="fx-flare" />
              <g transform="rotate(45)">
                <path d={star4(0, 0, 26, 0.12)} fill="#ff6f89" className="fx-flare" style={v({ '--delay': '.05s' })} />
              </g>
              <circle r="10" fill="none" stroke="#ff8aa0" strokeWidth="3" className="fx-ring" style={v({ '--s': 5.5 })} />
              <circle r="10" fill="none" stroke="#ffe08a" strokeWidth="1.5" className="fx-ring" style={v({ '--s': 4, '--delay': '.1s' })} />
              {FX_EMBERS.map((p, i) => (
                <path key={i} d="M0 -4 L3 0 L0 4 L-3 0Z" fill={i % 3 ? '#ff4d6d' : '#ffd36b'} className="burst" style={burstStyle(p, 1)} />
              ))}
              {FX_SPARK.map((p, i) => (
                <path key={`s${i}`} d={star4(0, 0, 4)} fill="#fff6d0" className="burst" style={burstStyle(p, 0.8)} />
              ))}
            </g>
          )}
        </g>
      </g>
    </Stage>
  );
}
