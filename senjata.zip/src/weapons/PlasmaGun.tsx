import { Stage, Shiny } from '../components/Stage';
import { burstStyle, spread, star4, v, zigzag } from '../lib/fx';

const BOLTS = [
  { d: zigzag(-26, 118, -40, 9, 12, 1), delay: 0 },
  { d: zigzag(-26, 118, -34, 10, 10, 2), delay: 0.25 },
  { d: zigzag(-20, 112, -46, 6, 14, 3), delay: 0.45 },
  { d: zigzag(0, 90, -30, 7, 8, 4), delay: 0.12 },
];
const FX_ARCS = Array.from({ length: 8 }, (_, i) => ({ a: i * 45 + 10, d: zigzag(6, 46, 0, 6, 5, 20 + i) }));
const FX_SPARK = spread(14, -90, 90, 40, 100, 31);
const BODY_ARCS = [
  zigzag(-126, -34, -72, 7, 7, 41),
  zigzag(-30, 116, 2, 6, 10, 42),
  zigzag(116, 178, -82, 6, 5, 43),
  zigzag(-34, 120, -64, 6, 11, 44),
  zigzag(-34, 120, -12, 6, 11, 45),
];
const GRIP_ARC = zigzag(-8, 90, 0, 6, 7, 46);

export default function PlasmaGun({ fire, label, rarity }: { fire: number; label?: string; rarity?: 'Rare' | 'Epic' | 'Legendary' | 'Mythic' }) {
  const boltCls = fire ? 'bolt-fast' : 'bolt';
  return (
    <Stage id="plasma" fire={fire} label={label} rarity={rarity} glow="#5dff6a" mote="#b8ffb0" outline="#04140a">
      <defs>
        <linearGradient id="p-metal" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#8a94a4" />
          <stop offset="0.3" stopColor="#4a525e" />
          <stop offset="0.7" stopColor="#262b33" />
          <stop offset="1" stopColor="#0c0e12" />
        </linearGradient>
        <linearGradient id="p-metalh" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0" stopColor="#14171c" />
          <stop offset="0.4" stopColor="#5a6472" />
          <stop offset="0.7" stopColor="#323842" />
          <stop offset="1" stopColor="#0c0e12" />
        </linearGradient>
        <linearGradient id="p-glass" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#e6ffe0" />
          <stop offset="0.2" stopColor="#7dff7a" />
          <stop offset="0.6" stopColor="#1ed43a" />
          <stop offset="1" stopColor="#035c14" />
        </linearGradient>
        <radialGradient id="p-core" cx="0.5" cy="0.5" r="0.6">
          <stop offset="0" stopColor="#f0fff0" stopOpacity="0.9" />
          <stop offset="0.5" stopColor="#7dff7a" stopOpacity="0.4" />
          <stop offset="1" stopColor="#7dff7a" stopOpacity="0" />
        </radialGradient>
        <radialGradient id="p-flash">
          <stop offset="0" stopColor="#ffffff" />
          <stop offset="0.35" stopColor="#b0ff9a" stopOpacity="0.9" />
          <stop offset="1" stopColor="#1ed43a" stopOpacity="0" />
        </radialGradient>
        <clipPath id="p-tubeclip">
          <rect x="-34" y="-60" width="156" height="44" rx="10" />
        </clipPath>
      </defs>

      <g className="floaty">
        <g transform="translate(186 196) rotate(-12) scale(0.98)">
          <g key={fire} className={fire ? 'recoil' : ''}>
            <Shiny id="plasma" fire={fire}>
              {/* ---------- grip ---------- */}
              <path d="M-106 -12 L-62 -12 C-66 20 -74 52 -80 78 Q-84 90 -96 90 L-112 90 Q-124 88 -120 76 C-114 48 -110 18 -106 -12Z" fill="url(#p-metalh)" />
              {Array.from({ length: 6 }, (_, i) => (
                <path key={i} d={`M${-100 - i * 2.4} ${6 + i * 12} L${-74 - i * 2} ${6 + i * 12}`} stroke="#0a0c10" strokeWidth="3" strokeLinecap="round" />
              ))}
              <path d="M-66 -4 C-70 24 -76 50 -82 76" stroke="#7dff7a" strokeWidth="2.5" fill="none" />
              <path d="M-66 -4 C-70 24 -76 50 -82 76" stroke="#3dff5a" strokeWidth="6" fill="none" opacity="0.5" filter="url(#plasma-soft)" className="pulse-op" />
              <path d="M-96 30 L-102 46 L-94 46 L-100 62 L-86 42 L-94 42 L-88 30Z" fill="#5dff6a" filter="url(#plasma-soft)" className="pulse-op" />
              <rect x="-124" y="82" width="46" height="10" rx="4" fill="url(#p-metal)" />

              {/* trigger guard */}
              <path d="M-62 -10 C-66 18 -34 26 -22 0" stroke="#0c0e12" strokeWidth="9" fill="none" strokeLinecap="round" />
              <path d="M-62 -10 C-66 18 -34 26 -22 0" stroke="url(#p-metal)" strokeWidth="6" fill="none" strokeLinecap="round" />
              <path d="M-46 -10 C-50 0 -48 8 -42 12" stroke="#5dff6a" strokeWidth="4" fill="none" strokeLinecap="round" />

              {/* under rail */}
              <path d="M-40 -18 L120 -18 L112 -2 L-36 -2Z" fill="url(#p-metal)" />
              <path d="M-30 -10 L108 -10" stroke="#5dff6a" strokeWidth="2" />
              <path d="M-30 -10 L108 -10" stroke="#5dff6a" strokeWidth="5" opacity="0.5" filter="url(#plasma-soft)" />

              {/* rear housing */}
              <path d="M-122 -68 L-30 -68 L-30 -8 L-112 -8 Q-128 -12 -128 -32 L-128 -60 Q-128 -68 -122 -68Z" fill="url(#p-metal)" />
              <path d="M-120 -62 L-36 -62" stroke="#b8c2d0" strokeWidth="2" opacity="0.7" strokeLinecap="round" />
              {[-108, -98, -88, -78].map((x) => (
                <rect key={x} x={x} y="-56" width="5" height="18" rx="2" fill="#0a0c10" />
              ))}
              {[-60, -50, -40].map((x, i) => (
                <circle key={x} cx={x} cy="-24" r="3.2" fill="#5dff6a" className="led" style={v({ '--delay': `${i * 0.3}s` })} />
              ))}
              <path d="M-120 -32 L-70 -32 L-62 -22" stroke="#0a0c10" strokeWidth="1.5" fill="none" />
              <path d="M-126 -50 L-140 -46 L-140 -24 L-126 -20Z" fill="url(#p-metalh)" />
              {/* top sight */}
              <path d="M-112 -68 L-104 -84 L-60 -84 L-52 -68Z" fill="url(#p-metal)" />
              <rect x="-100" y="-81" width="34" height="5" rx="2.5" fill="#5dff6a" className="pulse-op" />
              <path d="M-106 -80 L-58 -80" stroke="#c8d2e0" strokeWidth="1.2" opacity="0.6" />

              {/* ---------- energy tube ---------- */}
              <rect x="-34" y="-60" width="156" height="44" rx="10" fill="url(#p-glass)" />
              <g clipPath="url(#p-tubeclip)">
                <rect x="-34" y="-60" width="156" height="44" fill="url(#p-core)" />
                {BOLTS.map((b, i) => (
                  <g key={i}>
                    <path d={b.d} stroke="#3dff5a" strokeWidth="5" fill="none" opacity="0.6" filter="url(#plasma-soft)" className={boltCls} style={v({ '--delay': `${b.delay}s` })} />
                    <path d={b.d} stroke="#f0fff0" strokeWidth="1.6" fill="none" strokeLinejoin="round" className={boltCls} style={v({ '--delay': `${b.delay}s` })} />
                  </g>
                ))}
                <rect x="-30" y="-56" width="148" height="6" rx="3" fill="#ffffff" opacity="0.6" />
                <rect x="-30" y="-24" width="148" height="5" fill="#022a0a" opacity="0.35" />
              </g>
              {fire > 0 && <rect key={`oc${fire}`} x="-34" y="-60" width="156" height="44" rx="10" fill="#f4fff0" className="overcharge" />}
              {/* rings */}
              {[-36, 40].map((x) => (
                <g key={x}>
                  <rect x={x} y="-64" width="12" height="52" rx="3" fill="url(#p-metalh)" />
                  <rect x={x + 2} y="-62" width="2" height="48" rx="1" fill="#b8c2d0" opacity="0.6" />
                  <circle cx={x + 6} cy="-58" r="2" fill="#0a0c10" />
                  <circle cx={x + 6} cy="-18" r="2" fill="#0a0c10" />
                </g>
              ))}

              {/* front cap + emitter */}
              <path d="M116 -70 L146 -70 L170 -80 Q176 -80 176 -74 L176 -2 Q176 4 170 4 L146 -6 L116 -6Z" fill="url(#p-metal)" />
              <path d="M120 -66 L146 -66 L168 -75" stroke="#c8d2e0" strokeWidth="2" fill="none" opacity="0.75" strokeLinecap="round" />
              {[124, 132, 140].map((x, i) => (
                <g key={x}>
                  <rect x={x} y="-58" width="5" height="40" rx="2.5" fill="#0a0c10" />
                  <rect x={x + 1.5} y="-52" width="2" height="28" rx="1" fill="#5dff6a" className="led" style={v({ '--delay': `${i * 0.25}s` })} />
                </g>
              ))}
              <path d="M150 -62 L170 -70 L170 -6 L150 -14Z" fill="#14171c" />
              <path d="M152 -58 L167 -64 M152 -18 L167 -12" stroke="#5dff6a" strokeWidth="2" />
              <ellipse cx="176" cy="-38" rx="7" ry="32" fill="url(#p-metalh)" />
              <ellipse cx="177" cy="-38" rx="5" ry="24" fill="#5dff6a" />
              <ellipse cx="177" cy="-38" rx="2.6" ry="14" fill="#f0fff0" />
            </Shiny>
            {/* emitter glow */}
            <g transform="translate(180 -38)">
              <circle r="16" fill="#5dff6a" opacity="0.55" filter="url(#plasma-soft)" className="pulse-op" />
              <path d={star4(0, 0, 14, 0.12)} fill="#e6ffe0" className="twinkle" />
            </g>
          </g>

          {fire > 0 && (
            <g key={`arcs${fire}`} strokeLinejoin="round" fill="none">
              {BODY_ARCS.map((d, i) => (
                <g key={i}>
                  <path d={d} stroke="#3dff5a" strokeWidth="6" opacity="0.55" className="flick-1s" style={v({ '--delay': `${(i % 3) * 0.04}s` })} />
                  <path d={d} stroke="#f4fff0" strokeWidth="1.8" className="flick-1s" style={v({ '--delay': `${(i % 3) * 0.04}s` })} />
                </g>
              ))}
              <g transform="translate(-70 -6) rotate(100)">
                <path d={GRIP_ARC} stroke="#3dff5a" strokeWidth="6" opacity="0.55" className="flick-1s" />
                <path d={GRIP_ARC} stroke="#f4fff0" strokeWidth="1.8" className="flick-1s" />
              </g>
            </g>
          )}

          {/* ---------- use effects (no projectile) ---------- */}
          {fire > 0 && (
            <g key={`fx${fire}`} transform="translate(184 -38)">
              <circle r="44" fill="url(#p-flash)" className="fx-flash" />
              <ellipse rx="8" ry="22" fill="none" stroke="#9dff8a" strokeWidth="3" className="fx-ring" style={v({ '--s': 4.5 })} />
              <ellipse rx="8" ry="22" fill="none" stroke="#ffffff" strokeWidth="1.5" className="fx-ring" style={v({ '--s': 3.2, '--delay': '.1s' })} />
              <circle r="10" fill="none" stroke="#5dff6a" strokeWidth="2" className="fx-ring" style={v({ '--s': 6, '--delay': '.18s', '--dur': '1s' })} />
              {FX_ARCS.map((a, i) => (
                <g key={i} transform={`rotate(${a.a})`}>
                  <path d={a.d} stroke="#e6ffe0" strokeWidth="2" fill="none" strokeLinejoin="round" className="overlay-flash" style={v({ '--delay': `${(i % 3) * 0.08}s` })} />
                  <path d={a.d} stroke="#3dff5a" strokeWidth="5" fill="none" opacity="0.6" className="overlay-flash" style={v({ '--delay': `${(i % 3) * 0.08}s` })} />
                </g>
              ))}
              {FX_SPARK.map((p, i) => (
                <path key={`s${i}`} d={star4(0, 0, 4.5)} fill={i % 2 ? '#e6ffe0' : '#7dff7a'} className="burst" style={burstStyle(p, 0.9)} />
              ))}
            </g>
          )}
        </g>
      </g>
    </Stage>
  );
}
