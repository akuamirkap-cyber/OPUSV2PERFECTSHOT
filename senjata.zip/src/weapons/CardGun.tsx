import { Stage, Shiny } from '../components/Stage';
import { burstStyle, spread, star4, v } from '../lib/fx';

type SuitT = 'h' | 'd' | 's' | 'c';
const RED = '#e0182c';
const BLK = '#1a1a24';

function Suit({ t, x, y, s = 1 }: { t: SuitT; x: number; y: number; s?: number }) {
  const fill = t === 'h' || t === 'd' ? RED : BLK;
  return (
    <g transform={`translate(${x} ${y}) scale(${s})`} fill={fill}>
      {t === 'h' && <path d="M0 4 C-7 -1 -6 -7 -3 -7 C-1.4 -7 -0.4 -6 0 -4.6 C0.4 -6 1.4 -7 3 -7 C6 -7 7 -1 0 4Z" />}
      {t === 'd' && <path d="M0 -7 L4.6 -1.5 L0 4 L-4.6 -1.5Z" />}
      {t === 's' && <path d="M0 -8 C-7 -2 -6.5 2 -3.2 2 C-1.7 2 -0.7 1 0 0 L-1.8 4 L1.8 4 L0 0 C0.7 1 1.7 2 3.2 2 C6.5 2 7 -2 0 -8Z" />}
      {t === 'c' && (
        <>
          <circle cx="0" cy="-4.4" r="2.8" />
          <circle cx="-3.2" cy="0" r="2.8" />
          <circle cx="3.2" cy="0" r="2.8" />
          <path d="M-0.8 0 L-2 4.5 L2 4.5 L0.8 0Z" />
        </>
      )}
    </g>
  );
}

function Card({ t, r, w = 24, h = 34 }: { t: SuitT; r: string; w?: number; h?: number }) {
  const col = t === 'h' || t === 'd' ? RED : BLK;
  return (
    <g>
      <rect x={-w / 2} y={-h} width={w} height={h} rx="3" fill="#ffffff" stroke="#9aa0b8" strokeWidth="1" />
      <rect x={-w / 2 + 2} y={-h + 2} width={w - 4} height={h - 4} rx="2" fill="none" stroke={col} strokeWidth="0.6" opacity="0.5" />
      <text x={-w / 2 + 3} y={-h + 8} fontSize="7" fontWeight="900" fill={col} fontFamily="Georgia, serif">
        {r}
      </text>
      <Suit t={t} x={0} y={-h / 2 + 1} s={w / 24} />
    </g>
  );
}

const FAN: { t: SuitT; r: string; a: number }[] = [
  { t: 's', r: 'J', a: -34 },
  { t: 'd', r: 'Q', a: -17 },
  { t: 'h', r: 'A', a: 0 },
  { t: 'c', r: 'K', a: 17 },
  { t: 'h', r: 'A', a: 34 },
];
const WINDOW: { t: SuitT; r: string }[] = [
  { t: 'h', r: 'A' },
  { t: 's', r: 'K' },
  { t: 'd', r: 'Q' },
  { t: 'c', r: 'J' },
];
const FX_CARDS = spread(7, -60, 60, 50, 90, 41);
const FX_SPARK = spread(12, -80, 80, 30, 90, 43);
const SUITS: SuitT[] = ['h', 's', 'd', 'c'];
const FX_SUITS = spread(8, -135, -45, 70, 120, 47);

export default function CardGun({ fire, label, rarity }: { fire: number; label?: string; rarity?: 'Rare' | 'Epic' | 'Legendary' | 'Mythic' }) {
  return (
    <Stage id="card" fire={fire} label={label} rarity={rarity} glow="#ff6a8a" mote="#ffd0dc" outline="#1a0410">
      <defs>
        <linearGradient id="c-white" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#ffffff" />
          <stop offset="0.45" stopColor="#eef1f7" />
          <stop offset="0.8" stopColor="#b8c0d0" />
          <stop offset="1" stopColor="#7a8498" />
        </linearGradient>
        <linearGradient id="c-red" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#ff8a96" />
          <stop offset="0.3" stopColor="#e8202e" />
          <stop offset="0.75" stopColor="#a00818" />
          <stop offset="1" stopColor="#56020c" />
        </linearGradient>
        <linearGradient id="c-redh" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0" stopColor="#6a0410" />
          <stop offset="0.45" stopColor="#ff4a5a" />
          <stop offset="0.75" stopColor="#c8101e" />
          <stop offset="1" stopColor="#5a020c" />
        </linearGradient>
        <linearGradient id="c-gold" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#fff6c4" />
          <stop offset="0.35" stopColor="#ffd25a" />
          <stop offset="0.7" stopColor="#c8841a" />
          <stop offset="1" stopColor="#6a3a06" />
        </linearGradient>
        <linearGradient id="c-win" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#7a0414" />
          <stop offset="1" stopColor="#2a0006" />
        </linearGradient>
        <linearGradient id="c-glass" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#ffffff" stopOpacity="0.45" />
          <stop offset="0.35" stopColor="#ffffff" stopOpacity="0" />
          <stop offset="0.6" stopColor="#ffffff" stopOpacity="0" />
          <stop offset="0.7" stopColor="#ffffff" stopOpacity="0.2" />
          <stop offset="0.8" stopColor="#ffffff" stopOpacity="0" />
        </linearGradient>
        <linearGradient id="c-streak" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0" stopColor="#5fd8ff" stopOpacity="0" />
          <stop offset="1" stopColor="#c8f4ff" />
        </linearGradient>
        <radialGradient id="c-flash">
          <stop offset="0" stopColor="#ffffff" />
          <stop offset="0.4" stopColor="#ffe08a" stopOpacity="0.8" />
          <stop offset="1" stopColor="#ff6a8a" stopOpacity="0" />
        </radialGradient>
      </defs>

      <g className="floaty">
        <g transform="translate(194 212) rotate(-6) scale(1.0)">
          <g key={fire} className={fire ? 'recoil' : ''}>
            <Shiny id="card" fire={fire}>
              {/* ---------- card fan on top ---------- */}
              {FAN.map((c, i) => (
                <g key={i} transform={`translate(-74 -50) rotate(${c.a})`}>
                  <g className="fan-idle" style={v({ '--k': i - 2 })}>
                    <g key={`f${fire}`} className={fire ? 'fan-fire' : ''} style={v({ '--k': i - 2 })}>
                      <g transform="translate(0 -2) scale(1.5)">
                        <Card t={c.t} r={c.r} />
                      </g>
                    </g>
                  </g>
                </g>
              ))}
              <rect x="-98" y="-60" width="48" height="14" rx="5" fill="url(#c-gold)" />
              <rect x="-94" y="-58" width="40" height="3" rx="1.5" fill="#fff6c4" />

              {/* ---------- grip ---------- */}
              <path d="M-102 -6 L-58 -6 C-62 24 -70 56 -78 80 Q-82 94 -96 94 L-112 94 Q-126 92 -122 78 C-112 52 -106 24 -102 -6Z" fill="url(#c-redh)" />
              <path d="M-102 -6 L-58 -6 C-62 24 -70 56 -78 80 Q-82 94 -96 94 L-112 94 Q-126 92 -122 78 C-112 52 -106 24 -102 -6Z" fill="none" stroke="url(#c-gold)" strokeWidth="4" strokeLinejoin="round" />
              <path d="M-94 4 C-98 30 -104 56 -112 82" stroke="#ffb0b8" strokeWidth="2.5" fill="none" opacity="0.6" strokeLinecap="round" />
              <circle cx="-88" cy="40" r="12" fill="url(#c-gold)" />
              <circle cx="-88" cy="40" r="9.5" fill="#ffffff" />
              <Suit t="s" x={-88} y={41} s={1.05} />
              <path d="M-120 82 L-78 82" stroke="url(#c-gold)" strokeWidth="3" />

              {/* trigger guard */}
              <path d="M-58 -6 C-62 24 -26 32 -10 6" stroke="#6a3a06" strokeWidth="9" fill="none" strokeLinecap="round" />
              <path d="M-58 -6 C-62 24 -26 32 -10 6" stroke="url(#c-gold)" strokeWidth="6" fill="none" strokeLinecap="round" />
              <path d="M-40 -4 C-46 8 -42 16 -36 20" stroke="#5a6070" strokeWidth="6.5" fill="none" strokeLinecap="round" />
              <path d="M-40 -4 C-46 8 -42 16 -36 20" stroke="url(#c-white)" strokeWidth="4" fill="none" strokeLinecap="round" />

              {/* rear fin */}
              <path d="M-118 -50 L-142 -60 Q-148 -34 -138 -8 L-118 -6Z" fill="url(#c-red)" stroke="url(#c-gold)" strokeWidth="2.5" strokeLinejoin="round" />

              {/* ---------- body ---------- */}
              <path d="M-112 -54 L114 -54 Q132 -54 138 -38 L142 -22 Q144 -4 128 -2 L-104 -2 Q-120 -4 -122 -24 L-122 -42 Q-122 -54 -112 -54Z" fill="url(#c-white)" />
              <path d="M-112 -54 L114 -54 Q128 -54 134 -46 L-120 -46 Q-120 -54 -112 -54Z" fill="url(#c-red)" />
              <path d="M-118 -46 L134 -46" stroke="url(#c-gold)" strokeWidth="2.5" />
              <path d="M-118 -10 L136 -10" stroke="url(#c-gold)" strokeWidth="2" />
              <path d="M-114 -8 L130 -8 Q138 -6 134 -2 L-104 -2 Q-114 -4 -114 -8Z" fill="#a00818" />
              <path d="M-112 -42 L-56 -42" stroke="#ffffff" strokeWidth="2.5" strokeLinecap="round" />

              {/* window with cards */}
              <rect x="-48" y="-43" width="146" height="32" rx="6" fill="url(#c-win)" stroke="url(#c-gold)" strokeWidth="3" />
              {WINDOW.map((c, i) => (
                <g key={i} transform={`translate(${-28 + i * 36} -13)`}>
                  <g className={fire ? 'card-pop' : ''} style={v({ '--delay': `${i * 0.06}s` })}>
                    <Card t={c.t} r={c.r} w={22} h={28} />
                  </g>
                </g>
              ))}
              <rect x="-46" y="-41" width="142" height="28" rx="5" fill="url(#c-glass)" />

              {/* nose */}
              <path d="M136 -48 L158 -44 Q166 -28 158 -10 L136 -6Z" fill="url(#c-white)" />
              <path d="M140 -44 L156 -41" stroke="#ffffff" strokeWidth="2" strokeLinecap="round" />
              <path d="M136 -12 L159 -12 Q157 -8 152 -8 L136 -6Z" fill="#a00818" />
              <rect x="138" y="-50" width="8" height="46" rx="3" fill="url(#c-gold)" />
              <rect x="158" y="-45" width="12" height="36" rx="5" fill="url(#c-gold)" />
              <rect x="160" y="-42" width="3" height="30" rx="1.5" fill="#fff6c4" opacity="0.8" />
              <ellipse cx="170" cy="-27" rx="5" ry="16" fill="#1a0a20" />
              <ellipse cx="170" cy="-27" rx="3.6" ry="12" fill="#5fd8ff" className="pulse-op" />
              <ellipse cx="170" cy="-27" rx="1.6" ry="6" fill="#e6fbff" />
              {/* rear filigree */}
              <path d="M-110 -32 C-100 -20 -86 -24 -88 -34 C-90 -40 -97 -38 -95 -33" stroke="url(#c-gold)" strokeWidth="2.5" fill="none" strokeLinecap="round" />
              <path d="M-70 -36 L-64 -28 L-70 -20 L-76 -28Z" fill="#e0182c" stroke="url(#c-gold)" strokeWidth="1.5" />
              <path d="M-70 -34 L-73 -28 L-70 -28Z" fill="#ffb0b8" />
              {/* screws */}
              {[-104, 116].map((x) => (
                <circle key={x} cx={x} cy="-28" r="3" fill="url(#c-gold)" />
              ))}
            </Shiny>
            <ellipse cx="174" cy="-27" rx="12" ry="22" fill="#5fd8ff" opacity="0.5" filter="url(#card-soft)" className="pulse-op" />
            <path d={star4(-30, -38, 5)} fill="#fff" className="twinkle" />
            <path d={star4(120, -50, 6)} fill="#fff" className="twinkle" style={v({ '--delay': '1s' })} />
          </g>

          {/* ---------- use effects (no projectile) ---------- */}
          {fire > 0 && (
            <g key={`fx${fire}`} transform="translate(178 -27)">
              <circle r="34" fill="url(#c-flash)" className="fx-flash" />
              <g className="card-circle">
                {Array.from({ length: 12 }, (_, i) => (
                  <g key={`cc${i}`} transform={`rotate(${i * 30}) translate(0 -40) scale(0.5)`}>
                    <Card t={SUITS[i % 4]} r={['A', 'K', 'Q', 'J'][i % 4]} />
                  </g>
                ))}
              </g>
              {FX_SUITS.map((p, i) => (
                <g key={`su${i}`} className="burst" style={burstStyle({ ...p, delay: p.delay + 0.2, s: 1.4 }, 1.3)}>
                  <Suit t={SUITS[i % 4]} x={0} y={0} s={1.6} />
                </g>
              ))}
              {[-14, -5, 4, 13].map((y, i) => (
                <rect key={i} x="4" y={y - 1.5} width={50 + (i % 2) * 20} height="3" rx="1.5" fill="url(#c-streak)" className="streak" style={v({ '--delay': `${i * 0.05}s` })} />
              ))}
              <circle r="10" fill="none" stroke="#ffd25a" strokeWidth="2.5" className="fx-ring" style={v({ '--s': 4.5 })} />
              {FX_CARDS.map((p, i) => (
                <g key={i} className="burst" style={burstStyle(p, 1)}>
                  <g transform="scale(0.55) translate(0 17)">
                    <Card t={SUITS[i % 4]} r={i % 2 ? 'A' : 'K'} />
                  </g>
                </g>
              ))}
              {FX_SPARK.map((p, i) => (
                <path key={`s${i}`} d={star4(0, 0, 4.5)} fill={i % 2 ? '#fff6c4' : '#ff8aa0'} className="burst" style={burstStyle(p, 0.8)} />
              ))}
            </g>
          )}
        </g>
      </g>
    </Stage>
  );
}
