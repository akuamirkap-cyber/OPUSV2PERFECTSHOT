import { Stage, Shiny } from '../components/Stage';
import { TEARDROP, burstStyle, rand, spread, star4, v } from '../lib/fx';

const WAVE =
  'M-200 -70 ' +
  Array.from({ length: 16 }, (_, i) => (i === 0 ? 'q15 -6 30 0' : 't30 0')).join(' ') +
  ' L280 -20 L-200 -20Z';
const WAVE2 =
  'M-180 -64 ' +
  Array.from({ length: 16 }, (_, i) => (i === 0 ? 'q15 5 30 0' : 't30 0')).join(' ') +
  ' L300 -20 L-180 -20Z';

const BUBBLES = Array.from({ length: 9 }, (_, i) => ({
  x: -90 + ((i * 29) % 150),
  y: -48 + ((i * 7) % 12),
  r: 1.6 + (i % 3),
  d: (i * 0.41) % 3,
  dur: 2.2 + (i % 4) * 0.5,
}));
const DROPS = Array.from({ length: 16 }, (_, i) => ({
  x: 30 + rand(i + 1) * 340,
  y: 30 + rand(i + 21) * 300,
  s: 0.5 + rand(i + 41) * 0.8,
  d: rand(i + 61) * 3,
}));
const FX_DROPS = spread(18, -70, 70, 50, 120, 21);
const RAINBOW = ['#ff4d6d', '#ffa62e', '#ffe84a', '#5fe06a', '#4fb8ff', '#9a6aff'];
const CROWN = Array.from({ length: 9 }, (_, i) => {
  const a = ((-150 + i * 15) * Math.PI) / 180;
  return { dx: Math.cos(a) * 46, dy: Math.sin(a) * 46, r: 0, delay: 0.05 + (i % 3) * 0.04, s: 1.1 };
});
const FX_MIST = [
  { dx: 40, dy: -20, d: 0 },
  { dx: 55, dy: 10, d: 0.08 },
  { dx: 30, dy: -40, d: 0.15 },
  { dx: 60, dy: -8, d: 0.2 },
];

export default function SuperSoaker({ fire, label, rarity }: { fire: number; label?: string; rarity?: 'Rare' | 'Epic' | 'Legendary' | 'Mythic' }) {
  return (
    <Stage id="soak" fire={fire} label={label} rarity={rarity} glow="#5fd8ff" mote="#bdf2ff" outline="#0a1c4a" bg={['#6fb8ff', '#2648c8', '#0b1048']}>
      <defs>
        <linearGradient id="s-green" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#d2ff7a" />
          <stop offset="0.3" stopColor="#6fe03a" />
          <stop offset="0.72" stopColor="#2a9e18" />
          <stop offset="1" stopColor="#0f560a" />
        </linearGradient>
        <linearGradient id="s-greenh" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0" stopColor="#1c7a10" />
          <stop offset="0.4" stopColor="#8af04a" />
          <stop offset="0.75" stopColor="#46c024" />
          <stop offset="1" stopColor="#14600a" />
        </linearGradient>
        <linearGradient id="s-orange" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#ffe89a" />
          <stop offset="0.3" stopColor="#ffb02e" />
          <stop offset="0.75" stopColor="#e2620a" />
          <stop offset="1" stopColor="#8a3404" />
        </linearGradient>
        <linearGradient id="s-tank" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#e6f7ff" />
          <stop offset="0.25" stopColor="#7cc8ff" />
          <stop offset="0.7" stopColor="#2f86f0" />
          <stop offset="1" stopColor="#123e9e" />
        </linearGradient>
        <linearGradient id="s-water" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#7ae4ff" />
          <stop offset="1" stopColor="#0d5ad8" />
        </linearGradient>
        <linearGradient id="s-white" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#ffffff" />
          <stop offset="0.6" stopColor="#dfe6f0" />
          <stop offset="1" stopColor="#8e9ab0" />
        </linearGradient>
        <linearGradient id="s-shade" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#ffffff" stopOpacity="0.55" />
          <stop offset="0.3" stopColor="#ffffff" stopOpacity="0" />
          <stop offset="0.75" stopColor="#000" stopOpacity="0" />
          <stop offset="1" stopColor="#001040" stopOpacity="0.4" />
        </linearGradient>
        <radialGradient id="s-flash">
          <stop offset="0" stopColor="#ffffff" />
          <stop offset="0.45" stopColor="#9eeaff" stopOpacity="0.8" />
          <stop offset="1" stopColor="#3aa8ff" stopOpacity="0" />
        </radialGradient>
        <clipPath id="s-tankclip">
          <rect x="-104" y="-92" width="170" height="56" rx="28" />
        </clipPath>
      </defs>

      {/* water swirl background */}
      <g fill="none" strokeLinecap="round">
        <path d="M40 270 C10 160 120 60 250 70 C340 78 380 150 340 210" stroke="#7fe6ff" strokeWidth="14" opacity="0.22" />
        <path d="M40 270 C10 160 120 60 250 70 C340 78 380 150 340 210" stroke="#c8f6ff" strokeWidth="3" opacity="0.6" strokeDasharray="60 20 10 20" className="dash-flow" />
        <path d="M70 300 C120 330 250 340 330 280" stroke="#7fe6ff" strokeWidth="10" opacity="0.2" />
        <path d="M70 300 C120 330 250 340 330 280" stroke="#c8f6ff" strokeWidth="2.5" opacity="0.5" strokeDasharray="40 16" className="dash-flow" />
      </g>
      {DROPS.map((d, i) => (
        <g key={i} transform={`translate(${d.x.toFixed(0)} ${d.y.toFixed(0)}) scale(${d.s.toFixed(2)})`}>
          <path d={TEARDROP} fill="#9eeaff" stroke="#e6fbff" strokeWidth="1" className="twinkle" style={v({ '--delay': `${d.d.toFixed(2)}s` })} />
        </g>
      ))}

      <g className="floaty">
        <g transform="translate(196 190) rotate(-14) scale(0.92)">
          <g key={fire} className={fire ? 'recoil' : ''}>
            <Shiny id="soak" fire={fire}>
              {/* ---------- grip ---------- */}
              <path d="M-80 0 L-38 0 C-42 30 -50 60 -56 84 Q-60 98 -76 98 L-94 98 Q-108 96 -104 82 C-94 56 -86 28 -80 0Z" fill="url(#s-greenh)" />
              <path d="M-74 10 L-48 10 C-52 36 -58 60 -64 82 L-90 84 C-84 60 -78 36 -74 10Z" fill="#1a6a10" />
              {Array.from({ length: 6 }, (_, i) => (
                <path key={i} d={`M${-74 - i * 2.6} ${18 + i * 11} L${-52 - i * 2.2} ${18 + i * 11}`} stroke="#5cd030" strokeWidth="2.5" strokeLinecap="round" />
              ))}
              <path d="M-74 4 C-80 30 -88 58 -98 88" stroke="#e6ffb0" strokeWidth="2.5" fill="none" opacity="0.6" strokeLinecap="round" />

              {/* lower housing */}
              <path d="M-126 -8 L-28 -8 L-28 16 Q-28 24 -36 24 L-112 24 Q-126 22 -126 8Z" fill="url(#s-green)" />
              <path d="M-120 -2 L-34 -2" stroke="#e6ffb0" strokeWidth="2.5" opacity="0.65" strokeLinecap="round" />
              <path d="M-118 18 L-40 18" stroke="#0f560a" strokeWidth="2" opacity="0.5" />
              <circle cx="-44" cy="8" r="3" fill="#ffb02e" stroke="#8a3404" strokeWidth="1" />
              {/* trigger guard + trigger */}
              <path d="M-38 0 C-42 30 -6 36 10 14 L10 0" stroke="#0f560a" strokeWidth="10" fill="none" strokeLinecap="round" strokeLinejoin="round" />
              <path d="M-38 0 C-42 30 -6 36 10 14 L10 0" stroke="url(#s-green)" strokeWidth="7" fill="none" strokeLinecap="round" strokeLinejoin="round" />
              <path d="M-18 2 C-26 12 -22 22 -14 28" stroke="#8a0a0a" strokeWidth="8" fill="none" strokeLinecap="round" />
              <path d="M-18 2 C-26 12 -22 22 -14 28" stroke="#ff3b3b" strokeWidth="5" fill="none" strokeLinecap="round" />

              {/* rear stock */}
              <path d="M-116 -28 L-150 -20 Q-162 -10 -154 2 L-116 8Z" fill="url(#s-green)" />
              <path d="M-148 -16 L-120 -22" stroke="#e6ffb0" strokeWidth="2" opacity="0.7" strokeLinecap="round" />

              {/* pump rod + pump */}
              <rect x="4" y="6" width="120" height="8" rx="4" fill="url(#s-green)" />
              <g key={`p${fire}`} className={fire ? 'pump-pull' : ''}>
                <rect x="22" y="2" width="86" height="26" rx="12" fill="url(#s-orange)" />
                {Array.from({ length: 8 }, (_, i) => (
                  <rect key={i} x={30 + i * 9.5} y="4" width="4" height="22" rx="2" fill="#b0480a" opacity="0.6" />
                ))}
                <rect x="28" y="5" width="74" height="4" rx="2" fill="#fff4c4" opacity="0.8" />
              </g>

              {/* ---------- body barrel ---------- */}
              <path d="M-114 -30 L118 -30 Q128 -30 128 -20 L128 -6 Q128 4 118 4 L-114 4 Q-124 4 -124 -6 L-124 -20 Q-124 -30 -114 -30Z" fill="url(#s-green)" />
              <rect x="-118" y="-30" width="244" height="34" rx="10" fill="url(#s-shade)" />
              <path d="M-110 -24 L120 -24" stroke="#f0ffc8" strokeWidth="3" strokeLinecap="round" opacity="0.8" />
              <path d="M-40 -8 L110 -8" stroke="#145e0c" strokeWidth="2" opacity="0.6" />

              {/* nozzle */}
              <rect x="122" y="-31" width="30" height="38" rx="7" fill="url(#s-orange)" />
              {[129, 136, 143].map((x) => (
                <rect key={x} x={x} y="-27" width="3.5" height="30" rx="1.7" fill="#b0480a" opacity="0.55" />
              ))}
              <rect x="125" y="-28" width="24" height="4" rx="2" fill="#fff4c4" opacity="0.9" />
              <path d="M151 -25 L166 -21 L166 -3 L151 1Z" fill="url(#s-tank)" />
              <path d="M153 -22 L164 -19" stroke="#ffffff" strokeWidth="1.6" strokeLinecap="round" />
              <rect x="164" y="-23" width="9" height="22" rx="3" fill="url(#s-orange)" />
              <ellipse cx="173" cy="-12" rx="2.6" ry="6.5" fill="#0a2a6e" />

              {/* gauge */}
              <g transform="translate(-92 -14)">
                <circle r="16" fill="url(#s-green)" stroke="#0f560a" strokeWidth="1.5" />
                <circle r="12.5" fill="url(#s-white)" />
                <path d="M-9 4 A10 10 0 0 1 -6 -8" stroke="#2fbf2f" strokeWidth="3" fill="none" />
                <path d="M-6 -8 A10 10 0 0 1 6 -8" stroke="#ffc12e" strokeWidth="3" fill="none" />
                <path d="M6 -8 A10 10 0 0 1 9 4" stroke="#ff3b3b" strokeWidth="3" fill="none" />
                <g className="needle-idle">
                  <g key={`n${fire}`} className={fire ? 'needle-fire' : ''}>
                    <path d="M0 0 L-1.6 0 L0 -10 L1.6 0Z" fill="#d81818" />
                  </g>
                </g>
                <circle r="2.4" fill="#333" />
              </g>

              {/* tank connectors */}
              <rect x="-74" y="-42" width="18" height="16" rx="3" fill="url(#s-greenh)" />
              <rect x="20" y="-42" width="18" height="16" rx="3" fill="url(#s-greenh)" />

              {/* ---------- tank ---------- */}
              <rect x="-104" y="-92" width="170" height="56" rx="28" fill="url(#s-tank)" opacity="0.95" />
              <g clipPath="url(#s-tankclip)">
                <g key={`w${fire}`} className={fire ? 'slosh' : ''}>
                  <g className="water-wave" style={{ animationDuration: '3.4s' }}>
                    <path d={WAVE2} fill="#4fb6ff" opacity="0.5" />
                  </g>
                  <g className="water-wave">
                    <path d={WAVE} fill="url(#s-water)" opacity="0.85" />
                  </g>
                </g>
                {BUBBLES.map((b, i) => (
                  <g key={i} transform={`translate(${b.x} ${b.y})`}>
                    <circle r={b.r} fill="#e6fbff" className="bubble" style={v({ '--delay': `${b.d}s`, '--dur': `${b.dur}s`, '--dx': '10px', '--dy': '-22px' })} />
                  </g>
                ))}
              </g>
              <rect x="-92" y="-86" width="146" height="8" rx="4" fill="#fff" opacity="0.75" />
              <rect x="-84" y="-48" width="60" height="4" rx="2" fill="#fff" opacity="0.3" />
              {fire > 0 && <rect x="-104" y="-92" width="170" height="56" rx="28" fill="#e6fbff" className="overlay-flash" />}
              {/* logo */}
              <circle cx="-18" cy="-64" r="14" fill="#ffffff" />
              <circle cx="-18" cy="-64" r="11" fill="#2a7ff0" />
              <path d={star4(-18, -64, 8, 0.25)} fill="#ffffff" />
              {/* back cap */}
              <rect x="-124" y="-88" width="28" height="48" rx="11" fill="url(#s-white)" />
              {[-118, -111, -104].map((x) => (
                <rect key={x} x={x} y="-84" width="3" height="40" rx="1.5" fill="#8e9ab0" opacity="0.7" />
              ))}
              {/* front cap */}
              <rect x="58" y="-88" width="18" height="48" rx="6" fill="#1a4fc0" />
              <rect x="61" y="-84" width="3" height="40" rx="1.5" fill="#7cc8ff" />
              <rect x="74" y="-78" width="20" height="28" rx="5" fill="url(#s-orange)" />
              <rect x="77" y="-75" width="3" height="22" rx="1.5" fill="#fff4c4" opacity="0.8" />
            </Shiny>
          </g>

          {/* idle drips from nozzle */}
          {[0, 1, 2].map((i) => (
            <g key={`dr${i}`} transform={`translate(${172 + i * 3} -4) scale(0.8)`}>
              <path d={TEARDROP} fill="#9eeaff" stroke="#2a7ff0" strokeWidth="0.8" className="drip" style={v({ '--delay': `${i * 0.6}s`, '--dx': `${i * 4}px` })} />
            </g>
          ))}

          {/* ---------- use effects (no projectile) ---------- */}
          {fire > 0 && (
            <g key={`fx${fire}`} transform="translate(176 -12)">
              {FX_MIST.map((m, i) => (
                <circle key={`m${i}`} r="10" fill="#d6f6ff" className="smoke" style={v({ '--dx': `${m.dx}px`, '--dy': `${m.dy}px`, '--delay': `${m.d}s` })} />
              ))}
              <circle r="38" fill="url(#s-flash)" className="fx-flash" />
              {RAINBOW.map((c, i) => {
                const R = 74 - i * 7;
                return (
                  <path
                    key={c}
                    d={`M${84 - R} 0 A${R} ${R} 0 0 1 ${84 + R} 0`}
                    fill="none"
                    stroke={c}
                    strokeWidth="7"
                    strokeLinecap="round"
                    opacity="0.85"
                    className="draw"
                    style={v({ '--len': `${(Math.PI * R).toFixed(0)}`, '--delay': `${0.12 + i * 0.03}s` })}
                  />
                );
              })}
              {CROWN.map((p, i) => (
                <g key={`cr${i}`} transform={`rotate(${((Math.atan2(p.dy, p.dx) * 180) / Math.PI + 90).toFixed(0)})`}>
                  <path d={TEARDROP} fill="#e6fbff" stroke="#2a7ff0" strokeWidth="0.8" className="burst" style={burstStyle({ ...p, dx: 0, dy: -46 }, 0.8)} />
                </g>
              ))}
              <ellipse rx="8" ry="20" fill="none" stroke="#bff4ff" strokeWidth="3" className="fx-ring" style={v({ '--s': 4.5 })} />
              <ellipse rx="8" ry="20" fill="none" stroke="#ffffff" strokeWidth="1.5" className="fx-ring" style={v({ '--s': 3, '--delay': '.12s' })} />
              {FX_DROPS.map((p, i) => (
                <g key={i} transform={`rotate(${(Math.atan2(p.dy, p.dx) * 180) / Math.PI + 90})`}>
                  <path
                    d={TEARDROP}
                    fill={i % 3 ? '#7ad8ff' : '#e6fbff'}
                    stroke="#2a7ff0"
                    strokeWidth="0.8"
                    className="burst"
                    style={burstStyle({ ...p, dx: 0, dy: -Math.hypot(p.dx, p.dy), r: 0 }, 0.9)}
                  />
                </g>
              ))}
            </g>
          )}
        </g>
      </g>
    </Stage>
  );
}
