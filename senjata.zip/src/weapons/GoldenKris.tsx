import { Stage, Shiny } from '../components/Stage';
import { Gem } from '../components/Gem';
import { burstStyle, spread, star4, v } from '../lib/fx';

/* ================= blade geometry (local: blade points +x) ================= */
const X0 = 50;
const X1 = 270;
const N = 140;
const center = (t: number) => {
  const env = Math.min(1, t * 3.2);
  let c = 15 * Math.sin(t * Math.PI * 5 + 0.35) * env * (1 - 0.35 * t);
  if (t > 0.8) c -= Math.pow((t - 0.8) / 0.2, 2) * 28;
  return c;
};
const width = (t: number) => 34 * Math.pow(1 - t, 0.74) * (1 + 0.2 * Math.sin(t * Math.PI * 5 + 1.9)) + (t < 0.08 ? (0.08 - t) * 90 : 0) + 0.4;
const PTS = Array.from({ length: N + 1 }, (_, i) => {
  const t = i / N;
  return { t, x: X0 + (X1 - X0) * t, c: center(t), w: width(t) };
});
const fmt = (a: number[][]) => a.map(([x, y]) => `${x.toFixed(1)} ${y.toFixed(1)}`).join(' L');
const band = (a: number, b: number) => {
  const top = PTS.map((p) => [p.x, p.c + p.w * a]);
  const bot = PTS.map((p) => [p.x, p.c + p.w * b]).reverse();
  return `M${fmt([...top, ...bot])}Z`;
};
const line = (a: number, from = 0.03, to = 0.92) => `M${fmt(PTS.filter((p) => p.t >= from && p.t <= to).map((p) => [p.x, p.c + p.w * a]))}`;
const at = (t: number) => PTS[Math.round(t * N)];

const BLADE = band(-1, 1);
const B_MID = band(-0.92, 0.5);
const B_LIT = band(-0.78, 0.02);
const B_HI = band(-0.62, -0.32);
const B_LOW = band(0.62, 1);
const GROOVE = line(0.16, 0.04, 0.86);
const GROOVE_HI = line(0.28, 0.04, 0.84);
const EDGE_HI = line(-0.9, 0.05, 0.95);
const TIP = at(1);

/* ================= orbit rings (threaded on the blade) ================= */
type Ring = { cx: number; rx: number; ry: number; phi: number; dur: number; op: number };
const RINGS: Ring[] = [
  { cx: -4, rx: 40, ry: 126, phi: -52, dur: 5.6, op: 0.85 },
  { cx: 84, rx: 26, ry: 96, phi: -40, dur: 4.6, op: 0.7 },
  { cx: 154, rx: 26, ry: 80, phi: -48, dur: 4, op: 1 },
  { cx: 232, rx: 18, ry: 54, phi: -56, dur: 3.2, op: 0.95 },
];
const ringPt = (r: Ring, th: number) => {
  const x = r.rx * Math.cos(th);
  const y = r.ry * Math.sin(th);
  const p = (r.phi * Math.PI) / 180;
  return [r.cx + x * Math.cos(p) - y * Math.sin(p), x * Math.sin(p) + y * Math.cos(p)];
};
const ringArc = (r: Ring, a0: number, a1: number, n = 48) =>
  `M${fmt(Array.from({ length: n + 1 }, (_, i) => ringPt(r, ((a0 + ((a1 - a0) * i) / n) * Math.PI) / 180)))}`;
const ringFull = (r: Ring) => `${ringArc(r, 0, 360, 96)}Z`;

/* ================= crescent guard ================= */
const GUARD_O = 'M54 -114 C-46 -98 -58 98 54 114 C12 72 16 -72 54 -114Z';
const GUARD_I = 'M45 -100 C-34 -86 -44 86 45 100 C6 62 10 -62 45 -100Z';
const FILIGREE = [
  'M40 -90 C8 -84 -16 -66 -12 -50 C-9 -40 4 -42 0 -51',
  'M-20 -34 C-28 -22 -24 -12 -16 -14 C-11 -15 -12 -21 -16 -20',
  'M24 -70 C14 -66 12 -56 19 -54',
  'M10 -40 C16 -33 14 -25 7 -25',
];

const FX_SPARKS = spread(18, -110, 110, 40, 120, 5);
const FX_GLINT = spread(12, 0, 360, 60, 130, 9);

function RingHalf({ r, back }: { r: Ring; back?: boolean }) {
  const d = back ? ringArc(r, -90, 90) : ringArc(r, 90, 270);
  return (
    <g opacity={back ? r.op * 0.7 : r.op}>
      <path d={d} fill="none" stroke="#ffc23a" strokeWidth={back ? 5 : 6} opacity="0.45" filter="url(#kris-soft)" strokeLinecap="round" />
      <path d={d} fill="none" stroke="#fff2b0" strokeWidth={back ? 1.4 : 1.9} strokeLinecap="round" />
      <path d={d} fill="none" stroke="#ffffff" strokeWidth="1" strokeDasharray="10 26" className="dash-flow" strokeLinecap="round" />
    </g>
  );
}

export default function GoldenKris({ fire }: { fire: number }) {
  return (
    <Stage id="kris" fire={fire} glow="#ffcc4d" mote="#ffe9a8" outline="#2a1404" bg={['#c4b2f2', '#7a5ac4', '#24124e']}>
      <defs>
        <linearGradient id="k-gold" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#fff6c4" />
          <stop offset="0.3" stopColor="#ffd25a" />
          <stop offset="0.68" stopColor="#c8841a" />
          <stop offset="1" stopColor="#6a3a06" />
        </linearGradient>
        <linearGradient id="k-goldh" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0" stopColor="#7a4206" />
          <stop offset="0.4" stopColor="#ffe08a" />
          <stop offset="0.75" stopColor="#d6962c" />
          <stop offset="1" stopColor="#6a3a06" />
        </linearGradient>
        <radialGradient id="k-goldr" cx="0.4" cy="0.35" r="0.75">
          <stop offset="0" stopColor="#fffbe0" />
          <stop offset="0.35" stopColor="#ffd25a" />
          <stop offset="0.8" stopColor="#c07a14" />
          <stop offset="1" stopColor="#6a3a06" />
        </radialGradient>
        <linearGradient id="k-dark" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#3a2410" />
          <stop offset="0.5" stopColor="#140a04" />
          <stop offset="1" stopColor="#050201" />
        </linearGradient>
        <linearGradient id="k-wrap" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#7a5634" />
          <stop offset="0.35" stopColor="#3a2414" />
          <stop offset="1" stopColor="#0c0604" />
        </linearGradient>
        <linearGradient id="k-shine" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0" stopColor="#ffffff" stopOpacity="0" />
          <stop offset="0.5" stopColor="#ffffff" stopOpacity="0.95" />
          <stop offset="1" stopColor="#ffffff" stopOpacity="0" />
        </linearGradient>
        <linearGradient id="k-slash" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#fff7d0" stopOpacity="0" />
          <stop offset="0.5" stopColor="#fff2b0" stopOpacity="0.95" />
          <stop offset="1" stopColor="#ffc94a" stopOpacity="0.2" />
        </linearGradient>
        <radialGradient id="k-flash">
          <stop offset="0" stopColor="#fffbe6" />
          <stop offset="0.45" stopColor="#ffd86b" stopOpacity="0.7" />
          <stop offset="1" stopColor="#ffb52e" stopOpacity="0" />
        </radialGradient>
        <clipPath id="k-bladeclip">
          <path d={BLADE} />
        </clipPath>
        <clipPath id="k-handleclip">
          <path d="M-128 -12 Q-128 -14 -124 -14 L-30 -14 L-30 14 L-124 14 Q-128 14 -128 12Z" />
        </clipPath>
      </defs>

      <g className="floaty">
        <g transform="translate(178 210) rotate(-50) scale(0.78)">
          {/* ---------- rings: back halves ---------- */}
          {RINGS.map((r, i) => (
            <g key={`rb${i}-${fire}`} className={fire ? 'ring-pulse' : ''} style={{ transformOrigin: `${r.cx}px 0px` }}>
              <g className="ring-bob" style={v({ '--delay': `${i * 0.8}s` })}>
                <RingHalf r={r} back />
              </g>
            </g>
          ))}

          <g key={fire} className={fire ? 'swing' : ''}>
            <Shiny id="kris" fire={fire}>
              {/* ---------- blade ---------- */}
              <path d={BLADE} fill="#cf8618" />
              <path d={B_MID} fill="#ffc43a" />
              <path d={B_LIT} fill="#ffe27a" />
              <path d={B_HI} fill="#fffbe6" opacity="0.9" />
              <path d={B_LOW} fill="#a65c0a" opacity="0.55" />
              <path d={GROOVE} fill="none" stroke="#a8620c" strokeWidth="2" strokeLinecap="round" />
              <path d={GROOVE_HI} fill="none" stroke="#fff4c0" strokeWidth="1.1" strokeLinecap="round" opacity="0.9" />
              <path d={EDGE_HI} fill="none" stroke="#ffffff" strokeWidth="1.2" strokeLinecap="round" opacity="0.7" />
              {[0.1, 0.2].map((t, i) => {
                const p = at(t);
                return (
                  <g key={t} transform={`translate(${p.x.toFixed(1)} ${(p.c + p.w * 0.45).toFixed(1)}) scale(${i ? 0.8 : 1})`}>
                    <path d="M-6 2 C0 -6 10 -6 11 0 C12 6 4 7 4 2 C4 -1 8 -1 8 1" fill="none" stroke="#a8620c" strokeWidth="1.5" strokeLinecap="round" />
                  </g>
                );
              })}
              <path d={BLADE} fill="none" stroke="#7a4a08" strokeWidth="1.3" strokeLinejoin="round" />
              <g clipPath="url(#k-bladeclip)">
                <g transform="skewX(-25)">
                  <rect x="20" y="-90" width="30" height="180" fill="url(#k-shine)" className={fire ? 'shine-fire' : 'shine-idle'} />
                </g>
              </g>

              {/* ---------- handle ---------- */}
              <path d="M-128 -12 Q-128 -14 -124 -14 L-30 -14 L-30 14 L-124 14 Q-128 14 -128 12Z" fill="url(#k-wrap)" />
              <g clipPath="url(#k-handleclip)">
                {Array.from({ length: 16 }, (_, i) => (
                  <g key={i}>
                    <path d={`M${-138 + i * 7.5} -15 L${-126 + i * 7.5} 15`} stroke="#0a0503" strokeWidth="2.6" />
                    <path d={`M${-135 + i * 7.5} -13 L${-129 + i * 7.5} 1`} stroke="#d8a868" strokeWidth="1.3" opacity="0.6" strokeLinecap="round" />
                  </g>
                ))}
              </g>
              {[
                [-40, 11],
                [-70, 7],
                [-98, 7],
                [-130, 10],
              ].map(([x, w], i) => (
                <g key={i}>
                  <rect x={x} y="-17.5" width={w} height="35" rx="3.5" fill="url(#k-gold)" stroke="#5a3006" strokeWidth="1" />
                  <rect x={x + 1.8} y="-15" width="2" height="30" rx="1" fill="#fff6c4" opacity="0.85" />
                  <path d={`M${x} 0 L${x + w} 0`} stroke="#8a5a10" strokeWidth="0.8" opacity="0.6" />
                </g>
              ))}

              {/* ---------- pommel ---------- */}
              <g transform="translate(-14 0)">
              <path d="M-116 -16 C-128 -25 -146 -24 -153 -12 L-170 0 L-153 12 C-146 24 -128 25 -116 16Z" fill="url(#k-gold)" stroke="#5a3006" strokeWidth="1.3" strokeLinejoin="round" />
              <path d="M-120 -13 C-130 -20 -142 -19 -148 -11" stroke="#fff5c4" strokeWidth="1.8" fill="none" opacity="0.85" strokeLinecap="round" />
              <circle cx="-171" cy="0" r="3.2" fill="url(#k-goldr)" stroke="#5a3006" strokeWidth="0.8" />
              <ellipse cx="-136" cy="0" rx="13.5" ry="14.5" fill="url(#k-goldh)" stroke="#5a3006" strokeWidth="1" />
              <Gem cx={-136} cy={0} r={10.5} n={8} light="#c8fff0" mid="#16c48e" dark="#02543a" rim="#ffd25a" />
              </g>

              {/* ---------- crescent guard ---------- */}
              <path d={GUARD_O} fill="url(#k-gold)" stroke="#5a3006" strokeWidth="1.4" strokeLinejoin="round" />
              <path d={GUARD_I} fill="url(#k-dark)" />
              {[1, -1].map((sy) => (
                <g key={sy} transform={`scale(1 ${sy})`} fill="none" stroke="url(#k-gold)" strokeLinecap="round">
                  <path d={FILIGREE[0]} strokeWidth="3" />
                  <path d={FILIGREE[1]} strokeWidth="2.4" />
                  <path d={FILIGREE[2]} strokeWidth="2" />
                  <path d={FILIGREE[3]} strokeWidth="2" />
                  <path d="M32 -80 C28 -86 34 -90 37 -86" strokeWidth="1.6" />
                  <circle cx="-12" cy="-68" r="2.2" fill="#ffd25a" stroke="none" />
                </g>
              ))}
              <path d="M50 -110 C-34 -94 -50 -40 -48 0" stroke="#fff5c4" strokeWidth="2" fill="none" opacity="0.85" strokeLinecap="round" />
              <circle cx="54" cy="-114" r="3.6" fill="url(#k-goldr)" stroke="#5a3006" strokeWidth="0.8" />
              <circle cx="54" cy="114" r="3.6" fill="url(#k-goldr)" stroke="#5a3006" strokeWidth="0.8" />

              {/* ---------- collar with diamond emblem ---------- */}
              <path d="M-34 -17 L-2 -20 C8 -18 12 -10 12 0 C12 10 8 18 -2 20 L-34 17 Q-38 16 -38 12 L-38 -12 Q-38 -16 -34 -17Z" fill="url(#k-gold)" stroke="#5a3006" strokeWidth="1.3" />
              <path d="M-32 -13 L-4 -16" stroke="#fff6c4" strokeWidth="1.6" strokeLinecap="round" opacity="0.85" />
              <path d="M-12 -14 L1 0 L-12 14 L-25 0Z" fill="url(#k-goldh)" stroke="#5a3006" strokeWidth="1.2" />
              <path d="M-12 -7 L-5 0 L-12 7 L-19 0Z" fill="#3a2008" />
              <path d="M-12 -7 L-5 0 L-12 0Z" fill="#8a5a14" />
              <circle cx="-12" cy="0" r="1.6" fill="#fff6c4" />

              {/* ---------- ganja / naga head ornament ---------- */}
              <path d="M8 -21 C26 -25 46 -25 62 -23 Q54 0 62 23 C46 25 26 25 8 21 Q2 14 2 0 Q2 -14 8 -21Z" fill="url(#k-gold)" stroke="#5a3006" strokeWidth="1.3" strokeLinejoin="round" />
              <path d="M10 -18 C26 -22 42 -22 56 -20" stroke="#fff6c4" strokeWidth="2" fill="none" opacity="0.9" strokeLinecap="round" />
              <g fill="none" stroke="#7a4606" strokeWidth="1.6" strokeLinecap="round">
                <path d="M10 -8 C16 -14 26 -12 25 -6 C24 -2 18 -3 19 -7" />
                <path d="M10 8 C16 14 26 12 25 6 C24 2 18 3 19 7" />
                <path d="M30 0 C38 -4 46 -3 52 0 C46 3 38 4 30 0Z" />
              </g>
              <path d="M30 0 C38 -3 46 -3 52 0" stroke="#fff6c4" strokeWidth="1" fill="none" />
              <Gem cx={40} cy={-13} r={6.5} n={6} light="#ffc0d0" mid="#f0245a" dark="#7a0024" rim="#ffd25a" />
              <Gem cx={40} cy={13} r={6.5} n={6} light="#ffc0d0" mid="#f0245a" dark="#7a0024" rim="#ffd25a" />

              {fire > 0 && (
                <g>
                  <circle cx="40" cy="-13" r="10" fill="#ff7aa0" className="overlay-flash" />
                  <circle cx="40" cy="13" r="10" fill="#ff7aa0" className="overlay-flash" />
                  <circle cx="-150" cy="0" r="15" fill="#7affd0" className="overlay-flash" />
                </g>
              )}
            </Shiny>
          </g>

          {/* ---------- rings: front halves + riding sparks ---------- */}
          {RINGS.map((r, i) => (
            <g key={`rf${i}-${fire}`} className={fire ? 'ring-pulse' : ''} style={{ transformOrigin: `${r.cx}px 0px` }}>
              <g className="ring-bob" style={v({ '--delay': `${i * 0.8}s` })}>
                <RingHalf r={r} />
                {[0, 0.5].map((o) => (
                  <path key={o} d={star4(0, 0, 5.5)} fill="#fffbe0" filter="url(#kris-soft)">
                    <animateMotion dur={`${r.dur}s`} begin={`${-o * r.dur}s`} repeatCount="indefinite" path={ringFull(r)} />
                  </path>
                ))}
              </g>
            </g>
          ))}

          {/* tip star + sparkles */}
          <g transform={`translate(${TIP.x.toFixed(1)} ${TIP.c.toFixed(1)})`}>
            <circle r="10" fill="#ffe28a" opacity="0.6" filter="url(#kris-soft)" className="pulse-op" />
            <g transform="rotate(50)">
              <path d={star4(0, 0, 15, 0.12)} fill="#fffbe6" className="twinkle" />
            </g>
          </g>
          {[
            [110, -46, 0],
            [170, 34, 0.7],
            [80, 44, 1.4],
            [205, -40, 2.1],
            [30, -120, 1],
            [250, 10, 1.8],
          ].map(([x, y, d], i) => (
            <path key={i} d={star4(x, y, 5.5)} fill="#fff6d0" className="twinkle" style={v({ '--delay': `${d}s` })} />
          ))}

          {fire > 0 && (
            <g key={`fx${fire}`}>
              <g transform={`translate(${TIP.x.toFixed(1)} ${TIP.c.toFixed(1)})`}>
                <circle r="36" fill="url(#k-flash)" className="fx-flash" style={v({ '--delay': '.22s' })} />
                {FX_SPARKS.map((p, i) => (
                  <path key={i} d={star4(0, 0, 5)} fill={i % 2 ? '#fff6c8' : '#ffd24a'} className="burst" style={burstStyle({ ...p, delay: p.delay + 0.22 }, 0.9)} />
                ))}
              </g>
              <g transform="translate(40 0)">
                {FX_GLINT.map((p, i) => (
                  <circle key={i} r="2.6" fill="#ffe79a" className="burst" style={burstStyle(p, 1.1)} />
                ))}
              </g>
            </g>
          )}
        </g>

        {fire > 0 && (
          <g key={`sl${fire}`} className="slash-fx">
            <path d="M70 120 Q290 10 345 260 Q270 80 70 120Z" fill="url(#k-slash)" />
            <path d="M70 120 Q290 10 345 260" fill="none" stroke="#ffffff" strokeWidth="2.5" strokeLinecap="round" opacity="0.9" />
          </g>
        )}
      </g>
    </Stage>
  );
}
