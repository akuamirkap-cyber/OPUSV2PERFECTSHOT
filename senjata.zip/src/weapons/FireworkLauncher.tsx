import { Stage, Shiny } from '../components/Stage';
import { burstStyle, rand, spread, star4, star5, v } from '../lib/fx';

const TUBES = [
  { y: -66, fill: 'url(#fw-blue)' },
  { y: -38, fill: 'url(#fw-red)' },
  { y: -10, fill: 'url(#fw-blue)' },
];
const ROCKETS = [
  { y: -53, L: 56 },
  { y: -25, L: 78 },
  { y: 3, L: 52 },
];
const FLAME = 'M0 -15 C-22 -18 -46 -8 -72 0 C-46 8 -22 18 0 15Z';
const FLAME_IN = 'M0 -8 C-14 -9 -28 -4 -44 0 C-28 4 -14 9 0 8Z';

const COLORS = ['#ff4d6d', '#ffd84a', '#4fd8ff', '#9dff6a', '#ff8ae6', '#ffffff'];
const FX_RING = Array.from({ length: 22 }, (_, i) => {
  const a = (i / 22) * Math.PI * 2;
  const d = 70 + rand(i + 3) * 20;
  return { dx: Math.cos(a) * d, dy: Math.sin(a) * d, r: 0, delay: 0.1 + rand(i + 9) * 0.08, s: 0.8 };
});
const FX_INNER = spread(12, 0, 330, 25, 45, 14);
const FX_CONF = spread(14, -80, 80, 50, 120, 17);
const SKY = [
  { x: 92, y: 92, c: '#ffd84a', c2: '#fff6c0', d: 0.15, R: 62 },
  { x: 312, y: 84, c: '#ff6ad5', c2: '#ffd0f4', d: 0.4, R: 56 },
  { x: 210, y: 52, c: '#4fd8ff', c2: '#e0fbff', d: 0.65, R: 48 },
  { x: 330, y: 230, c: '#9dff6a', c2: '#eaffd8', d: 0.85, R: 40 },
];
const SKY_P = Array.from({ length: 20 }, (_, i) => (i * 18 * Math.PI) / 180);
const FX_SMOKE = [
  { dx: -50, dy: -10, d: 0 },
  { dx: -40, dy: -34, d: 0.1 },
  { dx: -64, dy: 10, d: 0.18 },
];

export default function FireworkLauncher({ fire, label, rarity }: { fire: number; label?: string; rarity?: 'Rare' | 'Epic' | 'Legendary' | 'Mythic' }) {
  return (
    <Stage id="fw" fire={fire} label={label} rarity={rarity} glow="#ffb84a" mote="#ffe0a0" outline="#140a2a">
      <defs>
        <pattern id="fw-starsB" width="22" height="28" patternUnits="userSpaceOnUse" x="0" y="-66">
          <rect width="22" height="28" fill="#1f4fd8" />
          <path d={star5(7, 9, 5)} fill="#ffd84a" />
          <path d={star5(18, 21, 4)} fill="#ffd84a" />
        </pattern>
        <pattern id="fw-starsR" width="24" height="28" patternUnits="userSpaceOnUse" x="6" y="-38">
          <rect width="24" height="28" fill="#e0202e" />
          <path d={star5(6, 8, 4.5)} fill="#ffd84a" />
          <path d={star5(18, 20, 5)} fill="#ffffff" />
        </pattern>
        <linearGradient id="fw-tubeshade" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#ffffff" stopOpacity="0.55" />
          <stop offset="0.25" stopColor="#ffffff" stopOpacity="0.05" />
          <stop offset="0.7" stopColor="#000" stopOpacity="0.05" />
          <stop offset="1" stopColor="#0a0420" stopOpacity="0.55" />
        </linearGradient>
        <linearGradient id="fw-gold" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0" stopColor="#8a4e0a" />
          <stop offset="0.35" stopColor="#ffe68a" />
          <stop offset="0.7" stopColor="#e0a030" />
          <stop offset="1" stopColor="#7a4206" />
        </linearGradient>
        <linearGradient id="fw-goldv" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#fff2b0" />
          <stop offset="0.4" stopColor="#f2b840" />
          <stop offset="1" stopColor="#7a4206" />
        </linearGradient>
        <linearGradient id="fw-rocket" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#ff9a9a" />
          <stop offset="0.4" stopColor="#e8202e" />
          <stop offset="1" stopColor="#7a0410" />
        </linearGradient>
        <linearGradient id="fw-dark" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#5a5f78" />
          <stop offset="0.5" stopColor="#262a40" />
          <stop offset="1" stopColor="#0c0e1a" />
        </linearGradient>
        <linearGradient id="fw-wood" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0" stopColor="#5a2c10" />
          <stop offset="0.4" stopColor="#b8703a" />
          <stop offset="0.7" stopColor="#d08a4e" />
          <stop offset="1" stopColor="#6a3412" />
        </linearGradient>
        <linearGradient id="fw-flame" x1="1" y1="0" x2="0" y2="0">
          <stop offset="0" stopColor="#fff6c0" />
          <stop offset="0.3" stopColor="#ffc23a" />
          <stop offset="0.7" stopColor="#ff5a1a" />
          <stop offset="1" stopColor="#ff2a00" stopOpacity="0" />
        </linearGradient>
        <radialGradient id="fw-flash">
          <stop offset="0" stopColor="#ffffff" />
          <stop offset="0.4" stopColor="#ffe08a" stopOpacity="0.8" />
          <stop offset="1" stopColor="#ff6a3a" stopOpacity="0" />
        </radialGradient>
        <linearGradient id="fw-blue" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#1f4fd8" />
          <stop offset="1" stopColor="#1f4fd8" />
        </linearGradient>
      </defs>

      {/* background firework bursts */}
      {[
        [62, 84, 18, 0, '#ffd84a'],
        [338, 70, 22, 0.9, '#ff6ad5'],
        [350, 262, 15, 1.8, '#4fd8ff'],
        [48, 250, 13, 2.3, '#9dff6a'],
      ].map(([x, y, r, d, c], i) => (
        <g key={i} transform={`translate(${x} ${y})`}>
          <g className="spark-burst" style={v({ '--delay': `${d}s` })}>
            {Array.from({ length: 10 }, (_, k) => {
              const a = (k * 36 * Math.PI) / 180;
              const R = Number(r);
              return <path key={k} d={`M${Math.cos(a) * R * 0.35} ${Math.sin(a) * R * 0.35} L${Math.cos(a) * R} ${Math.sin(a) * R}`} stroke={String(c)} strokeWidth="2.2" strokeLinecap="round" />;
            })}
            <circle r="2.5" fill="#ffffff" />
          </g>
        </g>
      ))}

      {fire > 0 && (
        <g key={`sky${fire}`}>
          {SKY.map((b, bi) => (
            <g key={bi} transform={`translate(${b.x} ${b.y})`}>
              <circle r="9" fill={b.c2} className="fx-flash" style={v({ '--delay': `${b.d}s` })} />
              <circle r="8" fill="none" stroke={b.c} strokeWidth="2.5" className="fx-ring" style={v({ '--s': b.R / 9, '--delay': `${b.d}s`, '--dur': '1s' })} />
              {SKY_P.map((a, i) => (
                <circle
                  key={i}
                  r={i % 2 ? 2.2 : 3}
                  fill={i % 2 ? b.c2 : b.c}
                  className="burst-fall"
                  style={v({ '--dx': `${(Math.cos(a) * b.R).toFixed(1)}px`, '--dy': `${(Math.sin(a) * b.R).toFixed(1)}px`, '--delay': `${b.d}s`, '--dur': '1.7s' })}
                />
              ))}
              {SKY_P.filter((_, i) => i % 2 === 0).map((a, i) => (
                <path
                  key={`s${i}`}
                  d={star4(0, 0, 4)}
                  fill="#ffffff"
                  className="burst-fall"
                  style={v({ '--dx': `${(Math.cos(a + 0.15) * b.R * 0.55).toFixed(1)}px`, '--dy': `${(Math.sin(a + 0.15) * b.R * 0.55).toFixed(1)}px`, '--delay': `${b.d + 0.05}s`, '--dur': '1.5s' })}
                />
              ))}
            </g>
          ))}
        </g>
      )}

      <g className="floaty">
        <g transform="translate(212 186) rotate(-8) scale(0.9)">
          <g key={fire} className={fire ? 'recoil' : ''}>
            {/* rear flame (behind) */}
            <g transform="translate(-158 -24)">
              <g className="flame-idle">
                <g key={`fl${fire}`} className={fire ? 'flame-fire' : ''}>
                  <path d={FLAME} fill="url(#fw-flame)" />
                  <path d={FLAME_IN} fill="#fffbe0" opacity="0.9" />
                </g>
              </g>
            </g>

            <Shiny id="fw" fire={fire}>
              {/* ---------- grips ---------- */}
              <g transform="rotate(8 -66 22)">
                <path d="M-82 20 L-50 20 L-54 76 Q-56 88 -68 88 L-84 88 Q-94 86 -92 76Z" fill="url(#fw-wood)" />
                <path d="M-78 30 L-80 78" stroke="#f0b880" strokeWidth="2" opacity="0.5" strokeLinecap="round" />
                <path d="M-62 30 L-64 78" stroke="#4a2008" strokeWidth="1.5" opacity="0.5" />
                <rect x="-96" y="80" width="44" height="10" rx="4" fill="url(#fw-dark)" />
              </g>
              <path d="M-50 22 C-52 46 -24 50 -14 26" stroke="#0c0e1a" strokeWidth="9" fill="none" strokeLinecap="round" />
              <path d="M-50 22 C-52 46 -24 50 -14 26" stroke="url(#fw-dark)" strokeWidth="6" fill="none" strokeLinecap="round" />
              <path d="M-36 22 C-40 30 -38 36 -32 40" stroke="url(#fw-goldv)" strokeWidth="4.5" fill="none" strokeLinecap="round" />
              <g transform="rotate(4 22 22)">
                <path d="M8 20 L36 20 L34 70 Q32 80 22 80 L18 80 Q10 80 10 70Z" fill="url(#fw-wood)" />
                <rect x="8" y="40" width="28" height="5" rx="2" fill="url(#fw-gold)" />
                <path d="M14 26 L14 70" stroke="#f0b880" strokeWidth="2" opacity="0.5" strokeLinecap="round" />
              </g>
              {/* rail */}
              <rect x="-104" y="14" width="168" height="12" rx="5" fill="url(#fw-dark)" />
              <rect x="-100" y="16" width="160" height="2.5" rx="1" fill="#8a90b0" opacity="0.7" />

              {/* ---------- tubes ---------- */}
              {TUBES.map((t, i) => (
                <g key={i}>
                  <rect x="-112" y={t.y} width="198" height="28" rx="6" fill={i === 1 ? 'url(#fw-starsR)' : 'url(#fw-starsB)'} />
                  <rect x="-112" y={t.y} width="198" height="28" rx="6" fill="url(#fw-tubeshade)" />
                  <path d={`M-108 ${t.y + 5} L82 ${t.y + 5}`} stroke="#ffffff" strokeWidth="2" opacity="0.5" strokeLinecap="round" />
                </g>
              ))}
              {/* gold bands */}
              {[-96, -30, 40].map((x) => (
                <g key={x}>
                  <rect x={x} y="-70" width="14" height="94" rx="4" fill="url(#fw-gold)" />
                  <rect x={x + 3} y="-68" width="3" height="90" rx="1.5" fill="#fff6c4" opacity="0.8" />
                  <circle cx={x + 7} cy="-52" r="2" fill="#7a4206" />
                  <circle cx={x + 7} cy="-24" r="2" fill="#7a4206" />
                  <circle cx={x + 7} cy="4" r="2" fill="#7a4206" />
                </g>
              ))}

              {/* rear cap + exhaust */}
              <path d="M-128 -44 L-152 -56 L-152 8 L-128 -4Z" fill="url(#fw-dark)" />
              <rect x="-158" y="-60" width="9" height="72" rx="3" fill="url(#fw-gold)" />
              <ellipse cx="-158" cy="-24" rx="3" ry="28" fill="#1a0a10" />
              <rect x="-132" y="-72" width="24" height="98" rx="8" fill="url(#fw-dark)" />
              <rect x="-128" y="-68" width="4" height="90" rx="2" fill="#8a90b0" opacity="0.6" />
              <rect x="-114" y="-72" width="8" height="98" rx="3" fill="url(#fw-gold)" />

              {/* front mouths */}
              {TUBES.map((t, i) => (
                <g key={i}>
                  <rect x="80" y={t.y - 2} width="12" height="32" rx="4" fill="url(#fw-goldv)" />
                  <ellipse cx="92" cy={t.y + 14} rx="4" ry="11" fill="#1a0a10" />
                </g>
              ))}

              {/* rockets */}
              <g key={`r${fire}`} className={fire ? 'rocket-push' : ''}>
                {ROCKETS.map((r, i) => (
                  <g key={i}>
                    <path d={`M90 ${r.y - 12} L${90 + r.L} ${r.y} L90 ${r.y + 12}Z`} fill="url(#fw-rocket)" stroke="#5a0208" strokeWidth="1" strokeLinejoin="round" />
                    <path d={`M90 ${r.y - 12} L${90 + r.L} ${r.y} L90 ${r.y - 3}Z`} fill="#ffc0c0" opacity="0.55" />
                    <rect x="90" y={r.y - 13} width="10" height="26" rx="3" fill="url(#fw-goldv)" stroke="#5a2a04" strokeWidth="0.8" />
                    <path d={`M${90 + r.L * 0.42} ${r.y - 7} L${90 + r.L * 0.42} ${r.y + 7}`} stroke="#ffffff" strokeWidth="3" />
                    <path d={`M${90 + r.L * 0.62} ${r.y - 4.5} L${90 + r.L * 0.62} ${r.y + 4.5}`} stroke="#ffd84a" strokeWidth="2.5" />
                  </g>
                ))}
              </g>

              {/* fuse */}
              <path d="M-84 -66 C-90 -80 -76 -86 -82 -96 C-86 -102 -96 -100 -98 -106" stroke="#3a2010" strokeWidth="4" fill="none" strokeLinecap="round" />
              <path d="M-84 -66 C-90 -80 -76 -86 -82 -96 C-86 -102 -96 -100 -98 -106" stroke="#c89a5a" strokeWidth="2" fill="none" strokeLinecap="round" strokeDasharray="3 3" />
              <rect x="-90" y="-72" width="12" height="8" rx="2" fill="url(#fw-goldv)" />
            </Shiny>

            {/* fuse spark */}
            <g transform="translate(-98 -108)">
              <circle r="9" fill="#ffb84a" opacity="0.6" filter="url(#fw-soft)" />
              <path d={star4(0, 0, 9, 0.2)} fill="#fff6c0" className="fuse-spark" />
              {[0, 1, 2, 3].map((i) => (
                <circle key={i} cx={Math.cos(i * 1.6) * 10} cy={Math.sin(i * 1.6) * 10} r="1.4" fill="#ffd84a" className="twinkle" style={v({ '--delay': `${i * 0.15}s` })} />
              ))}
            </g>
            <path d={star4(170, -25, 11, 0.14)} fill="#fff6d0" className="twinkle" />
            {[
              [-60, -52],
              [10, -24],
              [60, 4],
            ].map(([x, y], i) => (
              <path key={i} d={star4(x, y, 6)} fill="#ffffff" className="twinkle" style={v({ '--delay': `${i * 0.7}s` })} />
            ))}
          </g>

          {/* ---------- use effects (no projectile) ---------- */}
          {fire > 0 && (
            <g key={`fx${fire}`}>
              <g transform="translate(-160 -24)">
                {FX_SMOKE.map((s, i) => (
                  <circle key={i} r="12" fill="#c8bcd8" className="smoke" style={v({ '--dx': `${s.dx}px`, '--dy': `${s.dy}px`, '--delay': `${s.d}s` })} />
                ))}
              </g>
              <g transform="translate(176 -26)">
                <circle r="40" fill="url(#fw-flash)" className="fx-flash" />
                <circle r="12" fill="none" stroke="#ffd84a" strokeWidth="3" className="fx-ring" style={v({ '--s': 6, '--delay': '.08s' })} />
                <circle r="12" fill="none" stroke="#ff6ad5" strokeWidth="2" className="fx-ring" style={v({ '--s': 4, '--delay': '.16s' })} />
                {FX_RING.map((p, i) => (
                  <circle key={i} r="3.4" fill={COLORS[i % COLORS.length]} className="burst" style={burstStyle(p, 1.1)} />
                ))}
                {FX_INNER.map((p, i) => (
                  <path key={`in${i}`} d={star4(0, 0, 5)} fill={COLORS[(i + 2) % COLORS.length]} className="burst" style={burstStyle(p, 0.9)} />
                ))}
                {FX_CONF.map((p, i) => (
                  <rect key={`c${i}`} x="-3" y="-1.5" width="6" height="3" fill={COLORS[(i + 4) % COLORS.length]} className="burst" style={burstStyle(p, 1.3)} />
                ))}
              </g>
            </g>
          )}
        </g>
      </g>
    </Stage>
  );
}
