import { Stage, Shiny } from '../components/Stage';
import { LEAF, burstStyle, spread, star4, v } from '../lib/fx';

const BUBBLES = Array.from({ length: 12 }, (_, i) => ({
  x: -66 + ((i * 41) % 130),
  y: -12 + ((i * 13) % 30),
  r: 1.5 + (i % 3),
  d: (i * 0.37) % 3,
  dur: 2.4 + (i % 4) * 0.5,
}));
const FX_LEAVES = spread(12, -70, 70, 60, 120, 3);
const FX_SPARKS = spread(14, -80, 80, 40, 110, 7);
const FX_BACK = spread(8, 100, 260, 30, 70, 11);

const Leaf = ({ x, y, r, s = 1, d = 0 }: { x: number; y: number; r: number; s?: number; d?: number }) => (
  <g transform={`translate(${x} ${y}) rotate(${r}) scale(${s})`}>
    <g className="leaf-sway" style={v({ '--delay': `${d}s` })}>
      <path d={LEAF} fill="url(#n-leaf)" stroke="#1a5c1f" strokeWidth="1.3" />
      <path d="M1 0 Q11 -1 20 0" stroke="#1a5c1f" strokeWidth="1" fill="none" opacity="0.7" />
      <path d="M4 -2 Q10 -5.5 15 -3.5" stroke="#f0ffc8" strokeWidth="1.2" fill="none" opacity="0.8" />
    </g>
  </g>
);

const Rope = ({ d }: { d: string }) => (
  <g>
    <path d={d} stroke="#3a1d06" strokeWidth="8" fill="none" strokeLinecap="round" />
    <path d={d} stroke="#a8672c" strokeWidth="5.5" fill="none" strokeLinecap="round" />
    <path d={d} stroke="#e2a464" strokeWidth="5.5" fill="none" strokeLinecap="round" strokeDasharray="2.5 3.5" />
    <path d={d} stroke="#5a300c" strokeWidth="1" fill="none" opacity="0.5" transform="translate(0 1.6)" />
  </g>
);

const GRIP = 'M-90 18 C-102 48 -118 78 -134 104 C-148 126 -136 150 -112 148 C-96 147 -88 136 -84 122 C-76 96 -58 66 -28 34 Z';
const BUTT = 'M-137 106 C-150 128 -138 153 -112 152 C-94 151 -84 138 -82 122 C-92 132 -110 136 -122 128 C-131 122 -136 114 -137 106Z';

export default function NatureGun({ fire }: { fire: number }) {
  return (
    <Stage id="nat" fire={fire} glow="#7dff8a" mote="#d2ff9e" outline="#241004">
      <defs>
        <linearGradient id="n-glass" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#f0ffe0" />
          <stop offset="0.18" stopColor="#8af7a4" />
          <stop offset="0.55" stopColor="#25c25f" />
          <stop offset="1" stopColor="#076030" />
        </linearGradient>
        <radialGradient id="n-inner" cx="0.45" cy="0.55" r="0.6">
          <stop offset="0" stopColor="#e4ffc8" stopOpacity="0.95" />
          <stop offset="0.6" stopColor="#9cff9a" stopOpacity="0.3" />
          <stop offset="1" stopColor="#9cff9a" stopOpacity="0" />
        </radialGradient>
        <linearGradient id="n-gold" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#fff2b0" />
          <stop offset="0.3" stopColor="#f0bd4a" />
          <stop offset="0.68" stopColor="#b8771a" />
          <stop offset="1" stopColor="#6a3e08" />
        </linearGradient>
        <linearGradient id="n-goldh" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0" stopColor="#7a4606" />
          <stop offset="0.4" stopColor="#ffe08a" />
          <stop offset="0.75" stopColor="#d6962c" />
          <stop offset="1" stopColor="#6a3e08" />
        </linearGradient>
        <linearGradient id="n-wood" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0" stopColor="#5a2e10" />
          <stop offset="0.35" stopColor="#b8763c" />
          <stop offset="0.6" stopColor="#d99a5a" />
          <stop offset="1" stopColor="#6e3a14" />
        </linearGradient>
        <linearGradient id="n-pot" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0" stopColor="#f2a468" />
          <stop offset="0.5" stopColor="#c8642c" />
          <stop offset="1" stopColor="#7c3412" />
        </linearGradient>
        <linearGradient id="n-leaf" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#d4ff86" />
          <stop offset="0.5" stopColor="#7fd84a" />
          <stop offset="1" stopColor="#2c9a34" />
        </linearGradient>
        <radialGradient id="n-flash">
          <stop offset="0" stopColor="#fbffe6" stopOpacity="1" />
          <stop offset="0.4" stopColor="#a5ff8f" stopOpacity="0.8" />
          <stop offset="1" stopColor="#4be36a" stopOpacity="0" />
        </radialGradient>
        <clipPath id="n-gripclip">
          <path d={GRIP} />
        </clipPath>
      </defs>

      <g className="floaty">
        <g transform="translate(214 168) rotate(-36) scale(0.9)">
          {/* bottle glow (unfiltered) */}
          <ellipse cx="20" cy="0" rx="120" ry="56" fill="#7dff8f" opacity="0.5" filter="url(#nat-blur)" />

          <g key={fire} className={fire ? 'recoil' : ''}>
            <Shiny id="nat" fire={fire}>
              {/* ---------- grip ---------- */}
              <path d={GRIP} fill="url(#n-wood)" />
              <g clipPath="url(#n-gripclip)" fill="none" strokeLinecap="round">
                <path d="M-74 30 C-88 60 -104 92 -120 124" stroke="#f6c48a" strokeWidth="3" opacity="0.45" />
                <path d="M-56 36 C-72 66 -90 98 -104 132" stroke="#4a240a" strokeWidth="1.6" opacity="0.4" />
                <path d="M-92 30 C-104 60 -120 90 -132 116" stroke="#4a240a" strokeWidth="1.6" opacity="0.4" />
                <path d="M-66 50 C-74 60 -72 70 -80 80" stroke="#4a240a" strokeWidth="1.2" opacity="0.35" />
              </g>
              {/* gold filigree on grip */}
              <g fill="none" stroke="url(#n-gold)" strokeLinecap="round">
                <path d="M-40 38 C-58 52 -48 66 -64 78 C-78 88 -70 102 -86 112 C-98 118 -106 112 -102 104 C-99 98 -92 101 -94 106" strokeWidth="4" />
                <path d="M-56 62 C-46 66 -48 76 -56 76" strokeWidth="3" />
                <path d="M-80 96 C-70 96 -68 106 -76 108" strokeWidth="2.6" />
              </g>
              <path d={BUTT} fill="url(#n-gold)" stroke="#5a3406" strokeWidth="1.5" strokeLinejoin="round" />
              <path d="M-132 118 C-130 134 -118 144 -104 144" stroke="#fff2b0" strokeWidth="2" fill="none" opacity="0.8" />
              <circle cx="-114" cy="142" r="3" fill="#fff2b0" />

              {/* ---------- trigger guard + trigger ---------- */}
              <path d="M-24 30 C-30 62 8 70 24 42" stroke="#5a3406" strokeWidth="9" fill="none" strokeLinecap="round" />
              <path d="M-24 30 C-30 62 8 70 24 42" stroke="url(#n-goldh)" strokeWidth="6" fill="none" strokeLinecap="round" />
              <path d="M24 42 C32 54 48 50 44 38 C41 31 32 34 35 40" stroke="url(#n-gold)" strokeWidth="4.5" fill="none" strokeLinecap="round" />
              <path d="M-2 30 C-9 44 -5 52 4 58" stroke="#5a3406" strokeWidth="7" fill="none" strokeLinecap="round" />
              <path d="M-2 30 C-9 44 -5 52 4 58" stroke="url(#n-gold)" strokeWidth="4.5" fill="none" strokeLinecap="round" />

              {/* ---------- ornate lock plate ---------- */}
              <path
                d="M-104 14 L40 14 C52 20 54 34 40 38 C26 42 16 30 6 34 C-10 40 -22 30 -40 38 C-60 46 -80 40 -96 30 Z"
                fill="url(#n-gold)"
                stroke="#5a3406"
                strokeWidth="1.5"
                strokeLinejoin="round"
              />
              <g fill="none" stroke="#7a4606" strokeWidth="1.6" strokeLinecap="round" opacity="0.9">
                <path d="M-90 22 C-78 34 -62 30 -64 22 C-65 17 -72 18 -70 23" />
                <path d="M-30 22 C-20 32 -6 28 -8 20" />
                <path d="M14 22 C22 30 34 28 34 20" />
              </g>
              <path d="M-100 18 L36 18" stroke="#fff4c0" strokeWidth="1.5" opacity="0.8" />
              {/* scroll curls */}
              <path d="M-96 30 C-112 34 -118 22 -110 16 C-104 12 -98 18 -102 22" stroke="url(#n-gold)" strokeWidth="5" fill="none" strokeLinecap="round" />
              <path d="M40 36 C56 42 66 30 58 22 C52 16 44 22 48 28" stroke="url(#n-gold)" strokeWidth="5" fill="none" strokeLinecap="round" />

              {/* hammer (flint cock) */}
              <g className={fire ? 'hammer' : ''}>
                <path d="M-96 -6 C-120 -14 -126 -42 -108 -50 C-104 -44 -108 -32 -96 -24 C-90 -20 -86 -14 -86 -8Z" fill="url(#n-gold)" stroke="#5a3406" strokeWidth="1.5" strokeLinejoin="round" />
                <circle cx="-110" cy="-44" r="3" fill="#fff2b0" />
              </g>

              {/* back cup */}
              <rect x="-104" y="-36" width="58" height="72" rx="34" fill="url(#n-gold)" stroke="#5a3406" strokeWidth="1.5" />
              <path d="M-96 -20 C-100 -6 -100 6 -96 20" stroke="#fff2b0" strokeWidth="2.5" fill="none" opacity="0.8" strokeLinecap="round" />

              {/* ---------- bottle ---------- */}
              <rect x="-82" y="-30" width="196" height="60" rx="30" fill="url(#n-glass)" stroke="#0a4a22" strokeWidth="1.5" />
              <rect x="-74" y="-22" width="180" height="46" rx="23" fill="url(#n-inner)" />
              <path d="M-78 2 Q-50 -6 -20 2 T40 2 T110 2 L110 12 Q110 26 92 26 L-58 26 Q-78 26 -78 12Z" fill="#0b7a36" opacity="0.35" />
              {BUBBLES.map((b, i) => (
                <g key={i} transform={`translate(${b.x} ${b.y})`}>
                  <circle r={b.r} fill="#effff0" className="bubble" style={v({ '--delay': `${b.d}s`, '--dur': `${b.dur}s`, '--dx': '70px', '--dy': '-8px' })} />
                </g>
              ))}
              {[-50, -18, 18, 54, 84].map((x, i) => (
                <path key={i} d={star4(x, i % 2 ? 8 : -6, 4.5)} fill="#fbffd0" className="twinkle" style={v({ '--delay': `${i * 0.55}s` })} />
              ))}
              <rect x="-62" y="-25" width="160" height="8" rx="4" fill="#fff" opacity="0.65" />
              <rect x="-40" y="-14" width="40" height="3" rx="1.5" fill="#fff" opacity="0.35" />
              <rect x="-66" y="19" width="70" height="4" rx="2" fill="#e8ffd0" opacity="0.35" />
              <circle cx="102" cy="-16" r="4" fill="#fff" opacity="0.8" />
              {fire > 0 && <rect x="-82" y="-30" width="196" height="60" rx="30" fill="#f2ffd8" className="overlay-flash" />}
              {/* gold band */}
              <rect x="-52" y="-33" width="10" height="66" rx="4" fill="url(#n-goldh)" stroke="#5a3406" strokeWidth="1" />

              {/* ---------- neck + nozzle ---------- */}
              <rect x="110" y="-22" width="18" height="44" rx="4" fill="url(#n-gold)" stroke="#5a3406" strokeWidth="1.5" />
              <path d="M114 -18 L114 18" stroke="#fff2b0" strokeWidth="2" opacity="0.8" />
              <rect x="126" y="-15" width="10" height="30" rx="3" fill="url(#n-gold)" stroke="#5a3406" strokeWidth="1.2" />
              <path d="M134 -11 L170 -34 Q180 0 170 34 L134 11Z" fill="url(#n-gold)" stroke="#5a3406" strokeWidth="1.5" strokeLinejoin="round" />
              <path d="M142 -13 L166 -27 M142 13 L166 27 M146 -6 L170 -14 M146 6 L170 14" stroke="#7a4606" strokeWidth="1.2" opacity="0.6" />
              <path d="M140 -10 L164 -26" stroke="#fff2b0" strokeWidth="2" opacity="0.8" />
              <ellipse cx="171" cy="0" rx="8" ry="34" fill="#e0a83c" stroke="#5a3406" strokeWidth="1.5" />
              <ellipse cx="171" cy="0" rx="5.5" ry="28" fill="#a8681a" />
              <ellipse cx="171" cy="0" rx="3" ry="16" fill="none" stroke="#ffd36b" strokeWidth="1" />
              {[-22, -14, -6, 2, 10, 18].map((y) => (
                <circle key={y} cx={y % 4 ? 170 : 172} cy={y + 2} r="1.6" fill="#3a2104" />
              ))}

              {/* ---------- vines crossing ---------- */}
              <Rope d="M-30 -32 C-6 -10 30 14 70 32" />
              <Rope d="M-20 32 C10 10 44 -14 74 -32" />
              <Rope d="M-38 -30 C-40 -10 -40 10 -36 30" />
              <Leaf x={-16} y={-20} r={-120} />
              <Leaf x={28} y={8} r={60} d={0.5} />
              <Leaf x={52} y={22} r={110} s={0.9} d={0.9} />
              <Leaf x={10} y={18} r={150} s={0.85} d={1.3} />
              <Leaf x={52} y={-18} r={-50} d={0.3} />
              <Leaf x={-38} y={10} r={170} s={0.85} d={0.7} />
              <Leaf x={-36} y={30} r={100} s={0.8} d={1.1} />

              {/* ---------- pot with sprout ---------- */}
              <g transform="translate(76 -48) rotate(36)">
                <g className="sprout-idle">
                  <g className={fire ? 'sprout-grow' : ''}>
                    <path d="M0 -22 C-3 -36 4 -48 0 -64" stroke="#2f8a24" strokeWidth="3.6" fill="none" strokeLinecap="round" />
                    <Leaf x={0} y={-56} r={-160} s={1.05} />
                    <Leaf x={0} y={-62} r={-25} s={1.15} d={0.5} />
                    <Leaf x={-1} y={-40} r={-170} s={0.8} d={0.9} />
                    <Leaf x={1} y={-34} r={-12} s={0.7} d={0.3} />
                  </g>
                </g>
                <path d="M-17 -14 L17 -14 L12 18 L-12 18Z" fill="url(#n-pot)" stroke="#4e1e06" strokeWidth="1.5" strokeLinejoin="round" />
                <path d="M-11 -9 L-8.5 14" stroke="#ffc796" strokeWidth="3" opacity="0.55" strokeLinecap="round" />
                <rect x="-21" y="-23" width="42" height="10" rx="3" fill="url(#n-pot)" stroke="#4e1e06" strokeWidth="1.5" />
                <path d="M-18 -20 L14 -20" stroke="#ffd2a8" strokeWidth="1.5" opacity="0.7" />
                <ellipse cx="0" cy="-23" rx="18" ry="3.2" fill="#3a1e0a" />
              </g>
            </Shiny>
          </g>

          {/* ---------- use effects (no projectile) ---------- */}
          {fire > 0 && (
            <g key={`fx${fire}`} transform="translate(180 0)">
              <circle r="36" fill="url(#n-flash)" className="fx-flash" />
              <circle r="12" fill="none" stroke="#b9ff9c" strokeWidth="3" className="fx-ring" style={v({ '--s': 5 })} />
              <circle r="12" fill="none" stroke="#ffffff" strokeWidth="1.5" className="fx-ring" style={v({ '--s': 3.4, '--delay': '.12s' })} />
              {FX_LEAVES.map((p, i) => (
                <path key={i} d={LEAF} fill="url(#n-leaf)" stroke="#1d6a24" strokeWidth="1" className="burst" style={burstStyle(p, 1.2)} />
              ))}
              {FX_SPARKS.map((p, i) => (
                <path key={`s${i}`} d={star4(0, 0, 5)} fill={i % 2 ? '#f6ffb8' : '#a8ff9a'} className="burst" style={burstStyle(p, 0.9)} />
              ))}
            </g>
          )}
          {fire > 0 && (
            <g key={`fb${fire}`} transform="translate(10 0)">
              {FX_BACK.map((p, i) => (
                <circle key={i} r="3" fill="#d8ffb5" className="burst" style={burstStyle(p, 1)} />
              ))}
            </g>
          )}
        </g>
      </g>
    </Stage>
  );
}
