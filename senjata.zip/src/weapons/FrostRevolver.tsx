import { Stage, Shiny } from '../components/Stage';
import { burstStyle, snowflake, spread, star4, v } from '../lib/fx';

const FLAKE_BIG = snowflake(17);
const FLAKE_SM = snowflake(6);
const FX_FLAKES = spread(12, -85, 85, 60, 125, 6);
const FX_SHARDS = spread(14, -100, 100, 40, 100, 12);

/** faceted crystal shards: [angleDeg, length, halfWidth] */
const SHARD_DEF: [number, number, number][] = [
  [-80, 26, 6],
  [80, 24, 6],
  [-58, 38, 8],
  [58, 36, 8],
  [-36, 30, 7],
  [36, 32, 7],
  [-20, 54, 11],
  [22, 48, 10],
  [0, 64, 13],
];
const SHARDS = SHARD_DEF.map(([a, L, w]) => {
  const r = (a * Math.PI) / 180;
  const ux = Math.cos(r), uy = Math.sin(r);
  const px = -uy, py = ux;
  const p = (t: number, s: number) => `${(ux * L * t + px * w * s).toFixed(1)},${(uy * L * t + py * w * s).toFixed(1)}`;
  return {
    light: [p(0, -0.55), p(0.62, -1), p(1, 0), p(0.05, 0)].join(' '),
    dark: [p(0, 0.55), p(0.62, 1), p(1, 0), p(0.05, 0)].join(' '),
    edge: [p(0, -0.55), p(0.62, -1), p(1, 0), p(0.62, 1), p(0, 0.55)].join(' '),
    tip: p(0.88, -0.3),
  };
});

const BARREL_STARS = [68, 116];

export default function FrostRevolver({ fire }: { fire: number }) {
  return (
    <Stage id="frost" fire={fire} glow="#4fd2ff" mote="#c8f4ff" outline="#0a1230">
      <defs>
        <linearGradient id="f-white" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#ffffff" />
          <stop offset="0.45" stopColor="#f1f5fb" />
          <stop offset="0.8" stopColor="#c3cfe0" />
          <stop offset="1" stopColor="#8796ae" />
        </linearGradient>
        <linearGradient id="f-silver" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#ffffff" />
          <stop offset="0.35" stopColor="#d5dde8" />
          <stop offset="0.7" stopColor="#8e9bb0" />
          <stop offset="1" stopColor="#4c5870" />
        </linearGradient>
        <linearGradient id="f-navy" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#3b4f7c" />
          <stop offset="0.5" stopColor="#1a2440" />
          <stop offset="1" stopColor="#080d1c" />
        </linearGradient>
        <linearGradient id="f-band" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#56688f" />
          <stop offset="0.4" stopColor="#1c2642" />
          <stop offset="1" stopColor="#070b18" />
        </linearGradient>
        <linearGradient id="f-icel" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0" stopColor="#a8ecff" />
          <stop offset="1" stopColor="#f4feff" />
        </linearGradient>
        <linearGradient id="f-iced" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0" stopColor="#1250d0" />
          <stop offset="1" stopColor="#3ab6ff" />
        </linearGradient>
        <radialGradient id="f-panel">
          <stop offset="0" stopColor="#e6fbff" />
          <stop offset="0.4" stopColor="#3cc4ff" />
          <stop offset="1" stopColor="#0a3a9a" />
        </radialGradient>
        <radialGradient id="f-flash">
          <stop offset="0" stopColor="#ffffff" />
          <stop offset="0.4" stopColor="#9eeaff" stopOpacity="0.85" />
          <stop offset="1" stopColor="#2f9bff" stopOpacity="0" />
        </radialGradient>
      </defs>

      <g className="floaty">
        <g transform="translate(184 222) rotate(-32) scale(0.9)">
          <g key={fire} className={fire ? 'recoil' : ''}>
            <Shiny id="frost" fire={fire}>
              {/* ---------- grip ---------- */}
              <path d="M-84 -14 L-28 -10 C-30 24 -38 56 -44 86 L-112 104 C-104 66 -94 26 -84 -14Z" fill="url(#f-navy)" />
              {Array.from({ length: 8 }, (_, i) => (
                <path
                  key={i}
                  d={`M${-80 - i * 3.6} ${4 + i * 11} L${-36 - i * 1.4} ${4 + i * 10}`}
                  stroke={i % 2 ? '#0a1024' : '#45598a'}
                  strokeWidth={i % 2 ? 2.5 : 1.4}
                  strokeLinecap="round"
                  opacity="0.8"
                />
              ))}
              {/* neon edges */}
              <path d="M-31 -4 C-33 28 -40 58 -46 86" stroke="#bff4ff" strokeWidth="2" fill="none" />
              <path d="M-31 -4 C-33 28 -40 58 -46 86" stroke="#38c8ff" strokeWidth="5" fill="none" opacity="0.6" filter="url(#frost-soft)" className="pulse-op" />
              <path d="M-84 -4 C-92 30 -100 64 -106 96" stroke="#bff4ff" strokeWidth="2" fill="none" />
              <path d="M-84 -4 C-92 30 -100 64 -106 96" stroke="#38c8ff" strokeWidth="5" fill="none" opacity="0.6" filter="url(#frost-soft)" className="pulse-op" />
              {/* backstrap silver fin */}
              <path d="M-90 -40 L-80 -14 L-88 18 L-104 -8Z" fill="url(#f-silver)" stroke="#3a4659" strokeWidth="1" />
              <path d="M-96 -12 L-88 8" stroke="#4fd8ff" strokeWidth="2" />
              {/* pommel */}
              <path d="M-118 98 L-42 80 L-44 100 L-60 130 L-74 112 L-110 116Z" fill="url(#f-silver)" stroke="#3a4659" strokeWidth="1.2" strokeLinejoin="round" />
              <path d="M-108 104 L-50 90" stroke="#4fd8ff" strokeWidth="2.5" />
              <path d="M-108 104 L-50 90" stroke="#4fd8ff" strokeWidth="6" opacity="0.5" filter="url(#frost-soft)" />
              <path d="M-62 104 L-60 122 L-70 110Z" fill="#4fd8ff" />

              {/* ---------- trigger guard ---------- */}
              <path d="M-28 -10 C-34 24 -6 34 14 22 C24 14 28 2 26 -10" stroke="#3a4659" strokeWidth="11" fill="none" strokeLinecap="round" />
              <path d="M-28 -10 C-34 24 -6 34 14 22 C24 14 28 2 26 -10" stroke="url(#f-silver)" strokeWidth="8" fill="none" strokeLinecap="round" />
              <path d="M-24 -4 C-26 16 -10 26 6 22" stroke="#fff" strokeWidth="1.5" fill="none" opacity="0.9" />
              <path d="M2 -8 C-5 4 -3 14 5 20" stroke="#0a1024" strokeWidth="6" fill="none" strokeLinecap="round" />
              <path d="M2 -8 C-5 4 -3 14 5 20" stroke="#4fd8ff" strokeWidth="1.5" fill="none" strokeLinecap="round" />

              {/* ---------- frame ---------- */}
              <path d="M-88 -72 L32 -72 L32 -10 L-26 -10 L-40 -4 L-80 -10 L-94 -30 L-96 -60Z" fill="url(#f-silver)" stroke="#3a4659" strokeWidth="1.2" strokeLinejoin="round" />
              <path d="M-90 -30 L-78 -16 L28 -16" stroke="#4fd8ff" strokeWidth="2.5" fill="none" />
              <path d="M-90 -30 L-78 -16 L28 -16" stroke="#4fd8ff" strokeWidth="6" fill="none" opacity="0.5" filter="url(#frost-soft)" />
              <path d="M-90 -66 L-60 -66" stroke="#fff" strokeWidth="2" opacity="0.9" strokeLinecap="round" />

              {/* hammer */}
              <g className={fire ? 'hammer' : ''}>
                <path d="M-82 -70 L-104 -90 L-94 -98 L-66 -74Z" fill="url(#f-silver)" stroke="#3a4659" strokeWidth="1.2" strokeLinejoin="round" />
                <path d="M-98 -92 L-92 -88" stroke="#4fd8ff" strokeWidth="2" />
              </g>

              {/* under shroud */}
              <path d="M28 -36 L142 -36 L128 -16 L28 -16Z" fill="url(#f-silver)" stroke="#3a4659" strokeWidth="1.2" strokeLinejoin="round" />
              <path d="M34 -24 L124 -24" stroke="#4fd8ff" strokeWidth="2" />
              <path d="M34 -24 L124 -24" stroke="#4fd8ff" strokeWidth="5" opacity="0.5" filter="url(#frost-soft)" />

              {/* ---------- barrel ---------- */}
              <rect x="26" y="-74" width="150" height="40" rx="11" fill="url(#f-white)" stroke="#5a6884" strokeWidth="1.2" />
              <rect x="34" y="-69" width="134" height="6" rx="3" fill="#fff" />
              {[40, 90, 140].map((x) => (
                <g key={x}>
                  <rect x={x - 2} y="-78" width="18" height="48" rx="4" fill="url(#f-silver)" stroke="#3a4659" strokeWidth="1" />
                  <rect x={x + 1} y="-76" width="12" height="44" rx="3" fill="url(#f-band)" />
                  <rect x={x + 3} y="-74" width="2" height="38" rx="1" fill="#7f93c0" opacity="0.8" />
                </g>
              ))}
              {BARREL_STARS.map((x, i) => (
                <g key={x}>
                  <path d={star4(x, -54, 10, 0.2)} fill="#38c0ff" opacity="0.6" filter="url(#frost-soft)" />
                  <path d={star4(x, -54, 8, 0.2)} fill="#1aa8ff" stroke="#0a3a9a" strokeWidth="0.8" className="twinkle" style={v({ '--delay': `${i * 0.9}s` })} />
                  <path d={star4(x, -54, 3.5, 0.2)} fill="#e8fbff" />
                </g>
              ))}

              {/* muzzle collar */}
              <rect x="170" y="-80" width="18" height="52" rx="6" fill="url(#f-silver)" stroke="#3a4659" strokeWidth="1.2" />
              <rect x="174" y="-77" width="3" height="46" rx="1.5" fill="#fff" />
              <rect x="186" y="-72" width="7" height="36" rx="2.5" fill="url(#f-band)" />

              {/* ---------- cylinder snow panel ---------- */}
              <rect x="-54" y="-82" width="84" height="74" rx="13" fill="url(#f-silver)" stroke="#3a4659" strokeWidth="1.2" />
              <rect x="-48" y="-76" width="72" height="62" rx="9" fill="url(#f-navy)" />
              <rect x="-43" y="-71" width="62" height="52" rx="7" fill="url(#f-panel)" />
              <rect x="-43" y="-71" width="62" height="52" rx="7" fill="#c8f4ff" opacity="0.25" className="pulse-op" />
              <rect x="-43" y="-71" width="62" height="52" rx="7" fill="none" stroke="#9eefff" strokeWidth="2" />
              <g transform="translate(-12 -45)">
                <circle r="20" fill="none" stroke="#c8f6ff" strokeWidth="1" opacity="0.6" />
                <path d={FLAKE_BIG} stroke="#ffffff" strokeWidth="2.6" strokeLinecap="round" fill="none" />
                <circle r="3" fill="#fff" />
              </g>
              <path d="M-40 -66 L-24 -66" stroke="#fff" strokeWidth="2" strokeLinecap="round" opacity="0.8" />
              {fire > 0 && <rect x="-43" y="-71" width="62" height="52" rx="7" fill="#ffffff" className="overlay-flash" />}
            </Shiny>
            <g transform="translate(-12 -45)">
              <path d={FLAKE_BIG} stroke="#7fe4ff" strokeWidth="5" strokeLinecap="round" fill="none" opacity="0.6" filter="url(#frost-soft)" className="pulse-op" />
            </g>

            {/* ---------- crystal cluster ---------- */}
            <g transform="translate(192 -54) scale(1.3)">
              <circle cx="22" r="44" fill="#4fd2ff" opacity="0.45" filter="url(#frost-blur)" />
              <g transform="translate(4 0)">
                <ellipse rx="14" ry="48" fill="none" stroke="#7fe8ff" strokeWidth="5" opacity="0.4" filter="url(#frost-soft)" className="halo-spin" />
              </g>
              <g className="crystal-idle">
                <g className={fire ? 'crystal-fire' : ''}>
                  {SHARDS.map((s, i) => (
                    <g key={i}>
                      <polygon points={s.edge} fill="#0b3a9e" stroke="#0b2a74" strokeWidth="2.5" strokeLinejoin="round" />
                      <polygon points={s.light} fill="url(#f-icel)" />
                      <polygon points={s.dark} fill="url(#f-iced)" />
                      <polygon points={s.edge} fill="none" stroke="#e6fbff" strokeWidth="0.9" strokeLinejoin="round" opacity="0.8" />
                    </g>
                  ))}
                  <path d={star4(60, -4, 7)} fill="#fff" className="twinkle" />
                  <path d={star4(22, -40, 5)} fill="#fff" className="twinkle" style={v({ '--delay': '1s' })} />
                </g>
              </g>
              <g transform="translate(4 0)">
                <ellipse rx="14" ry="48" fill="none" stroke="#c4f6ff" strokeWidth="2" className="halo-spin" />
                <ellipse rx="18" ry="56" fill="none" stroke="#c4f6ff" strokeWidth="1.2" strokeDasharray="22 8 4 8" className="dash-flow" opacity="0.7" />
              </g>
            </g>
          </g>

          {/* ---------- use effects ---------- */}
          {fire > 0 && (
            <g key={`fx${fire}`} transform="translate(250 -54)">
              <circle r="46" fill="url(#f-flash)" className="fx-flash" />
              <ellipse rx="8" ry="22" fill="none" stroke="#9eefff" strokeWidth="3" className="fx-ring" style={v({ '--s': 5 })} />
              <ellipse rx="8" ry="22" fill="none" stroke="#ffffff" strokeWidth="1.5" className="fx-ring" style={v({ '--s': 3.5, '--delay': '.12s' })} />
              <circle r="12" fill="none" stroke="#5fd8ff" strokeWidth="2" className="fx-ring" style={v({ '--s': 6, '--delay': '.2s', '--dur': '1s' })} />
              {FX_FLAKES.map((p, i) => (
                <path key={i} d={i % 2 ? FLAKE_SM : snowflake(8)} stroke="#ffffff" strokeWidth="1.6" strokeLinecap="round" fill="none" className="burst" style={burstStyle(p, 1.3)} />
              ))}
              {FX_SHARDS.map((p, i) => (
                <path key={`s${i}`} d={i % 2 ? star4(0, 0, 5) : 'M0 -5 L2 0 L0 5 L-2 0Z'} fill={i % 3 ? '#bff4ff' : '#4fc8ff'} className="burst" style={burstStyle(p, 0.9)} />
              ))}
            </g>
          )}
        </g>
      </g>
    </Stage>
  );
}
