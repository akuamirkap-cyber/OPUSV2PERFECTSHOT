import { Stage, Shiny } from '../components/Stage';
import { burstStyle, rand, spread, star4, v } from '../lib/fx';

/* ---------- wing geometry (local: shoulder at 0,0, wing rises up-left) ---------- */
type Pt = [number, number];
const qb = (a: Pt, b: Pt, c: Pt, t: number): Pt => [
  (1 - t) ** 2 * a[0] + 2 * (1 - t) * t * b[0] + t * t * c[0],
  (1 - t) ** 2 * a[1] + 2 * (1 - t) * t * b[1] + t * t * c[1],
];
const ARM: [Pt, Pt, Pt] = [
  [0, 0],
  [-46, -104],
  [-138, -128],
];
const TIPS: [Pt, Pt, Pt] = [
  [-222, -100],
  [-224, 30],
  [-58, 36],
];
const bone = (t: number) => qb(...ARM, t);
const tipAt = (s: number) => qb(...TIPS, s);
const lerp = (a: Pt, b: Pt, k: number): Pt => [a[0] + (b[0] - a[0]) * k, a[1] + (b[1] - a[1]) * k];

type Feather = { x: number; y: number; a: number; L: number; w: number };
const mk = (A: Pt, T: Pt, wr: number): Feather => {
  const dx = T[0] - A[0], dy = T[1] - A[1];
  const L = Math.hypot(dx, dy);
  return { x: A[0], y: A[1], a: (Math.atan2(dy, dx) * 180) / Math.PI, L, w: Math.min(L * wr, 15) };
};
function layer(n: number, t0: number, t1: number, reach: number, wr: number) {
  return Array.from({ length: n }, (_, i) => {
    const k = i / (n - 1);
    const t = t0 + (t1 - t0) * k;
    const A = bone(t);
    const T = tipAt(1 - k * 0.98);
    return mk(A, lerp(A, T, reach), wr);
  });
}
// draw order: from inner (near shoulder) to outer so upper feathers overlap
const L1 = layer(15, 0.05, 1, 1, 0.12);
const L2 = layer(12, 0.04, 0.97, 0.62, 0.17);
const L3 = layer(10, 0.02, 0.94, 0.3, 0.3);
const featherPath = (L: number, w: number) =>
  `M0 0 C${L * 0.25} ${-w} ${L * 0.7} ${-w * 1.05} ${L * 0.95} ${-w * 0.38} Q${L * 1.03} 0 ${L * 0.95} ${w * 0.32} C${L * 0.7} ${w} ${L * 0.25} ${w * 0.9} 0 0Z`;
const ARM_D = `M${ARM[0].join(' ')} Q${ARM[1].join(' ')} ${ARM[2].join(' ')}`;
const GLITTER = Array.from({ length: 22 }, (_, i) => {
  const p = tipAt(rand(i + 3));
  const b = bone(rand(i + 7));
  const q = lerp(b, p, 0.55 + rand(i + 11) * 0.4);
  return { x: q[0], y: q[1], r: 0.8 + rand(i + 13) * 1.4, d: rand(i + 17) * 3 };
});

function Wing({ grad, fire, back }: { grad: string; fire: number; back?: boolean }) {
  const stroke = back ? '#a996c8' : '#b9a4d4';
  const F = (f: Feather, i: number, round = false) => (
    <g key={i} transform={`translate(${f.x.toFixed(1)} ${f.y.toFixed(1)}) rotate(${f.a.toFixed(1)})`}>
      <path d={featherPath(f.L, f.w)} fill="#5a3f8c" opacity="0.18" transform="translate(1.5 3.5)" />
      <path d={featherPath(f.L, f.w)} fill={`url(#${grad})`} stroke={stroke} strokeWidth="1.1" strokeLinejoin="round" />
      {!round && <path d={`M3 0 Q${f.L * 0.5} ${-f.w * 0.12} ${f.L * 0.86} 0`} stroke="#d9c6ee" strokeWidth="1" fill="none" />}
      <path d={`M${f.L * 0.2} ${-f.w * 0.55} Q${f.L * 0.5} ${-f.w * 0.85} ${f.L * 0.78} ${-f.w * 0.62}`} stroke="#ffffff" strokeWidth="1.2" fill="none" opacity="0.9" />
    </g>
  );
  return (
    <g className="wing-idle">
      <g className={fire ? 'wing-flap' : ''}>
        {L1.map((f, i) => F(f, i))}
        {L2.map((f, i) => F(f, i))}
        {L3.map((f, i) => F(f, i, true))}
        {/* arm / leading edge */}
        <path d={ARM_D} stroke="#b88a2e" strokeWidth="11" fill="none" strokeLinecap="round" />
        <path d={ARM_D} stroke={back ? '#ece6f6' : '#ffffff'} strokeWidth="8" fill="none" strokeLinecap="round" />
        <path d={ARM_D} stroke="url(#a-goldline)" strokeWidth="2.2" fill="none" strokeLinecap="round" transform="translate(1.5 2)" />
        {GLITTER.map((g, i) => (
          <circle key={i} cx={g.x.toFixed(1)} cy={g.y.toFixed(1)} r={g.r.toFixed(2)} fill="#ffe28a" className="twinkle" style={v({ '--delay': `${g.d.toFixed(2)}s` })} />
        ))}
      </g>
    </g>
  );
}

/* ---------- fx ---------- */
const FX_LIGHT = spread(14, -80, 80, 40, 110, 2);
const FX_FEATHERS = Array.from({ length: 8 }, (_, i) => ({
  x: 60 + rand(i + 40) * 110,
  y: 70 + rand(i + 50) * 90,
  dx: -40 + rand(i + 60) * 60,
  dy: 70 + rand(i + 70) * 80,
  r: (rand(i + 80) - 0.5) * 300,
  d: rand(i + 90) * 0.3,
}));

const GRIP = 'M-96 -26 L-36 -30 C-40 6 -54 46 -66 80 L-126 86 C-116 46 -104 10 -96 -26Z';

export default function AngelPistol({ fire }: { fire: number }) {
  return (
    <Stage id="angel" fire={fire} glow="#fff0b8" mote="#fff6d6" outline="#6a4610">
      <defs>
        <linearGradient id="a-ivory" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#ffffff" />
          <stop offset="0.4" stopColor="#f8f3ea" />
          <stop offset="0.8" stopColor="#dcd0bb" />
          <stop offset="1" stopColor="#b3a285" />
        </linearGradient>
        <linearGradient id="a-ivoryh" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0" stopColor="#c8b898" />
          <stop offset="0.4" stopColor="#ffffff" />
          <stop offset="0.75" stopColor="#f2ebdc" />
          <stop offset="1" stopColor="#bba98a" />
        </linearGradient>
        <linearGradient id="a-gold" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#fff6c4" />
          <stop offset="0.3" stopColor="#ffd25a" />
          <stop offset="0.7" stopColor="#c8841a" />
          <stop offset="1" stopColor="#6a3a06" />
        </linearGradient>
        <linearGradient id="a-goldline" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#e8b440" />
          <stop offset="0.5" stopColor="#fff0a8" />
          <stop offset="1" stopColor="#c8841a" />
        </linearGradient>
        <linearGradient id="a-feather" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0" stopColor="#ffffff" />
          <stop offset="0.55" stopColor="#fdfbff" />
          <stop offset="0.82" stopColor="#efe6fb" />
          <stop offset="0.94" stopColor="#f7e4a6" />
          <stop offset="1" stopColor="#ecc35e" />
        </linearGradient>
        <linearGradient id="a-feather2" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0" stopColor="#f3eefb" />
          <stop offset="0.6" stopColor="#e4dbf2" />
          <stop offset="0.9" stopColor="#efd9a0" />
          <stop offset="1" stopColor="#e0b450" />
        </linearGradient>
        <linearGradient id="a-crystal" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#ffffff" />
          <stop offset="0.5" stopColor="#dff4ff" />
          <stop offset="1" stopColor="#8fc4ec" />
        </linearGradient>
        <linearGradient id="a-halo" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0" stopColor="#ffcf4a" />
          <stop offset="0.5" stopColor="#fff8d0" />
          <stop offset="1" stopColor="#ffcf4a" />
        </linearGradient>
        <radialGradient id="a-flash">
          <stop offset="0" stopColor="#ffffff" />
          <stop offset="0.4" stopColor="#fff2b8" stopOpacity="0.9" />
          <stop offset="1" stopColor="#ffd36b" stopOpacity="0" />
        </radialGradient>
        <clipPath id="a-gripclip">
          <path d={GRIP} />
        </clipPath>
      </defs>

      {/* light bloom behind */}
      <circle cx="190" cy="170" r="110" fill="#fff4d0" opacity="0.35" filter="url(#angel-blur)" />

      <g className="floaty">
        {/* ---------- halo ---------- */}
        <g className="halo-bob">
          <g key={`h${fire}`} className={fire ? 'halo-fire' : ''}>
            <ellipse cx="300" cy="70" rx="62" ry="17" fill="none" stroke="#ffcf4a" strokeWidth="14" opacity="0.35" filter="url(#angel-blur)" />
            <ellipse cx="300" cy="70" rx="62" ry="17" fill="none" stroke="#ffd65e" strokeWidth="8" opacity="0.7" filter="url(#angel-soft)" />
            <ellipse cx="300" cy="70" rx="62" ry="17" fill="none" stroke="url(#a-halo)" strokeWidth="4.5" />
            <ellipse cx="300" cy="69" rx="61" ry="16" fill="none" stroke="#ffffff" strokeWidth="1.4" />
            {fire > 0 && <ellipse cx="300" cy="70" rx="62" ry="17" fill="none" stroke="#ffffff" strokeWidth="12" className="overlay-flash" filter="url(#angel-soft)" />}
          </g>
          {[
            [238, 58, 5],
            [362, 62, 4],
            [318, 44, 6],
            [252, 90, 3.5],
          ].map(([x, y, r], i) => (
            <path key={i} d={star4(x, y, r)} fill="#fff6c8" className="twinkle" style={v({ '--delay': `${i * 0.7}s` })} />
          ))}
        </g>

        <g key={fire} className={fire ? 'recoil' : ''}>
          <Shiny id="angel" fire={fire}>
            {/* back wing */}
            <g transform="translate(210 172) rotate(18) scale(0.88)">
              <Wing grad="a-feather2" fire={fire} back />
            </g>

            {/* ---------- gun ---------- */}
            <g transform="translate(236 216) rotate(-22) scale(0.86)">
              {/* grip */}
              <g transform="translate(0 -28) skewX(-24) translate(0 28)">
              <path d={GRIP} fill="url(#a-ivoryh)" />
              <g clipPath="url(#a-gripclip)">
                <path d="M-84 -20 C-92 16 -104 50 -114 84" stroke="#ffffff" strokeWidth="6" fill="none" opacity="0.8" />
              </g>
              <path d={GRIP} fill="none" stroke="url(#a-gold)" strokeWidth="4.5" strokeLinejoin="round" />
              <g fill="none" stroke="url(#a-gold)" strokeLinecap="round">
                <path d="M-44 -18 C-62 -10 -52 8 -66 18 C-80 28 -72 46 -88 56 C-100 64 -100 76 -110 78" strokeWidth="3.4" />
                <path d="M-66 18 C-74 10 -84 14 -82 22 C-80 28 -74 26 -75 22" strokeWidth="2.6" />
                <path d="M-88 56 C-78 52 -70 58 -74 64 C-77 68 -82 66 -80 62" strokeWidth="2.6" />
                <path d="M-88 -14 C-82 -2 -90 6 -86 14" strokeWidth="2.4" />
                <path d="M-58 40 C-66 46 -66 56 -60 58" strokeWidth="2.4" />
              </g>
              {[
                [-66, 18],
                [-88, 56],
                [-60, 58],
              ].map(([x, y], i) => (
                <circle key={i} cx={x} cy={y} r="2.6" fill="#fff0a8" stroke="#a8680e" strokeWidth="0.8" />
              ))}
              {/* bottom band */}
              <path d="M-131 80 L-61 74 L-63 96 L-129 102Z" fill="url(#a-gold)" stroke="#6a3a06" strokeWidth="1.2" strokeLinejoin="round" />
              <path d="M-127 84 L-65 79" stroke="#fff6c4" strokeWidth="1.5" opacity="0.9" />
              <path d="M-96 78 L-89 88 L-96 98 L-103 88Z" fill="url(#a-crystal)" stroke="#6a3a06" strokeWidth="1" />
              <path d="M-96 80 L-100 88 L-96 88Z" fill="#fff" />

              </g>
              {/* charms (counter-rotated to hang straight) */}
              {[
                [-177, 101, 4, 0],
                [-153, 99, 14, 0.4],
                [-129, 97, 4, 0.8],
              ].map(([x, y, ext, d], i) => (
                <g key={i} transform={`translate(${x} ${y}) rotate(22)`}>
                  <g className="charm" style={v({ '--delay': `${d}s` })}>
                    <path d={`M0 0 L0 ${6 + ext}`} stroke="#d6a640" strokeWidth="1.8" />
                    <circle cy={6 + ext} r="2.6" fill="url(#a-gold)" />
                    <path d={`M0 ${8 + ext} L7 ${17 + ext} L0 ${33 + ext} L-7 ${17 + ext}Z`} fill="url(#a-crystal)" stroke="#b07a1e" strokeWidth="1.3" strokeLinejoin="round" />
                    <path d={`M0 ${8 + ext} L0 ${33 + ext} M-7 ${17 + ext} L7 ${17 + ext}`} stroke="#b9dcf2" strokeWidth="0.8" />
                    <path d={`M-2.5 ${14 + ext} L1 ${11 + ext}`} stroke="#fff" strokeWidth="1.6" strokeLinecap="round" />
                    <path d={`M0 ${33 + ext} L3 ${38 + ext} L0 ${43 + ext} L-3 ${38 + ext}Z`} fill="url(#a-gold)" />
                  </g>
                </g>
              ))}

              {/* trigger guard */}
              <path d="M-36 -28 C-40 4 -6 14 14 -4 C20 -12 24 -22 22 -30" stroke="#6a3a06" strokeWidth="9" fill="none" strokeLinecap="round" />
              <path d="M-36 -28 C-40 4 -6 14 14 -4 C20 -12 24 -22 22 -30" stroke="url(#a-gold)" strokeWidth="6" fill="none" strokeLinecap="round" />
              <path d="M14 -4 C24 6 36 0 32 -8 C29 -13 22 -10 25 -6" stroke="url(#a-gold)" strokeWidth="3.5" fill="none" strokeLinecap="round" />
              <path d="M-6 -30 C-12 -16 -8 -6 0 0" stroke="#6a3a06" strokeWidth="7" fill="none" strokeLinecap="round" />
              <path d="M-6 -30 C-12 -16 -8 -6 0 0" stroke="url(#a-gold)" strokeWidth="4.5" fill="none" strokeLinecap="round" />

              {/* frame */}
              <path d="M-98 -70 L-36 -70 L-36 -26 L-90 -18 Q-104 -28 -104 -48 Q-104 -68 -98 -70Z" fill="url(#a-ivory)" stroke="url(#a-gold)" strokeWidth="3.5" strokeLinejoin="round" />
              <path d="M-92 -40 C-84 -28 -68 -32 -72 -42 C-74 -48 -80 -46 -78 -42" stroke="url(#a-gold)" strokeWidth="2.5" fill="none" strokeLinecap="round" />
              <path d="M-60 -58 C-52 -50 -44 -56 -46 -62" stroke="url(#a-gold)" strokeWidth="2.2" fill="none" strokeLinecap="round" />

              {/* hammer */}
              <g className={fire ? 'hammer' : ''}>
                <path d="M-92 -68 C-102 -86 -92 -100 -78 -94 C-86 -88 -88 -80 -80 -70Z" fill="url(#a-gold)" stroke="#6a3a06" strokeWidth="1.3" strokeLinejoin="round" />
                <circle cx="-86" cy="-90" r="2" fill="#fff6c4" />
              </g>

              {/* barrel */}
              <rect x="-40" y="-64" width="192" height="32" rx="15" fill="url(#a-ivory)" stroke="#b8902e" strokeWidth="1.4" />
              <rect x="-32" y="-59" width="176" height="6" rx="3" fill="#ffffff" />
              <rect x="-40" y="-67" width="192" height="5" rx="2.5" fill="url(#a-gold)" />
              <g fill="none" stroke="url(#a-gold)" strokeLinecap="round">
                <path d="M-20 -44 C-10 -56 6 -54 10 -44 C14 -36 26 -36 30 -44 C34 -52 46 -52 50 -44" strokeWidth="2.6" />
                <path d="M10 -44 C8 -38 2 -38 2 -42 M50 -44 C48 -38 42 -38 42 -42" strokeWidth="2" />
                <path d="M74 -40 C84 -54 104 -54 110 -44 C114 -38 122 -38 126 -46 C130 -52 138 -50 138 -44" strokeWidth="2.6" />
                <path d="M110 -44 C106 -38 100 -40 102 -44" strokeWidth="2" />
              </g>
              {[60, 118].map((x) => (
                <g key={x}>
                  <rect x={x} y="-66" width="9" height="36" rx="3" fill="url(#a-gold)" stroke="#6a3a06" strokeWidth="1" />
                  <rect x={x + 2} y="-63" width="2" height="30" rx="1" fill="#fff6c4" />
                </g>
              ))}
              <rect x="-44" y="-68" width="14" height="40" rx="4" fill="url(#a-gold)" stroke="#6a3a06" strokeWidth="1" />
              <rect x="-41" y="-65" width="3" height="34" rx="1.5" fill="#fff6c4" />

              {/* muzzle */}
              <path d="M148 -66 L162 -72 Q172 -48 162 -24 L148 -30Z" fill="url(#a-gold)" stroke="#6a3a06" strokeWidth="1.3" strokeLinejoin="round" />
              <ellipse cx="163" cy="-48" rx="7" ry="24" fill="#f0bd4e" stroke="#6a3a06" strokeWidth="1.3" />
              <ellipse cx="164" cy="-48" rx="4" ry="13" fill="#3a2004" />
              <path d="M152 -64 L158 -66" stroke="#fff6c4" strokeWidth="2" strokeLinecap="round" />
            </g>

            {/* front wing */}
            <g transform="translate(186 188) rotate(4) scale(0.86)">
              <Wing grad="a-feather" fire={fire} />
            </g>
            {/* shoulder ornament */}
            <g transform="translate(184 186)">
              <path d="M-10 -8 C0 -22 20 -20 22 -6 C14 -12 4 -10 2 -2Z" fill="url(#a-gold)" stroke="#6a3a06" strokeWidth="1" />
              <path d="M2 -12 L7 -6 L2 0 L-3 -6Z" fill="url(#a-crystal)" stroke="#6a3a06" strokeWidth="0.8" />
            </g>
          </Shiny>
        </g>

        {/* ---------- use effects ---------- */}
        {fire > 0 && (
          <g key={`fx${fire}`}>
            <g transform="translate(344 136)">
              <circle r="44" fill="url(#a-flash)" className="fx-flash" />
              <path d={star4(0, 0, 52, 0.08)} fill="#ffffff" className="fx-flare" />
              <g transform="rotate(45)">
                <path d={star4(0, 0, 28, 0.1)} fill="#ffe28a" className="fx-flare" style={v({ '--delay': '.06s' })} />
              </g>
              <circle r="10" fill="none" stroke="#fff3c4" strokeWidth="3" className="fx-ring" style={v({ '--s': 5.5 })} />
              <circle r="10" fill="none" stroke="#ffd56b" strokeWidth="1.5" className="fx-ring" style={v({ '--s': 4, '--delay': '.12s' })} />
              {FX_LIGHT.map((p, i) => (
                <path key={i} d={star4(0, 0, i % 2 ? 4 : 6)} fill={i % 2 ? '#fff8dc' : '#ffd56b'} className="burst" style={burstStyle({ ...p, dx: p.dx * 0.9 - 10, dy: p.dy * 0.9 - 30 }, 1)} />
              ))}
            </g>
            {FX_FEATHERS.map((f, i) => (
              <g key={`f${i}`} transform={`translate(${f.x.toFixed(1)} ${f.y.toFixed(1)})`}>
                <path
                  d={featherPath(24, 5)}
                  fill="url(#a-feather)"
                  stroke="#b9a4d4"
                  strokeWidth="0.8"
                  className="feather-fall"
                  style={v({ '--dx': `${f.dx.toFixed(0)}px`, '--dy': `${f.dy.toFixed(0)}px`, '--r': `${f.r.toFixed(0)}deg`, '--delay': `${f.d.toFixed(2)}s` })}
                />
              </g>
            ))}
          </g>
        )}
      </g>
    </Stage>
  );
}
