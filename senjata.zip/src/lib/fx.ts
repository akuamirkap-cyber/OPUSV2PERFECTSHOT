import type { CSSProperties } from 'react';

export const v = (o: Record<string, string | number>) => o as CSSProperties;

export const rand = (n: number) => {
  const x = Math.sin(n * 127.1 + 311.7) * 43758.5453;
  return x - Math.floor(x);
};

/** 4-point sparkle star */
export const star4 = (cx: number, cy: number, r: number, k = 0.18) => {
  const i = r * k;
  return `M${cx} ${cy - r} Q${cx + i} ${cy - i} ${cx + r} ${cy} Q${cx + i} ${cy + i} ${cx} ${cy + r} Q${cx - i} ${cy + i} ${cx - r} ${cy} Q${cx - i} ${cy - i} ${cx} ${cy - r}Z`;
};

export type Particle = { dx: number; dy: number; r: number; delay: number; s: number };

export function spread(n: number, a0: number, a1: number, d0: number, d1: number, seed = 1): Particle[] {
  return Array.from({ length: n }, (_, i) => {
    const t = n === 1 ? 0.5 : i / (n - 1);
    const a = ((a0 + (a1 - a0) * t + (rand(seed * 100 + i) - 0.5) * 14) * Math.PI) / 180;
    const d = d0 + (d1 - d0) * rand(seed * 200 + i);
    return {
      dx: Math.cos(a) * d,
      dy: Math.sin(a) * d,
      r: (rand(seed * 300 + i) - 0.5) * 420,
      delay: rand(seed * 400 + i) * 0.18,
      s: 0.6 + rand(seed * 500 + i) * 0.8,
    };
  });
}

export const burstStyle = (p: Particle, dur = 1) =>
  v({
    '--dx': `${p.dx.toFixed(1)}px`,
    '--dy': `${p.dy.toFixed(1)}px`,
    '--r': `${p.r.toFixed(0)}deg`,
    '--delay': `${p.delay.toFixed(2)}s`,
    '--s': p.s.toFixed(2),
    '--dur': `${dur}s`,
  });

export const LEAF = 'M0 0 C5 -7 15 -8 22 0 C15 8 5 7 0 0Z';

export const snowflake = (r: number) => {
  let d = '';
  for (let k = 0; k < 6; k++) {
    const a = (k * Math.PI) / 3;
    const c = Math.cos(a), s = Math.sin(a);
    d += `M0 0 L${(c * r).toFixed(2)} ${(s * r).toFixed(2)} `;
    const bx = c * r * 0.55, by = s * r * 0.55;
    for (const sg of [-1, 1]) {
      const b = a + (sg * Math.PI) / 4;
      d += `M${bx.toFixed(2)} ${by.toFixed(2)} L${(bx + Math.cos(b) * r * 0.32).toFixed(2)} ${(by + Math.sin(b) * r * 0.32).toFixed(2)} `;
    }
  }
  return d;
};

export const star5 = (cx: number, cy: number, r: number, k = 0.45) =>
  'M' +
  Array.from({ length: 10 }, (_, i) => {
    const a = ((-90 + i * 36) * Math.PI) / 180;
    const rr = i % 2 ? r * k : r;
    return `${(cx + Math.cos(a) * rr).toFixed(2)} ${(cy + Math.sin(a) * rr).toFixed(2)}`;
  }).join(' L') +
  'Z';

export const TEARDROP = 'M0 -7 C3 -3 4.5 0 4.5 2.5 A4.5 4.5 0 0 1 -4.5 2.5 C-4.5 0 -3 -3 0 -7Z';

/** zig-zag lightning from x0 to x1 around y */
export const zigzag = (x0: number, x1: number, y: number, amp: number, n: number, seed: number) =>
  'M' +
  Array.from({ length: n + 1 }, (_, i) => {
    const x = x0 + ((x1 - x0) * i) / n;
    const yy = i === 0 || i === n ? y : y + (rand(seed * 31 + i) - 0.5) * 2 * amp;
    return `${x.toFixed(1)} ${yy.toFixed(1)}`;
  }).join(' L');
