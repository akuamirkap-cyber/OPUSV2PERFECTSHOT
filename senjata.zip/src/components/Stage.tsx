import type { ReactNode } from 'react';
import { burstStyle, rand, spread, star4, v } from '../lib/fx';

type Rarity = 'Rare' | 'Epic' | 'Legendary' | 'Mythic';
type Props = {
  id: string;
  glow: string;
  mote: string;
  outline?: string;
  bg?: [string, string, string];
  label?: string;
  rarity?: Rarity;
  fire?: number;
  children: ReactNode;
};

const RAYS = Array.from({ length: 18 }, (_, i) => {
  const a = (i * 20 * Math.PI) / 180;
  const w = (5.5 * Math.PI) / 180;
  const R = 420;
  return `M200 200 L${200 + Math.cos(a - w) * R} ${200 + Math.sin(a - w) * R} L${200 + Math.cos(a + w) * R} ${200 + Math.sin(a + w) * R}Z`;
});
const SPARKS = Array.from({ length: 20 }, (_, i) => ({
  x: 20 + rand(i * 3.1 + 1) * 360,
  y: 18 + rand(i * 7.7 + 2) * 300,
  s: 2 + rand(i * 5.3 + 3) * 4.5,
  d: rand(i * 9.1 + 4) * 3,
  star: rand(i * 2.9 + 5) > 0.45,
}));
const MOTES = Array.from({ length: 14 }, (_, i) => ({
  x: 90 + rand(i * 4.4 + 11) * 220,
  y: 150 + rand(i * 6.6 + 12) * 170,
  r: 1.2 + rand(i * 8.8 + 13) * 2.2,
  d: rand(i * 1.7 + 14) * 5,
  dur: 4 + rand(i * 3.3 + 15) * 3,
  dx: (rand(i * 2.2 + 16) - 0.5) * 40,
}));
const SPEED = Array.from({ length: 30 }, (_, i) => {
  const a = ((i * 12 + rand(i + 70) * 6) * Math.PI) / 180;
  const r0 = 120 + rand(i + 71) * 40;
  const r1 = r0 + 50 + rand(i + 72) * 70;
  return { x0: 200 + Math.cos(a) * r0, y0: 190 + Math.sin(a) * r0, x1: 200 + Math.cos(a) * r1, y1: 190 + Math.sin(a) * r1, w: 1.5 + rand(i + 73) * 2.5 };
});
const FX_STARS = spread(22, 0, 340, 120, 185, 77);
const ORBIT = 'M56 200 A144 44 0 1 1 344 200 A144 44 0 1 1 56 200';

/** Wraps the weapon body: applies outline/aura and adds a glossy sweep + hit-flash clipped to its silhouette. */
export function Shiny({ id, fire = 0, children }: { id: string; fire?: number; children: ReactNode }) {
  const delay = ((id.charCodeAt(0) * 7 + id.length * 13) % 40) / 10;
  return (
    <>
      <g id={`${id}-body`} filter={`url(#${id}-aura)`}>
        {children}
      </g>
      <g mask={`url(#${id}-gm)`} style={{ pointerEvents: 'none' }}>
        <mask id={`${id}-gm`} maskUnits="userSpaceOnUse" x="-600" y="-600" width="1200" height="1200">
          <use href={`#${id}-body`} filter={`url(#${id}-solid)`} />
        </mask>
        <g transform="rotate(24)">
          <rect x="-360" y="-500" width="46" height="1000" fill={`url(#${id}-gl)`} className="gloss-idle" style={v({ '--delay': `${delay}s` })} />
        </g>
        {fire > 0 && (
          <g key={`hf${fire}`}>
            <rect x="-600" y="-600" width="1200" height="1200" fill="#ffffff" className="hit-flash" />
            <g transform="rotate(24)">
              <rect x="-360" y="-500" width="80" height="1000" fill={`url(#${id}-gl)`} className="gloss-fire" />
            </g>
          </g>
        )}
      </g>
    </>
  );
}

export function Stage({ id, glow, mote, outline = '#241004', bg = ['#b59cf0', '#6a42b8', '#1c0d40'], label, rarity, fire = 0, children }: Props) {
  const bw = label ? label.length * 12.6 + 56 : 0;
  const chip = rarity === 'Legendary' ? '#ffb52e' : rarity === 'Mythic' ? '#ff5a8a' : rarity === 'Epic' ? '#b36bff' : '#4fb8ff';
  const toggle = (a: string, b: string) => (fire ? (fire % 2 ? a : b) : '');

  return (
    <svg viewBox="0 0 400 400" className="block h-full w-full select-none" role="img">
      <defs>
        <radialGradient id={`${id}-bg`} cx="50%" cy="42%" r="72%">
          <stop offset="0" stopColor={bg[0]} />
          <stop offset="0.4" stopColor={bg[1]} />
          <stop offset="1" stopColor={bg[2]} />
        </radialGradient>
        <radialGradient id={`${id}-glow`}>
          <stop offset="0" stopColor={glow} stopOpacity="0.6" />
          <stop offset="0.5" stopColor={glow} stopOpacity="0.18" />
          <stop offset="1" stopColor={glow} stopOpacity="0" />
        </radialGradient>
        <radialGradient id={`${id}-fl`} cx="50%" cy="47%" r="60%">
          <stop offset="0" stopColor="#ffffff" stopOpacity="0.9" />
          <stop offset="0.25" stopColor={glow} stopOpacity="0.75" />
          <stop offset="1" stopColor={glow} stopOpacity="0" />
        </radialGradient>
        <linearGradient id={`${id}-beam`} x1="0" y1="1" x2="0" y2="0">
          <stop offset="0" stopColor={glow} stopOpacity="0.55" />
          <stop offset="0.5" stopColor={glow} stopOpacity="0.15" />
          <stop offset="1" stopColor={glow} stopOpacity="0" />
        </linearGradient>
        <linearGradient id={`${id}-gl`} x1="0" y1="0" x2="1" y2="0">
          <stop offset="0" stopColor="#ffffff" stopOpacity="0" />
          <stop offset="0.5" stopColor="#ffffff" stopOpacity="0.85" />
          <stop offset="1" stopColor="#ffffff" stopOpacity="0" />
        </linearGradient>
        <radialGradient id={`${id}-plat`} cx="50%" cy="40%" r="60%">
          <stop offset="0" stopColor="#3b1f7a" />
          <stop offset="1" stopColor="#170a35" />
        </radialGradient>
        <linearGradient id={`${id}-platedge`} x1="0" y1="0" x2="1" y2="0">
          <stop offset="0" stopColor={glow} stopOpacity="0" />
          <stop offset="0.5" stopColor={glow} stopOpacity="0.95" />
          <stop offset="1" stopColor={glow} stopOpacity="0" />
        </linearGradient>

        {/* game-art look: drop shadow + coloured aura + dark outline */}
        <filter id={`${id}-aura`} x="-30%" y="-30%" width="160%" height="160%">
          <feMorphology in="SourceAlpha" operator="dilate" radius="1.8" result="d1" />
          <feFlood floodColor={outline} result="oc" />
          <feComposite in="oc" in2="d1" operator="in" result="ol" />
          <feMorphology in="SourceAlpha" operator="dilate" radius="4" result="d2" />
          <feGaussianBlur in="d2" stdDeviation="9" result="b2" />
          <feFlood floodColor={glow} floodOpacity="0.7" result="gc" />
          <feComposite in="gc" in2="b2" operator="in" result="aura" />
          <feGaussianBlur in="SourceAlpha" stdDeviation="6" result="sb" />
          <feOffset in="sb" dx="0" dy="12" result="so" />
          <feFlood floodColor="#0b0320" floodOpacity="0.45" result="sc" />
          <feComposite in="sc" in2="so" operator="in" result="shadow" />
          <feMerge>
            <feMergeNode in="shadow" />
            <feMergeNode in="aura" />
            <feMergeNode in="ol" />
            <feMergeNode in="SourceGraphic" />
          </feMerge>
        </filter>
        {/* silhouette (alpha > 0.8 → white) used as gloss mask */}
        <filter id={`${id}-solid`} x="-30%" y="-30%" width="160%" height="160%">
          <feComponentTransfer in="SourceAlpha" result="a">
            <feFuncA type="discrete" tableValues="0 0 0 0 1" />
          </feComponentTransfer>
          <feFlood floodColor="#ffffff" />
          <feComposite in2="a" operator="in" />
        </filter>
        <filter id={`${id}-soft`} x="-60%" y="-60%" width="220%" height="220%">
          <feGaussianBlur stdDeviation="2.2" result="b" />
          <feMerge>
            <feMergeNode in="b" />
            <feMergeNode in="b" />
            <feMergeNode in="SourceGraphic" />
          </feMerge>
        </filter>
        <filter id={`${id}-blur`} x="-50%" y="-50%" width="200%" height="200%">
          <feGaussianBlur stdDeviation="10" />
        </filter>
      </defs>

      {/* ---------- background ---------- */}
      <rect width="400" height="400" fill={`url(#${id}-bg)`} />
      <g className="rays">
        {RAYS.map((d, i) => (
          <path key={i} d={d} fill="#ffffff" opacity={i % 2 ? 0.05 : 0.1} />
        ))}
      </g>
      <circle cx="200" cy="190" r="175" fill={`url(#${id}-glow)`} className="glow-breathe" />
      <path d="M120 356 L280 356 L330 -10 L70 -10Z" fill={`url(#${id}-beam)`} className="beam" />

      {/* platform */}
      <ellipse cx="200" cy="356" rx="150" ry="24" fill={`url(#${id}-plat)`} />
      <ellipse cx="200" cy="352" rx="150" ry="22" fill="none" stroke={`url(#${id}-platedge)`} strokeWidth="2.5" />
      <ellipse cx="200" cy="354" rx="110" ry="14" fill={glow} opacity="0.35" filter={`url(#${id}-blur)`} className="plat-pulse" />
      <ellipse cx="200" cy="356" rx="95" ry="11" fill="#0c0420" opacity="0.5" />

      {SPARKS.map((s, i) =>
        s.star ? (
          <path key={i} d={star4(s.x, s.y, s.s)} fill="#fff6d6" className="twinkle" style={v({ '--delay': `${s.d}s` })} />
        ) : (
          <circle key={i} cx={s.x} cy={s.y} r={s.s / 3} fill="#ffffff" className="twinkle" style={v({ '--delay': `${s.d}s` })} />
        ),
      )}
      {MOTES.map((m, i) => (
        <circle key={`m${i}`} cx={m.x} cy={m.y} r={m.r} fill={mote} className="mote" style={v({ '--delay': `${m.d}s`, '--dur': `${m.dur}s`, '--dx': `${m.dx}px` })} />
      ))}

      {/* ---------- fire: background layer ---------- */}
      {fire > 0 && (
        <g key={`bgfx${fire}`} style={{ pointerEvents: 'none' }}>
          <rect width="400" height="400" fill={`url(#${id}-fl)`} className="overlay-flash" />
          <g className="speedlines">
            {SPEED.map((s, i) => (
              <line key={i} x1={s.x0.toFixed(1)} y1={s.y0.toFixed(1)} x2={s.x1.toFixed(1)} y2={s.y1.toFixed(1)} stroke={i % 3 ? '#ffffff' : glow} strokeWidth={s.w.toFixed(1)} strokeLinecap="round" />
            ))}
          </g>
          <ellipse cx="200" cy="354" rx="40" ry="8" fill="none" stroke={glow} strokeWidth="4" className="fx-ring" style={v({ '--s': 4.2, '--dur': '.9s' })} />
        </g>
      )}

      {/* ---------- weapon ---------- */}
      <g className={toggle('kick-a', 'kick-b')}>{children}</g>

      {/* orbiting sparkles */}
      <g transform="rotate(-14 200 200)" style={{ pointerEvents: 'none' }}>
        {[0, 1, 2].map((i) => (
          <path key={i} d={star4(0, 0, 3.5 + i * 1.2)} fill={i === 1 ? glow : '#ffffff'} opacity="0.95">
            <animateMotion dur={`${7 + i * 1.7}s`} begin={`${-i * 2.3}s`} repeatCount="indefinite" path={ORBIT} />
          </path>
        ))}
      </g>

      {/* ---------- fire: foreground layer ---------- */}
      {fire > 0 && (
        <g key={`fgfx${fire}`} style={{ pointerEvents: 'none' }}>
          <circle cx="200" cy="190" r="30" fill="none" stroke={glow} strokeWidth="7" className="fx-ring" style={v({ '--s': 6.5, '--dur': '.85s' })} />
          <circle cx="200" cy="190" r="30" fill="none" stroke="#ffffff" strokeWidth="2.5" className="fx-ring" style={v({ '--s': 5, '--dur': '.75s', '--delay': '.08s' })} />
          <g transform="translate(200 190)">
            {FX_STARS.map((p, i) => (
              <path key={i} d={star4(0, 0, i % 3 ? 5 : 8)} fill={i % 2 ? '#ffffff' : glow} className="burst" style={burstStyle(p, 1.1)} />
            ))}
          </g>
        </g>
      )}

      {/* rare light sweep */}
      <g opacity="0.16" style={{ pointerEvents: 'none' }}>
        <rect x="-160" y="-60" width="70" height="520" fill="#ffffff" transform="rotate(22 200 200)" className="sweep" />
      </g>

      {/* ---------- banner ---------- */}
      {label && (
        <g className={toggle('pop-a', 'pop-b')}>
          <defs>
            <linearGradient id={`${id}-ban`} x1="0" y1="0" x2="0" y2="1">
              <stop offset="0" stopColor="#4a2a8a" />
              <stop offset="0.5" stopColor="#2a1258" />
              <stop offset="1" stopColor="#160830" />
            </linearGradient>
            <linearGradient id={`${id}-bgold`} x1="0" y1="0" x2="0" y2="1">
              <stop offset="0" stopColor="#fff2b0" />
              <stop offset="0.45" stopColor="#f2b840" />
              <stop offset="1" stopColor="#8a4e0a" />
            </linearGradient>
            <linearGradient id={`${id}-btext`} x1="0" y1="0" x2="0" y2="1">
              <stop offset="0" stopColor="#fffbe0" />
              <stop offset="0.5" stopColor="#ffd24a" />
              <stop offset="1" stopColor="#e88a10" />
            </linearGradient>
            <linearGradient id={`${id}-shine`} x1="0" y1="0" x2="1" y2="0">
              <stop offset="0.38" stopColor="#ffffff" stopOpacity="0" />
              <stop offset="0.5" stopColor="#ffffff" stopOpacity="1" />
              <stop offset="0.62" stopColor="#ffffff" stopOpacity="0" />
              <animateTransform attributeName="gradientTransform" type="translate" values="-1 0;1.2 0;1.2 0" keyTimes="0;0.45;1" dur="3.2s" repeatCount="indefinite" />
            </linearGradient>
          </defs>
          <path d={`M${200 - bw / 2 + 4} 345 L${200 - bw / 2 - 18} 352 L${200 - bw / 2 + 4} 360Z`} fill={`url(#${id}-bgold)`} stroke="#3a1a00" strokeWidth="1.5" />
          <path d={`M${200 + bw / 2 - 4} 345 L${200 + bw / 2 + 18} 352 L${200 + bw / 2 - 4} 360Z`} fill={`url(#${id}-bgold)`} stroke="#3a1a00" strokeWidth="1.5" />
          <rect x={200 - bw / 2} y="334" width={bw} height="36" rx="12" fill={`url(#${id}-ban)`} stroke="#1a0800" strokeWidth="5" />
          <rect x={200 - bw / 2} y="334" width={bw} height="36" rx="12" fill="none" stroke={`url(#${id}-bgold)`} strokeWidth="3" />
          <rect x={200 - bw / 2 + 5} y="339" width={bw - 10} height="26" rx="8" fill="none" stroke={chip} strokeWidth="1.2" opacity="0.75" className="pulse-op" />
          <rect x={200 - bw / 2 + 8} y="340" width={bw - 16} height="7" rx="3.5" fill="#ffffff" opacity="0.1" />
          <path d="M200 324 L209 334 L200 344 L191 334Z" fill={chip} stroke={`url(#${id}-bgold)`} strokeWidth="2.5" strokeLinejoin="round" />
          <path d="M200 327 L204 334 L200 334Z" fill="#ffffff" opacity="0.8" />
          <path d={star4(209, 326, 5)} fill="#ffffff" className="twinkle" />
          {(['stroke', 'shine'] as const).map((k) => (
            <text
              key={k}
              x="200"
              y="359.5"
              textAnchor="middle"
              fontSize="19"
              fontWeight="900"
              letterSpacing="0.8"
              fontFamily="'Arial Black', 'Segoe UI Black', Impact, system-ui, sans-serif"
              fill={k === 'stroke' ? `url(#${id}-btext)` : `url(#${id}-shine)`}
              stroke={k === 'stroke' ? '#2a0e00' : 'none'}
              strokeWidth="4"
              strokeLinejoin="round"
              paintOrder="stroke"
            >
              {label}
            </text>
          ))}
        </g>
      )}
    </svg>
  );
}
