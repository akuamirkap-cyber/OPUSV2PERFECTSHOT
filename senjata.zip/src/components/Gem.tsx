type Props = { cx: number; cy: number; r: number; n?: number; light: string; mid: string; dark: string; rim?: string; rot?: number };

/** Brilliant-cut faceted gem */
export function Gem({ cx, cy, r, n = 8, light, mid, dark, rim = '#ffd36b', rot }: Props) {
  const off = rot ?? 180 / n;
  const P = (rr: number, k: number) => {
    const a = ((k * 360) / n + off) * (Math.PI / 180);
    return [cx + Math.cos(a) * rr, cy + Math.sin(a) * rr];
  };
  const O = Array.from({ length: n }, (_, k) => P(r, k));
  const T = Array.from({ length: n }, (_, k) => P(r * 0.52, k));
  const S = Array.from({ length: n }, (_, k) => P(r * 0.8, k + 0.5));
  const f = (pts: number[][]) => pts.map((p) => p.map((x) => x.toFixed(1)).join(',')).join(' ');
  return (
    <g>
      <polygon points={f(O)} fill={dark} stroke={rim} strokeWidth={r * 0.12} strokeLinejoin="round" />
      {O.map((_, k) => {
        const k2 = (k + 1) % n;
        const lit = k >= n * 0.5 && k < n * 0.9;
        return (
          <g key={k}>
            <polygon points={f([O[k], S[k], T[k]])} fill={lit ? light : mid} opacity={0.95} />
            <polygon points={f([S[k], O[k2], T[k2]])} fill={lit ? mid : dark} opacity={0.95} />
            <polygon points={f([T[k], S[k], T[k2]])} fill={k % 2 ? mid : light} opacity={0.8} />
          </g>
        );
      })}
      <polygon points={f(T)} fill={mid} stroke={light} strokeWidth={r * 0.04} />
      <polygon points={f(T.slice(n * 0.5, n * 0.5 + 3).concat([[cx, cy]]))} fill={light} opacity={0.55} />
      <path d={`M${cx - r * 0.42} ${cy - r * 0.2} L${cx - r * 0.12} ${cy - r * 0.46} L${cx - r * 0.2} ${cy - r * 0.12}Z`} fill="#fff" opacity={0.9} />
      <circle cx={cx + r * 0.3} cy={cy + r * 0.28} r={r * 0.07} fill="#fff" opacity={0.8} />
    </g>
  );
}
