import { useCallback, useEffect, useRef, useState, type ComponentType } from 'react';
import NatureGun from './weapons/NatureGun';
import GoldenKris from './weapons/GoldenKris';
import RubyRevolver from './weapons/RubyRevolver';
import FrostRevolver from './weapons/FrostRevolver';
import AngelPistol from './weapons/AngelPistol';
import SuperSoaker from './weapons/SuperSoaker';
import FireworkLauncher from './weapons/FireworkLauncher';
import PlasmaGun from './weapons/PlasmaGun';
import CardGun from './weapons/CardGun';
import Minigun from './weapons/Minigun';

type Weapon = {
  id: string;
  name: string;
  type: string;
  rarity: 'Rare' | 'Epic' | 'Legendary' | 'Mythic';
  group: 'magic' | 'arcade';
  desc: string;
  effect: string;
  accent: string;
  Comp: ComponentType<{ fire: number; label?: string; rarity?: Weapon['rarity'] }>;
};

const WEAPONS: Weapon[] = [
  {
    id: 'verdant',
    group: 'magic',
    name: 'Verdant Sprout',
    type: 'Pistol Ramuan Alam',
    rarity: 'Epic',
    desc: 'Botol ramuan hijau berbalut sulur hidup, dengan tunas mungil yang tumbuh di atasnya.',
    effect: 'Daun beterbangan & tunas tumbuh',
    accent: 'from-emerald-300 to-lime-400',
    Comp: NatureGun,
  },
  {
    id: 'kris',
    group: 'magic',
    name: 'Keris Mentari',
    type: 'Belati Emas Berlekuk',
    rarity: 'Legendary',
    desc: 'Keris emas berluk lima dengan hulu bulan sabit, rubi kembar, dan zamrud di pangkalnya.',
    effect: 'Tebasan cahaya & cincin berputar',
    accent: 'from-amber-200 to-yellow-500',
    Comp: GoldenKris,
  },
  {
    id: 'ruby',
    group: 'magic',
    name: 'Ruby Royale',
    type: 'Revolver Mahkota',
    rarity: 'Epic',
    desc: 'Revolver merah delima berhias emas, permata rubi di silinder dan mahkota di gagangnya.',
    effect: 'Kilatan rubi & bara api',
    accent: 'from-rose-300 to-red-500',
    Comp: RubyRevolver,
  },
  {
    id: 'frost',
    group: 'magic',
    name: 'Frostbite Crystal',
    type: 'Revolver Kristal Es',
    rarity: 'Legendary',
    desc: 'Revolver putih-perak dengan panel kepingan salju yang bersinar dan kristal es di moncongnya.',
    effect: 'Gelombang beku & kepingan salju',
    accent: 'from-sky-200 to-cyan-400',
    Comp: FrostRevolver,
  },
  {
    id: 'angel',
    group: 'magic',
    name: 'Seraphim Grace',
    type: 'Pistol Malaikat',
    rarity: 'Mythic',
    desc: 'Pistol gading berukir emas dengan sepasang sayap malaikat, halo suci, dan liontin kristal.',
    effect: 'Kepakan sayap & cahaya suci',
    accent: 'from-yellow-100 to-amber-300',
    Comp: AngelPistol,
  },
  {
    id: 'soaker',
    name: 'Super Soaker',
    type: 'Pistol Air Bertekanan',
    rarity: 'Rare',
    group: 'arcade',
    desc: 'Pistol air hijau dengan tangki biru berisi air beriak, pompa oranye, dan pengukur tekanan.',
    effect: 'Pompa ditarik, air bergolak & cipratan',
    accent: 'from-sky-300 to-lime-400',
    Comp: SuperSoaker,
  },
  {
    id: 'firework',
    name: 'Firework Launcher',
    type: 'Peluncur Kembang Api',
    rarity: 'Epic',
    group: 'arcade',
    desc: 'Tabung kembang api berbintang merah-biru dengan cincin emas, sumbu menyala, dan api pendorong.',
    effect: 'Semburan api & ledakan kembang api',
    accent: 'from-orange-300 to-rose-500',
    Comp: FireworkLauncher,
  },
  {
    id: 'plasma',
    name: 'Plasma Volt',
    type: 'Pistol Energi Plasma',
    rarity: 'Epic',
    group: 'arcade',
    desc: 'Badan logam gelap dengan tabung plasma hijau berisi petir dan lampu neon yang berdenyut.',
    effect: 'Petir mengamuk & gelombang energi',
    accent: 'from-lime-300 to-emerald-500',
    Comp: PlasmaGun,
  },
  {
    id: 'card',
    name: 'Card Gun',
    type: 'Pistol Kartu Remi',
    rarity: 'Rare',
    group: 'arcade',
    desc: 'Pistol putih-merah berlis emas dengan kipas kartu di atasnya dan jendela berisi empat kartu.',
    effect: 'Kipas kartu mekar & kartu beterbangan',
    accent: 'from-rose-200 to-red-500',
    Comp: CardGun,
  },
  {
    id: 'minigun',
    name: 'Minigun',
    type: 'Senapan Mesin Putar',
    rarity: 'Epic',
    group: 'arcade',
    desc: 'Enam laras berputar, gagang kontrol di belakang, pegangan angkut, dan moncong menyala.',
    effect: 'Laras berputar kencang & getaran',
    accent: 'from-zinc-200 to-amber-400',
    Comp: Minigun,
  },
];

const SECTIONS = [
  { id: 'magic', title: '✦ Koleksi Ajaib ✦' },
  { id: 'arcade', title: '🎮 Koleksi Arcade' },
] as const;

const RARITY_STYLE: Record<Weapon['rarity'], string> = {
  Rare: 'bg-sky-500/25 text-sky-200 ring-sky-300/50',
  Epic: 'bg-fuchsia-500/25 text-fuchsia-200 ring-fuchsia-300/50',
  Legendary: 'bg-amber-400/20 text-amber-200 ring-amber-300/50',
  Mythic: 'bg-rose-400/20 text-rose-100 ring-rose-200/60',
};

function WeaponCard({ w, index, fire, onUse }: { w: Weapon; index: number; fire: number; onUse: () => void }) {
  const { Comp } = w;
  const ref = useRef<HTMLElement>(null);
  const [visible, setVisible] = useState(true);
  useEffect(() => {
    const el = ref.current;
    if (!el || typeof IntersectionObserver === 'undefined') return;
    const io = new IntersectionObserver(([e]) => setVisible(e.isIntersecting), { rootMargin: '120px' });
    io.observe(el);
    return () => io.disconnect();
  }, []);
  return (
    <article
      ref={ref}
      className={`rare-frame frame-${w.rarity} group relative w-full max-w-[360px] rounded-[26px] p-[3px] transition-transform duration-300 hover:-translate-y-1 ${visible ? '' : 'paused'}`}
    >
      <div className="overflow-hidden rounded-[23px] bg-[#1d0f40]">
        <button
          type="button"
          onClick={onUse}
          aria-label={`Gunakan ${w.name}`}
          className="relative block aspect-square w-full cursor-pointer outline-none focus-visible:ring-4 focus-visible:ring-amber-300"
        >
          <Comp fire={fire} label={w.group === 'arcade' ? w.name.toUpperCase() : undefined} rarity={w.rarity} />
          <span className="absolute left-3 top-3 rounded-full bg-black/40 px-2.5 py-1 text-xs font-bold text-white/80 ring-1 ring-white/20 backdrop-blur">
            {(index + 1) % 10}
          </span>
          <span className={`absolute right-3 top-3 rounded-full px-2.5 py-1 text-[11px] font-extrabold uppercase tracking-wider ring-1 backdrop-blur ${RARITY_STYLE[w.rarity]}`}>
            {w.rarity}
          </span>
        </button>

        <div className="space-y-3 border-t border-amber-400/30 bg-gradient-to-b from-[#2a1658] to-[#170a35] p-5">
          <div>
            <h2 className={`bg-gradient-to-r ${w.accent} bg-clip-text text-2xl font-black tracking-tight text-transparent`}>{w.name}</h2>
            <p className="text-sm font-semibold text-violet-200/80">{w.type}</p>
          </div>
          <p className="text-sm leading-relaxed text-violet-100/70">{w.desc}</p>
          <div className="flex items-center justify-between gap-3">
            <span className="text-xs text-violet-200/60">✦ {w.effect}</span>
            <button
              type="button"
              onClick={onUse}
              className={`shrink-0 rounded-full bg-gradient-to-r ${w.accent} px-5 py-2 text-sm font-extrabold text-[#2a1250] shadow-lg shadow-black/40 transition active:scale-95 hover:brightness-110`}
            >
              Gunakan
            </button>
          </div>
        </div>
      </div>
    </article>
  );
}

export default function App() {
  const [fires, setFires] = useState<Record<string, number>>({});
  const timers = useRef<number[]>([]);

  const use = useCallback((id: string) => {
    setFires((f) => ({ ...f, [id]: (f[id] ?? 0) + 1 }));
  }, []);

  const fireAll = () => {
    WEAPONS.forEach((w, i) => {
      timers.current.push(window.setTimeout(() => use(w.id), i * 140));
    });
  };

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (!/^[0-9]$/.test(e.key)) return;
      const n = e.key === '0' ? 10 : Number(e.key);
      if (n <= WEAPONS.length) use(WEAPONS[n - 1].id);
    };
    window.addEventListener('keydown', onKey);
    const t = timers.current;
    return () => {
      window.removeEventListener('keydown', onKey);
      t.forEach(clearTimeout);
    };
  }, [use]);

  return (
    <div className="min-h-screen overflow-x-hidden bg-[radial-gradient(ellipse_at_top,#4a2a8f_0%,#1f0f45_45%,#0e0622_100%)] text-white">
      <div className="pointer-events-none fixed inset-0 bg-[radial-gradient(circle_at_20%_80%,rgba(255,200,120,0.08),transparent_40%),radial-gradient(circle_at_80%_20%,rgba(120,220,255,0.08),transparent_40%)]" />

      <header className="relative mx-auto max-w-6xl px-6 pb-8 pt-14 text-center">
        <p className="mb-3 text-xs font-bold uppercase tracking-[0.4em] text-amber-300/80">✦ Koleksi Senjata Ajaib ✦</p>
        <h1 className="bg-gradient-to-b from-amber-100 via-amber-300 to-amber-600 bg-clip-text text-5xl font-black tracking-tight text-transparent drop-shadow-[0_4px_20px_rgba(251,191,36,0.35)] sm:text-6xl">
          Arsenal Ajaib
        </h1>
        <p className="mx-auto mt-4 max-w-xl text-violet-200/80">
          Sepuluh senjata SVG 2D dengan animasi saat digunakan — tanpa peluru, hanya kilau sihir. Klik senjatanya, tekan tombol{' '}
          <b className="text-amber-200">Gunakan</b>, atau tekan tombol <kbd className="rounded bg-white/10 px-1.5 py-0.5 text-amber-200">1</kbd>–
          <kbd className="rounded bg-white/10 px-1.5 py-0.5 text-amber-200">0</kbd>.
        </p>
        <button
          type="button"
          onClick={fireAll}
          className="mt-6 rounded-full border border-amber-300/60 bg-amber-400/10 px-6 py-2.5 text-sm font-extrabold text-amber-100 shadow-[0_0_30px_-5px_rgba(251,191,36,0.5)] transition hover:bg-amber-400/20 active:scale-95"
        >
          ✨ Gunakan Semua
        </button>
      </header>

      {SECTIONS.map((sec) => (
        <section key={sec.id} className="relative mx-auto max-w-6xl px-5 pb-16">
          <div className="mb-7 flex items-center gap-4">
            <span className="h-px flex-1 bg-gradient-to-r from-transparent to-amber-300/50" />
            <h2 className="text-center text-2xl font-black tracking-wide text-amber-100 sm:text-3xl">{sec.title}</h2>
            <span className="h-px flex-1 bg-gradient-to-l from-transparent to-amber-300/50" />
          </div>
          <div className="flex flex-wrap justify-center gap-7">
            {WEAPONS.map((w, i) =>
              w.group === sec.id ? <WeaponCard key={w.id} w={w} index={i} fire={fires[w.id] ?? 0} onUse={() => use(w.id)} /> : null,
            )}
          </div>
        </section>
      ))}

      <footer className="relative pb-10 text-center text-xs text-violet-300/50">Dibuat dengan SVG murni + animasi CSS</footer>
    </div>
  );
}
