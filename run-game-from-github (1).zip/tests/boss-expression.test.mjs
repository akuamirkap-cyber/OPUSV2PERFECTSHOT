import assert from 'node:assert/strict';
import { after, test } from 'node:test';
import React from 'react';
import { renderToStaticMarkup } from 'react-dom/server';
import { createServer } from 'vite';

const vite = await createServer({
  configFile: false,
  appType: 'custom',
  logLevel: 'silent',
  optimizeDeps: { noDiscovery: true, include: [] },
  server: { middlewareMode: true },
});
const { HeadArt, HEAD_KINDS } = await vite.ssrLoadModule('/src/games/perfect-shot/play/HeadArt.tsx');
const expression = await vite.ssrLoadModule('/src/games/gunhit/game/bossExpressions.ts');
after(() => vite.close());

test('every boss has a hidden closed-eye expression', () => {
  for (const kind of HEAD_KINDS) {
    const markup = renderToStaticMarkup(React.createElement(HeadArt, { kind }));
    assert.match(markup, /data-boss-eyes="open"/, kind);
    assert.match(markup, /data-boss-eyes="laugh" display="none"/, kind);
    assert.ok(expression.BOSS_EYE_BOXES[kind].length > 0, kind);
  }
});

test('laughing eyes fade in and out with the boss mood', () => {
  assert.equal(expression.bossLaughEyeOpacity(0, 1), 0);
  assert.equal(expression.bossLaughEyeOpacity(0.12, 1), 1);
  assert.equal(expression.bossLaughEyeOpacity(0.8, 0.08), 0.5);
  assert.equal(expression.bossLaughEyeOpacity(1, 0), 0);
});

test('only the eye region is composited over the existing face', () => {
  const calls = [];
  const ctx = {
    globalAlpha: 1,
    save() {},
    restore() {},
    drawImage: (...args) => calls.push(args),
  };
  const image = { naturalWidth: 200, naturalHeight: 200 };
  expression.drawBossLaughEyes(ctx, image, 'pirate', 100, 1);
  assert.equal(calls.length, 1);
  assert.deepEqual(calls[0].slice(1), [107, 92, 23, 21, 7, -8, 23, 21]);
});