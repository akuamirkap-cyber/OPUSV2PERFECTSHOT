import assert from 'node:assert/strict';
import { after, test } from 'node:test';
import { resolve } from 'node:path';
import { createServer } from 'vite';

const vite = await createServer({
  configFile: false,
  appType: 'custom',
  logLevel: 'silent',
  resolve: { alias: { '@': resolve(process.cwd(), 'src') } },
  optimizeDeps: { noDiscovery: true, include: [] },
  server: { middlewareMode: true },
});
const motion = await vite.ssrLoadModule('/src/games/gunhit/zipWeapons/motion.ts');
const visualPose = await vite.ssrLoadModule('/src/games/gunhit/zipWeapons/visualPose.ts');
const art = await vite.ssrLoadModule('/src/games/gunhit/zipWeapons/sharkArt.ts');
const shot = await vite.ssrLoadModule('/src/games/gunhit/game/zipShotFx.ts');
const water = await vite.ssrLoadModule('/src/games/gunhit/game/sharkWaterFx.ts');
const weapons = await vite.ssrLoadModule('/src/games/gunhit/game/weapons.ts');
const fx = await vite.ssrLoadModule('/src/games/gunhit/game/fx.ts');
after(() => vite.close());

test('shark jaw opens on a shot and closes again', () => {
  assert.equal(motion.sharkJawDegrees(Infinity), motion.SHARK_JAW_CLOSED_DEGREES);
  assert.equal(motion.sharkJawDegrees(0), motion.SHARK_JAW_CLOSED_DEGREES);
  assert.equal(motion.sharkJawDegrees(90), 0);
  assert.equal(motion.sharkJawDegrees(120), 0);
  assert.ok(motion.sharkJawDegrees(200) > 0);
  assert.equal(motion.sharkJawDegrees(motion.SHARK_JAW_FIRE_MS), motion.SHARK_JAW_CLOSED_DEGREES);
});

test('shark artwork moves right 3.5 percent without moving the firing lane', () => {
  assert.equal(visualPose.zipGunVisualX('shark', 210, 'portrait'), 203.7);
  assert.equal(visualPose.zipGunVisualX('shark', 238, 'landscape'), 226.6);
  assert.equal(visualPose.zipGunVisualX('diamond', 210, 'portrait'), 210);
  assert.deepEqual(visualPose.sharkGunWorldOffset('shark', 'portrait'), { x: -6.3, y: 0 });
  assert.deepEqual(visualPose.sharkGunWorldOffset('shark', 'landscape'), { x: 0, y: 11.4 });
  assert.deepEqual(visualPose.sharkGunWorldOffset('diamond', 'portrait'), { x: 0, y: 0 });
});

test('the projectile keeps the shark art but removes the grip and orange mouth', () => {
  assert.match(art.sharkGunMarkup, /class="shark-jaw" transform="rotate\(38\)"/);
  assert.match(art.sharkGunMarkup, /class="shark-mouth-light"/);
  assert.match(art.sharkGunMarkup, /translate\(84 50\) rotate\(16\)/);
  assert.doesNotMatch(art.sharkProjectileMarkup, /translate\(84 50\) rotate\(16\)/);
  assert.match(art.sharkProjectileMarkup, /class="shark-jaw" transform="rotate\(10\)"/);
  const mouth = art.sharkGunMarkup.match(/<radialGradient id="sl-mouth"[\s\S]*?<\/radialGradient>/)?.[0];
  assert.ok(mouth);
  assert.doesNotMatch(mouth, /#ffe788|#ffa22a|#ea381c/i);
});

test('Shark speed is doubled without changing damage or other weapons', () => {
  const shark = weapons.getWeapon('shark');
  assert.equal(shark.speed, 3400);
  assert.equal(shark.points, 3);
  assert.equal(water.sharkLayerSpeed('shark', 880), 1760);
  assert.equal(water.sharkLayerSpeed('pistol', 880), 880);
  assert.equal(weapons.getWeapon('pistol').speed, 2700);
});

test('Shark launch, wake, and impact produce water rather than generic chips', () => {
  const particles = [];
  const lights = [];
  const sink = { push: (p) => particles.push(p), light: (...args) => lights.push(args) };
  water.spawnSharkWaterLaunch(sink, 210, 548, 0);
  assert.equal(particles.filter((p) => p.kind === 'waterDrop').length, 12);
  assert.ok(particles.some((p) => p.kind === 'waterSplash'));
  assert.ok(particles.filter((p) => p.kind === 'waterDrop').every((p) => p.vy < 0 && p.unclipped));
  assert.equal(lights.length, 1);
  particles.length = 0;
  water.spawnSharkWaterLaunch(sink, 210, 548, Math.PI / 2);
  assert.ok(particles.filter((p) => p.kind === 'waterDrop').every((p) => p.vx > 0));
  particles.length = 0;
  water.spawnSharkWaterTrail(sink, 210, 400, 0, -3400);
  assert.equal(particles.length, 2);
  assert.ok(particles.every((p) => p.y > 400 && p.unclipped));
  assert.ok(particles.some((p) => p.kind === 'waterDrop'));
  particles.length = 0;
  water.spawnSharkWaterImpact(sink, 210, 250, 0, 1);
  assert.equal(particles.filter((p) => p.kind === 'waterDrop').length, 22);
  assert.equal(particles.filter((p) => p.kind === 'drop').length, 0);
  assert.ok(particles.some((p) => p.kind === 'waterSplash' && p.size === 52));
  assert.ok(particles.every((p) => p.kind !== 'chip'));
});

test('water drops are batched separately for clipped and free effects', () => {
  const positions = [];
  const ctx = { save() {}, restore() {}, beginPath() {}, fill() {}, moveTo() {}, arc() {},
    ellipse: (x) => positions.push(x) };
  const drop = (x, unclipped) => ({ x, y: 0, vx: 0, vy: 1, life: 1, max: 1, size: 2, color: '#ffffff', kind: 'drop', unclipped });
  const particles = [drop(10, false), drop(20, true)];
  fx.drawDropParticles(ctx, particles);
  assert.deepEqual(positions, [10]);
  positions.length = 0;
  fx.drawDropParticles(ctx, particles, true);
  assert.deepEqual(positions, [20]);
});

test('the shark round is twice the old projectile height', () => {
  const previousImage = globalThis.Image;
  globalThis.Image = class {
    complete = true;
    naturalWidth = 307;
    naturalHeight = 556;
  };
  try {
    const draws = [];
    const canvas = { save() {}, restore() {}, drawImage: (...args) => draws.push(args) };
    shot.drawZipCrystalRound(canvas, 53, 0, 0, 0, true, 'shark');
    assert.equal(draws.length, 1);
    assert.equal(draws[0][4], 96);
    assert.ok(draws[0][3] > 52 && draws[0][3] < 54);
  } finally {
    globalThis.Image = previousImage;
  }
});