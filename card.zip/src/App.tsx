import { useCallback, useEffect, useRef, useState } from 'react';
import WeaponStage from './components/WeaponStage';
import CardGun from './components/weapons/CardGun';

const WEAPON = {
  id: 'cardgun',
  name: 'Card Gun',
  subtitle: 'Kocokan kartu · Simbol berkilau',
  rarity: 'Langka',
  accent: '#ff7a8a',
  accentSoft: 'rgba(255,122,138,0.3)',
  plate: '#3b1b6e',
  textColor: '#ffffff',
  duration: 1600,
} as const;

function GlobalDefs() {
  return (
    <svg width="0" height="0" className="absolute" aria-hidden focusable="false">
      <defs>
        <linearGradient id="ui-gold" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#fff6c8" />
          <stop offset="0.4" stopColor="#f5c84a" />
          <stop offset="0.75" stopColor="#b17716" />
          <stop offset="1" stopColor="#efc453" />
        </linearGradient>
        <linearGradient id="ui-shine" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0" stopColor="#fff" stopOpacity="0" />
          <stop offset="0.5" stopColor="#fff" stopOpacity="0.55" />
          <stop offset="1" stopColor="#fff" stopOpacity="0" />
        </linearGradient>
      </defs>
    </svg>
  );
}

function Divider() {
  return (
    <div className="mx-auto mt-5 flex items-center justify-center gap-3" aria-hidden>
      <span className="h-px w-20 bg-gradient-to-r from-transparent to-amber-300/70 sm:w-32" />
      <svg width="22" height="22" viewBox="0 0 22 22">
        <path d="M11,1 L21,11 L11,21 L1,11 Z" fill="url(#ui-gold)" stroke="#5a3a05" strokeWidth="1.2" />
        <path d="M11,5 L17,11 L11,17 L5,11 Z" fill="#fff6c8" opacity="0.8" />
        <path d="M11,8 L14,11 L11,14 L8,11 Z" fill="#f3c74f" />
      </svg>
      <span className="h-px w-20 bg-gradient-to-l from-transparent to-amber-300/70 sm:w-32" />
    </div>
  );
}

export default function App() {
  const [shotId, setShotId] = useState(0);
  const [active, setActive] = useState(false);
  const timer = useRef<number>(0);

  const use = useCallback(() => {
    setShotId((s) => s + 1);
    setActive(true);
    window.clearTimeout(timer.current);
    timer.current = window.setTimeout(() => setActive(false), WEAPON.duration);
  }, []);

  useEffect(() => () => window.clearTimeout(timer.current), []);

  return (
    <div className="page relative min-h-screen text-white">
      <GlobalDefs />
      <div className="ambient" />
      <div className="stars pointer-events-none fixed inset-0" />

      <header className="relative z-10 mx-auto max-w-4xl px-5 pb-6 pt-12 text-center sm:pt-16">
        <p className="mb-4 text-[11px] font-semibold uppercase tracking-[0.45em] text-amber-200/70">Senjata SVG 2D</p>
        <h1 className="font-display text-4xl leading-tight text-transparent sm:text-6xl">
          <span className="title-gold">✦ Card Gun ✦</span>
        </h1>
        <Divider />
        <p className="mx-auto mt-5 max-w-xl text-sm leading-relaxed text-violet-200/75 sm:text-base">
          Senjata kartu yang digambar sepenuhnya dengan SVG vektor. Klik senjata atau tombol
          <span className="text-amber-200"> GUNAKAN </span>
          untuk memicu animasi — kipas kartu mengocok, kartu mengorbit, dan simbol ♠ ♥ ♦ ♣ bermunculan. Tanpa peluru.
        </p>
      </header>

      <main className="relative z-10 mx-auto max-w-7xl px-4 pb-24 pt-4 sm:px-6">
        <div className="mx-auto w-full max-w-[520px]">
          <WeaponStage
            id={WEAPON.id}
            name={WEAPON.name}
            subtitle={WEAPON.subtitle}
            rarity={WEAPON.rarity}
            accent={WEAPON.accent}
            accentSoft={WEAPON.accentSoft}
            plate={WEAPON.plate}
            textColor={WEAPON.textColor}
            theme="arcade"
            active={active}
            shotId={shotId}
            onUse={use}
          >
            <CardGun active={active} shotId={shotId} />
          </WeaponStage>
        </div>

        <div className="mt-8 flex flex-wrap items-center justify-center gap-3">
          <button type="button" onClick={use} className="btn-gold btn-gold-lg">
            ✦ Gunakan Card Gun ✦
          </button>
          <span className="rounded-full border border-violet-300/20 bg-white/5 px-4 py-2 text-xs tracking-wider text-violet-200/70">
            Digunakan {shotId}× · animasi idle + aktif
          </span>
        </div>

        <footer className="mt-16 text-center text-xs tracking-wider text-violet-300/50">
          Semua grafis dirender dari path, gradien & filter SVG — tanpa gambar bitmap.
        </footer>
      </main>
    </div>
  );
}
