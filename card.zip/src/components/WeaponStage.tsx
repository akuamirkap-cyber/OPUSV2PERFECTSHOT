import { useCallback, useRef, type PointerEvent, type ReactNode } from 'react';

export type StageTheme = 'fantasy' | 'arcade';

interface Props {
  id: string;
  name: string;
  subtitle: string;
  rarity: string;
  accent: string;
  accentSoft: string;
  plate: string;
  textColor: string;
  theme: StageTheme;
  active: boolean;
  shotId: number;
  onUse: () => void;
  children: ReactNode;
}

/* ---------- ornate gold corner bracket ---------- */
export function Corner({ pos }: { pos: 'tl' | 'tr' | 'bl' | 'br' }) {
  return (
    <svg viewBox="0 0 48 48" className={`corner corner-${pos}`} aria-hidden>
      <path d="M5,44 L5,15 Q5,5 15,5 L44,5" fill="none" stroke="#3a2205" strokeWidth="5" strokeLinecap="round" opacity="0.7" />
      <path d="M5,44 L5,15 Q5,5 15,5 L44,5" fill="none" stroke="url(#ui-gold)" strokeWidth="3" strokeLinecap="round" />
      <path d="M12,34 L12,18 Q12,12 18,12 L34,12" fill="none" stroke="#fff3b0" strokeWidth="1" opacity="0.5" />
      <path d="M5,5 m0,-5 l5,5 l-5,5 l-5,-5 Z" fill="url(#ui-gold)" stroke="#3a2205" strokeWidth="0.8" />
      <path d="M5,30 l3,-3.5 l-3,-3.5 l-3,3.5 Z M30,5 l3.5,-3 l3.5,3 l-3.5,3 Z" fill="#ffd766" stroke="#3a2205" strokeWidth="0.6" />
      <circle cx="5" cy="44" r="2.2" fill="#ffd766" />
      <circle cx="44" cy="5" r="2.2" fill="#ffd766" />
    </svg>
  );
}

/* ---------- ribbon name banner ---------- */
export function NameBanner({ id, name, plate, textColor, theme }: { id: string; name: string; plate: string; textColor: string; theme: StageTheme }) {
  const upper = name.toUpperCase();
  const font = theme === 'arcade' ? "'Lilita One', 'Arial Black', sans-serif" : "'Cinzel', Georgia, serif";
  const charW = theme === 'arcade' ? 0.58 : 0.68;
  const maxW = 228;
  const fontSize = Math.max(12.5, Math.min(24, maxW / (upper.length * charW)));
  const needsFit = upper.length * charW * fontSize > maxW;
  return (
    <svg viewBox="0 0 320 70" className="w-full drop-shadow-[0_6px_14px_rgba(0,0,0,0.6)]" aria-hidden>
      <defs>
        <linearGradient id={`${id}-bn-plate`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#ffffff" stopOpacity="0.24" />
          <stop offset="0.45" stopColor="#ffffff" stopOpacity="0" />
          <stop offset="1" stopColor="#000000" stopOpacity="0.32" />
        </linearGradient>
        <clipPath id={`${id}-bn-clip`}>
          <rect x="36" y="16" width="248" height="42" rx="7" />
        </clipPath>
      </defs>
      {/* tails */}
      <path d="M8,26 L48,26 L48,62 L8,62 L20,44 Z" fill={plate} stroke="#3a2205" strokeWidth="2" />
      <path d="M312,26 L272,26 L272,62 L312,62 L300,44 Z" fill={plate} stroke="#3a2205" strokeWidth="2" />
      <path d="M8,26 L48,26 L48,62 L8,62 L20,44 Z M312,26 L272,26 L272,62 L312,62 L300,44 Z" fill="#000" opacity="0.28" />
      {/* plate */}
      <rect x="36" y="16" width="248" height="42" rx="7" fill={plate} stroke="#3a2205" strokeWidth="3" />
      <rect x="36" y="16" width="248" height="42" rx="7" fill={`url(#${id}-bn-plate)`} />
      <g clipPath={`url(#${id}-bn-clip)`}>
        <rect x="-60" y="10" width="44" height="54" fill="url(#ui-shine)" className="banner-shine" />
      </g>
      <rect x="36" y="16" width="248" height="42" rx="7" fill="none" stroke="url(#ui-gold)" strokeWidth="2.5" />
      <rect x="41" y="21" width="238" height="32" rx="5" fill="none" stroke="#fff" strokeWidth="0.8" opacity="0.25" />
      {/* side studs */}
      <circle cx="44" cy="37" r="2.6" fill="url(#ui-gold)" stroke="#3a2205" strokeWidth="0.8" />
      <circle cx="276" cy="37" r="2.6" fill="url(#ui-gold)" stroke="#3a2205" strokeWidth="0.8" />
      {/* crest */}
      <path d="M136,13 L150,13 M170,13 L184,13" stroke="#3a2205" strokeWidth="4.5" strokeLinecap="round" opacity="0.6" />
      <path d="M136,13 L150,13 M170,13 L184,13" stroke="url(#ui-gold)" strokeWidth="2.6" strokeLinecap="round" />
      <path d="M160,2 L172,13 L160,24 L148,13 Z" fill="url(#ui-gold)" stroke="#3a2205" strokeWidth="1.5" strokeLinejoin="round" />
      <path d="M160,6 L166,13 L160,20 L154,13 Z" fill="#fff6c8" />
      <path d="M160,9 L163,13 L160,17 L157,13 Z" fill="#f3c74f" />
      <text
        x="160"
        y="45"
        textAnchor="middle"
        fontFamily={font}
        fontSize={fontSize}
        fontWeight={theme === 'arcade' ? 400 : 700}
        fill={textColor}
        stroke="#000"
        strokeWidth="3"
        strokeOpacity="0.4"
        paintOrder="stroke"
        letterSpacing={theme === 'arcade' ? 1 : 0.6}
        textLength={needsFit ? maxW : undefined}
        lengthAdjust={needsFit ? 'spacingAndGlyphs' : undefined}
      >
        {upper}
      </text>
    </svg>
  );
}

export default function WeaponStage({ id, name, subtitle, rarity, accent, accentSoft, plate, textColor, theme, active, shotId, onUse, children }: Props) {
  const cardRef = useRef<HTMLElement>(null);

  const onMove = useCallback((e: PointerEvent<HTMLElement>) => {
    if (e.pointerType === 'touch') return;
    const el = cardRef.current;
    if (!el) return;
    const r = el.getBoundingClientRect();
    const px = (e.clientX - r.left) / r.width;
    const py = (e.clientY - r.top) / r.height;
    el.style.setProperty('--rx', `${((0.5 - py) * 7).toFixed(2)}deg`);
    el.style.setProperty('--ry', `${((px - 0.5) * 9).toFixed(2)}deg`);
    el.style.setProperty('--mx', `${(px * 100).toFixed(1)}%`);
    el.style.setProperty('--my', `${(py * 100).toFixed(1)}%`);
    el.style.setProperty('--gl', '1');
    el.style.setProperty('--ty', '-6px');
  }, []);

  const onLeave = useCallback(() => {
    const el = cardRef.current;
    if (!el) return;
    el.style.setProperty('--rx', '0deg');
    el.style.setProperty('--ry', '0deg');
    el.style.setProperty('--gl', '0');
    el.style.setProperty('--ty', '0px');
  }, []);

  return (
    <article
      ref={cardRef}
      onPointerMove={onMove}
      onPointerLeave={onLeave}
      className="tilt-card group relative flex w-full flex-col overflow-hidden rounded-[28px] border border-amber-200/30 bg-[#1b1340]"
      style={{
        boxShadow: active
          ? `0 0 70px -8px ${accent}, 0 30px 80px -30px rgba(0,0,0,.9), inset 0 0 0 1px rgba(255,215,120,.12)`
          : '0 30px 80px -30px rgba(0,0,0,.9), 0 0 0 1px rgba(255,215,120,.08), inset 0 0 0 1px rgba(255,215,120,.12)',
      }}
    >
      {/* inner frame line + corners */}
      <div className="pointer-events-none absolute inset-[7px] z-20 rounded-[22px] border border-amber-200/25" />
      <Corner pos="tl" />
      <Corner pos="tr" />
      <Corner pos="bl" />
      <Corner pos="br" />

      <button type="button" onClick={onUse} aria-label={`Gunakan ${name}`} className="relative aspect-square w-full cursor-pointer overflow-hidden focus:outline-none">
        <div className="absolute inset-0" style={{ background: 'radial-gradient(circle at 50% 44%, #8a77d4 0%, #5c4a9c 32%, #382969 62%, #1f1748 100%)' }} />
        <div className="rays absolute left-[-60%] top-[-66%] h-[220%] w-[220%]" />
        <div
          className="absolute inset-0 transition-opacity duration-700"
          style={{ background: `radial-gradient(circle at 50% 46%, ${accentSoft} 0%, transparent 48%)`, opacity: active ? 1 : 0.55 }}
        />
        <div className="absolute inset-0" style={{ background: 'radial-gradient(circle at 50% 45%, transparent 36%, rgba(18,10,46,0.82) 100%)' }} />
        {/* top gloss */}
        <div className="pointer-events-none absolute inset-x-0 top-0 h-1/3" style={{ background: 'linear-gradient(180deg, rgba(255,255,255,0.08), transparent)' }} />

        {/* platform */}
        <svg viewBox="0 0 400 120" className="absolute bottom-0 left-0 w-full" aria-hidden>
          <defs>
            <radialGradient id={`${id}-pl-glow`} cx="0.5" cy="0.5" r="0.5">
              <stop offset="0" stopColor="#ffd966" stopOpacity="0.6" />
              <stop offset="1" stopColor="#ffd966" stopOpacity="0" />
            </radialGradient>
            <linearGradient id={`${id}-pl-rim`} x1="0" y1="0" x2="1" y2="0">
              <stop offset="0" stopColor="#b57b16" />
              <stop offset="0.5" stopColor="#ffe28a" />
              <stop offset="1" stopColor="#b57b16" />
            </linearGradient>
            <linearGradient id={`${id}-pl-top`} x1="0" y1="0" x2="0" y2="1">
              <stop offset="0" stopColor="#2b1d5e" />
              <stop offset="1" stopColor="#120b2c" />
            </linearGradient>
          </defs>
          <ellipse cx="200" cy="58" rx="178" ry="32" fill={`url(#${id}-pl-glow)`} />
          <ellipse cx="200" cy="63" rx="142" ry="22" fill="#000" opacity="0.4" />
          <ellipse cx="200" cy="60" rx="142" ry="22" fill="#7a4e10" />
          <ellipse cx="200" cy="56" rx="142" ry="22" fill={`url(#${id}-pl-top)`} stroke={`url(#${id}-pl-rim)`} strokeWidth="4" />
          <ellipse cx="200" cy="56" rx="142" ry="22" fill="none" stroke="#fff3b0" strokeWidth="0.8" opacity="0.5" />
          <ellipse cx="200" cy="58" rx="118" ry="14" fill="#2a1c58" opacity="0.6" />
          <ellipse cx="200" cy="56" rx="118" ry="14" fill="none" stroke="#ffe28a" strokeWidth="0.8" opacity="0.25" />
          <ellipse cx="200" cy="56" rx="80" ry="8" fill="#3b2a70" opacity="0.5" />
          {[66, 334].map((x) => (
            <g key={x}>
              <path d={`M${x},49 l5,7 l-5,7 l-5,-7 Z`} fill="#ffe28a" stroke="#5a3a05" strokeWidth="1" />
              <path d={`M${x},52 l2,4 l-2,4 l-2,-4 Z`} fill="#fff" opacity="0.7" />
            </g>
          ))}
        </svg>

        {/* contact shadow (breathes opposite to float) */}
        <div className="pointer-events-none absolute" style={{ left: '27%', width: '46%', bottom: '12.5%', height: '7%' }}>
          <div
            className="shadow-breathe h-full w-full"
            style={{ background: 'radial-gradient(ellipse at center, rgba(0,0,0,0.55) 0%, rgba(0,0,0,0.25) 42%, transparent 70%)' }}
          />
        </div>

        {/* weapon */}
        <div className="absolute inset-0 p-2 sm:p-3" style={{ transform: 'translateY(-3%)' }}>
          {children}
        </div>

        {active && (
          <div
            key={shotId}
            className="card-flash pointer-events-none absolute inset-0"
            style={{ background: `radial-gradient(circle at 50% 46%, ${accent} 0%, transparent 62%)` }}
          />
        )}

        {/* glare following the cursor */}
        <div className="glare pointer-events-none absolute inset-0" />

        <span
          className="absolute left-10 top-4 z-10 inline-flex items-center gap-1.5 rounded-full border px-3 py-1 text-[10px] font-semibold uppercase tracking-[0.2em] backdrop-blur-sm"
          style={{ borderColor: `${accent}88`, color: accent, background: 'rgba(20,12,50,0.6)', boxShadow: `0 0 14px -4px ${accent}` }}
        >
          <span className="text-[9px]">◆</span>
          {rarity}
        </span>

        <span className="absolute right-10 top-4 z-10 rounded-full bg-black/30 px-3 py-1 text-[10px] uppercase tracking-[0.2em] text-amber-100/70 opacity-0 backdrop-blur-sm transition-opacity duration-300 group-hover:opacity-100">
          Klik untuk gunakan
        </span>

        <div className="pointer-events-none absolute bottom-1 left-1/2 z-10 w-[82%] -translate-x-1/2">
          <NameBanner id={id} name={name} plate={plate} textColor={textColor} theme={theme} />
        </div>
      </button>

      <div className="relative z-10 flex items-center justify-between gap-3 border-t border-amber-200/15 bg-gradient-to-b from-[#1f164a] to-[#130c2e] px-10 py-3.5">
        <p className="min-w-0 truncate text-xs text-violet-200/75">{subtitle}</p>
        <button type="button" onClick={onUse} className={`btn-gold shrink-0 ${active ? 'is-active' : ''}`} style={active ? { boxShadow: `0 0 24px ${accent}` } : undefined}>
          {active ? '✦ AKTIF ✦' : 'GUNAKAN'}
        </button>
      </div>
    </article>
  );
}
