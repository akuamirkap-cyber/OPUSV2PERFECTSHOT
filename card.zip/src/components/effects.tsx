import { mulberry32, starPath } from '../utils/path';

/* ---------- idle sparkle ---------- */
export function Sparkle({
  x,
  y,
  size = 6,
  color = '#fff6c2',
  delay = 0,
  dur = 2.6,
}: {
  x: number;
  y: number;
  size?: number;
  color?: string;
  delay?: number;
  dur?: number;
}) {
  return (
    <g transform={`translate(${x} ${y})`}>
      <path
        d={starPath(size)}
        fill={color}
        className="twinkle"
        style={{ animationDelay: `${delay}s`, animationDuration: `${dur}s` }}
      />
    </g>
  );
}

/* ---------- scattered idle sparkles ---------- */
export function SparkleField({
  seed,
  colors,
  count = 10,
  cx = 200,
  cy = 200,
  radius = 170,
  sizeMin = 3,
  sizeMax = 9,
}: {
  seed: number;
  colors: string[];
  count?: number;
  cx?: number;
  cy?: number;
  radius?: number;
  sizeMin?: number;
  sizeMax?: number;
}) {
  const rand = mulberry32(seed);
  const items = Array.from({ length: count }, (_, i) => {
    const a = rand() * Math.PI * 2;
    const r = radius * (0.45 + rand() * 0.55);
    return {
      x: cx + Math.cos(a) * r,
      y: cy + Math.sin(a) * r * 0.95,
      s: sizeMin + rand() * (sizeMax - sizeMin),
      c: colors[i % colors.length],
      d: rand() * 3,
      dur: 2 + rand() * 2,
    };
  });
  return (
    <g>
      {items.map((it, i) => (
        <Sparkle key={i} x={it.x} y={it.y} size={it.s} color={it.c} delay={it.d} dur={it.dur} />
      ))}
    </g>
  );
}

/* ---------- burst sparkles when weapon is used ---------- */
export function SparkleBurst({
  seed,
  colors,
  cx = 200,
  cy = 200,
  radius = 140,
  count = 14,
  size = 8,
}: {
  seed: number;
  colors: string[];
  cx?: number;
  cy?: number;
  radius?: number;
  count?: number;
  size?: number;
}) {
  const rand = mulberry32(seed * 7919 + 17);
  const items = Array.from({ length: count }, (_, i) => {
    const a = rand() * Math.PI * 2;
    const r = radius * (0.3 + rand() * 0.7);
    return {
      x: cx + Math.cos(a) * r,
      y: cy + Math.sin(a) * r,
      s: size * (0.45 + rand() * 0.9),
      c: colors[i % colors.length],
      d: rand() * 0.4,
    };
  });
  return (
    <g>
      {items.map((it, i) => (
        <g key={i} transform={`translate(${it.x} ${it.y})`}>
          <path d={starPath(it.s)} fill={it.c} className="spark-pop" style={{ animationDelay: `${it.d}s` }} />
        </g>
      ))}
    </g>
  );
}

/* ---------- expanding shock ring ---------- */
export function BurstRing({
  cx = 200,
  cy = 200,
  color,
  r = 60,
  width = 6,
  delay = 0,
}: {
  cx?: number;
  cy?: number;
  color: string;
  r?: number;
  width?: number;
  delay?: number;
}) {
  return (
    <circle
      cx={cx}
      cy={cy}
      r={r}
      fill="none"
      stroke={color}
      strokeWidth={width}
      className="burst-ring"
      style={{ animationDelay: `${delay}s` }}
    />
  );
}
