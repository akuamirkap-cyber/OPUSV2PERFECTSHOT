import type { CSSProperties } from 'react';
import type { WeaponProps } from '../../utils/path';
import { mulberry32 } from '../../utils/path';
import { BurstRing, SparkleBurst, SparkleField } from '../effects';

const GOLD = 'url(#cg-gold)';
const RED = 'url(#cg-red)';
type SuitT = 'heart' | 'spade' | 'diamond' | 'club';
const SUITS: SuitT[] = ['spade', 'heart', 'diamond', 'club'];

function Suit({ type, x = 0, y = 0, s = 1, color }: { type: SuitT; x?: number; y?: number; s?: number; color?: string }) {
  const fill = color ?? (type === 'heart' || type === 'diamond' ? '#d8101f' : '#15131a');
  return (
    <g transform={`translate(${x} ${y}) scale(${s})`} fill={fill}>
      {type === 'heart' && <path d="M0,7 C-7,1 -11,-3 -11,-7 C-11,-11 -5,-13 0,-8 C5,-13 11,-11 11,-7 C11,-3 7,1 0,7 Z" />}
      {type === 'spade' && (
        <>
          <path d="M0,-11 C6,-4 11,-1 11,4 C11,8 5,11 0,6 C-5,11 -11,8 -11,4 C-11,-1 -6,-4 0,-11 Z" />
          <path d="M-4,13 C-1,9 0,6 0,5 C0,6 1,9 4,13 Z" />
        </>
      )}
      {type === 'diamond' && <path d="M0,-12 L9,0 L0,12 L-9,0 Z" />}
      {type === 'club' && (
        <>
          <circle cx="0" cy="-6" r="5" />
          <circle cx="-5.5" cy="2" r="5" />
          <circle cx="5.5" cy="2" r="5" />
          <path d="M-4,13 C-1,8 0,4 0,1 C0,4 1,8 4,13 Z" />
        </>
      )}
    </g>
  );
}

function Card({ type, w = 26, h = 38 }: { type: SuitT; w?: number; h?: number }) {
  return (
    <g>
      <rect x={-w / 2} y={-h / 2} width={w} height={h} rx="3" fill="url(#cg-card)" stroke="#b9b2a4" strokeWidth="1.2" />
      <rect x={-w / 2 + 2} y={-h / 2 + 2} width={w - 4} height={h - 4} rx="2" fill="none" stroke="#e8e2d4" strokeWidth="0.8" />
      <Suit type={type} s={0.62} />
      <Suit type={type} x={-w / 2 + 5} y={-h / 2 + 6} s={0.24} />
      <g transform="rotate(180)">
        <Suit type={type} x={-w / 2 + 5} y={-h / 2 + 6} s={0.24} />
      </g>
    </g>
  );
}

const FAN = [-30, -15, 0, 15, 30];
const FLOATERS: { x: number; y: number; r: number; s: number; t: SuitT; d: number }[] = [
  { x: 58, y: 108, r: -22, s: 1, t: 'heart', d: 0 },
  { x: 338, y: 296, r: 16, s: 0.85, t: 'spade', d: 1.1 },
  { x: 72, y: 300, r: 26, s: 0.75, t: 'diamond', d: 2 },
  { x: 352, y: 92, r: -12, s: 0.8, t: 'club', d: 0.6 },
  { x: 120, y: 56, r: 8, s: 0.6, t: 'diamond', d: 1.5 },
];

export default function CardGun({ active, shotId }: WeaponProps) {
  const rand = mulberry32(shotId * 37 + 9);
  const pops = Array.from({ length: 10 }, (_, i) => {
    const a = rand() * Math.PI * 2;
    const d = 70 + rand() * 90;
    return { x: 200 + Math.cos(a) * d, y: 200 + Math.sin(a) * d * 0.9, t: SUITS[i % 4], s: 0.8 + rand() * 0.7, delay: rand() * 0.4, gold: rand() > 0.6 };
  });

  return (
    <svg viewBox="0 0 400 400" className="h-full w-full overflow-visible" aria-label="Card Gun">
      <defs>
        <linearGradient id="cg-gold" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#fff8d2" />
          <stop offset="0.3" stopColor="#f6cf5a" />
          <stop offset="0.62" stopColor="#c98c1f" />
          <stop offset="0.85" stopColor="#8a5a0e" />
          <stop offset="1" stopColor="#e9bd4c" />
        </linearGradient>
        <linearGradient id="cg-red" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#ff6b6b" />
          <stop offset="0.3" stopColor="#e3192a" />
          <stop offset="0.8" stopColor="#9b0a16" />
          <stop offset="1" stopColor="#c8141f" />
        </linearGradient>
        <linearGradient id="cg-ivory" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#ffffff" />
          <stop offset="0.5" stopColor="#f7f3ea" />
          <stop offset="0.85" stopColor="#d9d1bf" />
          <stop offset="1" stopColor="#ece6d8" />
        </linearGradient>
        <linearGradient id="cg-ivory2" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#ffffff" />
          <stop offset="0.6" stopColor="#f1ece0" />
          <stop offset="1" stopColor="#cdc4ad" />
        </linearGradient>
        <linearGradient id="cg-card" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#ffffff" />
          <stop offset="1" stopColor="#ece7dc" />
        </linearGradient>
        <radialGradient id="cg-aura" cx="0.5" cy="0.5" r="0.5">
          <stop offset="0" stopColor="#ff7a8a" stopOpacity="0.45" />
          <stop offset="0.6" stopColor="#ff3b5c" stopOpacity="0.12" />
          <stop offset="1" stopColor="#ff3b5c" stopOpacity="0" />
        </radialGradient>
        <linearGradient id="cg-streak" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0" stopColor="#ff9a4a" stopOpacity="0" />
          <stop offset="0.35" stopColor="#ffb347" stopOpacity="0.55" />
          <stop offset="0.7" stopColor="#ffd166" stopOpacity="0.7" />
          <stop offset="1" stopColor="#fff2c4" stopOpacity="0.9" />
        </linearGradient>
        <linearGradient id="cg-shine" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0" stopColor="#fff" stopOpacity="0" />
          <stop offset="0.5" stopColor="#fff" stopOpacity="0.95" />
          <stop offset="1" stopColor="#fff" stopOpacity="0" />
        </linearGradient>
        <filter id="cg-glow" x="-40%" y="-40%" width="180%" height="180%">
          <feGaussianBlur stdDeviation="3.5" result="b" />
          <feMerge>
            <feMergeNode in="b" />
            <feMergeNode in="SourceGraphic" />
          </feMerge>
        </filter>
        <filter id="cg-soft" x="-50%" y="-50%" width="200%" height="200%">
          <feGaussianBlur stdDeviation="6" />
        </filter>
        <filter id="cg-shadow" x="-25%" y="-25%" width="150%" height="160%">
          <feGaussianBlur in="SourceAlpha" stdDeviation="6" result="b" />
          <feOffset in="b" dx="4" dy="14" result="o" />
          <feFlood floodColor="#0b0520" floodOpacity="0.5" />
          <feComposite in2="o" operator="in" result="s" />
          <feMerge>
            <feMergeNode in="s" />
            <feMergeNode in="SourceGraphic" />
          </feMerge>
        </filter>
        <clipPath id="cg-body-clip">
          <rect x="96" y="150" width="250" height="62" rx="12" />
        </clipPath>
      </defs>

      <circle cx="200" cy="200" r="155" fill="url(#cg-aura)" className="glow-pulse" />
      {active && <circle key={`bg-${shotId}`} cx="200" cy="200" r="130" fill="#ff7a8a" opacity="0" filter="url(#cg-soft)" className="aura-flash" />}

      {/* card-stream streak behind (like the reference) */}
      <g opacity="0.95" transform="rotate(-14 330 150)">
        <path d="M300,152 L420,96 L420,176 Z" fill="url(#cg-streak)" />
        <path d="M300,152 L420,118 L420,156 Z" fill="#fff" opacity="0.2" />
        {[
          [322, 146, -18, 0.5, 'heart'],
          [344, 136, -26, 0.6, 'spade'],
          [368, 124, -32, 0.72, 'diamond'],
          [350, 160, -12, 0.5, 'club'],
          [382, 148, -22, 0.62, 'heart'],
        ].map(([x, y, r, s, t], i) => (
          <g key={i} transform={`translate(${x} ${y}) rotate(${r}) scale(${s})`}>
            <g className="bob" style={{ animationDelay: `${i * 0.4}s`, animationDuration: '2.6s' }}>
              <Card type={t as SuitT} />
            </g>
          </g>
        ))}
      </g>

      {/* floating cards */}
      {FLOATERS.map((f, i) => (
        <g key={i} transform={`translate(${f.x} ${f.y}) rotate(${f.r}) scale(${f.s})`}>
          <g className="bob" style={{ animationDelay: `${f.d}s` }}>
            <Card type={f.t} />
          </g>
        </g>
      ))}

      <g className="weapon-float">
        <g key={shotId} className={active ? 'recoil' : undefined} style={{ transformOrigin: '200px 220px' }}>
          <g transform="translate(200 216) scale(0.98) rotate(-8) translate(-218 -186)" filter="url(#cg-shadow)">
            {/* ================= CARD MAGAZINE (fan) ================= */}
            <rect x="140" y="134" width="72" height="20" rx="4" fill={RED} stroke="#4a0a10" strokeWidth="2.2" />
            {FAN.map((base, i) => (
              <g key={i} transform={`translate(176 152) rotate(${base})`}>
                <g className={active ? 'riffle' : undefined} style={{ '--spread': `${base * 0.9}deg` } as CSSProperties}>
                  <g transform="translate(0 -30)">
                    <Card type={SUITS[(i + 1) % 4]} w={28} h={42} />
                  </g>
                </g>
              </g>
            ))}
            <rect x="140" y="146" width="72" height="9" rx="2" fill={RED} stroke="#4a0a10" strokeWidth="1.6" />
            <rect x="144" y="148" width="64" height="2" rx="1" fill="#ffb3b3" opacity="0.6" />

            {/* ================= GRIP ================= */}
            <path d="M150,212 C144,234 138,258 144,282 C148,296 180,298 188,284 C188,260 196,236 206,212 Z" fill="url(#cg-ivory2)" stroke="#b3101e" strokeWidth="4" strokeLinejoin="round" />
            <path d="M188,284 C188,260 196,236 206,212 L198,212 C188,236 182,260 182,284 Z" fill="#c9bfa6" opacity="0.4" />
            <path d="M156,222 C150,240 146,258 148,274" stroke="#fff" strokeWidth="2.4" fill="none" opacity="0.7" strokeLinecap="round" />
            <g transform="translate(169 250)">
              <path d="M0,-18 L13,0 L0,18 L-13,0 Z" fill={GOLD} stroke="#5a3a05" strokeWidth="1.2" strokeLinejoin="round" />
              <path d="M0,-13 L9,0 L0,13 L-9,0 Z" fill={RED} stroke="#ffd1d1" strokeWidth="0.6" />
              <path d="M-3,-5 L0,-2" stroke="#fff" strokeWidth="1.4" opacity="0.85" strokeLinecap="round" />
            </g>
            <path d="M144,278 C148,296 180,298 188,284 L186,276 C178,288 154,288 150,274 Z" fill={RED} stroke="#4a0a10" strokeWidth="1.6" strokeLinejoin="round" />
            <path d="M154,286 C164,292 178,290 184,284" stroke="#ffb3b3" strokeWidth="1.2" fill="none" opacity="0.7" />
            {/* trigger guard */}
            <path d="M186,214 C180,246 222,252 234,216" fill="none" stroke="#4a0a10" strokeWidth="9" strokeLinecap="round" />
            <path d="M186,214 C180,246 222,252 234,216" fill="none" stroke={RED} strokeWidth="5.5" strokeLinecap="round" />
            <path d="M204,216 C200,228 204,238 212,236" fill="none" stroke="#5a3a05" strokeWidth="6" strokeLinecap="round" />
            <path d="M204,216 C200,228 204,238 212,236" fill="none" stroke={GOLD} strokeWidth="3.5" strokeLinecap="round" />

            {/* ================= BODY ================= */}
            <rect x="96" y="150" width="250" height="62" rx="12" fill="url(#cg-ivory)" stroke="#b3101e" strokeWidth="4" />
            <rect x="100" y="196" width="242" height="12" rx="5" fill={RED} />
            <path d="M104,194 h236" stroke={GOLD} strokeWidth="1.6" />
            <rect x="106" y="155" width="200" height="5" rx="2.5" fill="#fff" opacity="0.9" />
            {/* suit panel */}
            {SUITS.map((t, i) => {
              const x = 150 + i * 42;
              return (
                <g key={t}>
                  <rect x={x - 15} y="161" width="30" height="30" rx="6" fill="#fff" stroke={GOLD} strokeWidth="2.2" />
                  <rect x={x - 15} y="161" width="30" height="30" rx="6" fill="none" stroke="#5a3a05" strokeWidth="0.6" opacity="0.6" />
                  <Suit type={t} x={x} y={176} s={0.95} />
                </g>
              );
            })}
            {/* studs */}
            {[112, 330].map((x) => (
              <g key={x}>
                <circle cx={x} cy="160" r="3" fill={GOLD} stroke="#5a3a05" strokeWidth="0.8" />
                <circle cx={x} cy="186" r="3" fill={GOLD} stroke="#5a3a05" strokeWidth="0.8" />
              </g>
            ))}
            {/* rear cap */}
            <rect x="86" y="152" width="22" height="58" rx="7" fill={RED} stroke="#4a0a10" strokeWidth="2.2" />
            <path d="M97,164 l5,7 l-5,7 l-5,-7 Z M97,184 l5,7 l-5,7 l-5,-7 Z" fill="#fff" opacity="0.85" />
            {/* front muzzle block */}
            <rect x="330" y="146" width="10" height="70" rx="3" fill={GOLD} stroke="#5a3a05" strokeWidth="1.4" />
            <rect x="338" y="152" width="32" height="58" rx="8" fill={RED} stroke="#4a0a10" strokeWidth="2.2" />
            <rect x="346" y="176" width="28" height="10" rx="3" fill="#2a0508" />
            <rect x="348" y="178" width="20" height="3" rx="1.5" fill="#fff" opacity="0.35" />
            <path d="M342,158 h20" stroke="#ffb3b3" strokeWidth="2" opacity="0.6" strokeLinecap="round" />
            {/* sight */}
            <path d="M298,150 L305,138 L312,150 Z" fill={GOLD} stroke="#5a3a05" strokeWidth="1.2" strokeLinejoin="round" />

            {active && (
              <g clipPath="url(#cg-body-clip)">
                <rect x="70" y="140" width="50" height="80" fill="url(#cg-shine)" className="shine-sweep" />
              </g>
            )}
          </g>
        </g>
      </g>

      <SparkleField seed={81} colors={['#ffd766', '#ffffff', '#ff8a9a']} count={14} sizeMax={9} />

      {active && (
        <g key={`fx-${shotId}`}>
          <BurstRing cx={200} cy={200} color="#ff5c7a" r={50} width={5} />
          <BurstRing cx={200} cy={200} color="#ffd766" r={50} width={2} delay={0.15} />
          {[0, 60, 120, 180, 240, 300].map((a, i) => (
            <g key={a} className="orbit-leaf" style={{ transformOrigin: '200px 200px', animationDelay: `${i * 0.05}s` }}>
              <g transform={`rotate(${a} 200 200) translate(200 95) rotate(${-20 + i * 12}) scale(0.9)`}>
                <Card type={SUITS[i % 4]} />
              </g>
            </g>
          ))}
          {pops.map((p, i) => (
            <g key={`p${i}`} transform={`translate(${p.x} ${p.y}) scale(${p.s})`}>
              <g className="spark-pop" style={{ animationDelay: `${p.delay}s` }} filter="url(#cg-glow)">
                <Suit type={p.t} s={1.2} color={p.gold ? '#ffd766' : undefined} />
              </g>
            </g>
          ))}
          <SparkleBurst seed={shotId} colors={['#ffd766', '#ffffff', '#ff8a9a']} cx={200} cy={200} radius={160} count={16} size={9} />
        </g>
      )}
    </svg>
  );
}
