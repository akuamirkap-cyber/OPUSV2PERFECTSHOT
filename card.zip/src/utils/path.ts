const f = (n: number) => Math.round(n * 10) / 10;

/** 4-pointed sparkle star centered at 0,0 */
export function starPath(size: number, inner = 0.26): string {
  const s = f(size);
  const i = f(size * inner);
  return `M0,${-s} L${i},${-i} L${s},0 L${i},${i} L0,${s} L${-i},${i} L${-s},0 L${-i},${-i} Z`;
}

/** Deterministic PRNG so bursts look random but stable */
export function mulberry32(seed: number) {
  let a = seed >>> 0;
  return function () {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export interface WeaponProps {
  active: boolean;
  shotId: number;
}
