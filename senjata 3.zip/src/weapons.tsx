import type { CSSProperties, ReactNode } from "react";

export type P = { shot: number };

/* ---------------- shared pieces ---------------- */

export function Glow({ id, std = 4 }: { id: string; std?: number }) {
  return (
    <filter id={id} x="-60%" y="-60%" width="220%" height="220%">
      <feGaussianBlur stdDeviation={std} result="b" />
      <feMerge>
        <feMergeNode in="b" />
        <feMergeNode in="b" />
        <feMergeNode in="SourceGraphic" />
      </feMerge>
    </filter>
  );
}

export function DropShadow({ id, dy = 9, op = 0.5, std = 4 }: { id: string; dy?: number; op?: number; std?: number }) {
  return (
    <filter id={id} x="-20%" y="-30%" width="140%" height="180%">
      <feGaussianBlur in="SourceAlpha" stdDeviation={std} />
      <feOffset dx="0" dy={dy} result="o" />
      <feFlood floodColor="#000" floodOpacity={op} />
      <feComposite in2="o" operator="in" result="s" />
      <feMerge>
        <feMergeNode in="s" />
        <feMergeNode in="SourceGraphic" />
      </feMerge>
    </filter>
  );
}

export function Blur({ id, std = 6 }: { id: string; std?: number }) {
  return (
    <filter id={id} x="-50%" y="-300%" width="200%" height="700%">
      <feGaussianBlur stdDeviation={std} />
    </filter>
  );
}

export function ShineGrad({ id }: { id: string }) {
  return (
    <linearGradient id={id} x1="0" y1="0" x2="1" y2="0">
      <stop offset="0" stopColor="#fff" stopOpacity="0" />
      <stop offset=".5" stopColor="#fff" stopOpacity=".75" />
      <stop offset="1" stopColor="#fff" stopOpacity="0" />
    </linearGradient>
  );
}

export function Shine({ clip, grad, h = 190 }: { clip: string; grad: string; h?: number }) {
  return (
    <g clipPath={`url(#${clip})`}>
      <g className="shine">
        <rect x="150" y="15" width="30" height={h} fill={`url(#${grad})`} transform="skewX(-20)" />
        <rect x="192" y="15" width="10" height={h} fill={`url(#${grad})`} transform="skewX(-20)" />
      </g>
    </g>
  );
}

/** Legendary aura: rotating god-rays + orbit rings + travelling spark */
export function Aura({ p, c1, c2 }: { p: string; c1: string; c2: string }) {
  return (
    <g>
      <defs>
        <radialGradient id={`${p}-am`} cx=".5" cy=".5" r=".5">
          <stop offset=".1" stopColor="#fff" />
          <stop offset="1" stopColor="#000" />
        </radialGradient>
        <mask id={`${p}-amask`} maskUnits="userSpaceOnUse" x="0" y="0" width="400" height="230">
          <rect x="0" y="0" width="400" height="230" fill={`url(#${p}-am)`} />
        </mask>
      </defs>
      <g mask={`url(#${p}-amask)`}>
        <g className="god-rays" opacity=".22">
          {Array.from({ length: 14 }).map((_, i) => (
            <polygon key={i} points="200,115 186,-40 214,-40" fill={i % 2 ? c1 : c2} transform={`rotate(${(i * 360) / 14} 200 115)`} />
          ))}
        </g>
      </g>
      <ellipse className="orbit" cx="200" cy="118" rx="184" ry="82" fill="none" stroke={c1} strokeOpacity=".35" strokeWidth="1.5" strokeDasharray="16 10" />
      <ellipse className="orbit orbit-rev" cx="200" cy="118" rx="158" ry="66" fill="none" stroke={c2} strokeOpacity=".3" strokeWidth="1" strokeDasharray="3 9" />
      <g>
        <animateMotion dur="8s" repeatCount="indefinite" path="M16 118 a184 82 0 1 0 368 0 a184 82 0 1 0 -368 0" />
        <circle r="7" fill={c1} opacity=".35" />
        <circle r="2.6" fill="#fff" />
      </g>
    </g>
  );
}

function starPoints(n: number, seed: number) {
  const pts: string[] = [];
  for (let i = 0; i < n * 2; i++) {
    const a = (i / (n * 2)) * Math.PI * 2;
    const f = Math.pow(0.5 + 0.5 * Math.cos(a), 2.5);
    const jitter = 0.75 + 0.5 * Math.abs(Math.sin(i * 12.9898 + seed));
    const r = i % 2 === 0 ? (16 + 58 * f) * jitter : 7 + 6 * f;
    pts.push(`${(Math.cos(a) * r).toFixed(1)},${(Math.sin(a) * r).toFixed(1)}`);
  }
  return pts.join(" ");
}

export function star(cx: number, cy: number, R: number, r: number, n = 5) {
  const pts: string[] = [];
  for (let i = 0; i < n * 2; i++) {
    const a = -Math.PI / 2 + (i * Math.PI) / n;
    const rad = i % 2 === 0 ? R : r;
    pts.push(`${(cx + rad * Math.cos(a)).toFixed(1)},${(cy + rad * Math.sin(a)).toFixed(1)}`);
  }
  return pts.join(" ");
}

function hex(cx: number, cy: number, r: number) {
  return Array.from({ length: 6 })
    .map((_, i) => {
      const a = Math.PI / 6 + (i * Math.PI) / 3;
      return `${(cx + r * Math.cos(a)).toFixed(1)},${(cy + r * Math.sin(a)).toFixed(1)}`;
    })
    .join(" ");
}

export function MuzzleFlash({
  x,
  y,
  c1 = "#ffffff",
  c2,
  c3,
  scale = 1,
  filter,
  sparks = 10,
}: {
  x: number;
  y: number;
  c1?: string;
  c2: string;
  c3: string;
  scale?: number;
  filter: string;
  sparks?: number;
}) {
  return (
    <g transform={`translate(${x} ${y}) scale(${scale})`}>
      <g className="mflash" filter={`url(#${filter})`}>
        <ellipse className="mf-streak" cx="30" rx="80" ry="3" fill={c1} />
        <g className="mf-rays">
          {Array.from({ length: 8 }).map((_, i) => (
            <path key={i} d="M0 0 L60 -4 L72 0 L60 4 Z" fill={i % 2 ? c2 : c1} opacity={0.8} transform={`rotate(${i * 45 - 90})`} />
          ))}
        </g>
        <g className="mf-burst">
          <polygon points={starPoints(9, 1)} fill={c3} opacity={0.85} />
          <polygon points={starPoints(9, 4)} fill={c2} transform="scale(0.7)" />
          <polygon points={starPoints(7, 7)} fill={c1} transform="scale(0.4)" />
        </g>
        <circle className="mf-core" r={13} fill={c1} />
        <circle className="mf-ring" r={18} fill="none" stroke={c2} strokeWidth={3} />
        <ellipse className="mf-ring2" rx={10} ry={22} fill="none" stroke={c1} strokeWidth={2} />
        {Array.from({ length: sparks }).map((_, i) => {
          const a = (i / sparks) * Math.PI * 1.6 - Math.PI * 0.8;
          const d = 45 + (i % 3) * 18;
          return (
            <circle
              key={i}
              className="mf-spark"
              r={i % 2 ? 2 : 3}
              fill={i % 2 ? c1 : c2}
              style={{ "--dx": `${Math.cos(a) * d}px`, "--dy": `${Math.sin(a) * d}px` } as CSSProperties}
            />
          );
        })}
      </g>
    </g>
  );
}

export function Twinkle({ x, y, s = 1, color = "#fff", delay = 0 }: { x: number; y: number; s?: number; color?: string; delay?: number }) {
  return (
    <g transform={`translate(${x} ${y}) scale(${s})`}>
      <path className="twinkle" style={{ animationDelay: `${delay}s` }} d="M0 -10 Q1.3 -1.3 10 0 Q1.3 1.3 0 10 Q-1.3 1.3 -10 0 Q-1.3 -1.3 0 -10Z" fill={color} />
    </g>
  );
}

export function Frame({ shot, children, defs, back }: { shot: number; children: ReactNode; defs: ReactNode; back?: ReactNode }) {
  return (
    <svg viewBox="0 0 400 230" className="h-full w-full overflow-visible">
      <defs>{defs}</defs>
      {back}
      <g className="weapon-float">
        <g key={shot} className={shot ? "is-firing" : ""}>
          {children}
        </g>
      </g>
    </svg>
  );
}

export const OL = { stroke: "#1a0a05", strokeWidth: 3, strokeLinejoin: "round" as const, strokeLinecap: "round" as const };

/* =============================================================
   1. GOLDEN TYCOON — ornate golden revolver
   ============================================================= */
export function GoldenRevolver({ shot }: P) {
  return (
    <Frame
      shot={shot}
      defs={
        <>
          <linearGradient id="gr-gold" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stopColor="#fff9d6" />
            <stop offset=".18" stopColor="#ffe56e" />
            <stop offset=".46" stopColor="#f4b41f" />
            <stop offset=".54" stopColor="#c8841a" />
            <stop offset=".78" stopColor="#ebb93e" />
            <stop offset="1" stopColor="#7a470a" />
          </linearGradient>
          <linearGradient id="gr-goldH" x1="0" y1="0" x2="1" y2="0">
            <stop offset="0" stopColor="#b8730f" />
            <stop offset=".5" stopColor="#ffe98a" />
            <stop offset="1" stopColor="#b8730f" />
          </linearGradient>
          <linearGradient id="gr-maroon" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0" stopColor="#ff4f72" />
            <stop offset=".4" stopColor="#b0123a" />
            <stop offset="1" stopColor="#45051a" />
          </linearGradient>
          <radialGradient id="gr-coin" cx=".35" cy=".3" r=".8">
            <stop offset="0" stopColor="#fffbe0" />
            <stop offset=".4" stopColor="#ffcc33" />
            <stop offset="1" stopColor="#9c5d06" />
          </radialGradient>
          <radialGradient id="gr-gem" cx=".35" cy=".3" r=".8">
            <stop offset="0" stopColor="#ffb3c1" />
            <stop offset=".5" stopColor="#e3123f" />
            <stop offset="1" stopColor="#5c0016" />
          </radialGradient>
          <radialGradient id="gr-em" cx=".35" cy=".3" r=".8">
            <stop offset="0" stopColor="#d2ffe0" />
            <stop offset=".5" stopColor="#12c46a" />
            <stop offset="1" stopColor="#024d2a" />
          </radialGradient>
          <ShineGrad id="gr-shine" />
          <clipPath id="gr-clip">
            <path d="M214 76 L368 70 L368 128 L214 126 Z M140 64 h78 v76 h-78 Z M98 84 L216 84 L216 134 L152 146 L98 114 Z" />
          </clipPath>
          <Glow id="gr-glow" std={5} />
          <Glow id="gr-soft" std={2} />
          <DropShadow id="gr-ds" />
          <Blur id="gr-blur" />
        </>
      }
      back={
        <>
          <Aura p="gr" c1="#ffcc33" c2="#ff5c9a" />
          <ellipse cx="220" cy="112" rx="175" ry="72" fill="#ffc533" opacity=".14" filter="url(#gr-glow)" className="glow-pulse" />
          {[0, -2.4, -4.8].map((b, i) => (
            <g key={i}>
              <animateMotion dur="7.2s" begin={`${b}s`} repeatCount="indefinite" path="M24 118 a176 66 0 1 0 352 0 a176 66 0 1 0 -352 0" />
              <g className="spin-coin" style={{ animationDelay: `${i * 0.4}s` }}>
                <circle r="8" fill="url(#gr-coin)" stroke="#6b3c04" strokeWidth="2" />
                <circle r="5.2" fill="none" stroke="#a86a0a" strokeWidth="1" />
                <text y="3.6" textAnchor="middle" fontSize="9" fontWeight="900" fill="#8a4f05" fontFamily="Lilita One, Impact, sans-serif">
                  $
                </text>
              </g>
            </g>
          ))}
          <Twinkle x={150} y={44} s={1.1} color="#fff3b0" />
          <Twinkle x={342} y={150} s={0.8} color="#ffd84a" delay={0.7} />
          <Twinkle x={54} y={110} s={0.9} color="#fff3b0" delay={1.3} />
          <Twinkle x={284} y={48} s={0.6} color="#fff" delay={0.4} />
          <Twinkle x={246} y={186} s={0.7} color="#ffd84a" delay={1.8} />
        </>
      }
    >
      <g transform="translate(0 -10)">
        <ellipse cx="215" cy="224" rx="140" ry="9" fill="#000" opacity=".45" filter="url(#gr-blur)" />
        <g className="recoil" style={{ transformOrigin: "110px 180px", "--rx": "-14px", "--rr": "-9deg" } as CSSProperties}>
          <g filter="url(#gr-ds)">
            {/* GRIP */}
            <path d="M108 120 L164 134 C152 156 144 176 140 196 Q138 210 124 210 L82 210 Q68 210 70 198 C76 170 92 146 108 120 Z" fill="url(#gr-maroon)" {...OL} />
            <path d="M112 128 C98 150 84 172 80 194" fill="none" stroke="#ff7a97" strokeOpacity=".5" strokeWidth="4" strokeLinecap="round" />
            <path d="M150 140 C140 160 134 178 132 196" fill="none" stroke="#2a0210" strokeOpacity=".5" strokeWidth="5" strokeLinecap="round" />
            <g fill="none" stroke="#ffd84a" strokeWidth="2.5" strokeLinecap="round">
              <path d="M98 196 C96 178 106 166 122 160 C110 170 110 182 118 186 C126 190 132 182 128 174" />
              <path d="M86 200 C88 186 98 176 108 172" />
              <path d="M122 146 C130 138 140 136 150 138" />
              <path d="M118 154 C126 150 132 150 138 152" />
            </g>
            <circle cx="128" cy="174" r="2.5" fill="#ffd84a" />
            <circle cx="108" cy="172" r="2.5" fill="#ffd84a" />
            <circle cx="112" cy="180" r="7" fill="url(#gr-coin)" stroke="#1a0a05" strokeWidth="2" />
            <circle cx="112" cy="180" r="3" fill="#7a470a" opacity=".6" />
            <path d="M68 200 L140 200 L138 214 Q136 220 128 220 L80 220 Q68 220 66 212 Z" fill="url(#gr-gold)" {...OL} />
            <path d="M74 204 L134 204" stroke="#fff" strokeOpacity=".6" strokeWidth="2" strokeLinecap="round" />
            {/* lanyard ring + tassel */}
            <circle cx="74" cy="224" r="5" fill="none" stroke="#1a0a05" strokeWidth="6" />
            <circle cx="74" cy="224" r="5" fill="none" stroke="url(#gr-goldH)" strokeWidth="3" />
            <g className="tassel">
              <path d="M74 229 L72 237" stroke="#1a0a05" strokeWidth="4" strokeLinecap="round" />
              <path d="M74 229 L72 237" stroke="#ffd84a" strokeWidth="2" strokeLinecap="round" />
              <path d="M65 236 L79 236 L81 248 Q72 253 63 248 Z" fill="url(#gr-maroon)" {...OL} strokeWidth={2.5} />
              <path d="M66 239 L78 239" stroke="#ffd84a" strokeWidth="2" strokeLinecap="round" />
              <path d="M68 243 L68 249 M72 243 L72 251 M76 243 L76 249" stroke="#ff7a97" strokeWidth="1" opacity=".6" />
            </g>
            {/* HAMMER */}
            <g className="hammer">
              <path d="M106 88 C104 80 100 76 92 72 C86 68 88 60 96 61 C106 62 114 70 118 84 Z" fill="url(#gr-gold)" {...OL} />
              <path d="M94 66 L98 64 M96 70 L100 68" stroke="#7a470a" strokeWidth="1.5" strokeLinecap="round" />
              <path d="M98 63 C104 65 110 71 113 80" stroke="#fff" strokeOpacity=".6" strokeWidth="1.5" fill="none" strokeLinecap="round" />
            </g>
            {/* FRAME */}
            <path d="M100 84 L216 84 L216 134 L168 140 L152 146 L112 130 L98 114 Z" fill="url(#gr-maroon)" {...OL} />
            <path d="M104 90 L136 90 M104 90 L104 112 L116 124" fill="none" stroke="#ffd84a" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
            <polygon points={star(122, 106, 8, 3.4)} fill="#ffd84a" stroke="#7a470a" strokeWidth=".8" />
            <circle cx="110" cy="94" r="3" fill="url(#gr-coin)" stroke="#1a0a05" strokeWidth="1.5" />
            <circle cx="130" cy="124" r="3" fill="url(#gr-coin)" stroke="#1a0a05" strokeWidth="1.5" />
            <circle cx="110" cy="118" r="2" fill="#ffd84a" />
            {/* TRIGGER GUARD */}
            <path d="M152 140 Q148 178 180 176 Q204 174 204 140" fill="none" stroke="#1a0a05" strokeWidth="11" strokeLinecap="round" />
            <path d="M152 140 Q148 178 180 176 Q204 174 204 140" fill="none" stroke="url(#gr-gold)" strokeWidth="6" strokeLinecap="round" />
            <path d="M174 142 Q170 156 180 164" fill="none" stroke="#1a0a05" strokeWidth="8" strokeLinecap="round" />
            <path d="M174 142 Q170 156 180 164" fill="none" stroke="#ffd84a" strokeWidth="4" strokeLinecap="round" />
            {/* BARREL */}
            <path d="M214 82 L330 84 L330 116 L214 118 Z" fill="url(#gr-gold)" {...OL} />
            <rect x="216" y="75" width="116" height="8" rx="2.5" fill="url(#gr-goldH)" {...OL} strokeWidth={2} />
            <rect x="218" y="68" width="7" height="8" rx="1.5" fill="url(#gr-gold)" {...OL} strokeWidth={2} />
            <path d="M220 89 L326 90" stroke="#fff" strokeOpacity=".75" strokeWidth="3" strokeLinecap="round" />
            <path d="M220 112 L326 112" stroke="#7a470a" strokeOpacity=".6" strokeWidth="2" strokeLinecap="round" />
            <g fill="none" stroke="#8a5207" strokeWidth="2" strokeLinecap="round">
              <path d="M280 100 c5 -8 10 -8 14 0 s9 8 14 0 s9 -8 14 0" />
              <path d="M280 100 c5 8 10 8 14 0 s9 -8 14 0 s9 8 14 0" opacity=".75" />
              <path d="M222 104 c0 -8 10 -8 10 -1 c0 4 -7 4 -7 1 c0 -2 4 -2 4 0" strokeWidth="1.8" />
              <path d="M222 104 c4 4 10 4 12 -2" strokeWidth="1.4" />
            </g>
            {[287, 301, 315].map((x) => (
              <circle key={x} cx={x} cy="100" r="1.8" fill="#fff4b8" />
            ))}
            {[244, 268].map((gx) => (
              <g key={gx}>
                <path d={`M${gx} 88 L${gx + 10} 99 L${gx} 110 L${gx - 10} 99 Z`} fill="url(#gr-gem)" stroke="#1a0a05" strokeWidth="2" strokeLinejoin="round" />
                <path d={`M${gx} 88 L${gx + 10} 99 L${gx - 10} 99 Z`} fill="#ff6b8f" opacity=".5" />
                <path d={`M${gx - 4} 96 L${gx - 1} 92`} stroke="#fff" strokeWidth="2" strokeLinecap="round" />
                <circle cx={gx} cy="99" r="12.5" fill="none" stroke="#fff4b8" strokeWidth=".8" opacity=".6" />
              </g>
            ))}
            <rect x="216" y="116" width="94" height="10" rx="5" fill="url(#gr-gold)" {...OL} strokeWidth={2} />
            <rect x="300" y="113" width="14" height="16" rx="3" fill="url(#gr-goldH)" {...OL} strokeWidth={2} />
            {/* MUZZLE */}
            <path d="M328 76 L350 70 Q368 70 368 88 L368 110 Q368 128 350 128 L328 122 Z" fill="url(#gr-gold)" {...OL} />
            <path d="M340 73 L341 125 M354 71 L355 127" stroke="#7a470a" strokeWidth="2" />
            <path d="M332 80 L362 78" stroke="#fff" strokeOpacity=".6" strokeWidth="2.5" strokeLinecap="round" />
            <circle cx="347.5" cy="99" r="5.5" fill="url(#gr-em)" stroke="#1a0a05" strokeWidth="1.8" />
            <path d="M345 97 L347 95" stroke="#fff" strokeWidth="1.5" strokeLinecap="round" />
            <path d="M352 70 L357 58 L363 70 Z" fill="url(#gr-gold)" {...OL} strokeWidth={2} />
            <ellipse cx="368" cy="99" rx="4" ry="11" fill="#2a1200" />
            <ellipse cx="368" cy="99" rx="2" ry="7" fill="#000" />
            {/* CYLINDER */}
            <rect x="140" y="66" width="78" height="74" rx="13" fill="url(#gr-gold)" {...OL} />
            <path d="M152 70 V136 M206 70 V136" stroke="#7a470a" strokeWidth="2.5" />
            <path d="M146 73 H212" stroke="#fff" strokeOpacity=".7" strokeWidth="3" strokeLinecap="round" />
            <path d="M146 133 H212" stroke="#4a2a04" strokeOpacity=".6" strokeWidth="2.5" strokeLinecap="round" />
            {[
              [147, 74],
              [211, 74],
              [147, 132],
              [211, 132],
            ].map(([x, y]) => (
              <circle key={`${x}${y}`} cx={x} cy={y} r="2.4" fill="#7a470a" stroke="#1a0a05" strokeWidth="1" />
            ))}
            <g className="coin">
              <circle cx="179" cy="103" r="27" fill="url(#gr-coin)" stroke="#5a3204" strokeWidth="3" />
              <circle cx="179" cy="103" r="21" fill="none" stroke="#a86a0a" strokeWidth="2" strokeDasharray="3 2.5" />
              <circle cx="179" cy="103" r="24" fill="none" stroke="#fff3b0" strokeWidth="1" opacity=".6" />
              <text x="180" y="116" textAnchor="middle" fontSize="32" fontWeight="900" fill="#7a470a" fontFamily="Lilita One, Impact, sans-serif">
                $
              </text>
              <text x="178" y="114" textAnchor="middle" fontSize="32" fontWeight="900" fill="#ffe27a" fontFamily="Lilita One, Impact, sans-serif">
                $
              </text>
              <ellipse cx="169" cy="90" rx="8" ry="3.5" fill="#fff" opacity=".7" transform="rotate(-30 169 90)" />
            </g>
            <Shine clip="gr-clip" grad="gr-shine" />
          </g>
          <MuzzleFlash x={370} y={99} c2="#ffd84a" c3="#ff8a00" filter="gr-soft" />
        </g>
      </g>
    </Frame>
  );
}

/* =============================================================
   2. LASER BUSTER — white sci-fi blaster with red cells
   ============================================================= */
export function LaserBuster({ shot }: P) {
  return (
    <Frame
      shot={shot}
      defs={
        <>
          <linearGradient id="lz-body" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stopColor="#ffffff" />
            <stop offset=".3" stopColor="#f3f6fb" />
            <stop offset=".62" stopColor="#c9d1e0" />
            <stop offset=".86" stopColor="#8f99b0" />
            <stop offset="1" stopColor="#525b72" />
          </linearGradient>
          <linearGradient id="lz-dark" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stopColor="#6b7590" />
            <stop offset="1" stopColor="#2b3142" />
          </linearGradient>
          <radialGradient id="lz-red" cx=".35" cy=".3" r=".85">
            <stop offset="0" stopColor="#ffd0d8" />
            <stop offset=".3" stopColor="#ff3a63" />
            <stop offset=".75" stopColor="#c4062f" />
            <stop offset="1" stopColor="#6a0019" />
          </radialGradient>
          <linearGradient id="lz-purple" x1="1" y1="0" x2="0" y2="0">
            <stop offset="0" stopColor="#d26bff" />
            <stop offset=".5" stopColor="#8a2be2" stopOpacity=".6" />
            <stop offset="1" stopColor="#3b0b8a" stopOpacity="0" />
          </linearGradient>
          <radialGradient id="lz-lens" cx=".4" cy=".4" r=".7">
            <stop offset="0" stopColor="#fff" />
            <stop offset=".4" stopColor="#ff6aa0" />
            <stop offset="1" stopColor="#c0003c" />
          </radialGradient>
          <ShineGrad id="lz-shine" />
          <clipPath id="lz-clip">
            <path d="M84 80 Q66 106 84 132 L298 130 Q332 128 356 112 Q366 104 356 98 Q332 82 298 80 Z M150 84 L168 58 L224 58 L236 84 Z M124 124 L172 124 L158 196 Q156 206 144 206 L116 204 Q106 202 110 190 Z" />
          </clipPath>
          <Glow id="lz-glow" std={4} />
          <Glow id="lz-soft" std={2} />
          <DropShadow id="lz-ds" />
          <Blur id="lz-blur" />
        </>
      }
      back={
        <>
          <Aura p="lz" c1="#ff5c9a" c2="#c04bff" />
          <ellipse cx="210" cy="112" rx="165" ry="62" fill="#ff2a6a" opacity=".13" filter="url(#lz-glow)" className="glow-pulse" />
          <Twinkle x={345} y={40} color="#ffb3c8" />
          <Twinkle x={66} y={178} s={0.8} color="#fff" delay={0.8} />
          <Twinkle x={262} y={184} s={0.7} color="#ff7aa8" delay={1.4} />
          <Twinkle x={120} y={50} s={0.6} color="#fff" delay={1.9} />
        </>
      }
    >
      <ellipse cx="205" cy="214" rx="150" ry="9" fill="#000" opacity=".45" filter="url(#lz-blur)" />
      <g transform="rotate(-14 210 115)">
        <g className="recoil" style={{ transformOrigin: "140px 170px", "--rx": "-18px", "--rr": "-5deg" } as CSSProperties}>
          <g filter="url(#lz-glow)">
            <path className="flicker" d="M62 90 L-6 78 Q-18 108 -6 138 L62 124 Z" fill="url(#lz-purple)" />
            <path className="flicker f2" d="M62 96 L12 90 Q4 108 12 126 L62 118 Z" fill="#e8b0ff" opacity=".6" />
          </g>
          <g filter="url(#lz-ds)">
            {/* thruster */}
            <path d="M60 84 Q46 108 60 132 L88 134 L88 82 Z" fill="url(#lz-dark)" stroke="#1a1f33" strokeWidth="3" strokeLinejoin="round" />
            {[94, 106, 118].map((y) => (
              <rect key={y} x="66" y={y} width="16" height="6" rx="3" fill="#c04bff" filter="url(#lz-soft)" className="glow-pulse" />
            ))}
            {/* grip */}
            <path d="M124 124 L172 124 L158 196 Q156 206 144 206 L116 204 Q106 202 110 190 Z" fill="url(#lz-body)" stroke="#1a1f33" strokeWidth="3" strokeLinejoin="round" />
            <path d="M128 130 L166 130" stroke="#fff" strokeWidth="2" opacity=".8" />
            <path d="M130 142 L162 142 L159 156 L127 156 Z" fill="url(#lz-red)" stroke="#1a1f33" strokeWidth="2" />
            <path d="M122 168 L154 168 L152 178 L120 178 Z" fill="#3b4256" />
            <path d="M118 188 L148 188" stroke="#8f99b0" strokeWidth="2" />
            <path d="M172 128 Q178 160 206 154 L210 130" fill="none" stroke="#1a1f33" strokeWidth="9" strokeLinecap="round" />
            <path d="M172 128 Q178 160 206 154 L210 130" fill="none" stroke="#c9d0de" strokeWidth="4" strokeLinecap="round" />
            <path d="M186 132 Q182 144 190 150" fill="none" stroke="#1a1f33" strokeWidth="6" strokeLinecap="round" />
            <path d="M186 132 Q182 144 190 150" fill="none" stroke="#8f99b0" strokeWidth="2.5" strokeLinecap="round" />
            {/* top fin + holo sight */}
            <path d="M150 84 L168 58 L224 58 L236 84 Z" fill="url(#lz-body)" stroke="#1a1f33" strokeWidth="3" strokeLinejoin="round" />
            <path d="M172 64 L218 64" stroke="#ff2a55" strokeWidth="4" strokeLinecap="round" filter="url(#lz-soft)" />
            <path d="M168 72 L224 72" stroke="#8f99b0" strokeWidth="1.5" />
            <rect x="202" y="52" width="8" height="7" fill="#2b3142" stroke="#1a1f33" strokeWidth="1.5" />
            <circle cx="206" cy="47" r="7.5" fill="#2b3142" stroke="#1a1f33" strokeWidth="2.5" />
            <circle cx="206" cy="47" r="4.5" fill="url(#lz-lens)" opacity=".95" />
            <circle className="reticle" cx="206" cy="47" r="2.2" fill="none" stroke="#fff" strokeWidth=".8" />
            <circle cx="206" cy="47" r="1" fill="#fff" />
            {/* body */}
            <path d="M84 80 Q66 106 84 132 L298 130 Q332 128 356 112 Q366 104 356 98 Q332 82 298 80 Z" fill="url(#lz-body)" stroke="#1a1f33" strokeWidth="3.5" strokeLinejoin="round" />
            <path d="M88 114 L298 112 Q326 112 348 108 Q352 112 346 116 Q326 124 298 124 L90 126 Z" fill="#6b7590" opacity=".35" />
            <path d="M92 87 L296 86 Q322 88 346 100" fill="none" stroke="#fff" strokeWidth="3" strokeLinecap="round" />
            <path d="M94 83.5 L296 83 Q322 85 344 96" fill="none" stroke="#ff8ab0" strokeWidth="1.5" strokeLinecap="round" opacity=".7" />
            <path d="M134 84 L132 128 M276 82 L278 128" stroke="#9aa3b8" strokeWidth="1.5" />
            {[92, 294].map((x) => (
              <circle key={x} cx={x} cy="122" r="2.5" fill="#7b849a" />
            ))}
            {/* plasma tube */}
            <rect x="96" y="119" width="194" height="7" rx="3.5" fill="#3a0612" stroke="#1a1f33" strokeWidth="1.5" />
            <path className="flow" d="M99 122.5 H287" stroke="#ff6a8a" strokeWidth="3.5" strokeLinecap="round" strokeDasharray="14 22" filter="url(#lz-soft)" />
            {/* cells */}
            <g className="lz-idle" filter="url(#lz-soft)">
              {[0, 1, 2, 3].map((i) => (
                <g key={i} className="lz-win" style={{ animationDelay: `${i * 0.06}s` }}>
                  <rect x={96 + i * 50} y={90} width={42} height={26} rx={13} fill="url(#lz-red)" stroke="#3a0a14" strokeWidth="2.5" />
                  <rect x={100 + i * 50} y={94} width={34} height={18} rx={9} fill="none" stroke="#ff8aa6" strokeWidth="1" opacity=".6" />
                  <ellipse cx={109 + i * 50} cy={97} rx={7} ry={3} fill="#fff" opacity=".85" />
                  <ellipse cx={128 + i * 50} cy={109} rx={4} ry={2} fill="#fff" opacity=".35" />
                </g>
              ))}
            </g>
            {[138, 188, 238].map((x) => (
              <rect key={x} x={x} y={99} width={8} height={8} rx={2} fill="#3b4256" />
            ))}
            {/* energy coils */}
            {[
              [304, 22],
              [318, 18],
              [332, 13],
            ].map(([cx, ry], i) => (
              <ellipse
                key={cx}
                className="coil"
                style={{ animationDelay: `${i * 0.08}s` }}
                cx={cx}
                cy={106}
                rx={3.8}
                ry={ry}
                fill="url(#lz-red)"
                stroke="#1a1f33"
                strokeWidth="2"
                filter="url(#lz-soft)"
              />
            ))}
            {/* nose */}
            <path d="M342 94 L364 100 L364 110 L342 116 Z" fill="#c9d0de" stroke="#1a1f33" strokeWidth="3" strokeLinejoin="round" />
            <path d="M346 98 L360 102" stroke="#fff" strokeWidth="1.5" />
            <Shine clip="lz-clip" grad="lz-shine" />
          </g>
          <circle cx="367" cy="105" r="12" fill="#ff5c9a" opacity=".35" filter="url(#lz-glow)" className="glow-pulse" />
          <circle cx="367" cy="105" r="7" fill="url(#lz-lens)" filter="url(#lz-soft)" className="fire-glow" />
          <MuzzleFlash x={372} y={105} c2="#ff5c9a" c3="#ff1744" filter="lz-soft" scale={1.05} />
        </g>
      </g>
    </Frame>
  );
}

/* =============================================================
   3. SHADOW STRIKER — black tactical rifle with blue neon
   ============================================================= */
export function ShadowStriker({ shot }: P) {
  const neon = "#3ad7ff";
  const ammo = String(30 - (shot % 30)).padStart(2, "0");
  return (
    <Frame
      shot={shot}
      defs={
        <>
          <linearGradient id="rf-body" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stopColor="#5a6478" />
            <stop offset=".25" stopColor="#2b3242" />
            <stop offset=".7" stopColor="#141824" />
            <stop offset="1" stopColor="#07090f" />
          </linearGradient>
          <linearGradient id="rf-dark" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stopColor="#3a4254" />
            <stop offset="1" stopColor="#0a0c12" />
          </linearGradient>
          <linearGradient id="rf-glass" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0" stopColor="#7fe8ff" stopOpacity=".55" />
            <stop offset="1" stopColor="#0b3a52" stopOpacity=".85" />
          </linearGradient>
          <ShineGrad id="rf-shine" />
          <clipPath id="rf-clip">
            <path d="M117 78 L254 78 L258 112 L212 116 L202 112 L122 112 Z M252 76 L334 78 L334 104 L256 110 Z M28 90 L98 86 L102 112 L74 118 L48 144 Q40 150 32 144 Q26 138 28 126 Z" />
          </clipPath>
          <Glow id="rf-glow" std={3} />
          <Glow id="rf-big" std={8} />
          <DropShadow id="rf-ds" />
          <Blur id="rf-blur" />
        </>
      }
      back={
        <>
          <Aura p="rf" c1="#8b5cff" c2="#3ad7ff" />
          <ellipse cx="200" cy="115" rx="155" ry="82" fill="#8b5cff" opacity=".18" filter="url(#rf-big)" className="glow-pulse" />
          {[
            [60, 50],
            [340, 182],
            [110, 192],
            [300, 30],
            [30, 170],
            [370, 60],
          ].map(([x, y], i) => (
            <g key={i} transform={`translate(${x} ${y})`}>
              <path className="twinkle" style={{ animationDelay: `${i * 0.45}s` }} d="M0 -7 L4.5 0 L0 7 L-4.5 0 Z" fill="#7fe8ff" />
            </g>
          ))}
        </>
      }
    >
      <ellipse cx="200" cy="214" rx="150" ry="9" fill="#000" opacity=".5" filter="url(#rf-blur)" />
      <g transform="rotate(-12 200 115)">
        <g className="recoil" style={{ transformOrigin: "60px 115px", "--rx": "-12px", "--rr": "-4deg" } as CSSProperties}>
          <g filter="url(#rf-ds)">
            <g stroke="#04050a" strokeWidth="2.5" strokeLinejoin="round">
              <path d="M28 90 L98 86 L102 112 L74 118 L48 144 Q40 150 32 144 Q26 138 28 126 Z" fill="url(#rf-body)" />
              <path d="M50 104 L86 100 L84 108 L62 112 Z" fill="#05060a" />
              <rect x="20" y="86" width="12" height="64" rx="4" fill="#111421" />
              <rect x="92" y="88" width="32" height="15" fill="url(#rf-dark)" />
              <path d="M117 78 L254 78 L258 112 L212 116 L202 112 L122 112 Z" fill="url(#rf-body)" />
              <rect x="122" y="70" width="198" height="9" fill="#1d2230" />
              <rect x="112" y="72" width="16" height="6" rx="1" fill="#0a0c12" />
              <rect x="174" y="84" width="30" height="11" rx="2" fill="#05060a" />
              <rect className="slide" x="178" y="86" width="22" height="7" rx="1" fill="#6c768f" strokeWidth={1} />
              <path d="M252 76 L334 78 L334 104 L256 110 Z" fill="url(#rf-body)" />
              {/* holo sight */}
              <path d="M150 70 L150 50 Q150 44 156 44 L192 44 Q198 44 198 50 L198 70 Z" fill="url(#rf-dark)" />
              <rect x="162" y="38" width="22" height="8" rx="2" fill="#262c3a" />
              {/* front post */}
              <path d="M316 70 L320 58 L332 58 L335 70 Z" fill="url(#rf-dark)" />
              <rect x="320" y="50" width="11" height="9" rx="2" fill="#e8e04a" />
              {/* barrel + suppressor */}
              <rect x="332" y="84" width="24" height="13" fill="#1a1e2a" />
              <rect x="352" y="78" width="44" height="25" rx="5" fill="url(#rf-dark)" />
              {/* light + foregrip */}
              <rect x="258" y="106" width="42" height="13" rx="6" fill="url(#rf-dark)" />
              <path d="M304 106 L322 106 L330 136 Q330 142 324 142 L314 142 L304 112 Z" fill="url(#rf-body)" />
              {/* grip + mag */}
              <path d="M140 110 L172 110 L162 170 Q160 177 151 177 L134 175 Q127 173 129 166 Z" fill="url(#rf-body)" />
              <path d="M207 112 L236 112 L244 170 Q246 179 235 179 L217 181 Q208 181 208 172 Z" fill="url(#rf-body)" />
            </g>
            {/* sight glass + reticle */}
            <rect x="156" y="48" width="36" height="19" rx="2" fill="url(#rf-glass)" stroke={neon} strokeWidth=".9" />
            <path d="M158 50 L172 50" stroke="#fff" strokeOpacity=".5" strokeWidth="1" />
            <g className="reticle">
              <circle cx="174" cy="57.5" r="5.5" fill="none" stroke={neon} strokeWidth="1.3" />
              <path d="M174 50 V53 M174 62 V65 M166.5 57.5 H169.5 M178.5 57.5 H181.5" stroke={neon} strokeWidth="1.2" />
            </g>
            <circle cx="174" cy="57.5" r="1.7" fill="#ff3050" filter="url(#rf-glow)" className="glow-pulse" />
            {/* trigger */}
            <path d="M172 114 Q174 134 200 132 L204 116" fill="none" stroke="#04050a" strokeWidth="7" strokeLinecap="round" />
            <path d="M172 114 Q174 134 200 132 L204 116" fill="none" stroke="#2a3040" strokeWidth="3.5" strokeLinecap="round" />
            <path d="M184 116 Q182 124 188 128" fill="none" stroke="#6c768f" strokeWidth="2.5" strokeLinecap="round" />
            {/* rail notches */}
            {Array.from({ length: 23 }).map((_, i) => (
              <rect key={i} x={126 + i * 8.3} y={72} width={4} height={4} fill="#0a0c12" />
            ))}
            {/* handguard hex */}
            {Array.from({ length: 11 }).map((_, i) => (
              <polygon key={`a${i}`} points={hex(262 + i * 6.6, 85, 3)} fill="#0a0c12" stroke="#3a4254" strokeWidth=".6" />
            ))}
            {Array.from({ length: 10 }).map((_, i) => (
              <polygon key={`b${i}`} points={hex(265.3 + i * 6.6, 91, 3)} fill="#0a0c12" stroke="#3a4254" strokeWidth=".6" />
            ))}
            {/* suppressor vents */}
            {[360, 369, 378, 387].map((x) => (
              <rect key={x} x={x} y={82} width={4} height={17} rx={2} fill="#04050a" />
            ))}
            <path d="M354 80 L394 80" stroke="#fff" strokeOpacity=".2" strokeWidth="1.5" />
            {/* mag ribs & grip texture */}
            <path d="M214 124 L238 124 M216 136 L240 136 M218 148 L242 148 M220 160 L243 160" stroke="#04050a" strokeWidth="2" />
            <path d="M136 150 L158 152 M135 158 L156 160" stroke="#04050a" strokeWidth="2" />
            {/* ammo counter */}
            <rect x="212" y="83" width="34" height="13" rx="2" fill="#03060b" stroke={neon} strokeOpacity=".6" strokeWidth="1" />
            <text className="ammo" x="229" y="93.5" textAnchor="middle" fontSize="10" fontWeight="700" fill="#7fe8ff" fontFamily="ui-monospace, Menlo, monospace" filter="url(#rf-glow)">
              {ammo}
            </text>
            {/* highlights / rim light */}
            <path d="M122 80.5 L252 80.5 M256 79 L332 80" stroke={neon} strokeOpacity=".35" strokeWidth="1.5" />
            <path d="M32 92 L96 89" stroke="#fff" strokeOpacity=".18" strokeWidth="2" />
            <path d="M126 106 L250 106" stroke="#000" strokeOpacity=".5" strokeWidth="2" />
            {/* circuit traces */}
            <path className="trace" d="M126 109 H256 M258 107 L330 102" fill="none" stroke={neon} strokeWidth="1.2" strokeDasharray="8 60" opacity=".8" />
            {/* neon */}
            <g className="neon" filter="url(#rf-glow)">
              <g className="neon-fire">
                <path d="M130 100 L198 100 M214 100 L248 100" stroke={neon} strokeWidth="3" strokeLinecap="round" />
                <path d="M130 100 L198 100 M214 100 L248 100" stroke="#fff" strokeWidth="1" strokeLinecap="round" opacity=".8" />
                <rect x="264" y="97" width="24" height="6" rx="3" fill={neon} />
                <rect x="296" y="97" width="26" height="6" rx="3" fill={neon} />
                <path d="M42 134 L68 112" stroke={neon} strokeWidth="3" strokeLinecap="round" />
                <path d="M148 124 L142 160" stroke={neon} strokeWidth="2.5" strokeLinecap="round" />
                <path d="M218 124 L224 166" stroke={neon} strokeWidth="2.5" strokeLinecap="round" />
                <path d="M312 114 L320 134" stroke={neon} strokeWidth="2" strokeLinecap="round" />
                <circle cx="300" cy="112.5" r="4.5" fill="#bdf4ff" />
                <path d="M62 96 L82 95" stroke={neon} strokeWidth="2" strokeLinecap="round" />
                {[360, 369, 378, 387].map((x) => (
                  <rect key={x} x={x + 1.25} y={85} width={1.5} height={11} fill={neon} opacity=".9" />
                ))}
              </g>
            </g>
            <circle cx="325" cy="54" r="2.5" fill="#fffbb0" filter="url(#rf-glow)" />
            <Shine clip="rf-clip" grad="rf-shine" />
          </g>
          <circle className="smoke" cx="396" cy="78" r="10" fill="#9fb4d8" style={{ animationDelay: ".1s" }} />
          <circle className="smoke" cx="388" cy="74" r="7" fill="#9fb4d8" style={{ animationDelay: ".2s" }} />
          <MuzzleFlash x={398} y={90} c2="#7fe8ff" c3="#1d7bff" filter="rf-glow" scale={1.1} />
        </g>
      </g>
    </Frame>
  );
}

/* =============================================================
   4. BANANA BLASTER — golden banana cannon
   ============================================================= */
export function BananaBlaster({ shot }: P) {
  return (
    <Frame
      shot={shot}
      defs={
        <>
          <linearGradient id="bn-body" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0" stopColor="#fff7bd" />
            <stop offset=".25" stopColor="#ffdd33" />
            <stop offset=".6" stopColor="#f5b400" />
            <stop offset=".85" stopColor="#d98a00" />
            <stop offset="1" stopColor="#9a5a00" />
          </linearGradient>
          <linearGradient id="bn-silver" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stopColor="#ffffff" />
            <stop offset=".4" stopColor="#dde3ee" />
            <stop offset=".75" stopColor="#8f9ab0" />
            <stop offset="1" stopColor="#434b5e" />
          </linearGradient>
          <linearGradient id="bn-stem" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0" stopColor="#a86e2a" />
            <stop offset="1" stopColor="#3f2208" />
          </linearGradient>
          <radialGradient id="bn-bore" cx=".5" cy=".5" r=".5">
            <stop offset="0" stopColor="#fffbe0" />
            <stop offset=".45" stopColor="#ffd000" />
            <stop offset=".8" stopColor="#8a4d00" />
            <stop offset="1" stopColor="#2a1600" />
          </radialGradient>
          <radialGradient id="bn-gem" cx=".35" cy=".3" r=".8">
            <stop offset="0" stopColor="#fff9c4" />
            <stop offset=".4" stopColor="#ffcc00" />
            <stop offset="1" stopColor="#9a5a00" />
          </radialGradient>
          <radialGradient id="bn-ruby" cx=".35" cy=".3" r=".8">
            <stop offset="0" stopColor="#ffb3c1" />
            <stop offset=".5" stopColor="#e3123f" />
            <stop offset="1" stopColor="#5c0016" />
          </radialGradient>
          <linearGradient id="bn-leaf" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stopColor="#fff2a0" />
            <stop offset="1" stopColor="#f5a800" />
          </linearGradient>
          <linearGradient id="bn-peel" x1="0" y1="0" x2="1" y2="0">
            <stop offset="0" stopColor="#fff6c8" />
            <stop offset="1" stopColor="#ffd92e" />
          </linearGradient>
          <ShineGrad id="bn-shine" />
          <clipPath id="bn-clip">
            <path d="M86 208 C50 140 128 68 292 62 L300 100 C172 102 122 140 120 208 Z" />
          </clipPath>
          <Glow id="bn-glow" std={6} />
          <Glow id="bn-soft" std={2} />
          <DropShadow id="bn-ds" />
          <Blur id="bn-blur" />
        </>
      }
      back={
        <>
          <Aura p="bn" c1="#ffcc00" c2="#c58bff" />
          <circle cx="200" cy="120" r="112" fill="#ffcc00" opacity=".14" filter="url(#bn-glow)" className="glow-pulse" />
          {[0, -3.6].map((b, i) => (
            <g key={i}>
              <animateMotion dur="7.2s" begin={`${b}s`} repeatCount="indefinite" path="M24 118 a176 66 0 1 0 352 0 a176 66 0 1 0 -352 0" rotate="auto" />
              <path d="M-11 5 Q-2 -9 11 1 Q0 1 -11 5 Z" fill="url(#bn-body)" stroke="#5a3300" strokeWidth="1.5" strokeLinejoin="round" />
              <path d="M-7 3 Q0 -4 8 1" stroke="#fff6c8" strokeWidth="1.2" fill="none" strokeLinecap="round" />
            </g>
          ))}
          <Twinkle x={76} y={90} color="#fff6b0" />
          <Twinkle x={236} y={174} s={0.8} color="#ffd92e" delay={0.9} />
          <Twinkle x={252} y={40} s={0.6} color="#fff" delay={1.5} />
          <Twinkle x={330} y={150} s={0.7} color="#fff6b0" delay={2} />
        </>
      }
    >
      <ellipse cx="200" cy="218" rx="110" ry="9" fill="#000" opacity=".45" filter="url(#bn-blur)" />
      <g className="recoil" style={{ transformOrigin: "100px 205px", "--rx": "-10px", "--ry": "6px", "--rr": "-6deg" } as CSSProperties}>
        <g className="squash">
          <g filter="url(#bn-ds)">
            <path d="M86 208 C50 140 128 68 292 62 L300 100 C172 102 122 140 120 208 Z" fill="url(#bn-body)" stroke="#5a3300" strokeWidth="3.5" strokeLinejoin="round" />
            <path d="M96 200 C70 142 138 82 288 72" fill="none" stroke="#fff7bd" strokeWidth="7" strokeLinecap="round" opacity=".9" />
            <path d="M100 196 C78 146 142 88 286 78" fill="none" stroke="#fff" strokeWidth="2" strokeLinecap="round" opacity=".8" />
            <path d="M106 206 C92 150 150 96 294 86" fill="none" stroke="#d98c00" strokeWidth="2" opacity=".8" />
            <path d="M113 208 C110 158 152 110 297 94" fill="none" stroke="#9a5a00" strokeWidth="2.5" opacity=".55" />
            <path d="M118 206 C118 160 160 114 298 98" fill="none" stroke="#7a4300" strokeWidth="4" opacity=".35" strokeLinecap="round" />
            {[
              [96, 190],
              [90, 176],
              [102, 172],
              [94, 160],
              [110, 186],
              [86, 196],
            ].map(([x, y], i) => (
              <ellipse key={i} cx={x} cy={y} rx="2.2" ry="1.4" fill="#7a4300" opacity=".45" transform={`rotate(-50 ${x} ${y})`} />
            ))}
            <path d="M86 208 L120 206 L114 224 Q102 230 92 224 Z" fill="url(#bn-stem)" stroke="#2e1a05" strokeWidth="3" strokeLinejoin="round" />
            <path d="M92 212 L112 211" stroke="#c98a3a" strokeWidth="2" strokeLinecap="round" opacity=".7" />
            {/* trigger guard */}
            <path d="M148 128 Q142 164 172 162 Q192 160 190 134" fill="none" stroke="#2a2f3d" strokeWidth="9" strokeLinecap="round" />
            <path d="M148 128 Q142 164 172 162 Q192 160 190 134" fill="none" stroke="url(#bn-silver)" strokeWidth="4.5" strokeLinecap="round" />
            <path d="M166 132 Q162 146 170 152" fill="none" stroke="#2a2f3d" strokeWidth="6" strokeLinecap="round" />
            <path d="M166 132 Q162 146 170 152" fill="none" stroke="#dde3ee" strokeWidth="2.5" strokeLinecap="round" />
            {/* clamp */}
            <path d="M126 86 Q164 94 190 126" fill="none" stroke="#2a2f3d" strokeWidth="26" strokeLinecap="round" />
            <path d="M126 86 Q164 94 190 126" fill="none" stroke="url(#bn-silver)" strokeWidth="19" strokeLinecap="round" />
            <path d="M128 81 Q164 86 186 114" fill="none" stroke="#fff" strokeWidth="3" strokeLinecap="round" opacity=".9" />
            <path d="M132 92 Q164 102 186 130" fill="none" stroke="#434b5e" strokeWidth="2" strokeLinecap="round" opacity=".6" />
            {[
              [136, 86],
              [182, 122],
            ].map(([x, y]) => (
              <circle key={x} cx={x} cy={y} r="3" fill="#6b7488" stroke="#2a2f3d" strokeWidth="1.5" />
            ))}
            <path d="M116 122 Q142 110 154 130 Q140 146 122 140 Z" fill="url(#bn-silver)" stroke="#2a2f3d" strokeWidth="3" strokeLinejoin="round" />
            <path d="M124 126 Q138 120 146 128" fill="none" stroke="#fff" strokeWidth="2" strokeLinecap="round" opacity=".8" />
            <circle cx="160" cy="106" r="7.5" fill="url(#bn-gem)" stroke="#5a3300" strokeWidth="2" filter="url(#bn-soft)" className="fire-glow" />
            <circle cx="158" cy="104" r="2" fill="#fff" opacity=".9" />
            {/* jeweled band near muzzle */}
            <path d="M244 66 L254 106" stroke="#2a2f3d" strokeWidth="13" strokeLinecap="round" />
            <path d="M244 66 L254 106" stroke="url(#bn-silver)" strokeWidth="8" strokeLinecap="round" />
            <path d="M243 68 L251 100" stroke="#fff" strokeWidth="1.5" strokeLinecap="round" opacity=".8" />
            <path d="M249 80 L255 86 L249 92 L243 86 Z" fill="url(#bn-ruby)" stroke="#2a2f3d" strokeWidth="1.5" strokeLinejoin="round" />
            <path d="M246 84 L248 82" stroke="#fff" strokeWidth="1.2" strokeLinecap="round" />
            <Shine clip="bn-clip" grad="bn-shine" />
            {/* muzzle */}
            <g transform="rotate(-6 300 82)">
              {/* peel petals */}
              <g transform="translate(288 66) rotate(22)">
                <g className="petal">
                  <path d="M0 -3 C-14 -10 -30 -9 -44 2 C-32 0 -18 2 0 7 Z" fill="url(#bn-peel)" stroke="#5a3300" strokeWidth="1.8" strokeLinejoin="round" />
                  <path d="M-6 0 C-18 -4 -30 -4 -38 1" fill="none" stroke="#fff" strokeWidth="1" opacity=".7" />
                </g>
              </g>
              <g transform="translate(298 98) scale(1 -1) rotate(22)">
                <g className="petal">
                  <path d="M0 -3 C-14 -10 -30 -9 -44 2 C-32 0 -18 2 0 7 Z" fill="url(#bn-peel)" stroke="#5a3300" strokeWidth="1.8" strokeLinejoin="round" />
                  <path d="M-6 0 C-18 -4 -30 -4 -38 1" fill="none" stroke="#fff" strokeWidth="1" opacity=".7" />
                </g>
              </g>
              <rect x="284" y="60" width="46" height="42" rx="7" fill="url(#bn-silver)" stroke="#2a2f3d" strokeWidth="3" />
              <path d="M298 60 V102 M310 60 V102" stroke="#6b7488" strokeWidth="2.5" />
              <path d="M299.5 60 V102 M311.5 60 V102" stroke="#fff" strokeWidth="1" opacity=".6" />
              <rect x="326" y="55" width="18" height="52" rx="5" fill="url(#bn-silver)" stroke="#2a2f3d" strokeWidth="3" />
              <path d="M288 66 H322 M330 60 H340" stroke="#fff" strokeWidth="3" strokeLinecap="round" />
              <circle cx="291" cy="96" r="2" fill="#434b5e" />
              <circle cx="322" cy="96" r="2" fill="#434b5e" />
              {/* leaf sight */}
              <path d="M304 60 C302 50 308 42 316 40 C316 50 312 58 304 60 Z" fill="url(#bn-leaf)" stroke="#8a5200" strokeWidth="1.8" strokeLinejoin="round" />
              <path d="M305 58 C308 52 311 47 315 42" stroke="#fff" strokeWidth="1" fill="none" opacity=".8" />
              <ellipse cx="344" cy="81" rx="5" ry="19" fill="#2a1600" />
              <ellipse cx="344" cy="81" rx="3.5" ry="14" fill="url(#bn-bore)" filter="url(#bn-soft)" className="glow-pulse" />
            </g>
          </g>
        </g>
        <MuzzleFlash x={348} y={80} c2="#ffe14d" c3="#ff9500" filter="bn-soft" scale={1.1} />
      </g>
      <g className="leaf-wrap">
        {[
          [372, 52, 0],
          [388, 96, 0.6],
          [356, 120, 1.2],
          [394, 66, 1.8],
          [340, 40, 0.3],
          [376, 140, 0.9],
        ].map(([x, y, d], i) => (
          <g key={i} transform={`translate(${x} ${y}) rotate(${i * 50})`}>
            <path className="leaf" style={{ animationDelay: `${d}s` }} d="M0 -9 Q8 0 0 9 Q-8 0 0 -9Z" fill="url(#bn-leaf)" stroke="#a86200" strokeWidth="1" />
          </g>
        ))}
      </g>
    </Frame>
  );
}

/* =============================================================
   5. STORM CALLER — lightning crystal cannon
   ============================================================= */
function Bolt({ d, delay, cls = "bolt" }: { d: string; delay: string; cls?: string }) {
  return (
    <g className={cls} style={{ animationDelay: delay }}>
      <path d={d} fill="none" stroke="#4fb3ff" strokeWidth="7" strokeOpacity=".5" strokeLinejoin="round" strokeLinecap="round" />
      <path d={d} fill="none" stroke="#ffffff" strokeWidth="2.5" strokeLinejoin="round" strokeLinecap="round" />
    </g>
  );
}

export function StormCaller({ shot }: P) {
  const bolts = [
    "M356 96 L372 78 L364 74 L386 52 L380 48 L398 30",
    "M358 112 L380 124 L372 132 L398 142",
    "M132 74 L144 56 L136 52 L152 30",
    "M252 136 L264 156 L256 160 L272 186",
    "M70 132 L58 150 L66 154 L48 178",
    "M202 70 L192 52 L200 48 L190 24",
    "M300 134 L318 148 L310 154 L332 170",
    "M160 150 L150 166 L158 168 L146 190",
  ];
  const arcs = ["M362 88 L368 94 L364 98 L372 102", "M362 122 L368 116 L364 112 L372 108", "M340 78 L346 86 L342 90 L350 94", "M340 132 L346 124 L342 120 L350 116"];
  return (
    <Frame
      shot={shot}
      defs={
        <>
          <linearGradient id="st-body" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stopColor="#4a5f9e" />
            <stop offset=".3" stopColor="#1b2756" />
            <stop offset=".7" stopColor="#0d1536" />
            <stop offset="1" stopColor="#050815" />
          </linearGradient>
          <linearGradient id="st-ice" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0" stopColor="#ffffff" />
            <stop offset=".35" stopColor="#dbf7ff" />
            <stop offset=".7" stopColor="#7ec9ff" />
            <stop offset="1" stopColor="#2f6fff" />
          </linearGradient>
          <linearGradient id="st-ice2" x1="0" y1="1" x2="1" y2="0">
            <stop offset="0" stopColor="#9fdcff" />
            <stop offset=".5" stopColor="#4a9eff" />
            <stop offset="1" stopColor="#1e4fd8" />
          </linearGradient>
          <linearGradient id="st-cap" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stopColor="#f2fbff" />
            <stop offset=".45" stopColor="#8aa2c8" />
            <stop offset="1" stopColor="#263352" />
          </linearGradient>
          <radialGradient id="st-orb" cx=".5" cy=".5" r=".5">
            <stop offset="0" stopColor="#ffffff" />
            <stop offset=".3" stopColor="#b3f4ff" />
            <stop offset=".6" stopColor="#3aa0ff" stopOpacity=".6" />
            <stop offset="1" stopColor="#1a6bff" stopOpacity="0" />
          </radialGradient>
          <ShineGrad id="st-shine" />
          <clipPath id="st-clip">
            <rect x="98" y="82" width="208" height="46" rx="10" />
          </clipPath>
          <Glow id="st-glow" std={3} />
          <Glow id="st-big" std={8} />
          <DropShadow id="st-ds" />
          <Blur id="st-blur" />
        </>
      }
      back={
        <>
          <Aura p="st" c1="#5fe1ff" c2="#a855f7" />
          <ellipse cx="200" cy="115" rx="150" ry="92" fill="#2a8cff" opacity=".2" filter="url(#st-big)" className="glow-pulse" />
          <g className="vortex">
            <circle cx="200" cy="115" r="104" fill="none" stroke="#5fe1ff" strokeOpacity=".28" strokeWidth="2" strokeDasharray="2 12" />
          </g>
          <g className="vortex vortex-rev">
            <circle cx="200" cy="115" r="84" fill="none" stroke="#a855f7" strokeOpacity=".3" strokeWidth="1.5" strokeDasharray="40 30" />
          </g>
          <Twinkle x={60} y={60} s={0.8} color="#bff4ff" />
          <Twinkle x={350} y={190} s={0.7} color="#fff" delay={1.1} />
          <Twinkle x={330} y={40} s={0.6} color="#bff4ff" delay={0.5} />
        </>
      }
    >
      <ellipse cx="200" cy="214" rx="125" ry="9" fill="#000" opacity=".45" filter="url(#st-blur)" />
      <g className="storm-shake">
        <g transform="translate(205 115) scale(.86) rotate(-36) translate(-205 -110)">
          <g className="recoil" style={{ transformOrigin: "90px 105px", "--rx": "-14px", "--rr": "0deg", "--ry": "0px" } as CSSProperties}>
            <g filter="url(#st-ds)">
              <g stroke="#06102a" strokeWidth="3" strokeLinejoin="round">
                <polygon points="74,90 86,66 96,94" fill="url(#st-ice2)" />
                <polygon points="74,120 86,144 96,116" fill="url(#st-ice2)" />
                <polygon points="54,105 86,76 110,105 86,134" fill="url(#st-ice)" />
                <polygon points="128,84 150,34 208,46 224,84" fill="url(#st-ice)" />
                <polygon points="128,126 150,176 208,164 224,126" fill="url(#st-ice)" />
                <polygon points="236,84 254,56 290,62 296,84" fill="url(#st-ice)" />
                <polygon points="236,126 254,154 290,148 296,126" fill="url(#st-ice)" />
                <polygon points="104,82 112,62 120,82" fill="url(#st-ice2)" />
                <polygon points="104,128 112,148 120,128" fill="url(#st-ice2)" />
                <rect x="98" y="82" width="208" height="46" rx="10" fill="url(#st-body)" />
                <path d="M302 82 L334 72 Q346 74 346 88 L346 122 Q346 136 334 138 L302 128 Z" fill="url(#st-cap)" />
                <rect x="292" y="78" width="14" height="54" rx="3" fill="url(#st-cap)" />
                <polygon points="334,78 366,92 342,100" fill="url(#st-ice)" />
                <polygon points="334,132 366,118 342,110" fill="url(#st-ice)" />
              </g>
              <g fill="#fff" opacity=".45">
                <polygon points="140,84 152,44 178,52 176,84" />
                <polygon points="140,126 152,166 178,158 176,126" />
                <polygon points="244,84 256,62 270,64 268,84" />
                <polygon points="244,126 256,148 270,146 268,126" />
                <polygon points="60,105 86,80 86,105" />
              </g>
              <g fill="#1e4fd8" opacity=".25">
                <polygon points="186,54 208,46 224,84 190,84" />
                <polygon points="186,156 208,164 224,126 190,126" />
                <polygon points="86,105 110,105 86,134" />
              </g>
              <g stroke="#fff" strokeWidth="1.5" opacity=".7" strokeLinecap="round">
                <path d="M152 44 L202 54 M152 166 L202 156 M256 62 L284 68 M256 148 L284 142 M86 80 L104 103" />
              </g>
              <path d="M106 86 H298" stroke="#9fe9ff" strokeOpacity=".5" strokeWidth="2" strokeLinecap="round" />
              <path d="M106 124 H298" stroke="#000" strokeOpacity=".4" strokeWidth="2" strokeLinecap="round" />
              <path d="M106 91 H298 M106 119 H298" stroke="#5fe1ff" strokeOpacity=".45" strokeWidth="1.2" />
              {[120, 154, 230, 264].map((x) => (
                <g key={x}>
                  <rect x={x} y="82" width="7" height="46" fill="#070c22" />
                  <rect x={x + 1.5} y="82" width="2" height="46" fill="#5fe1ff" opacity=".5" />
                </g>
              ))}
              {/* runes */}
              <g fill="none" stroke="#9ff0ff" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" filter="url(#st-glow)">
                <g className="rune">
                  <path d="M140 94 L146 105 L140 116 L134 105 Z M140 98 V112" />
                </g>
                <g className="rune" style={{ animationDelay: ".5s" }}>
                  <path d="M216 95 L226 102 L216 109 L226 116" />
                </g>
                <g className="rune" style={{ animationDelay: "1s" }}>
                  <circle cx="250" cy="105" r="6.5" />
                  <circle cx="250" cy="105" r="1.5" fill="#9ff0ff" />
                </g>
                <g className="rune" style={{ animationDelay: "1.5s" }}>
                  <path d="M275 116 L281 94 L287 116 M278 108 H284" />
                </g>
              </g>
              {/* emblem */}
              <rect x="168" y="83" width="44" height="44" rx="6" fill="#0b163a" stroke="#5fe1ff" strokeWidth="3.5" filter="url(#st-glow)" className="fire-glow" />
              <rect x="174" y="89" width="32" height="32" rx="3" fill="url(#st-ice)" opacity=".2" />
              <path d="M197 89 L180 109 L191 109 L184 123 L203 102 L192 102 Z" fill="#eafcff" stroke="#06102a" strokeWidth="1.5" strokeLinejoin="round" filter="url(#st-glow)" />
              <path d="M306 84 L334 76" stroke="#fff" strokeWidth="2" opacity=".8" />
              <path d="M310 90 L310 120 M322 86 L322 124" stroke="#06102a" strokeWidth="2" opacity=".6" />
              <Shine clip="st-clip" grad="st-shine" />
            </g>
            {/* energy rings around the head */}
            <g filter="url(#st-glow)">
              <ellipse className="ring-spin" cx="316" cy="105" rx="6" ry="40" fill="none" stroke="#9ff0ff" strokeWidth="2.5" strokeDasharray="10 7" />
              <ellipse className="ring-spin rev" cx="330" cy="105" rx="5" ry="36" fill="none" stroke="#fff" strokeWidth="1.5" strokeDasharray="4 9" />
            </g>
            {/* orb */}
            <g className="fire-glow">
              <circle className="orb" cx="354" cy="105" r="24" fill="url(#st-orb)" filter="url(#st-glow)" />
              <circle className="orb-ring" cx="354" cy="105" r="14" fill="none" stroke="#bff4ff" strokeWidth="1.5" />
              <circle cx="354" cy="105" r="7" fill="#fff" filter="url(#st-glow)" />
            </g>
            <g filter="url(#st-glow)">
              {arcs.map((d, i) => (
                <g key={i} className="arc" style={{ animationDelay: `${i * 0.27}s` }}>
                  <path d={d} fill="none" stroke="#fff" strokeWidth="1.6" strokeLinejoin="round" strokeLinecap="round" />
                </g>
              ))}
            </g>
            <MuzzleFlash x={358} y={105} c2="#9ff0ff" c3="#2a8cff" filter="st-glow" scale={1.15} sparks={12} />
          </g>
          <g filter="url(#st-glow)">
            {bolts.map((d, i) => (
              <Bolt key={i} d={d} delay={shot ? `${i * 0.02}s` : `${(i * 0.37) % 1.4}s`} />
            ))}
          </g>
        </g>
      </g>
    </Frame>
  );
}
