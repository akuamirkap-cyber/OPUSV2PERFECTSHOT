import { useCallback, useEffect, useMemo, useRef, useState, type ComponentType, type CSSProperties, type PointerEvent as RPointerEvent } from "react";
import { BananaBlaster, GoldenRevolver, LaserBuster, ShadowStriker, StormCaller } from "./weapons";
import { CardGun, FireworkLauncher, Minigun, PlasmaPistol, SuperSoaker } from "./weapons2";

type SoundKind = "gold" | "laser" | "rifle" | "banana" | "storm" | "water" | "firework" | "plasma" | "cards" | "minigun";

/* ------------ tiny WebAudio synth ------------ */
let ctx: AudioContext | null = null;
function ac() {
  if (!ctx) ctx = new (window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext)();
  return ctx;
}
function noise(dur: number, freq: number, gain: number, type: BiquadFilterType = "lowpass") {
  const a = ac();
  const buf = a.createBuffer(1, a.sampleRate * dur, a.sampleRate);
  const d = buf.getChannelData(0);
  for (let i = 0; i < d.length; i++) d[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / d.length, 2);
  const src = a.createBufferSource();
  src.buffer = buf;
  const f = a.createBiquadFilter();
  f.type = type;
  f.frequency.value = freq;
  const g = a.createGain();
  g.gain.value = gain;
  src.connect(f).connect(g).connect(a.destination);
  src.start();
}
function tone(type: OscillatorType, f0: number, f1: number, dur: number, gain: number, delay = 0) {
  const a = ac();
  const t = a.currentTime + delay;
  const o = a.createOscillator();
  const g = a.createGain();
  o.type = type;
  o.frequency.setValueAtTime(f0, t);
  o.frequency.exponentialRampToValueAtTime(Math.max(f1, 20), t + dur);
  g.gain.setValueAtTime(gain, t);
  g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
  o.connect(g).connect(a.destination);
  o.start(t);
  o.stop(t + dur + 0.02);
}
function play(kind: SoundKind) {
  try {
    switch (kind) {
      case "gold":
        noise(0.25, 1800, 0.5);
        tone("sine", 160, 50, 0.2, 0.4);
        tone("triangle", 2093, 2093, 0.35, 0.12, 0.05);
        tone("triangle", 2637, 2637, 0.4, 0.1, 0.11);
        break;
      case "laser":
        tone("square", 1600, 180, 0.28, 0.12);
        tone("sawtooth", 900, 120, 0.3, 0.06);
        break;
      case "rifle":
        noise(0.18, 2600, 0.6);
        tone("square", 120, 40, 0.12, 0.25);
        tone("sine", 1400, 600, 0.08, 0.05);
        break;
      case "banana":
        tone("sine", 240, 720, 0.12, 0.3);
        tone("sine", 720, 160, 0.25, 0.25, 0.12);
        noise(0.15, 900, 0.3);
        break;
      case "storm":
        noise(0.5, 3000, 0.5, "bandpass");
        noise(0.35, 400, 0.4);
        tone("sawtooth", 90, 40, 0.45, 0.15);
        break;
      case "water":
        noise(0.4, 1200, 0.35, "bandpass");
        tone("sine", 380, 900, 0.18, 0.18);
        tone("sine", 900, 300, 0.22, 0.12, 0.14);
        break;
      case "firework":
        noise(0.22, 900, 0.5);
        tone("sine", 110, 40, 0.3, 0.45);
        tone("sawtooth", 600, 1800, 0.35, 0.05, 0.05);
        noise(0.5, 4000, 0.25, "highpass");
        break;
      case "plasma":
        tone("sawtooth", 220, 1400, 0.22, 0.1);
        tone("square", 1100, 90, 0.3, 0.08, 0.05);
        noise(0.2, 2200, 0.2, "bandpass");
        break;
      case "cards":
        noise(0.08, 5000, 0.5, "highpass");
        noise(0.12, 3000, 0.3, "bandpass");
        tone("triangle", 1800, 2600, 0.1, 0.12);
        tone("triangle", 2600, 1800, 0.12, 0.08, 0.06);
        break;
      case "minigun":
        noise(0.08, 2200, 0.55);
        tone("square", 140, 50, 0.07, 0.3);
        tone("sine", 60, 40, 0.1, 0.25);
        break;
    }
  } catch {
    /* audio unavailable */
  }
}

/* ------------ data ------------ */
type Weapon = {
  id: string;
  name: string;
  rarity: string;
  stars: number;
  rarityColor: string;
  Comp: ComponentType<{ shot: number }>;
  sound: SoundKind;
  bg: string;
  glow: string;
  border: string;
  border2: string;
  title: string;
  platform?: string;
  rate: number;
  stats: { dmg: number; rate: number; range: number };
  desc: string;
  power: number;
  tag?: string;
  cls: string;
};

const WEAPONS: Weapon[] = [
  {
    id: "gold",
    name: "GOLDEN TYCOON",
    rarity: "MYTHIC",
    stars: 5,
    rarityColor: "#ffcc33",
    Comp: GoldenRevolver,
    sound: "gold",
    bg: "linear-gradient(135deg,#1c1446 0%,#0e1033 50%,#1f0e2c 100%)",
    glow: "rgba(255,190,40,.55)",
    border: "#ffcc33",
    border2: "#ff5c9a",
    title: "linear-gradient(180deg,#fff7c2,#ffcc33 55%,#d98a0b)",
    rate: 520,
    stats: { dmg: 92, rate: 40, range: 70 },
    desc: "Revolver emas berukir dengan koin keberuntungan, zamrud di moncong & rumbai beludru.",
    power: 9800,
    tag: "LIMITED",
    cls: "",
  },
  {
    id: "laser",
    name: "LASER BUSTER",
    rarity: "LEGEND",
    stars: 4,
    rarityColor: "#ffb020",
    Comp: LaserBuster,
    sound: "laser",
    bg: "linear-gradient(135deg,#12205e 0%,#1b0f4e 55%,#2c0a42 100%)",
    glow: "rgba(255,40,100,.5)",
    border: "#ff5c9a",
    border2: "#c04bff",
    title: "linear-gradient(180deg,#ffe0e8,#ff7aa0 55%,#ff2a55)",
    rate: 360,
    stats: { dmg: 74, rate: 75, range: 85 },
    desc: "Blaster sci-fi dengan 4 sel plasma merah, tabung energi mengalir & kumparan pemfokus.",
    power: 8400,
    cls: "",
  },
  {
    id: "shadow",
    name: "SHADOW STRIKER",
    rarity: "LEGEND",
    stars: 4,
    rarityColor: "#b07bff",
    Comp: ShadowStriker,
    sound: "rifle",
    bg: "radial-gradient(circle at 50% 45%,#5b34c9 0%,#2a1570 45%,#120a38 100%)",
    glow: "rgba(150,110,255,.6)",
    border: "#8b5cff",
    border2: "#3ad7ff",
    title: "linear-gradient(180deg,#e9e0ff,#a98bff 55%,#6a3dff)",
    platform: "#a57bff",
    rate: 140,
    stats: { dmg: 58, rate: 95, range: 80 },
    desc: "Senapan taktis dengan holo-sight, penghitung amunisi digital, peredam neon & sirkuit hidup.",
    power: 8700,
    cls: "",
  },
  {
    id: "banana",
    name: "BANANA BLASTER",
    rarity: "EPIC",
    stars: 3,
    rarityColor: "#c58bff",
    Comp: BananaBlaster,
    sound: "banana",
    bg: "linear-gradient(135deg,#1a1a4e 0%,#2b1654 50%,#3d2c10 100%)",
    glow: "rgba(255,200,0,.55)",
    border: "#ffcc00",
    border2: "#c58bff",
    title: "linear-gradient(180deg,#fff6c2,#ffd21f 55%,#e08a00)",
    rate: 420,
    stats: { dmg: 66, rate: 55, range: 60 },
    desc: "Meriam pisang emas: kulitnya mengelupas tiap tembakan! Gelang permata & bidikan daun.",
    power: 7200,
    cls: "",
  },
  {
    id: "storm",
    name: "STORM CALLER",
    rarity: "MYTHIC",
    stars: 5,
    rarityColor: "#5fe1ff",
    Comp: StormCaller,
    sound: "storm",
    bg: "radial-gradient(circle at 50% 45%,#1e3a8a 0%,#14205a 45%,#0a0f2e 100%)",
    glow: "rgba(60,170,255,.6)",
    border: "#5fe1ff",
    border2: "#a855f7",
    title: "linear-gradient(180deg,#ffffff,#9ff0ff 55%,#2a8cff)",
    platform: "#a855f7",
    rate: 600,
    stats: { dmg: 98, rate: 30, range: 90 },
    desc: "Meriam kristal petir dengan rune bercahaya, cincin energi berputar & busur listrik.",
    power: 9900,
    tag: "LIMITED",
    cls: "",
  },
  {
    id: "soaker",
    name: "SUPER SOAKER",
    rarity: "RARE",
    stars: 3,
    rarityColor: "#3cc8ff",
    Comp: SuperSoaker,
    sound: "water",
    bg: "linear-gradient(135deg,#0a2a6a 0%,#0c4aa8 50%,#0a1e5a 100%)",
    glow: "rgba(60,200,255,.55)",
    border: "#3cc8ff",
    border2: "#8be83a",
    title: "linear-gradient(180deg,#fff6c2,#ffb02e 55%,#e8600c)",
    rate: 300,
    stats: { dmg: 35, rate: 80, range: 55 },
    desc: "Pistol air biru-hijau dengan tangki H2O berombak & pompa oranye yang bergerak tiap semprotan.",
    power: 5600,
    cls: "",
  },
  {
    id: "firework",
    name: "FIREWORK LAUNCHER",
    rarity: "LEGEND",
    stars: 4,
    rarityColor: "#ffd34d",
    Comp: FireworkLauncher,
    sound: "firework",
    bg: "linear-gradient(135deg,#2a0a4a 0%,#4a0d3a 50%,#1a0a3a 100%)",
    glow: "rgba(255,120,60,.55)",
    border: "#ffd34d",
    border2: "#e8182c",
    title: "linear-gradient(180deg,#fff6c2,#ffd34d 55%,#e86a0c)",
    rate: 650,
    stats: { dmg: 88, rate: 25, range: 95 },
    desc: "Tabung roket bergaris merah-biru berbintang emas, sumbu menyala & semburan balik api saat ditembak.",
    power: 8900,
    cls: "",
  },
  {
    id: "plasma",
    name: "VOID PLASMA",
    rarity: "EPIC",
    stars: 3,
    rarityColor: "#5bff5b",
    Comp: PlasmaPistol,
    sound: "plasma",
    bg: "radial-gradient(circle at 50% 45%,#3b1a7a 0%,#1a0f4a 45%,#0a0a2a 100%)",
    glow: "rgba(91,255,91,.5)",
    border: "#5bff5b",
    border2: "#a855f7",
    title: "linear-gradient(180deg,#eaffea,#8dff8d 55%,#13c13a)",
    platform: "#5bff5b",
    rate: 260,
    stats: { dmg: 70, rate: 70, range: 75 },
    desc: "Pistol hitam dengan laras kaca berisi plasma hijau yang bergejolak & emitor bola energi.",
    power: 7600,
    cls: "",
  },
  {
    id: "cards",
    name: "CARD GUN",
    rarity: "EPIC",
    stars: 3,
    rarityColor: "#ff5c6a",
    Comp: CardGun,
    sound: "cards",
    bg: "linear-gradient(135deg,#2a0a3a 0%,#4a0a2a 50%,#1a0a3a 100%)",
    glow: "rgba(255,80,110,.5)",
    border: "#ff5c6a",
    border2: "#5fe1ff",
    title: "linear-gradient(180deg,#fff6c2,#ffd34d 55%,#e86a0c)",
    rate: 220,
    stats: { dmg: 52, rate: 85, range: 65 },
    desc: "Pistol kasino merah-putih dengan magasin kipas kartu As, simbol ♠♥♦♣ & celah kartu bercahaya.",
    power: 7100,
    cls: "",
  },
  {
    id: "minigun",
    name: "MINIGUN",
    rarity: "EPIC",
    stars: 3,
    rarityColor: "#c58bff",
    Comp: Minigun,
    sound: "minigun",
    bg: "radial-gradient(circle at 50% 45%,#5b2ea8 0%,#2a1560 45%,#120a30 100%)",
    glow: "rgba(197,139,255,.55)",
    border: "#c58bff",
    border2: "#ffd34d",
    title: "linear-gradient(180deg,#f3e9ff,#c58bff 55%,#7c3aed)",
    platform: "#c58bff",
    rate: 90,
    stats: { dmg: 45, rate: 100, range: 70 },
    desc: "Meriam putar 6 laras gunmetal dengan ventilasi panas, pita amunisi kuningan & penghitung peluru.",
    power: 8200,
    cls: "",
  },
];

/* ------------ card ------------ */
type CardProps = {
  w: Weapon;
  index: number;
  muted: boolean;
  trigger: number;
  onFire: () => void;
  big?: boolean;
  onOpen?: () => void;
  onClose?: () => void;
};

function Card({ w, index, muted, trigger, onFire, big, onOpen, onClose }: CardProps) {
  const [shot, setShot] = useState(0);
  const timer = useRef<number | null>(null);
  const cardRef = useRef<HTMLDivElement>(null);
  const stageRef = useRef<HTMLDivElement>(null);
  const flashRef = useRef<HTMLDivElement>(null);
  const mutedRef = useRef(muted);
  mutedRef.current = muted;

  const fire = useCallback(() => {
    setShot((s) => s + 1);
    onFire();
    if (!mutedRef.current) play(w.sound);
    stageRef.current?.animate(
      [
        { transform: "translate(0,0)" },
        { transform: "translate(-3px,2px)" },
        { transform: "translate(3px,-1px)" },
        { transform: "translate(-1px,-2px)" },
        { transform: "translate(0,0)" },
      ],
      { duration: 280 },
    );
    flashRef.current?.animate([{ opacity: 0.95 }, { opacity: 0 }], { duration: 480, easing: "ease-out" });
  }, [w.sound, onFire]);

  const lastTrigger = useRef(trigger);
  useEffect(() => {
    if (trigger !== lastTrigger.current) {
      lastTrigger.current = trigger;
      fire();
    }
  }, [trigger, fire]);

  // showcase entrance shot
  useEffect(() => {
    if (!big) return;
    const t = window.setTimeout(fire, 550);
    return () => window.clearTimeout(t);
  }, [big, fire]);

  const stop = useCallback(() => {
    if (timer.current) window.clearInterval(timer.current);
    timer.current = null;
  }, []);
  const start = useCallback(() => {
    fire();
    stop();
    timer.current = window.setInterval(fire, w.rate);
  }, [fire, stop, w.rate]);
  useEffect(() => stop, [stop]);

  const onMove = (e: RPointerEvent<HTMLDivElement>) => {
    const el = cardRef.current;
    if (!el) return;
    const r = el.getBoundingClientRect();
    const x = (e.clientX - r.left) / r.width;
    const y = (e.clientY - r.top) / r.height;
    el.style.setProperty("--ty", `${(x - 0.5) * (big ? 6 : 12)}deg`);
    el.style.setProperty("--tx", `${(0.5 - y) * (big ? 6 : 12)}deg`);
    el.style.setProperty("--mx", `${x * 100}%`);
    el.style.setProperty("--my", `${y * 100}%`);
    el.style.setProperty("--px", `${(x - 0.5) * 18}px`);
    el.style.setProperty("--py", `${(y - 0.5) * 12}px`);
  };
  const onLeave = () => {
    const el = cardRef.current;
    if (el) {
      el.style.setProperty("--ty", "0deg");
      el.style.setProperty("--tx", "0deg");
      el.style.setProperty("--px", "0px");
      el.style.setProperty("--py", "0px");
    }
    stop();
  };

  const particles = useMemo(
    () =>
      Array.from({ length: 14 }).map((_, i) => ({
        left: `${(i * 37 + 11) % 100}%`,
        size: 2 + ((i * 7) % 4),
        delay: `${((i * 1.37) % 6).toFixed(2)}s`,
        dur: `${(5 + ((i * 1.9) % 5)).toFixed(2)}s`,
        px: `${((i * 23) % 60) - 30}px`,
        color: i % 3 === 0 ? w.border2 : w.border,
      })),
    [w.border, w.border2],
  );

  const { Comp } = w;
  return (
    <div
      ref={cardRef}
      className={`tilt card-in group relative ${big ? "" : w.cls}`}
      style={{ animationDelay: big ? "0s" : `${index * 0.12}s` }}
      onPointerMove={onMove}
      onPointerLeave={onLeave}
    >
      {/* holographic border */}
      <div
        className="holo absolute -inset-[2px] rounded-[28px] opacity-70 transition-opacity duration-300 group-hover:opacity-100"
        style={{ "--c": w.border, "--c2": w.border2 } as CSSProperties}
      />
      <div
        className="pointer-events-none absolute -inset-3 rounded-[34px] opacity-0 blur-2xl transition-opacity duration-500 group-hover:opacity-60"
        style={{ background: `radial-gradient(circle at 50% 30%, ${w.glow}, transparent 70%)` }}
      />

      <div className="relative select-none overflow-hidden rounded-[26px] shadow-[0_30px_60px_-25px_rgba(0,0,0,.9)]" style={{ background: w.bg }}>
        {/* bg layers */}
        <div className="tech-grid pointer-events-none absolute inset-0" />
        <div className="rays pointer-events-none absolute -inset-1/2" />
        <div className="pointer-events-none absolute inset-0" style={{ background: `radial-gradient(circle at 50% 42%, ${w.glow}, transparent 58%)` }} />
        <div className="scan pointer-events-none absolute inset-0 opacity-70" />
        <div className="vignette pointer-events-none absolute inset-0" />
        <div className="sheen pointer-events-none absolute inset-0 opacity-0 transition-opacity duration-300 group-hover:opacity-100" />
        <div className={`foil pointer-events-none absolute inset-0 transition-opacity duration-300 ${w.stars === 5 ? "opacity-70 group-hover:opacity-100" : "opacity-0 group-hover:opacity-60"}`} />
        {/* particles */}
        <div className="pointer-events-none absolute inset-0 overflow-hidden">
          {particles.map((p, i) => (
            <span
              key={i}
              className="particle"
              style={
                {
                  left: p.left,
                  width: p.size,
                  height: p.size,
                  background: p.color,
                  boxShadow: `0 0 ${p.size * 3}px ${p.color}`,
                  animationDelay: p.delay,
                  animationDuration: p.dur,
                  "--px": p.px,
                } as CSSProperties
              }
            />
          ))}
        </div>
        {/* big ghost number */}
        <div
          className="font-game pointer-events-none absolute right-5 top-12 select-none text-[6rem] leading-none text-transparent"
          style={{ WebkitTextStroke: `1px ${w.border}`, opacity: 0.12 }}
        >
          0{index + 1}
        </div>

        {/* HUD frame */}
        <div className="pointer-events-none absolute left-3 top-3 h-7 w-7 rounded-tl-md border-l-2 border-t-2" style={{ borderColor: w.border }} />
        <div className="pointer-events-none absolute right-3 top-3 h-7 w-7 rounded-tr-md border-r-2 border-t-2" style={{ borderColor: w.border }} />
        <div className="pointer-events-none absolute bottom-3 left-3 h-7 w-7 rounded-bl-md border-b-2 border-l-2" style={{ borderColor: w.border }} />
        <div className="pointer-events-none absolute bottom-3 right-3 h-7 w-7 rounded-br-md border-b-2 border-r-2" style={{ borderColor: w.border }} />
        <div className="pointer-events-none absolute left-0 top-1/2 h-16 w-[3px] -translate-y-1/2 rounded-r" style={{ background: w.border, boxShadow: `0 0 12px ${w.border}` }} />
        <div className="pointer-events-none absolute right-0 top-1/2 h-16 w-[3px] -translate-y-1/2 rounded-l" style={{ background: w.border, boxShadow: `0 0 12px ${w.border}` }} />

        {/* rarity badge + stars */}
        <div className="absolute left-5 top-5 z-10">
          <div className="flex items-center">
            <div
              className="-skew-x-12 border px-3 py-1"
              style={{
                borderColor: w.rarityColor,
                background: "linear-gradient(90deg, rgba(10,12,40,.9), rgba(10,12,40,.6))",
                boxShadow: `0 0 14px ${w.rarityColor}66, inset 0 0 10px ${w.rarityColor}33`,
              }}
            >
              <span className="block skew-x-12 text-sm font-bold tracking-[0.25em]" style={{ color: w.rarityColor, textShadow: `0 0 8px ${w.rarityColor}` }}>
                ◆ {w.rarity}
              </span>
            </div>
            {w.tag && (
              <span
                className="badge-shimmer ml-2 -skew-x-12 rounded-sm px-2 py-0.5 text-[10px] font-black tracking-[0.2em] text-black"
                style={{ backgroundImage: `linear-gradient(90deg, ${w.border}, #fff, ${w.border2}, ${w.border})` }}
              >
                {w.tag}
              </span>
            )}
          </div>
          <div className="mt-1.5 flex gap-0.5 pl-1 text-base leading-none" style={{ color: w.rarityColor }}>
            {Array.from({ length: 5 }).map((_, i) => (
              <span key={i} className={i < w.stars ? "rarity-star inline-block" : "inline-block opacity-25"} style={{ animationDelay: `${i * 0.2}s` }}>
                ★
              </span>
            ))}
          </div>
        </div>

        {/* top right controls */}
        <div className="absolute right-5 top-5 z-10 flex items-center gap-2">
          {!big && (
            <span className="rounded-md border border-white/15 bg-black/40 px-2 py-0.5 font-mono text-xs font-bold text-white/70 backdrop-blur">KEY {(index + 1) % 10}</span>
          )}
          {onOpen && (
            <button
              onClick={onOpen}
              title="Showcase"
              className="rounded-md border bg-black/40 px-2 py-0.5 text-xs font-bold backdrop-blur transition hover:scale-110"
              style={{ borderColor: w.border, color: w.border }}
            >
              ⤢
            </button>
          )}
          {onClose && (
            <button
              onClick={onClose}
              className="rounded-md border border-white/30 bg-black/50 px-2.5 py-0.5 text-sm font-bold text-white backdrop-blur transition hover:bg-white/20"
            >
              ✕ ESC
            </button>
          )}
        </div>

        {/* flash overlay */}
        <div ref={flashRef} className="pointer-events-none absolute inset-0 z-[5] opacity-0" style={{ background: `radial-gradient(circle at 75% 42%, ${w.glow}, transparent 55%)` }} />

        {/* weapon stage */}
        <button
          aria-label={`Tembak ${w.name}`}
          className={`relative block w-full cursor-crosshair outline-none ${big ? "aspect-[16/9]" : "aspect-[16/10]"}`}
          onPointerDown={start}
          onPointerUp={stop}
          onPointerCancel={stop}
        >
          {w.platform && (
            <>
              <div className="platform-ring pointer-events-none absolute bottom-[15%] left-1/2 h-[14%] w-[62%] rounded-[50%] border" style={{ borderColor: w.platform }} />
              <div
                className="platform pointer-events-none absolute bottom-[15%] left-1/2 h-[14%] w-[62%] rounded-[50%] border-2"
                style={{
                  borderColor: w.platform,
                  boxShadow: `0 0 30px ${w.platform}, inset 0 0 25px ${w.platform}`,
                  background: `radial-gradient(ellipse, ${w.platform}66, transparent 70%)`,
                }}
              />
            </>
          )}
          <div className="parallax absolute inset-[5%]">
            <div ref={stageRef} className="h-full w-full">
              <Comp shot={shot} />
            </div>
          </div>
        </button>

        {/* footer */}
        <div className="relative z-10 px-6 pb-6">
          <div className="mx-auto mb-2 h-px w-3/4" style={{ background: `linear-gradient(90deg, transparent, ${w.border}, transparent)` }} />
          <h2
            className={`font-game title-stroke text-center leading-none ${big ? "text-5xl sm:text-6xl" : "text-3xl sm:text-[2.4rem]"}`}
            style={{
              backgroundImage: w.title,
              WebkitBackgroundClip: "text",
              backgroundClip: "text",
              color: "transparent",
              filter: `drop-shadow(0 3px 0 rgba(0,0,0,.55)) drop-shadow(0 0 14px ${w.glow})`,
            }}
          >
            {w.name}
          </h2>
          <p className={`mt-2 text-center leading-snug text-white/60 ${big ? "text-base" : "text-sm"}`}>{w.desc}</p>

          <div className="mt-4 grid grid-cols-3 gap-3 text-[11px] font-bold tracking-widest text-white/60">
            {(
              [
                ["DMG", w.stats.dmg],
                ["RATE", w.stats.rate],
                ["RANGE", w.stats.range],
              ] as const
            ).map(([k, v], i) => (
              <div key={k}>
                <div className="flex justify-between">
                  <span>{k}</span>
                  <span className="font-mono text-xs" style={{ color: w.border }}>
                    {v}
                  </span>
                </div>
                <div className="mt-1 h-2 overflow-hidden rounded-full bg-black/40 ring-1 ring-white/10">
                  <div className="relative h-full overflow-hidden rounded-full" style={{ width: `${v}%`, background: w.title, boxShadow: `0 0 10px ${w.glow}` }}>
                    <div className="stat-shine absolute inset-y-0 w-1/3" style={{ animationDelay: `${i * 0.4}s` }} />
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="mt-4 flex items-center gap-3">
            <button
              onPointerDown={start}
              onPointerUp={stop}
              onPointerLeave={stop}
              onPointerCancel={stop}
              className="btn-glow font-game relative flex-1 overflow-hidden rounded-xl border py-2.5 text-lg tracking-wider text-white transition-transform active:scale-[.97]"
              style={
                {
                  borderColor: w.border,
                  background: `linear-gradient(90deg, ${w.border}22, ${w.border}66 50%, ${w.border}22)`,
                  "--g": w.glow,
                } as CSSProperties
              }
            >
              <span className="relative z-10 drop-shadow-[0_2px_0_rgba(0,0,0,.5)]">🔥 TEMBAK — tahan untuk auto</span>
              <span className="pointer-events-none absolute inset-0 -translate-x-full bg-gradient-to-r from-transparent via-white/30 to-transparent transition-transform duration-700 group-hover:translate-x-full" />
            </button>
            <div className="rounded-xl border border-white/10 bg-black/30 px-3 py-1.5 text-center">
              <div className="text-[9px] font-bold tracking-[0.3em] text-white/40">POWER</div>
              <div className="font-mono text-base font-bold leading-none" style={{ color: w.border }}>
                {w.power}
              </div>
            </div>
          </div>
          <div className="mt-3 flex justify-between font-mono text-[10px] tracking-widest text-white/30">
            <span>SN-{String(index + 1).padStart(4, "0")}-{w.id.toUpperCase()}</span>
            <span>SVG · 2D · VECTOR</span>
          </div>
        </div>
      </div>
    </div>
  );
}

export default function App() {
  const [muted, setMuted] = useState(false);
  const [triggers, setTriggers] = useState<number[]>(() => WEAPONS.map(() => 0));
  const [total, setTotal] = useState(0);
  const [focus, setFocus] = useState<number | null>(null);
  const [filter, setFilter] = useState<string>("ALL");
  const RARITIES = ["ALL", "MYTHIC", "LEGEND", "EPIC", "RARE"];
  const rarityColor: Record<string, string> = { ALL: "#ffffff", MYTHIC: "#5fe1ff", LEGEND: "#ffb020", EPIC: "#c58bff", RARE: "#3cc8ff" };

  const onFire = useCallback(() => setTotal((n) => n + 1), []);
  const fireAll = useCallback(() => setTriggers((t) => t.map((v) => v + 1)), []);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (/^[0-9]$/.test(e.key)) {
        const idx = e.key === "0" ? 9 : parseInt(e.key, 10) - 1;
        if (idx < WEAPONS.length) setTriggers((t) => t.map((v, i) => (i === idx ? v + 1 : v)));
      }
      if (e.code === "Space") {
        e.preventDefault();
        if (focus !== null) setTriggers((t) => t.map((v, i) => (i === focus ? v + 1 : v)));
        else fireAll();
      }
      if (e.key === "Escape") setFocus(null);
      if (focus !== null && e.key === "ArrowRight") setFocus((focus + 1) % WEAPONS.length);
      if (focus !== null && e.key === "ArrowLeft") setFocus((focus + WEAPONS.length - 1) % WEAPONS.length);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [fireAll, focus]);

  useEffect(() => {
    document.body.style.overflow = focus !== null ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [focus]);

  return (
    <div className="relative min-h-screen overflow-x-hidden text-white">
      {/* page background */}
      <div className="pointer-events-none fixed inset-0 -z-10 bg-[radial-gradient(ellipse_at_top,#1d1766_0%,#0a0c2a_45%,#05071a_100%)]" />
      <div className="stars-bg pointer-events-none fixed inset-0 -z-10 opacity-60" />
      <div className="tech-grid pointer-events-none fixed inset-0 -z-10 opacity-70" />
      <div className="blob -z-10 left-[-10%] top-[-10%] h-[40vw] w-[40vw] bg-violet-600" />
      <div className="blob -z-10 right-[-10%] top-[20%] h-[35vw] w-[35vw] bg-sky-500" style={{ animationDelay: "-5s" }} />
      <div className="blob -z-10 bottom-[-10%] left-[30%] h-[35vw] w-[35vw] bg-pink-500" style={{ animationDelay: "-9s" }} />

      <header className="mx-auto max-w-7xl px-5 pb-8 pt-12 text-center">
        <div className="mx-auto flex max-w-md items-center gap-4">
          <span className="h-px flex-1 bg-gradient-to-r from-transparent to-cyan-300/70" />
          <p className="text-xs font-bold tracking-[0.5em] text-cyan-300">WEAPON ARSENAL</p>
          <span className="h-px flex-1 bg-gradient-to-l from-transparent to-cyan-300/70" />
        </div>
        <h1
          className="font-game hero-title title-stroke mt-4 bg-clip-text text-5xl text-transparent sm:text-7xl"
          style={{
            backgroundImage: "linear-gradient(90deg,#fff2b0,#ffcc33,#ff7aa0,#9ff0ff,#fff2b0)",
            filter: "drop-shadow(0 4px 0 rgba(0,0,0,.55)) drop-shadow(0 0 30px rgba(255,200,80,.35))",
          }}
        >
          LEGENDARY COLLECTION
        </h1>
        <p className="font-game mt-1 text-lg tracking-[0.3em] text-white/50">10 SENJATA · SVG 2D · ANIMASI</p>
        <p className="mx-auto mt-4 max-w-xl text-base text-white/60">
          Klik / tahan senjata untuk menembak. Tekan <kbd className="rounded border border-white/20 bg-white/10 px-1.5 font-mono">1</kbd>–
          <kbd className="rounded border border-white/20 bg-white/10 px-1.5 font-mono">9</kbd>,{" "}
          <kbd className="rounded border border-white/20 bg-white/10 px-1.5 font-mono">0</kbd> untuk tiap senjata,{" "}
          <kbd className="rounded border border-white/20 bg-white/10 px-1.5 font-mono">Spasi</kbd> untuk semua, dan tombol{" "}
          <span className="font-bold text-white/80">⤢</span> untuk mode Showcase.
        </p>
        <div className="mt-6 flex flex-wrap items-center justify-center gap-3">
          <button
            onClick={fireAll}
            className="font-game rounded-full border border-amber-300/60 bg-gradient-to-r from-amber-400/20 via-pink-500/30 to-cyan-400/20 px-6 py-2 text-lg tracking-wider shadow-[0_0_30px_rgba(255,180,60,.3)] transition hover:scale-105 active:scale-95"
          >
            ⚡ TEMBAK SEMUA
          </button>
          <button
            onClick={() => setMuted((m) => !m)}
            className="rounded-full border border-white/20 bg-white/5 px-4 py-2 text-sm font-bold text-white/80 backdrop-blur transition hover:bg-white/10"
          >
            {muted ? "🔇 Suara Mati" : "🔊 Suara Nyala"}
          </button>
          <div className="rounded-full border border-white/10 bg-black/30 px-4 py-2 font-mono text-sm text-white/70">
            SHOTS <span className="text-cyan-300">{total.toString().padStart(4, "0")}</span>
          </div>
        </div>
        <div className="mt-6 flex flex-wrap items-center justify-center gap-2">
          {RARITIES.map((r) => {
            const count = r === "ALL" ? WEAPONS.length : WEAPONS.filter((w) => w.rarity === r).length;
            const active = filter === r;
            const c = rarityColor[r];
            return (
              <button
                key={r}
                onClick={() => setFilter(r)}
                className="rounded-full border px-4 py-1.5 text-[11px] font-bold tracking-[0.25em] transition hover:scale-105"
                style={{
                  borderColor: active ? c : "rgba(255,255,255,.15)",
                  color: active ? c : "rgba(255,255,255,.55)",
                  background: active ? `${c}22` : "rgba(0,0,0,.25)",
                  boxShadow: active ? `0 0 18px ${c}55` : "none",
                }}
              >
                {r === "ALL" ? "SEMUA" : r} <span className="opacity-60">×{count}</span>
              </button>
            );
          })}
        </div>
      </header>

      <main className="mx-auto grid max-w-7xl grid-cols-1 gap-8 px-5 pb-20 md:grid-cols-4 lg:grid-cols-6 [&>*]:md:col-span-2">
        {WEAPONS.map((w, i) =>
          filter === "ALL" || w.rarity === filter ? (
            <Card key={`${w.id}-${filter}`} w={w} index={i} muted={muted || focus !== null} trigger={triggers[i]} onFire={onFire} onOpen={() => setFocus(i)} />
          ) : null,
        )}
      </main>

      <footer className="pb-10 text-center text-xs tracking-widest text-white/30">SEMUA SENJATA DIGAMBAR DENGAN SVG 2D — TANPA GAMBAR BITMAP</footer>

      {/* showcase modal */}
      {focus !== null && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4 backdrop-blur-md" onClick={() => setFocus(null)}>
          <button
            className="absolute left-3 top-1/2 z-10 -translate-y-1/2 rounded-full border border-white/20 bg-black/40 px-4 py-3 text-2xl text-white/80 hover:bg-white/10 sm:left-8"
            onClick={(e) => {
              e.stopPropagation();
              setFocus((focus + WEAPONS.length - 1) % WEAPONS.length);
            }}
          >
            ‹
          </button>
          <button
            className="absolute right-3 top-1/2 z-10 -translate-y-1/2 rounded-full border border-white/20 bg-black/40 px-4 py-3 text-2xl text-white/80 hover:bg-white/10 sm:right-8"
            onClick={(e) => {
              e.stopPropagation();
              setFocus((focus + 1) % WEAPONS.length);
            }}
          >
            ›
          </button>
          <div className="modal-in max-h-full w-full max-w-3xl overflow-y-auto" onClick={(e) => e.stopPropagation()}>
            <Card key={WEAPONS[focus].id} w={WEAPONS[focus]} index={focus} muted={muted} trigger={triggers[focus]} onFire={onFire} big onClose={() => setFocus(null)} />
            <div className="mt-4 flex justify-center gap-2">
              {WEAPONS.map((w, i) => (
                <button
                  key={w.id}
                  onClick={() => setFocus(i)}
                  className="h-2.5 rounded-full transition-all"
                  style={{ width: i === focus ? 28 : 10, background: i === focus ? w.border : "rgba(255,255,255,.25)", boxShadow: i === focus ? `0 0 10px ${w.border}` : "none" }}
                />
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
