import type { CSSProperties } from "react";
import { Aura, Blur, DropShadow, Frame, Glow, MuzzleFlash, OL, Shine, ShineGrad, Twinkle, star, type P } from "./weapons";

/* =============================================================
   6. SUPER SOAKER — blue/green water blaster with orange tank
   ============================================================= */
export function SuperSoaker({ shot }: P) {
  return (
    <Frame
      shot={shot}
      defs={
        <>
          <linearGradient id="ws-blue" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stopColor="#b8f4ff" />
            <stop offset=".25" stopColor="#3cc8ff" />
            <stop offset=".7" stopColor="#1280e0" />
            <stop offset="1" stopColor="#083f8c" />
          </linearGradient>
          <linearGradient id="ws-green" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stopColor="#dfff9a" />
            <stop offset=".25" stopColor="#8be83a" />
            <stop offset=".7" stopColor="#3aa81a" />
            <stop offset="1" stopColor="#1b5a0c" />
          </linearGradient>
          <linearGradient id="ws-orange" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stopColor="#ffe6a0" />
            <stop offset=".3" stopColor="#ffb02e" />
            <stop offset=".75" stopColor="#e86a0c" />
            <stop offset="1" stopColor="#8a3404" />
          </linearGradient>
          <linearGradient id="ws-tank" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stopColor="#ffffff" stopOpacity=".95" />
            <stop offset=".3" stopColor="#8fe6ff" stopOpacity=".85" />
            <stop offset="1" stopColor="#1c7ad6" />
          </linearGradient>
          <linearGradient id="ws-water" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stopColor="#5fd8ff" />
            <stop offset="1" stopColor="#0d66c8" />
          </linearGradient>
          <linearGradient id="ws-splash" x1="0" y1="0" x2="1" y2="0">
            <stop offset="0" stopColor="#9ff0ff" />
            <stop offset="1" stopColor="#2aa6ff" stopOpacity="0" />
          </linearGradient>
          <ShineGrad id="ws-shine" />
          <clipPath id="ws-clip">
            <rect x="112" y="78" width="200" height="40" rx="12" />
            <rect x="140" y="38" width="130" height="40" rx="20" />
          </clipPath>
          <clipPath id="ws-tankclip">
            <rect x="146" y="40" width="118" height="36" rx="18" />
          </clipPath>
          <Glow id="ws-glow" std={4} />
          <Glow id="ws-soft" std={2} />
          <DropShadow id="ws-ds" />
          <Blur id="ws-blur" />
        </>
      }
      back={
        <>
          <Aura p="ws" c1="#3cc8ff" c2="#8be83a" />
          <ellipse cx="200" cy="115" rx="165" ry="70" fill="#2aa6ff" opacity=".16" filter="url(#ws-glow)" className="glow-pulse" />
          {/* water swirl */}
          <g className="vortex" opacity=".55">
            <path d="M40 120 C60 40 300 30 352 92" fill="none" stroke="url(#ws-splash)" strokeWidth="14" strokeLinecap="round" filter="url(#ws-soft)" />
            <path d="M360 120 C340 200 110 210 50 150" fill="none" stroke="url(#ws-splash)" strokeWidth="10" strokeLinecap="round" filter="url(#ws-soft)" />
          </g>
          {[
            [56, 60, 1],
            [348, 170, 0.8],
            [330, 48, 0.6],
            [70, 180, 0.7],
            [300, 200, 0.5],
          ].map(([x, y, s], i) => (
            <g key={i} transform={`translate(${x} ${y}) scale(${s})`}>
              <path className="droplet" style={{ animationDelay: `${i * 0.5}s` }} d="M0 -12 C6 -2 9 3 9 7 A9 9 0 1 1 -9 7 C-9 3 -6 -2 0 -12Z" fill="url(#ws-water)" stroke="#063a7a" strokeWidth="1.5" />
              <circle cx="-3" cy="4" r="2" fill="#fff" opacity=".8" />
            </g>
          ))}
          <Twinkle x={120} y={44} s={0.8} color="#c8f6ff" />
          <Twinkle x={366} y={120} s={0.6} color="#fff" delay={1.2} />
        </>
      }
    >
      <ellipse cx="205" cy="214" rx="140" ry="9" fill="#000" opacity=".45" filter="url(#ws-blur)" />
      <g transform="rotate(-10 200 120)">
        <g className="recoil" style={{ transformOrigin: "140px 170px", "--rx": "-8px", "--rr": "-3deg" } as CSSProperties}>
          <g filter="url(#ws-ds)">
            {/* grip */}
            <path d="M136 112 L184 112 L176 192 Q174 204 162 204 L136 204 Q124 204 126 192 Z" fill="url(#ws-green)" {...OL} />
            <path d="M142 118 L176 118" stroke="#dfff9a" strokeWidth="2.5" strokeLinecap="round" opacity=".9" />
            {[134, 148, 162].map((y) => (
              <path key={y} d={`M${138 - (y - 134) / 7} ${y} L${174 - (y - 134) / 7} ${y}`} stroke="#1b5a0c" strokeWidth="3" strokeLinecap="round" opacity=".55" />
            ))}
            <path d="M128 196 L172 196" stroke="#ffb02e" strokeWidth="4" strokeLinecap="round" />
            {/* trigger */}
            <path d="M184 118 Q190 150 218 146 L222 120" fill="none" stroke="#1a0a05" strokeWidth="9" strokeLinecap="round" />
            <path d="M184 118 Q190 150 218 146 L222 120" fill="none" stroke="#ffb02e" strokeWidth="4.5" strokeLinecap="round" />
            <path d="M198 122 Q194 136 204 142" fill="none" stroke="#1a0a05" strokeWidth="7" strokeLinecap="round" />
            <path d="M198 122 Q194 136 204 142" fill="none" stroke="#ffe6a0" strokeWidth="3" strokeLinecap="round" />
            {/* rear cap */}
            <rect x="92" y="80" width="30" height="36" rx="8" fill="url(#ws-orange)" {...OL} />
            <path d="M98 86 L116 86" stroke="#fff" strokeOpacity=".7" strokeWidth="2" strokeLinecap="round" />
            {/* main body */}
            <rect x="112" y="78" width="200" height="40" rx="12" fill="url(#ws-blue)" {...OL} />
            <path d="M120 85 L304 85" stroke="#fff" strokeOpacity=".75" strokeWidth="3" strokeLinecap="round" />
            <path d="M120 112 L304 112" stroke="#083f8c" strokeOpacity=".5" strokeWidth="2.5" strokeLinecap="round" />
            <rect x="222" y="82" width="10" height="32" rx="3" fill="url(#ws-green)" stroke="#1a0a05" strokeWidth="2" />
            <rect x="240" y="82" width="10" height="32" rx="3" fill="url(#ws-green)" stroke="#1a0a05" strokeWidth="2" />
            <path d="M225 86 L225 108 M243 86 L243 108" stroke="#dfff9a" strokeWidth="1.5" strokeLinecap="round" opacity=".8" />
            <circle cx="160" cy="98" r="7" fill="#fff" stroke="#1a0a05" strokeWidth="2" />
            <circle cx="160" cy="98" r="3" fill="#1280e0" />
            {/* splash decal */}
            <path d="M184 92 C188 86 196 86 198 92 C204 90 208 96 204 100 C208 104 202 110 196 106 C192 112 184 108 186 102 C180 100 180 94 184 92Z" fill="#fff" opacity=".85" />
            <path d="M190 96 L196 100 M196 95 L191 101" stroke="#1280e0" strokeWidth="1.5" strokeLinecap="round" />
            {/* pump handle (slides) */}
            <g className="pump">
              <rect x="256" y="104" width="54" height="20" rx="9" fill="url(#ws-orange)" {...OL} />
              <path d="M262 109 L302 109" stroke="#fff" strokeOpacity=".7" strokeWidth="2" strokeLinecap="round" />
              {[268, 280, 292].map((x) => (
                <rect key={x} x={x} y="113" width="4" height="8" rx="2" fill="#8a3404" opacity=".6" />
              ))}
            </g>
            {/* nozzle */}
            <rect x="306" y="84" width="40" height="28" rx="7" fill="url(#ws-green)" {...OL} />
            <path d="M312 89 L338 89" stroke="#dfff9a" strokeWidth="2.5" strokeLinecap="round" />
            <rect x="340" y="88" width="26" height="20" rx="5" fill="url(#ws-orange)" {...OL} />
            <ellipse cx="366" cy="98" rx="3.5" ry="7" fill="#0a2a5a" />
            <ellipse cx="366" cy="98" rx="1.8" ry="4" fill="#3cc8ff" filter="url(#ws-soft)" className="glow-pulse" />
            {/* tank mounts */}
            <rect x="160" y="66" width="18" height="18" rx="3" fill="url(#ws-orange)" {...OL} strokeWidth={2.5} />
            <rect x="236" y="66" width="18" height="18" rx="3" fill="url(#ws-orange)" {...OL} strokeWidth={2.5} />
            <path d="M164 70 L174 70 M240 70 L250 70" stroke="#fff" strokeOpacity=".7" strokeWidth="2" strokeLinecap="round" />
            {/* tank */}
            <rect x="140" y="38" width="130" height="40" rx="20" fill="url(#ws-tank)" {...OL} />
            <g clipPath="url(#ws-tankclip)">
              <rect x="140" y="56" width="130" height="24" fill="url(#ws-water)" opacity=".9" />
              <path className="wave" d="M100 58 q10 -5 20 0 t20 0 t20 0 t20 0 t20 0 t20 0 t20 0 t20 0 t20 0 V80 H100Z" fill="#2aa6ff" />
              <path className="wave w2" d="M100 60 q10 -4 20 0 t20 0 t20 0 t20 0 t20 0 t20 0 t20 0 t20 0 t20 0 V80 H100Z" fill="#0d66c8" opacity=".7" />
              {[
                [170, 70, 2],
                [200, 66, 1.5],
                [230, 72, 2.4],
                [250, 64, 1.2],
              ].map(([x, y, r], i) => (
                <circle key={i} className="bubble" style={{ animationDelay: `${i * 0.6}s` }} cx={x} cy={y} r={r} fill="#fff" opacity=".8" />
              ))}
            </g>
            <path d="M150 46 L250 46" stroke="#fff" strokeWidth="4" strokeLinecap="round" opacity=".9" />
            <rect x="140" y="38" width="130" height="40" rx="20" fill="none" {...OL} />
            <circle cx="152" cy="58" r="8" fill="url(#ws-green)" stroke="#1a0a05" strokeWidth="2" />
            <circle cx="152" cy="58" r="3" fill="#dfff9a" />
            <rect x="262" y="50" width="16" height="16" rx="4" fill="url(#ws-orange)" {...OL} strokeWidth={2.5} />
            <text x="206" y="62" textAnchor="middle" fontSize="10" fontWeight="900" fill="#083f8c" fontFamily="Lilita One, Impact, sans-serif" opacity=".85">
              H2O
            </text>
            <Shine clip="ws-clip" grad="ws-shine" />
          </g>
          {/* spray (no projectile — just a splash burst at the nozzle) */}
          <g className="splash" transform="translate(368 98)">
            {[-28, -14, 0, 14, 28].map((a, i) => (
              <path key={a} className="jet" style={{ animationDelay: `${i * 0.03}s` }} d="M0 0 Q22 -3 46 0 Q22 3 0 0Z" fill="#9ff0ff" transform={`rotate(${a})`} filter="url(#ws-soft)" />
            ))}
          </g>
          <MuzzleFlash x={370} y={98} c1="#e6fbff" c2="#3cc8ff" c3="#1280e0" filter="ws-soft" scale={0.9} />
        </g>
      </g>
    </Frame>
  );
}

/* =============================================================
   7. FIREWORK LAUNCHER — red/blue striped rocket tube
   ============================================================= */
export function FireworkLauncher({ shot }: P) {
  return (
    <Frame
      shot={shot}
      defs={
        <>
          <linearGradient id="fw-red" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stopColor="#ff8a8a" />
            <stop offset=".3" stopColor="#e8182c" />
            <stop offset=".8" stopColor="#8e0416" />
            <stop offset="1" stopColor="#4a0109" />
          </linearGradient>
          <linearGradient id="fw-blue" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stopColor="#8ab0ff" />
            <stop offset=".3" stopColor="#1f4fd6" />
            <stop offset=".8" stopColor="#0d2a86" />
            <stop offset="1" stopColor="#061648" />
          </linearGradient>
          <linearGradient id="fw-gold" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stopColor="#fff6c2" />
            <stop offset=".3" stopColor="#ffd34d" />
            <stop offset=".7" stopColor="#d08a10" />
            <stop offset="1" stopColor="#7a470a" />
          </linearGradient>
          <linearGradient id="fw-cone" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stopColor="#ff9a7a" />
            <stop offset=".4" stopColor="#ff4a3a" />
            <stop offset="1" stopColor="#9a1210" />
          </linearGradient>
          <radialGradient id="fw-fire" cx=".5" cy=".5" r=".5">
            <stop offset="0" stopColor="#fff8c2" />
            <stop offset=".35" stopColor="#ffb52e" />
            <stop offset=".75" stopColor="#ff5a1a" stopOpacity=".8" />
            <stop offset="1" stopColor="#ff2a1a" stopOpacity="0" />
          </radialGradient>
          <ShineGrad id="fw-shine" />
          <clipPath id="fw-clip">
            <rect x="84" y="70" width="230" height="58" rx="10" />
          </clipPath>
          <Glow id="fw-glow" std={4} />
          <Glow id="fw-soft" std={2} />
          <DropShadow id="fw-ds" />
          <Blur id="fw-blur" />
        </>
      }
      back={
        <>
          <Aura p="fw" c1="#ffd34d" c2="#e8182c" />
          <ellipse cx="200" cy="115" rx="165" ry="72" fill="#ff6a2a" opacity=".14" filter="url(#fw-glow)" className="glow-pulse" />
          {/* bursting fireworks in the sky */}
          {[
            [60, 56, "#ff5a7a", 0],
            [340, 44, "#5fe1ff", 1.1],
            [350, 180, "#ffd34d", 2.2],
            [70, 180, "#8be83a", 0.6],
          ].map(([x, y, c, d], i) => (
            <g key={i} transform={`translate(${x} ${y})`} className="fwburst" style={{ animationDelay: `${d}s` }}>
              {Array.from({ length: 12 }).map((_, k) => (
                <line key={k} x1="0" y1="0" x2="0" y2="-22" stroke={c as string} strokeWidth="2" strokeLinecap="round" transform={`rotate(${k * 30})`} />
              ))}
              {Array.from({ length: 12 }).map((_, k) => (
                <circle key={`c${k}`} cx="0" cy="-24" r="1.8" fill="#fff" transform={`rotate(${k * 30 + 15})`} />
              ))}
            </g>
          ))}
          <Twinkle x={150} y={40} s={0.8} color="#fff3b0" />
          <Twinkle x={290} y={196} s={0.6} color="#ffd34d" delay={1.4} />
        </>
      }
    >
      <ellipse cx="205" cy="216" rx="150" ry="9" fill="#000" opacity=".45" filter="url(#fw-blur)" />
      <g transform="rotate(-12 200 115)">
        <g className="recoil" style={{ transformOrigin: "140px 170px", "--rx": "-20px", "--rr": "-6deg" } as CSSProperties}>
          {/* back blast */}
          <g className="backblast" filter="url(#fw-glow)">
            <path d="M84 84 L30 70 Q10 99 30 128 L84 114 Z" fill="url(#fw-fire)" />
            <path d="M84 90 L48 82 Q38 99 48 116 L84 108 Z" fill="#fff6c2" opacity=".7" />
          </g>
          <g filter="url(#fw-ds)">
            {/* grip */}
            <path d="M132 126 L178 126 L166 196 Q164 206 152 206 L128 204 Q118 202 120 190 Z" fill="url(#fw-red)" {...OL} />
            <path d="M138 132 L172 132" stroke="#ff8a8a" strokeWidth="2.5" strokeLinecap="round" opacity=".9" />
            <path d="M136 146 L170 146 L168 156 L134 156 Z" fill="url(#fw-gold)" stroke="#1a0a05" strokeWidth="2" />
            <polygon points={star(152, 176, 7, 3)} fill="#ffd34d" stroke="#7a470a" strokeWidth=".8" />
            {/* trigger */}
            <path d="M178 132 Q184 164 212 160 L216 134" fill="none" stroke="#1a0a05" strokeWidth="9" strokeLinecap="round" />
            <path d="M178 132 Q184 164 212 160 L216 134" fill="none" stroke="url(#fw-gold)" strokeWidth="4.5" strokeLinecap="round" />
            <path d="M192 136 Q188 150 198 156" fill="none" stroke="#1a0a05" strokeWidth="7" strokeLinecap="round" />
            <path d="M192 136 Q188 150 198 156" fill="none" stroke="#ffd34d" strokeWidth="3" strokeLinecap="round" />
            {/* foregrip */}
            <path d="M240 128 L262 128 L258 160 Q257 166 250 166 L244 166 Q238 166 238 160 Z" fill="url(#fw-blue)" {...OL} />
            <path d="M244 134 L258 134 M243 142 L257 142 M243 150 L256 150" stroke="#061648" strokeWidth="2" strokeLinecap="round" opacity=".7" />
            {/* tube */}
            <rect x="84" y="70" width="230" height="58" rx="10" fill="url(#fw-red)" {...OL} />
            {[0, 1, 2].map((i) => (
              <rect key={i} x={114 + i * 72} y={70} width={30} height={58} fill="url(#fw-blue)" />
            ))}
            <path d="M90 78 L308 78" stroke="#fff" strokeOpacity=".65" strokeWidth="3.5" strokeLinecap="round" />
            <path d="M90 121 L308 121" stroke="#000" strokeOpacity=".35" strokeWidth="3" strokeLinecap="round" />
            {/* stars on tube */}
            {[100, 160, 232, 300].map((x) => (
              <polygon key={x} points={star(x, 99, 9, 3.8)} fill="#ffd34d" stroke="#7a470a" strokeWidth="1" />
            ))}
            {[129, 201, 273].map((x) => (
              <g key={x}>
                <polygon points={star(x, 88, 5, 2.1)} fill="#fff6c2" />
                <polygon points={star(x, 110, 5, 2.1)} fill="#fff6c2" />
              </g>
            ))}
            {/* gold bands */}
            {[82, 310].map((x) => (
              <rect key={x} x={x} y="64" width="16" height="70" rx="5" fill="url(#fw-gold)" {...OL} />
            ))}
            <rect x="180" y="62" width="14" height="74" rx="4" fill="url(#fw-gold)" {...OL} />
            <path d="M85 70 L95 70 M313 70 L323 70 M183 68 L191 68" stroke="#fff" strokeOpacity=".7" strokeWidth="2" strokeLinecap="round" />
            {/* sight */}
            <path d="M200 62 L204 48 L216 48 L220 62 Z" fill="url(#fw-gold)" {...OL} strokeWidth={2.5} />
            <circle cx="210" cy="55" r="2.5" fill="#e8182c" />
            {/* rear exhaust cone */}
            <path d="M84 76 L62 66 Q54 66 54 74 L54 124 Q54 132 62 132 L84 122 Z" fill="url(#fw-gold)" {...OL} />
            <path d="M60 72 L60 126" stroke="#7a470a" strokeWidth="2" />
            <ellipse cx="56" cy="99" rx="4" ry="22" fill="#2a1200" />
            {/* rocket head (nose cone) protruding */}
            <g className="rocket">
              <path d="M322 74 L348 74 L382 99 L348 124 L322 124 Z" fill="url(#fw-cone)" {...OL} />
              <path d="M326 80 L348 80 L370 96" fill="none" stroke="#ffd0b0" strokeWidth="2.5" strokeLinecap="round" opacity=".9" />
              <rect x="318" y="68" width="14" height="62" rx="4" fill="url(#fw-gold)" {...OL} />
              <polygon points={star(352, 99, 7, 3)} fill="#ffd34d" stroke="#7a470a" strokeWidth=".8" />
              {/* fuse */}
              <path className="fuse" d="M382 99 Q392 92 396 84" fill="none" stroke="#1a0a05" strokeWidth="4" strokeLinecap="round" />
              <path className="fuse" d="M382 99 Q392 92 396 84" fill="none" stroke="#d9a05a" strokeWidth="2" strokeLinecap="round" />
              <g className="spark-wrap" transform="translate(396 84)">
                <circle className="fuse-spark" r="4" fill="#fff6c2" filter="url(#fw-soft)" />
                {Array.from({ length: 6 }).map((_, i) => (
                  <line key={i} className="fuse-ray" x1="0" y1="0" x2="0" y2="-9" stroke="#ffb52e" strokeWidth="1.5" strokeLinecap="round" transform={`rotate(${i * 60})`} />
                ))}
              </g>
            </g>
            <Shine clip="fw-clip" grad="fw-shine" />
          </g>
          <MuzzleFlash x={384} y={99} c1="#fff6c2" c2="#ffb52e" c3="#ff3a1a" filter="fw-soft" scale={1.25} sparks={14} />
        </g>
      </g>
    </Frame>
  );
}

/* =============================================================
   8. VOID PLASMA — black pistol with green plasma barrel
   ============================================================= */
export function PlasmaPistol({ shot }: P) {
  const g = "#5bff5b";
  return (
    <Frame
      shot={shot}
      defs={
        <>
          <linearGradient id="pl-body" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stopColor="#5f6b7a" />
            <stop offset=".3" stopColor="#2a313d" />
            <stop offset=".75" stopColor="#12161d" />
            <stop offset="1" stopColor="#06080b" />
          </linearGradient>
          <linearGradient id="pl-dark" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stopColor="#3a4250" />
            <stop offset="1" stopColor="#0a0d12" />
          </linearGradient>
          <linearGradient id="pl-tube" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stopColor="#e8ffe8" stopOpacity=".9" />
            <stop offset=".3" stopColor="#5bff5b" stopOpacity=".55" />
            <stop offset="1" stopColor="#0a4a14" stopOpacity=".9" />
          </linearGradient>
          <radialGradient id="pl-core" cx=".5" cy=".5" r=".5">
            <stop offset="0" stopColor="#ffffff" />
            <stop offset=".4" stopColor="#8dff8d" />
            <stop offset="1" stopColor="#0f8a2a" stopOpacity="0" />
          </radialGradient>
          <linearGradient id="pl-beam" x1="0" y1="0" x2="1" y2="0">
            <stop offset="0" stopColor="#5bff5b" stopOpacity=".9" />
            <stop offset="1" stopColor="#5bff5b" stopOpacity="0" />
          </linearGradient>
          <ShineGrad id="pl-shine" />
          <clipPath id="pl-clip">
            <path d="M116 84 L250 84 L250 120 L116 120 Z" />
          </clipPath>
          <Glow id="pl-glow" std={3} />
          <Glow id="pl-big" std={8} />
          <DropShadow id="pl-ds" />
          <Blur id="pl-blur" />
        </>
      }
      back={
        <>
          <Aura p="pl" c1="#5bff5b" c2="#a855f7" />
          <ellipse cx="200" cy="115" rx="160" ry="80" fill="#22c55e" opacity=".16" filter="url(#pl-big)" className="glow-pulse" />
          <g className="vortex vortex-rev">
            <circle cx="200" cy="115" r="96" fill="none" stroke={g} strokeOpacity=".25" strokeWidth="1.5" strokeDasharray="6 14" />
          </g>
          {[
            [56, 64],
            [340, 190],
            [350, 52],
            [70, 186],
          ].map(([x, y], i) => (
            <g key={i} transform={`translate(${x} ${y})`}>
              <path className="twinkle" style={{ animationDelay: `${i * 0.5}s` }} d="M0 -7 L4.5 0 L0 7 L-4.5 0 Z" fill="#9dff9d" />
            </g>
          ))}
        </>
      }
    >
      <ellipse cx="205" cy="214" rx="145" ry="9" fill="#000" opacity=".5" filter="url(#pl-blur)" />
      <g transform="rotate(-16 200 115)">
        <g className="recoil" style={{ transformOrigin: "150px 170px", "--rx": "-14px", "--rr": "-6deg" } as CSSProperties}>
          {/* ambient glow beam behind barrel (no projectile; it's barrel light) */}
          <path className="beam-glow" d="M250 92 L392 96 L392 112 L250 116 Z" fill="url(#pl-beam)" opacity=".35" filter="url(#pl-big)" />
          <g filter="url(#pl-ds)">
            <g stroke="#04050a" strokeWidth="2.5" strokeLinejoin="round">
              {/* grip */}
              <path d="M126 118 L170 118 L158 186 Q156 196 146 196 L124 194 Q114 192 116 182 Z" fill="url(#pl-body)" />
              {/* frame */}
              <path d="M110 84 L252 84 L256 120 L204 124 L196 120 L112 120 Z" fill="url(#pl-body)" />
              <rect x="116" y="76" width="130" height="9" rx="2" fill="#1d2230" />
              {/* rear sight + hammer */}
              <path d="M104 86 L98 72 L112 72 L114 86 Z" fill="url(#pl-dark)" />
              {/* under-barrel */}
              <path d="M252 112 L336 110 L336 122 L252 124 Z" fill="url(#pl-dark)" />
              {/* front muzzle housing */}
              <path d="M340 78 L372 76 Q380 76 380 84 L380 116 Q380 124 372 124 L340 122 Z" fill="url(#pl-dark)" />
            </g>
            <path d="M132 124 L160 124 M131 134 L158 134 M130 144 L156 144 M129 154 L154 154" stroke="#04050a" strokeWidth="2" />
            <path d="M118 88 L248 88" stroke="#fff" strokeOpacity=".2" strokeWidth="2" />
            {Array.from({ length: 14 }).map((_, i) => (
              <rect key={i} x={120 + i * 9} y={78} width={4} height={4} fill="#0a0c12" />
            ))}
            {/* trigger */}
            <path d="M170 122 Q172 144 198 142 L202 124" fill="none" stroke="#04050a" strokeWidth="7" strokeLinecap="round" />
            <path d="M170 122 Q172 144 198 142 L202 124" fill="none" stroke="#2a3040" strokeWidth="3.5" strokeLinecap="round" />
            <path d="M182 124 Q180 132 186 136" fill="none" stroke={g} strokeWidth="2.5" strokeLinecap="round" filter="url(#pl-glow)" />
            {/* glass plasma barrel */}
            <rect x="248" y="86" width="100" height="30" rx="8" fill="#031a08" stroke="#04050a" strokeWidth="2.5" />
            <rect x="250" y="88" width="96" height="26" rx="7" fill="url(#pl-tube)" />
            <g filter="url(#pl-glow)">
              <path className="plasma p1" d="M252 101 L262 94 L270 106 L280 96 L290 105 L300 95 L310 106 L320 96 L330 104 L344 100" fill="none" stroke={g} strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
              <path className="plasma p2" d="M252 100 L264 106 L274 95 L284 104 L294 96 L306 105 L316 95 L326 105 L336 97 L344 102" fill="none" stroke="#e8ffe8" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
            </g>
            <path d="M254 91 L340 91" stroke="#fff" strokeOpacity=".75" strokeWidth="2.5" strokeLinecap="round" />
            {/* barrel rings */}
            {[262, 300, 334].map((x) => (
              <g key={x}>
                <rect x={x} y="82" width="10" height="38" rx="3" fill="url(#pl-body)" stroke="#04050a" strokeWidth="2.5" />
                <rect x={x + 3.5} y="86" width="3" height="30" fill={g} opacity=".9" filter="url(#pl-glow)" className="glow-pulse" />
              </g>
            ))}
            {/* slide cells */}
            {[140, 170, 200, 230].map((x) => (
              <g key={x}>
                <rect x={x} y="94" width="18" height="12" rx="2" fill="#031a08" stroke="#04050a" strokeWidth="1.5" />
                <rect x={x + 2} y="96" width="14" height="8" rx="1.5" fill={g} opacity=".85" filter="url(#pl-glow)" className="neon-fire" />
              </g>
            ))}
            <path className="trace" d="M118 114 H250" fill="none" stroke={g} strokeWidth="1.2" strokeDasharray="8 60" opacity=".8" />
            {/* grip core */}
            <circle cx="142" cy="170" r="7" fill="#031a08" stroke="#04050a" strokeWidth="2" />
            <circle cx="142" cy="170" r="4" fill={g} filter="url(#pl-glow)" className="glow-pulse" />
            {/* muzzle emitter */}
            <path d="M372 86 L372 114" stroke="#1d2230" strokeWidth="2" />
            <circle cx="380" cy="100" r="10" fill="#031a08" stroke="#04050a" strokeWidth="2.5" />
            <circle className="orb" cx="380" cy="100" r="9" fill="url(#pl-core)" filter="url(#pl-glow)" />
            <circle cx="380" cy="100" r="3" fill="#fff" />
            {/* emitter prongs */}
            <path d="M376 80 L392 86 M376 120 L392 114" stroke="#2a313d" strokeWidth="5" strokeLinecap="round" />
            <path d="M376 80 L392 86 M376 120 L392 114" stroke={g} strokeWidth="1.5" strokeLinecap="round" opacity=".8" />
            <Shine clip="pl-clip" grad="pl-shine" />
          </g>
          <MuzzleFlash x={384} y={100} c1="#eaffea" c2="#8dff8d" c3="#13c13a" filter="pl-glow" scale={1.05} />
        </g>
      </g>
    </Frame>
  );
}

/* =============================================================
   9. CARD GUN — red/white casino pistol shooting playing cards
   ============================================================= */
function Pip({ suit, x, y, s = 1, color }: { suit: "♠" | "♥" | "♦" | "♣"; x: number; y: number; s?: number; color: string }) {
  return (
    <text x={x} y={y} textAnchor="middle" fontSize={12 * s} fontWeight="900" fill={color} fontFamily="Georgia, 'Times New Roman', serif">
      {suit}
    </text>
  );
}

function PlayingCard({ x, y, r, suit, color, cls, delay }: { x: number; y: number; r: number; suit: "♠" | "♥" | "♦" | "♣"; color: string; cls?: string; delay?: string }) {
  return (
    <g transform={`translate(${x} ${y}) rotate(${r})`}>
      <g className={cls} style={{ animationDelay: delay }}>
        <rect x="-9" y="-13" width="18" height="26" rx="2.5" fill="#fff" stroke="#1a0a05" strokeWidth="1.5" />
        <Pip suit={suit} x={0} y={4} s={1} color={color} />
        <text x="-6.5" y="-6" fontSize="5" fontWeight="700" fill={color} fontFamily="Georgia, serif">
          A
        </text>
      </g>
    </g>
  );
}

export function CardGun({ shot }: P) {
  return (
    <Frame
      shot={shot}
      defs={
        <>
          <linearGradient id="cg-red" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stopColor="#ff7a86" />
            <stop offset=".3" stopColor="#e8182c" />
            <stop offset=".8" stopColor="#8e0416" />
            <stop offset="1" stopColor="#4a0109" />
          </linearGradient>
          <linearGradient id="cg-white" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stopColor="#ffffff" />
            <stop offset=".5" stopColor="#eef0f6" />
            <stop offset="1" stopColor="#aeb5c8" />
          </linearGradient>
          <linearGradient id="cg-gold" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stopColor="#fff6c2" />
            <stop offset=".3" stopColor="#ffd34d" />
            <stop offset=".7" stopColor="#d08a10" />
            <stop offset="1" stopColor="#7a470a" />
          </linearGradient>
          <linearGradient id="cg-cyan" x1="0" y1="0" x2="1" y2="0">
            <stop offset="0" stopColor="#5fe1ff" />
            <stop offset="1" stopColor="#5fe1ff" stopOpacity="0" />
          </linearGradient>
          <ShineGrad id="cg-shine" />
          <clipPath id="cg-clip">
            <path d="M96 80 L330 80 L334 124 L96 124 Z" />
          </clipPath>
          <Glow id="cg-glow" std={4} />
          <Glow id="cg-soft" std={2} />
          <DropShadow id="cg-ds" />
          <Blur id="cg-blur" />
        </>
      }
      back={
        <>
          <Aura p="cg" c1="#ff5c6a" c2="#5fe1ff" />
          <ellipse cx="200" cy="115" rx="165" ry="72" fill="#ff2a4a" opacity=".13" filter="url(#cg-glow)" className="glow-pulse" />
          {/* floating cards around */}
          <PlayingCard x={48} y={70} r={-20} suit="♥" color="#e8182c" cls="card-float" />
          <PlayingCard x={356} y={170} r={16} suit="♠" color="#1a0a05" cls="card-float" delay="0.8s" />
          <PlayingCard x={360} y={60} r={28} suit="♦" color="#e8182c" cls="card-float" delay="1.5s" />
          <PlayingCard x={60} y={186} r={-12} suit="♣" color="#1a0a05" cls="card-float" delay="2.2s" />
          {/* poker chips */}
          {[
            [330, 206, "#e8182c"],
            [96, 44, "#1f4fd6"],
          ].map(([x, y, c], i) => (
            <g key={i} transform={`translate(${x} ${y})`} className="chip" style={{ animationDelay: `${i * 0.7}s` }}>
              <circle r="9" fill={c as string} stroke="#1a0a05" strokeWidth="1.5" />
              <circle r="9" fill="none" stroke="#fff" strokeWidth="2.5" strokeDasharray="4 4" />
              <circle r="4" fill="#fff" />
            </g>
          ))}
          <Twinkle x={150} y={40} s={0.7} color="#fff" />
          <Twinkle x={286} y={200} s={0.6} color="#ffd34d" delay={1.1} />
        </>
      }
    >
      <ellipse cx="205" cy="214" rx="150" ry="9" fill="#000" opacity=".45" filter="url(#cg-blur)" />
      <g transform="rotate(-8 200 115)">
        <g className="recoil" style={{ transformOrigin: "140px 170px", "--rx": "-12px", "--rr": "-6deg" } as CSSProperties}>
          <g filter="url(#cg-ds)">
            {/* card magazine on top — fan of cards */}
            <g className="card-fan" transform="translate(150 70)">
              {[
                [-18, "♥", "#e8182c"],
                [-9, "♠", "#1a0a05"],
                [0, "♦", "#e8182c"],
                [9, "♣", "#1a0a05"],
                [18, "♥", "#e8182c"],
              ].map(([r, s, c], i) => (
                <g key={i} className="fan-card" style={{ animationDelay: `${i * 0.04}s` }} transform={`rotate(${r} 0 26)`}>
                  <rect x="-10" y="-30" width="20" height="40" rx="3" fill="#fff" stroke="#1a0a05" strokeWidth="1.8" />
                  <Pip suit={s as "♥"} x={0} y={-6} s={1.1} color={c as string} />
                  <text x="-7" y="-21" fontSize="6" fontWeight="700" fill={c as string} fontFamily="Georgia, serif">
                    A
                  </text>
                </g>
              ))}
            </g>
            {/* grip */}
            <path d="M118 120 L166 120 L156 192 Q154 204 142 204 L118 202 Q106 200 108 188 Z" fill="url(#cg-red)" {...OL} />
            <path d="M124 126 L160 126" stroke="#ff9aa4" strokeWidth="2.5" strokeLinecap="round" opacity=".9" />
            <path d="M122 140 L160 140 L152 182 L116 182 Z" fill="url(#cg-white)" stroke="#1a0a05" strokeWidth="2" />
            <Pip suit="♠" x={137} y={166} s={1.6} color="#1a0a05" />
            <text x="126" y="150" fontSize="8" fontWeight="700" fill="#e8182c" fontFamily="Georgia, serif">
              A
            </text>
            {/* trigger */}
            <path d="M168 124 Q174 156 202 152 L206 126" fill="none" stroke="#1a0a05" strokeWidth="9" strokeLinecap="round" />
            <path d="M168 124 Q174 156 202 152 L206 126" fill="none" stroke="url(#cg-gold)" strokeWidth="4.5" strokeLinecap="round" />
            <path d="M182 128 Q178 142 188 148" fill="none" stroke="#1a0a05" strokeWidth="7" strokeLinecap="round" />
            <path d="M182 128 Q178 142 188 148" fill="none" stroke="#ffd34d" strokeWidth="3" strokeLinecap="round" />
            {/* body */}
            <path d="M96 80 L330 80 L334 124 L96 124 Z" fill="url(#cg-red)" {...OL} />
            <path d="M104 86 L324 86" stroke="#ff9aa4" strokeWidth="3" strokeLinecap="round" opacity=".9" />
            <path d="M104 118 L324 118" stroke="#4a0109" strokeWidth="2.5" strokeLinecap="round" opacity=".6" />
            {/* white panel with cards */}
            <path d="M196 86 L318 86 L320 118 L196 118 Z" fill="url(#cg-white)" stroke="#1a0a05" strokeWidth="2.5" strokeLinejoin="round" />
            <path d="M200 90 L314 90" stroke="#fff" strokeWidth="2" strokeLinecap="round" />
            {[
              [212, "♠", "#1a0a05"],
              [236, "♥", "#e8182c"],
              [260, "♦", "#e8182c"],
              [284, "♣", "#1a0a05"],
            ].map(([x, s, c]) => (
              <g key={x as number}>
                <rect x={(x as number) - 9} y="91" width="18" height="24" rx="2" fill="#fff" stroke="#1a0a05" strokeWidth="1.3" />
                <Pip suit={s as "♥"} x={x as number} y={108} s={1.1} color={c as string} />
              </g>
            ))}
            <rect x="300" y="92" width="14" height="22" rx="2" fill="#ffd34d" stroke="#7a470a" strokeWidth="1.3" />
            <polygon points={star(307, 103, 5, 2)} fill="#e8182c" />
            {/* gold rails */}
            <rect x="98" y="74" width="236" height="8" rx="3" fill="url(#cg-gold)" {...OL} strokeWidth={2.5} />
            <rect x="96" y="122" width="100" height="8" rx="3" fill="url(#cg-gold)" {...OL} strokeWidth={2.5} />
            <path d="M104 77 L326 77" stroke="#fff" strokeOpacity=".7" strokeWidth="2" strokeLinecap="round" />
            {/* diamond emblem */}
            <path d="M126 102 L140 90 L154 102 L140 114 Z" fill="url(#cg-gold)" stroke="#1a0a05" strokeWidth="2" strokeLinejoin="round" />
            <Pip suit="♦" x={140} y={107} s={1.1} color="#e8182c" />
            <circle cx="172" cy="102" r="8" fill="url(#cg-white)" stroke="#1a0a05" strokeWidth="2" />
            <Pip suit="♥" x={172} y={106} s={1} color="#e8182c" />
            {/* muzzle — card slot with cyan glow */}
            <rect x="330" y="84" width="22" height="36" rx="5" fill="url(#cg-gold)" {...OL} />
            <rect x="340" y="92" width="16" height="20" rx="2" fill="#0a1a2a" stroke="#1a0a05" strokeWidth="2" />
            <rect x="344" y="94" width="8" height="16" rx="1" fill="#5fe1ff" filter="url(#cg-soft)" className="glow-pulse" />
            <path d="M356 100 L392 94 L392 110 L356 104 Z" fill="url(#cg-cyan)" opacity=".5" filter="url(#cg-soft)" className="glow-pulse" />
            <Shine clip="cg-clip" grad="cg-shine" />
          </g>
          {/* burst of card confetti at muzzle when firing (they fade in place, no projectile) */}
          <g transform="translate(360 102)">
            {[
              [-30, "♥", "#e8182c"],
              [-10, "♠", "#1a0a05"],
              [10, "♦", "#e8182c"],
              [30, "♣", "#1a0a05"],
            ].map(([a, s, c], i) => (
              <g key={i} transform={`rotate(${a})`}>
                <g className="card-pop" style={{ animationDelay: `${i * 0.04}s` }}>
                  <rect x="12" y="-7" width="10" height="14" rx="1.5" fill="#fff" stroke="#1a0a05" strokeWidth="1" />
                  <Pip suit={s as "♥"} x={17} y={3} s={0.7} color={c as string} />
                </g>
              </g>
            ))}
          </g>
          <MuzzleFlash x={360} y={102} c1="#ffffff" c2="#5fe1ff" c3="#ff5c6a" filter="cg-soft" scale={1} />
        </g>
      </g>
    </Frame>
  );
}

/* =============================================================
   10. MINIGUN — gunmetal rotary cannon with 6 barrels
   ============================================================= */
export function Minigun({ shot }: P) {
  return (
    <Frame
      shot={shot}
      defs={
        <>
          <linearGradient id="mg-steel" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stopColor="#c9d2de" />
            <stop offset=".25" stopColor="#737e90" />
            <stop offset=".6" stopColor="#3a4150" />
            <stop offset="1" stopColor="#141820" />
          </linearGradient>
          <linearGradient id="mg-dark" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stopColor="#4a5262" />
            <stop offset=".5" stopColor="#1e232c" />
            <stop offset="1" stopColor="#07090d" />
          </linearGradient>
          <linearGradient id="mg-barrel" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stopColor="#aab4c4" />
            <stop offset=".4" stopColor="#4d5668" />
            <stop offset="1" stopColor="#161a22" />
          </linearGradient>
          <linearGradient id="mg-brass" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stopColor="#fff2b0" />
            <stop offset=".4" stopColor="#e2b23a" />
            <stop offset="1" stopColor="#7a4f08" />
          </linearGradient>
          <linearGradient id="mg-heat" x1="0" y1="0" x2="1" y2="0">
            <stop offset="0" stopColor="#ff6a00" stopOpacity="0" />
            <stop offset="1" stopColor="#ff3a00" stopOpacity=".9" />
          </linearGradient>
          <ShineGrad id="mg-shine" />
          <clipPath id="mg-clip">
            <rect x="92" y="78" width="130" height="56" rx="10" />
          </clipPath>
          <Glow id="mg-glow" std={3} />
          <Glow id="mg-soft" std={2} />
          <DropShadow id="mg-ds" />
          <Blur id="mg-blur" />
        </>
      }
      back={
        <>
          <Aura p="mg" c1="#c58bff" c2="#ffd34d" />
          <ellipse cx="200" cy="115" rx="165" ry="78" fill="#a855f7" opacity=".16" filter="url(#mg-glow)" className="glow-pulse" />
          {/* brass casings scattered (static sparkle, not projectiles) */}
          {[
            [330, 190, -30],
            [352, 178, 20],
            [300, 204, 60],
            [370, 150, -70],
            [60, 190, 25],
          ].map(([x, y, r], i) => (
            <g key={i} transform={`translate(${x} ${y}) rotate(${r})`} className="casing" style={{ animationDelay: `${i * 0.35}s` }}>
              <rect x="-7" y="-3" width="14" height="6" rx="1.5" fill="url(#mg-brass)" stroke="#4a2e05" strokeWidth="1" />
              <rect x="4" y="-2" width="3" height="4" fill="#7a4f08" />
              <path d="M-5 -1.5 L3 -1.5" stroke="#fff6c2" strokeWidth="1" strokeLinecap="round" />
            </g>
          ))}
          <Twinkle x={64} y={56} s={0.8} color="#e9e0ff" />
          <Twinkle x={352} y={44} s={0.6} color="#fff" delay={1.3} />
        </>
      }
    >
      <ellipse cx="205" cy="216" rx="150" ry="9" fill="#000" opacity=".5" filter="url(#mg-blur)" />
      <g transform="rotate(-8 200 115)">
        <g className="recoil" style={{ transformOrigin: "150px 170px", "--rx": "-5px", "--ry": "1px", "--rr": "-1.5deg" } as CSSProperties}>
          <g filter="url(#mg-ds)">
            {/* top carry handle */}
            <path d="M128 78 L128 62 Q128 54 136 54 L160 54 Q172 54 180 62 L180 78" fill="none" stroke="#07090d" strokeWidth="11" strokeLinecap="round" strokeLinejoin="round" />
            <path d="M128 78 L128 62 Q128 54 136 54 L160 54 Q172 54 180 62 L180 78" fill="none" stroke="url(#mg-steel)" strokeWidth="6" strokeLinecap="round" strokeLinejoin="round" />
            <circle cx="136" cy="58" r="3" fill="#ffd34d" stroke="#07090d" strokeWidth="1.5" />
            {/* rear motor housing */}
            <rect x="92" y="78" width="130" height="56" rx="10" fill="url(#mg-dark)" stroke="#07090d" strokeWidth="3" />
            <rect x="80" y="86" width="20" height="40" rx="5" fill="url(#mg-steel)" stroke="#07090d" strokeWidth="2.5" />
            <path d="M84 92 L84 120 M90 90 L90 122" stroke="#07090d" strokeWidth="1.5" opacity=".7" />
            <path d="M100 84 L214 84" stroke="#fff" strokeOpacity=".3" strokeWidth="2.5" strokeLinecap="round" />
            {/* vents */}
            {[110, 124, 138, 152].map((x) => (
              <rect key={x} x={x} y="94" width="7" height="26" rx="2" fill="#07090d" />
            ))}
            {[110, 124, 138, 152].map((x) => (
              <rect key={`g${x}`} x={x + 2.5} y="98" width="2" height="18" fill="#ff6a00" opacity=".7" filter="url(#mg-soft)" className="heat" />
            ))}
            {/* ammo feed */}
            <path d="M170 134 L210 134 L216 166 Q217 174 209 174 L178 174 Q170 174 170 166 Z" fill="url(#mg-dark)" stroke="#07090d" strokeWidth="2.5" />
            <path d="M176 142 L208 142 M177 152 L209 152 M179 162 L211 162" stroke="#07090d" strokeWidth="2" />
            {[180, 190, 200].map((x) => (
              <rect key={x} x={x} y="136" width="4" height="10" rx="1" fill="url(#mg-brass)" />
            ))}
            {/* grips */}
            <path d="M120 134 L148 134 L142 180 Q141 188 133 188 L124 188 Q116 188 116 180 Z" fill="url(#mg-dark)" stroke="#07090d" strokeWidth="2.5" />
            <path d="M124 146 L142 146 M123 156 L141 156 M122 166 L140 166" stroke="#07090d" strokeWidth="2" />
            <path d="M226 112 L248 112 L246 150 Q245 156 239 156 L232 156 Q226 156 226 150 Z" fill="url(#mg-dark)" stroke="#07090d" strokeWidth="2.5" />
            <path d="M230 122 L244 122 M230 132 L244 132 M230 142 L244 142" stroke="#07090d" strokeWidth="2" />
            {/* trigger */}
            <path d="M148 140 Q150 160 172 158" fill="none" stroke="#07090d" strokeWidth="7" strokeLinecap="round" />
            <path d="M148 140 Q150 160 172 158" fill="none" stroke="#4a5262" strokeWidth="3.5" strokeLinecap="round" />
            {/* barrel clamp (rear) */}
            <rect x="220" y="80" width="26" height="52" rx="6" fill="url(#mg-steel)" stroke="#07090d" strokeWidth="3" />
            <path d="M226 86 L240 86" stroke="#fff" strokeOpacity=".6" strokeWidth="2" strokeLinecap="round" />
            {/* rotating barrel cluster */}
            <g className="barrels">
              {/* six barrels: perspective rows (3 visible + 3 shaded) */}
              {[
                { y: 86, h: 9, f: "url(#mg-barrel)", o: 0.55 },
                { y: 118, h: 9, f: "url(#mg-barrel)", o: 0.55 },
                { y: 80, h: 10, f: "url(#mg-barrel)", o: 1 },
                { y: 122, h: 10, f: "url(#mg-barrel)", o: 1 },
                { y: 92, h: 12, f: "url(#mg-steel)", o: 1 },
                { y: 108, h: 12, f: "url(#mg-steel)", o: 1 },
              ].map((b, i) => (
                <g key={i} opacity={b.o}>
                  <rect x="246" y={b.y} width="118" height={b.h} rx={b.h / 2} fill={b.f} stroke="#07090d" strokeWidth="2.2" />
                  <path d={`M252 ${b.y + 2.5} L356 ${b.y + 2.5}`} stroke="#fff" strokeOpacity=".45" strokeWidth="1.5" strokeLinecap="round" />
                </g>
              ))}
              {/* heat glow at barrel tips (fires) */}
              <rect className="heat-tip" x="300" y="80" width="64" height="52" rx="8" fill="url(#mg-heat)" opacity="0" />
              {/* front clamp */}
              <rect x="332" y="76" width="20" height="60" rx="6" fill="url(#mg-steel)" stroke="#07090d" strokeWidth="2.5" />
              <path d="M337 82 L337 130" stroke="#fff" strokeOpacity=".5" strokeWidth="1.5" />
              <path d="M347 82 L347 130" stroke="#07090d" strokeOpacity=".6" strokeWidth="1.5" />
              {/* muzzle ends */}
              {[84, 94, 104, 114, 122].map((y, i) => (
                <circle key={i} cx="364" cy={y + 1} r={i === 2 ? 4 : 3.2} fill="#07090d" stroke="#4d5668" strokeWidth="1.2" />
              ))}
              {/* spin indicator ring */}
              <ellipse className="spin-ring" cx="340" cy="106" rx="5" ry="30" fill="none" stroke="#ffd34d" strokeWidth="1.5" strokeDasharray="8 8" opacity=".6" />
            </g>
            {/* ammo counter plate */}
            <rect x="176" y="94" width="36" height="14" rx="2" fill="#05070a" stroke="#4a5262" strokeWidth="1.2" />
            <text className="ammo" x="194" y="105" textAnchor="middle" fontSize="10" fontWeight="700" fill="#ffd34d" fontFamily="ui-monospace, Menlo, monospace" filter="url(#mg-glow)">
              {String(999 - (shot % 1000)).padStart(3, "0")}
            </text>
            <Shine clip="mg-clip" grad="mg-shine" />
          </g>
          <circle className="smoke" cx="366" cy="92" r="9" fill="#9fb4d8" style={{ animationDelay: ".05s" }} />
          <circle className="smoke" cx="372" cy="110" r="7" fill="#9fb4d8" style={{ animationDelay: ".18s" }} />
          <MuzzleFlash x={368} y={105} c1="#fff6c2" c2="#ffd34d" c3="#ff6a00" filter="mg-soft" scale={1.15} sparks={14} />
        </g>
      </g>
    </Frame>
  );
}
